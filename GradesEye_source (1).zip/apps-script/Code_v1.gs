/**
 * WDD Register — Google Drive connector (Google Apps Script web app)
 *
 * The WDD Register Android app sends the Excel register here; this script saves it in your Drive
 * (creating it the first time, then updating the same file) and sends it back when the app asks.
 *
 * Set-up (once, on a computer):
 *  1. Go to https://script.google.com with the Google account whose Drive should hold the file,
 *     click "New project" and replace all the code with this file.
 *  2. Change SECRET below to your own password (letters and numbers), and save.
 *  3. Deploy > New deployment > type "Web app". Execute as: Me. Who has access: Anyone.
 *     Click Deploy and allow access (Advanced > Go to project, if Google warns about an unverified app).
 *  4. Copy the Web app URL (ends with /exec) into the app (Drive sync screen) with the same secret
 *     and the link of the Drive folder where the Excel file should live.
 * After changing this code later, use Deploy > Manage deployments > Edit > Version: New version.
 */
const SECRET = 'change-this-secret';
const MIME = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
const DEFAULT_NAME = 'CS309_WDD_Attendance_and_Marks_Fall2026.xlsx';

function doGet() {
  return json_({ ok: true, app: 'WDD Register Drive connector', note: 'The app talks to this address with POST requests.' });
}

function doPost(e) {
  try {
    const req = JSON.parse(e.postData.contents);
    if (!SECRET || SECRET === 'change-this-secret') return json_({ ok: false, error: 'Open the script, set your own SECRET, save, and deploy a new version.' });
    if (req.key !== SECRET) return json_({ ok: false, error: 'Wrong secret key.' });
    const lock = LockService.getScriptLock();
    lock.waitLock(30000);
    try {
      switch (req.action) {
        case 'ping': return json_({ ok: true, user: Session.getEffectiveUser().getEmail(), folder: folderInfo_(req) });
        case 'info': return json_(info_(req));
        case 'load': return json_(load_(req));
        case 'save': return json_(save_(req));
        default: return json_({ ok: false, error: 'Unknown action: ' + req.action });
      }
    } finally {
      lock.releaseLock();
    }
  } catch (err) {
    return json_({ ok: false, error: String((err && err.message) || err) });
  }
}

function json_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

function folder_(req) {
  return req.folderId ? DriveApp.getFolderById(req.folderId) : DriveApp.getRootFolder();
}

function folderInfo_(req) {
  const f = folder_(req);
  return { id: f.getId(), name: f.getName() };
}

function auth_() {
  return { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() };
}

const FIELDS = 'id,name,modifiedTime,trashed,webViewLink,size,md5Checksum';

// null only when the file really is gone (404 / trashed); any other Drive error stops the request,
// so a temporary problem can never make the app think the file is missing.
function meta_(id) {
  const r = UrlFetchApp.fetch('https://www.googleapis.com/drive/v3/files/' + encodeURIComponent(id) +
    '?supportsAllDrives=true&fields=' + FIELDS, { headers: auth_(), muteHttpExceptions: true });
  const code = r.getResponseCode();
  if (code === 404) return null;
  if (code !== 200) throw new Error('Drive is not answering right now (' + code + '). Try again in a minute.');
  const m = JSON.parse(r.getContentText());
  return m.trashed ? null : m;
}

function md5_(bytes) {
  return Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, bytes)
    .map(function (b) { return ('0' + ((b + 256) % 256).toString(16)).slice(-2); }).join('');
}

function find_(req) {
  if (req.fileId) {
    const m = meta_(req.fileId);
    if (m) return m;
  }
  const files = folder_(req).getFilesByName(req.name || DEFAULT_NAME);
  while (files.hasNext()) {
    const f = files.next();
    if (!f.isTrashed()) return meta_(f.getId());
  }
  return null;
}

function out_(m) {
  return { ok: true, exists: true, fileId: m.id, name: m.name, modified: Date.parse(m.modifiedTime), url: m.webViewLink, size: Number(m.size || 0), md5: m.md5Checksum || '' };
}

function info_(req) {
  const m = find_(req);
  return m ? out_(m) : { ok: true, exists: false };
}

function load_(req) {
  const m = find_(req);
  if (!m) return { ok: false, error: 'The Excel file was not found in the Drive folder.' };
  const o = out_(m);
  const bytes = DriveApp.getFileById(m.id).getBlob().getBytes();
  o.data = Utilities.base64Encode(bytes);
  if (!o.md5) o.md5 = md5_(bytes);
  return o;
}

// The app sends baseMd5 = checksum of the Drive file it last saw ('' = it expects no file yet).
// If the file in Drive is different (edited elsewhere, or created meanwhile) the save is refused as a conflict.
function save_(req) {
  const bytes = Utilities.base64Decode(req.data);
  const sum = md5_(bytes);
  let m = find_(req);
  if (m && !req.force && (m.md5Checksum || '') !== (req.baseMd5 || '')) {
    return { ok: false, conflict: true, modified: Date.parse(m.modifiedTime), fileId: m.id, md5: m.md5Checksum || '' };
  }
  if (!m) {
    const f = folder_(req).createFile(Utilities.newBlob(bytes, MIME, req.name || DEFAULT_NAME));
    let created = null;
    try { created = meta_(f.getId()); } catch (e) { created = null; }
    m = created || { id: f.getId(), name: f.getName(), modifiedTime: new Date(f.getLastUpdated()).toISOString(), webViewLink: f.getUrl(), size: bytes.length };
  } else {
    const r = UrlFetchApp.fetch('https://www.googleapis.com/upload/drive/v3/files/' + encodeURIComponent(m.id) +
      '?uploadType=media&supportsAllDrives=true&fields=' + FIELDS,
      { method: 'patch', contentType: MIME, payload: bytes, headers: auth_(), muteHttpExceptions: true });
    if (r.getResponseCode() !== 200) throw new Error('Drive update failed (' + r.getResponseCode() + '): ' + r.getContentText().slice(0, 300));
    m = JSON.parse(r.getContentText());
  }
  const o = out_(m);
  o.md5 = sum;
  return o;
}
