/**
 * GradesEye — Google Drive connector (Google Apps Script web app), version 4
 * © 2026 softonicBank Co. All rights reserved.
 *
 * The GradesEye faculty app sends each course's Excel register here; this script saves it in your Drive
 * (inside sub-folders "Department / Programme Batch – Semester (Session)", created automatically),
 * updates the same file afterwards, and sends it back when the app asks.
 *
 * Student app (GradesEye Student): the faculty app publishes, for each course you choose, a summary of every
 * student's own attendance and marks into the private folder "GradesEye student data (private)" in the root of your
 * My Drive, plus the students' PINs as salted hashes. A student who signs in with Reg. No + PIN receives only their own
 * record, and may then replace the PIN with a password of their own (stored only as a salted, repeated hash; giving the
 * student a new PIN in the faculty app clears it). Sign-ins are recorded so the faculty app can list who has signed in.
 * Students never see your secret key, cannot change any marks, and cannot read the Excel files.
 *
 * Set-up (once, on a computer):
 *  1. Go to https://script.google.com with the Google account whose Drive should hold the files,
 *     click "New project" (or open your existing project) and replace all the code with this file.
 *  2. Change SECRET below to your own key of at least 16 letters and numbers (the app makes one for you:
 *     Drive and app settings → Make a strong key), and save.
 *  3. Deploy > New deployment > type "Web app". Execute as: Me. Who has access: Anyone.
 *     Click Deploy and allow access (Advanced > Go to project, if Google warns about an unverified app).
 *  4. Copy the Web app URL (ends with /exec) into the app (Drive and app settings) with the same secret
 *     and the link of the Drive folder where the Excel files should live.
 * After changing this code later, use Deploy > Manage deployments > Edit (pencil) > Version: New version > Deploy.
 * This keeps the same Web app URL, so student apps you have already shared keep working.
 */
const SECRET = 'change-this-secret';
const MIME = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
const DEFAULT_NAME = 'Register.xlsx';
const VERSION = 4;
const PORTAL_FOLDER = 'GradesEye student data (private)';   // kept in the root of My Drive, never inside a shared folder
const MIN_SECRET = 16;
const COMMON_PW = ['password', 'passw', 'pass', 'qwerty', 'qwertyuiop', 'asdf', 'zxcvbn', 'abc', 'abcd', 'abcde', 'abcdef', 'iloveyou', 'love', 'pakistan', 'welcome', 'admin', 'letmein', 'hitec', 'student', 'test', 'user', 'computer', 'secret', 'login'];

function doGet() {
  return json_({ ok: true, app: 'GradesEye Drive connector', copyright: '© 2026 softonicBank Co.', version: VERSION, note: 'The apps talk to this address with POST requests.' });
}

function doPost(e) {
  try {
    const req = JSON.parse(e.postData.contents);
    // student app: read-only, answers only with the signed-in student's own record
    if (req.action === 'hello' || req.action === 'student') return json_(student_(req));
    if (req.action === 'password') return json_(password_(req));
    if (!SECRET || SECRET === 'change-this-secret') return json_({ ok: false, error: 'Open the script, set your own SECRET, save, and deploy a new version.' });
    if (String(SECRET).length < MIN_SECRET) return json_({ ok: false, error: 'The SECRET in the script is too short. Students\' apps know this web address, so use at least ' + MIN_SECRET + ' letters and numbers (Drive and app settings → Make a strong key), put the same key in the script and in the app, and deploy a new version.' });
    if (req.key !== SECRET) { Utilities.sleep(1500); return json_({ ok: false, error: 'Wrong secret key.' }); }
    const lock = LockService.getScriptLock();
    lock.waitLock(30000);
    try {
      switch (req.action) {
        case 'ping': return json_({ ok: true, version: VERSION, user: Session.getEffectiveUser().getEmail(), folder: folderInfo_({ folderId: req.folderId }), portal: portalInfo_() });
        case 'info': return json_(info_(req));
        case 'load': return json_(load_(req));
        case 'save': return json_(save_(req));
        case 'publish': return json_(publish_(req));
        case 'unpublish': return json_(unpublish_(req.courseId));
        case 'pins': return json_(pins_(req));
        case 'logins': return json_(logins_());
        default: return json_({ ok: false, error: 'Unknown action: ' + req.action });
      }
    } finally {
      lock.releaseLock();
    }
  } catch (err) {
    return json_({ ok: false, error: String((err && err.message) || err) });
  }
}

function json_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

// base folder (the link given in the app, or My Drive), then the sub-folders in req.path (created when missing)
function folder_(req, create) {
  let f = req.folderId ? DriveApp.getFolderById(req.folderId) : DriveApp.getRootFolder();
  const path = Array.isArray(req.path) ? req.path : [];
  for (let i = 0; i < path.length; i++) {
    const name = String(path[i] || '').trim();
    if (!name) continue;
    const it = f.getFoldersByName(name);
    let next = null;
    while (it.hasNext()) { const x = it.next(); if (!x.isTrashed()) { next = x; break; } }
    if (!next) {
      if (!create) return null;
      next = f.createFolder(name);
    }
    f = next;
  }
  return f;
}

function folderInfo_(req) {
  const f = folder_(req);
  return { id: f.getId(), name: f.getName() };
}

function auth_() {
  return { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() };
}

const FIELDS = 'id,name,modifiedTime,trashed,webViewLink,size,md5Checksum';

// null only when the file really is gone (404 / trashed); any other Drive error stops the request,
// so a temporary problem can never make the app think the file is missing.
function meta_(id) {
  const r = UrlFetchApp.fetch('https://www.googleapis.com/drive/v3/files/' + encodeURIComponent(id) +
    '?supportsAllDrives=true&fields=' + FIELDS, { headers: auth_(), muteHttpExceptions: true });
  const code = r.getResponseCode();
  if (code === 404) return null;
  if (code !== 200) throw new Error('Drive is not answering right now (' + code + '). Try again in a minute.');
  const m = JSON.parse(r.getContentText());
  return m.trashed ? null : m;
}

function md5_(bytes) {
  return Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, bytes)
    .map(function (b) { return ('0' + ((b + 256) % 256).toString(16)).slice(-2); }).join('');
}

function find_(req) {
  if (req.fileId) {
    const m = meta_(req.fileId);
    if (m && /\.xlsx$/i.test(m.name || '')) return m;      // the app only ever works on its Excel registers
  }
  const folder = folder_(req, false);
  if (!folder) return null;
  const files = folder.getFilesByName(req.name || DEFAULT_NAME);
  while (files.hasNext()) {
    const f = files.next();
    if (!f.isTrashed()) return meta_(f.getId());
  }
  return null;
}

function out_(m) {
  return { ok: true, exists: true, fileId: m.id, name: m.name, modified: Date.parse(m.modifiedTime), url: m.webViewLink, size: Number(m.size || 0), md5: m.md5Checksum || '' };
}

function info_(req) {
  const m = find_(req);
  return m ? out_(m) : { ok: true, exists: false };
}

function load_(req) {
  const m = find_(req);
  if (!m) return { ok: false, error: 'The Excel file was not found in the Drive folder.' };
  const o = out_(m);
  const bytes = DriveApp.getFileById(m.id).getBlob().getBytes();
  o.data = Utilities.base64Encode(bytes);
  if (!o.md5) o.md5 = md5_(bytes);
  return o;
}

// The app sends baseMd5 = checksum of the Drive file it last saw ('' = it expects no file yet).
// If the file in Drive is different (edited elsewhere, or created meanwhile) the save is refused as a conflict.
function save_(req) {
  const bytes = Utilities.base64Decode(req.data);
  const sum = md5_(bytes);
  let m = find_(req);
  if (m && !req.force && (m.md5Checksum || '') !== (req.baseMd5 || '')) {
    return { ok: false, conflict: true, modified: Date.parse(m.modifiedTime), fileId: m.id, md5: m.md5Checksum || '' };
  }
  if (!m) {
    const f = folder_(req, true).createFile(Utilities.newBlob(bytes, MIME, req.name || DEFAULT_NAME));
    let created = null;
    try { created = meta_(f.getId()); } catch (e) { created = null; }
    m = created || { id: f.getId(), name: f.getName(), modifiedTime: new Date(f.getLastUpdated()).toISOString(), webViewLink: f.getUrl(), size: bytes.length };
  } else {
    const r = UrlFetchApp.fetch('https://www.googleapis.com/upload/drive/v3/files/' + encodeURIComponent(m.id) +
      '?uploadType=media&supportsAllDrives=true&fields=' + FIELDS,
      { method: 'patch', contentType: MIME, payload: bytes, headers: auth_(), muteHttpExceptions: true });
    if (r.getResponseCode() !== 200) throw new Error('Drive update failed (' + r.getResponseCode() + '): ' + r.getContentText().slice(0, 300));
    m = JSON.parse(r.getContentText());
  }
  const o = out_(m);
  o.md5 = sum;
  return o;
}

// ------------------------------------------------------------------ student app
// Script properties hold where the published data is: { folderId, pinsId, pinsRev, title, open, courses: { id: { id, rev } } }
// read through the script cache, so sign-ins do not use up the daily Properties quota
function props_() {
  const cache = CacheService.getScriptCache();
  let t = cache.get('portalprops');
  if (t === null) {
    t = PropertiesService.getScriptProperties().getProperty('portal') || '{}';
    try { cache.put('portalprops', t, 21600); } catch (e) { /* only a speed-up */ }
  }
  try { return JSON.parse(t); } catch (e) { return {}; }
}
function saveProps_(P) {
  const t = JSON.stringify(P);
  PropertiesService.getScriptProperties().setProperty('portal', t);
  try { CacheService.getScriptCache().put('portalprops', t, 21600); } catch (e) { /* only a speed-up */ }
}
function portalInfo_() {
  const P = props_();
  return { open: !!(P.open && P.pinsId), courses: Object.keys(P.courses || {}).length };
}
function norm_(s) {
  return String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
}
function hex_(bytes) {
  return bytes.map(function (b) { return ('0' + ((b + 256) % 256).toString(16)).slice(-2); }).join('');
}
function sha256_(s) {
  return hex_(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, s, Utilities.Charset.UTF_8));
}
// sign-in token: Reg. No + HMAC of (Reg. No, current credential) — stops working when the PIN or password changes
function tokenKey_(P) {
  if (!P.tokenKey) { P.tokenKey = Utilities.getUuid() + Utilities.getUuid(); saveProps_(P); }
  return P.tokenKey;
}
function token_(P, reg, credential) {
  return reg + '.' + hex_(Utilities.computeHmacSha256Signature(reg + '|' + credential, tokenKey_(P)));
}
// students' own passwords: { REG: { s: salt, h: hash, b: PIN hash it replaced, t: time } }; a new PIN from the teacher voids it
function pwData_(P) {
  try { return P.pwId ? JSON.parse(cachedText_(P.pwId, P.pwRev || 0)) : {}; } catch (e) { return {}; }
}
function pwHash_(salt, reg, pw) {
  let h = sha256_(salt + '|' + reg + '|' + pw);
  for (let i = 0; i < 199; i++) h = sha256_(h + '|' + salt);
  return h;
}
function own_(pinHash, entry) {
  return entry && pinHash && entry.b === pinHash ? entry : null;
}
function pwProblem_(pw, reg) {
  if (pw.length < 8) return 'Use at least 8 characters.';
  if (pw.length > 64) return 'Use at most 64 characters.';
  if (!/[A-Za-z]/.test(pw) || !/[0-9]/.test(pw)) return 'Use both letters and numbers.';
  if (reg && norm_(pw).indexOf(reg) >= 0) return 'Do not use your Reg. No in your password.';
  const letters = pw.toLowerCase().replace(/[^a-z]/g, '');
  if (letters.length < 3 || COMMON_PW.indexOf(letters) >= 0) return 'That password is too easy to guess. Mix a few words with numbers.';
  return '';
}
// remember sign-ins (first, last, how many) and when the app was last opened, for the faculty app's list
function login_(reg, signIn) {
  const cache = CacheService.getScriptCache();
  if (!signIn && cache.get('seen_' + reg)) return;
  try {
    const props = PropertiesService.getScriptProperties(), k = 'L_' + reg, now = Date.now();
    let o = {};
    try { o = JSON.parse(props.getProperty(k) || '{}'); } catch (e) { o = {}; }
    if (signIn) { o.f = o.f || now; o.l = now; o.n = (o.n || 0) + 1; }
    o.s = now;
    props.setProperty(k, JSON.stringify(o));
    cache.put('seen_' + reg, '1', 3600);
  } catch (e) { /* the list is only informative */ }
}
function logins_() {
  const all = PropertiesService.getScriptProperties().getProperties(), P = props_(), out = {};
  let pins = {}, pw = {};
  try { pins = P.pinsId ? (JSON.parse(cachedText_(P.pinsId, P.pinsRev || 0)).pins || {}) : {}; pw = pwData_(P); } catch (e) { /* no PINs yet */ }
  Object.keys(all).forEach(function (k) {
    if (k.indexOf('L_') !== 0) return;
    const reg = k.slice(2);
    let o = {};
    try { o = JSON.parse(all[k]); } catch (e) { o = {}; }
    o.pw = !!own_(pins[reg], pw[reg]);
    out[reg] = o;
  });
  return { ok: true, logins: out, time: Date.now(), version: VERSION };
}

function portalFolder_(P) {
  if (P.folderId) {
    try { const f = DriveApp.getFolderById(P.folderId); if (!f.isTrashed()) return f; } catch (e) { /* recreate below */ }
  }
  const base = DriveApp.getRootFolder();
  const it = base.getFoldersByName(PORTAL_FOLDER);
  let f = null;
  while (it.hasNext()) { const x = it.next(); if (!x.isTrashed()) { f = x; break; } }
  if (!f) f = base.createFolder(PORTAL_FOLDER);
  P.folderId = f.getId();
  return f;
}

function writeText_(folder, name, fileId, text) {
  if (fileId) {
    try {
      const f = DriveApp.getFileById(fileId);
      if (!f.isTrashed()) { f.setContent(text); return fileId; }
    } catch (e) { /* write a new file */ }
  }
  return folder.createFile(Utilities.newBlob(text, 'application/json', name)).getId();
}

// file text through the script cache (in pieces: one cache value holds at most 100 KB)
function putText_(id, rev, text) {
  try {
    const parts = {}, base = 't' + rev + '_' + id;
    let i = 0, p = 0;
    while (p < text.length) {
      let q = Math.min(text.length, p + 30000);
      const c = text.charCodeAt(q - 1);
      if (q < text.length && c >= 0xD800 && c <= 0xDBFF) q--;          // never split a character in two
      parts[base + '_' + (i++)] = text.slice(p, q);
      p = q;
    }
    if (i <= 80) { parts[base] = String(i); CacheService.getScriptCache().putAll(parts, 21600); }
  } catch (e) { /* caching is only a speed-up */ }
}
function dropText_(id, rev) {
  try {
    const cache = CacheService.getScriptCache(), base = 't' + rev + '_' + id, n = Number(cache.get(base) || 0), keys = [base];
    for (let i = 0; i < n; i++) keys.push(base + '_' + i);
    cache.removeAll(keys);
  } catch (e) { /* nothing cached */ }
}
function cachedText_(id, rev) {
  const cache = CacheService.getScriptCache(), base = 't' + rev + '_' + id;
  const n = Number(cache.get(base) || 0);
  if (n > 0) {
    const keys = [];
    for (let i = 0; i < n; i++) keys.push(base + '_' + i);
    const got = cache.getAll(keys);
    if (keys.every(function (k) { return typeof got[k] === 'string'; })) return keys.map(function (k) { return got[k]; }).join('');
  }
  const text = DriveApp.getFileById(id).getBlob().getDataAsString('UTF-8');
  putText_(id, rev, text);
  return text;
}

function publish_(req) {
  const id = String(req.courseId || '');
  if (!/^[\w-]{1,60}$/.test(id)) throw new Error('Bad course id.');
  const text = String(req.data || '');
  const d = JSON.parse(text);
  if (!d || typeof d.students !== 'object') throw new Error('Bad course data.');
  const P = props_(), folder = portalFolder_(P);
  P.courses = P.courses || {};
  const cur = P.courses[id] || {};
  const fileId = writeText_(folder, 'course_' + id + '.json', cur.id, text);
  P.courses[id] = { id: fileId, rev: (cur.rev || 0) + 1 };
  saveProps_(P);
  if (cur.id) dropText_(cur.id, cur.rev || 0);
  putText_(fileId, P.courses[id].rev, text);
  return { ok: true, rev: P.courses[id].rev, version: VERSION };
}

function unpublish_(courseId) {
  const id = String(courseId || ''), P = props_();
  const cur = (P.courses || {})[id];
  if (cur) {
    try { DriveApp.getFileById(cur.id).setTrashed(true); } catch (e) { /* already gone */ }
    dropText_(cur.id, cur.rev || 0);
    delete P.courses[id];
    saveProps_(P);
  }
  return { ok: true };
}

// PIN hashes, title and on/off; req.keep = the courses that should stay published (any other one is removed)
function pins_(req) {
  const given = req.pins && typeof req.pins === 'object' ? req.pins : {}, pins = {};
  let skipped = 0;
  Object.keys(given).forEach(function (k) { if (/^[A-Z0-9]{1,40}$/.test(k) && /^[0-9a-f]{64}$/.test(String(given[k]))) pins[k] = String(given[k]); else skipped++; });
  if (Array.isArray(req.keep)) {
    const keep = {};
    req.keep.forEach(function (id) { keep[String(id)] = true; });
    Object.keys(props_().courses || {}).forEach(function (id) { if (!keep[id]) unpublish_(id); });
  }
  const P = props_(), folder = portalFolder_(P), text = JSON.stringify({ salt: String(req.salt || ''), pins: pins }), old = P.pinsId, oldRev = P.pinsRev || 0;
  P.pinsId = writeText_(folder, 'pins.json', P.pinsId, text);
  P.pinsRev = oldRev + 1;
  P.title = String(req.title || '').slice(0, 150);
  P.open = !!req.open;
  if (!P.tokenKey) P.tokenKey = Utilities.getUuid() + Utilities.getUuid();
  saveProps_(P);
  if (old) dropText_(old, oldRev);
  putText_(P.pinsId, P.pinsRev, text);
  return { ok: true, rev: P.pinsRev, students: Object.keys(pins).length, skipped: skipped, courses: Object.keys(P.courses || {}).length, version: VERSION };
}

function student_(req) {
  const P = props_();
  if (req.action === 'hello') return { ok: true, version: VERSION, title: P.title || '', open: !!(P.open && P.pinsId) };
  if (!P.open || !P.pinsId) return { ok: false, off: true, error: 'The student app is switched off at the moment. Ask your teacher.' };
  const pinData = JSON.parse(cachedText_(P.pinsId, P.pinsRev || 0)), all = pinData.pins || {}, pw = pwData_(P);
  let reg, signIn = false;
  if (req.token) {                                     // already signed in on this phone
    const t = String(req.token), dot = t.indexOf('.');
    reg = dot > 0 ? t.slice(0, dot) : '';
    const own = reg && all[reg] ? own_(all[reg], pw[reg]) : null;
    if (!reg || !all[reg] || t !== token_(P, reg, own ? own.h : all[reg])) return { ok: false, expired: true, error: 'Please sign in again with your PIN or password.' };
  } else {
    reg = norm_(req.reg);
    const given = String(req.pin || '').trim();
    if (!reg || reg.length > 40 || !given || given.length > 64) return { ok: false, error: 'Enter your Reg. No and your PIN or password.' };
    const cache = CacheService.getScriptCache(), fk = 'fail_' + reg, fails = Number(cache.get(fk) || 0);
    if (fails >= 6) return { ok: false, locked: true, error: 'Too many wrong tries for this Reg. No. Wait 15 minutes and try again.' };
    const own = all[reg] ? own_(all[reg], pw[reg]) : null;
    const good = !!all[reg] && (own ? pwHash_(own.s, reg, given) === own.h : sha256_(pinData.salt + '|' + reg + '|' + norm_(given)) === all[reg]);
    if (!good) {
      cache.put(fk, String(fails + 1), 900);
      return { ok: false, error: own ? 'Reg. No or password is not correct.' : 'Reg. No or PIN is not correct.' };
    }
    if (fails) cache.remove(fk);
    signIn = true;
  }
  const list = P.courses || {}, courses = [];
  Object.keys(list).forEach(function (cid) {
    try {
      const d = JSON.parse(cachedText_(list[cid].id, list[cid].rev));
      const me = d.students ? d.students[reg] : null;
      if (!me) return;
      const c = {};
      Object.keys(d).forEach(function (k) { if (k !== 'students') c[k] = d[k]; });
      c.me = me;
      courses.push(c);
    } catch (e) { /* skip a course that cannot be read right now */ }
  });
  login_(reg, signIn);
  const own = own_(all[reg], pw[reg]), first = courses.length ? courses[0].me : null;
  return { ok: true, reg: first ? first.reg : String(req.reg || reg), name: first ? first.name : '', title: P.title || '', courses: courses, time: Date.now(),
    own: !!own, token: token_(P, reg, own ? own.h : all[reg]) };
}

// a signed-in student replaces the PIN (or their earlier password) with a new password
function password_(req) {
  const P = props_();
  if (!P.open || !P.pinsId) return { ok: false, off: true, error: 'The student app is switched off at the moment. Ask your teacher.' };
  const pinData = JSON.parse(cachedText_(P.pinsId, P.pinsRev || 0)), all = pinData.pins || {};
  const t = String(req.token || ''), dot = t.indexOf('.'), reg = dot > 0 ? t.slice(0, dot) : '';
  const cur0 = reg && all[reg] ? own_(all[reg], pwData_(P)[reg]) : null;
  if (!reg || !all[reg] || t !== token_(P, reg, cur0 ? cur0.h : all[reg])) return { ok: false, expired: true, error: 'Please sign in again with your PIN or password.' };
  const cache = CacheService.getScriptCache(), fk = 'fail_' + reg, fails = Number(cache.get(fk) || 0);
  if (fails >= 6) return { ok: false, locked: true, error: 'Too many wrong tries. Wait 15 minutes and try again.' };
  const current = String(req.current || '').trim();
  const good = cur0 ? pwHash_(cur0.s, reg, current) === cur0.h : sha256_(pinData.salt + '|' + reg + '|' + norm_(current)) === all[reg];
  if (!good) {
    cache.put(fk, String(fails + 1), 900);
    return { ok: false, error: cur0 ? 'Your current password is not correct.' : 'Your current PIN is not correct.' };
  }
  const next = String(req.next || '').trim(), problem = pwProblem_(next, reg);
  if (problem) return { ok: false, error: problem };
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(20000)) return { ok: false, error: 'The class server is busy. Try again in a minute.' };
  try {
    const P2 = props_();
    let pw = {};
    try { pw = P2.pwId ? JSON.parse(DriveApp.getFileById(P2.pwId).getBlob().getDataAsString('UTF-8')) : {}; } catch (e) { pw = {}; }
    Object.keys(pw).forEach(function (k) { if (!own_(all[k], pw[k])) delete pw[k]; });   // drop passwords voided by a new PIN
    const salt = Utilities.getUuid();
    pw[reg] = { s: salt, h: pwHash_(salt, reg, next), b: all[reg], t: Date.now() };
    const text = JSON.stringify(pw), old = P2.pwId, oldRev = P2.pwRev || 0;
    P2.pwId = writeText_(portalFolder_(P2), 'passwords.json', P2.pwId, text);
    P2.pwRev = oldRev + 1;
    saveProps_(P2);
    if (old) dropText_(old, oldRev);
    putText_(P2.pwId, P2.pwRev, text);
    if (fails) cache.remove(fk);
    return { ok: true, token: token_(P2, reg, pw[reg].h) };
  } finally {
    lock.releaseLock();
  }
}
