import json, sys, subprocess, os
from openpyxl import load_workbook
W = sys.argv[1]
SK = '/root/.claude/skills/synced/24466788-a825-4746-89de-6ba1653bc3d9_8e63e634-ebae-4b68-8f3e-c07a602701cb/xlsx/scripts'
checks = json.load(open(f'{W}/checks.json'))
total_bad = 0
for chk in checks:
    f = chk['file']; rc = f.replace('.xlsx', '_recalc.xlsx')
    subprocess.run(['cp', f, rc])
    out = subprocess.run(['python3', f'{SK}/recalc.py', rc, '600'], capture_output=True, text=True).stdout
    res = json.loads(out[out.index('{'):])
    wb = load_workbook(rc, data_only=True)
    bad = n = 0
    for sheet, ref, exp in chk['exp']:
        got = wb[sheet][ref].value
        n += 1
        if (exp in ('', None)) and (got in ('', None)): continue
        if isinstance(exp, (int, float)) and isinstance(got, (int, float)) and not isinstance(got, bool) and abs(exp - got) < 1e-4: continue
        if str(exp) == str(got): continue
        bad += 1
        if bad <= 12: print('  DIFF', os.path.basename(f), sheet, ref, 'app=', exp, 'excel=', got)
    total_bad += bad
    print(os.path.basename(f), 'formulas', res.get('total_formulas'), 'errors', res.get('total_errors'), res.get('error_summary') or '', '| compared', n, 'diff', bad)
print('TOTAL DIFFERENCES', total_bad)
