"""Phone-sized run of the v2 app with a mock Android bridge and mock Drive script:
semesters → sections → class lists → three courses (theory+lab, theory, lab) → marks → Drive files in sub-folders →
offline queue → PC edit pulled (shared class list) → conflict → migration of v1 data."""
import json, os, subprocess, sys, time, shutil, glob, hashlib
from playwright.sync_api import sync_playwright

APP = 'file:///home/claude/apk/app/dist2/index.html'
OUT = sys.argv[1]; os.makedirs(OUT, exist_ok=True)
PORT = 8775
DRIVE = os.path.join(OUT, 'drive'); shutil.rmtree(DRIVE, ignore_errors=True)
srv = subprocess.Popen([sys.executable, os.path.join(os.path.dirname(__file__), 'mock_script.py'), str(PORT), DRIVE])
time.sleep(0.8)
MOCK = open('/home/claude/apk/app/web/test/ui_test.py').read().split('MOCK = """')[1].split('"""')[0] + "\nwindow.__loads = (Number(sessionStorage.getItem('loads')) || 0) + 1; sessionStorage.setItem('loads', window.__loads); window.__lskeys0 = Object.keys(localStorage).join(',');\n" 
errors = []
def shot(page, name, full=False):
    print('step', name, flush=True); page.screenshot(path=os.path.join(OUT, name + '.png'), full_page=full)
def wait_status(page, words, timeout=30):
    t0 = time.time()
    while time.time() - t0 < timeout:
        txt = page.locator('#syncbtn').inner_text()
        if any(w in txt for w in words): return txt
        time.sleep(0.25)
    raise AssertionError(f'status not {words}: {page.locator("#syncbtn").inner_text()}')
def fill(page, sel, val):
    page.fill(sel, val); page.locator(sel).press('Tab')
def calls():
    return json.loads(subprocess.check_output(['curl', '-s', f'http://127.0.0.1:{PORT}/control']))['calls']

with sync_playwright() as p:
    b = p.chromium.launch()
    ctx = b.new_context(viewport={'width': 393, 'height': 800}, device_scale_factor=2, is_mobile=True, has_touch=True)
    page = ctx.new_page(); page.set_default_timeout(15000)
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.on('framenavigated', lambda f: print('EVENT navigated', f.url[-40:], flush=True))
    page.on('load', lambda pg_: print('EVENT load', flush=True))
    page.on('crash', lambda pg_: print('EVENT CRASH', flush=True))
    page.on('worker', lambda w: print('EVENT worker', w.url[:30], flush=True))
    page.add_init_script(MOCK)
    try:
        page.goto(APP); page.wait_for_selector('#main .card')
        shot(page, '01_home_empty')
        # ---- semester
        page.click('[data-act=new-sem]')
        fill(page, 'input[placeholder="Department of Computing"]', 'Department of Computing')
        fill(page, 'input[placeholder="BSCS"]', 'BSCS')
        fill(page, 'input[placeholder="2024"]', '2024')
        fill(page, 'input[placeholder="5th"]', '5th')
        fill(page, 'input[placeholder="Fall 2026"]', 'Fall 2026')
        page.click('[data-act=create-sem]')
        for code in ['A', 'B', 'C']:
            page.fill('#newsec-code', code); page.click('[data-act=add-sec]')
        shot(page, '02_semester_sections')
        names = ['Ali Khan', 'Sara Ahmed', 'Hamza Malik', 'Ayesha Raza', 'Usman Iqbal', 'Zainab Shah', 'Bilal Butt', 'Hira Qureshi']
        reg = 0
        for k, (code, n) in enumerate([('A', 12), ('B', 9), ('C', 6)]):
            page.locator('.secedit').nth(k).locator('[data-classlist]').click()
            page.click('[data-act=paste]')
            lines = []
            for i in range(n):
                reg += 1; lines.append(f'24-CS-{reg:03d}\t{names[i % 8]} {code}{i + 1}')
            page.fill('#m-paste', '\n'.join(lines)); page.click('#modal [data-x="1"]')
            page.click('#backbtn')
        shot(page, '03_semester_lists')
        # ---- course 1: theory + lab (WDD plan) for A and B
        page.click('[data-act=new-course]')
        fill(page, 'input[placeholder="CS-309"]', 'CS-309')
        fill(page, 'input[placeholder="Web Design & Development"]', 'Web Design & Development')
        fill(page, 'input[placeholder="3(2+1)"]', '3(2+1)')
        page.locator('.secpick[data-code=C] input').uncheck()
        shot(page, '04_plan_new', full=True)
        page.click('[data-act=plan-save]')
        page.wait_for_selector('.tabs .tab')
        shot(page, '05_course_home')
        # theory attendance week 1 + quiz for section A
        page.click('[data-nav*="Theory Att"]')
        page.click('th[data-act=week][data-c="0"]'); page.click('#modal [data-x=allP]')
        page.click('td.e[data-r="1"][data-c="0"]'); page.click('.attb.A'); page.click('.nav.done')
        page.click('#backbtn')
        page.click('[data-nav*="|Quizzes"]')
        page.click('td.e[data-r="0"][data-c="0"]')
        for v in ['8', '6', '9.5']: page.fill('#edin', v); page.press('#edin', 'Enter')
        page.click('.nav.done'); page.click('#backbtn')
        page.click('[data-nav*="Lab Perf"]')
        page.click('td.e[data-r="0"][data-c="0"]')
        for v in [4, 5, 3, 5, 5, 4]: page.click(f'.quick button[data-v="{v}"]')
        page.click('.nav.done'); shot(page, '06_lab_perf'); page.click('#backbtn')
        page.click('[data-nav*="|Project"]')
        page.click('td.e[data-r="0"][data-c="0"]')
        for v in [5, 4, 4, 5]: page.click(f'.quick button[data-v="{v}"]')
        page.click('.nav.done'); page.click('#backbtn')
        for pg, nm in [('CLO', '07_clo'), ('PLO', '08_plo'), ('Final Sheet', '09_final')]:
            page.click(f'[data-nav$="|{pg}"]'); shot(page, nm, full=(pg != 'Final Sheet')); page.click('#backbtn')
        page.click('[data-nav^="results|"]'); shot(page, '10_results', full=True); page.click('#backbtn')
        page.click('#backbtn')
        # ---- course 2: theory only, section A, 3 quizzes, no final
        page.click('[data-act=new-course]')
        page.click('.seg button:has-text("Theory course")')
        fill(page, 'input[placeholder="CS-309"]', 'CS-103')
        fill(page, 'input[placeholder="Web Design & Development"]', 'Discrete Structures')
        page.locator('.secpick[data-code=B] input').uncheck(); page.locator('.secpick[data-code=C] input').uncheck()
        page.locator('.sub', has_text='Quizzes').locator('.stepper button').last.click()
        page.locator('.sub', has_text='Final exam').locator('input[type=checkbox]').uncheck()
        shot(page, '11_plan_theory', full=True)
        page.click('[data-act=plan-save]'); page.wait_for_selector('.tabs .tab')
        page.click('[data-nav*="|Quizzes"]')
        assert page.locator('th.lab:has-text("Quiz 3")').count() == 1
        page.click('td.e[data-r="0"][data-c="2"]'); page.fill('#edin', '7'); page.press('#edin', 'Enter'); page.click('.nav.done')
        page.click('#backbtn'); page.click('#backbtn')
        # ---- course 3: lab only, sections B and C
        page.click('[data-act=new-course]')
        page.click('.seg button:has-text("Lab course")')
        fill(page, 'input[placeholder="CS-309"]', 'CS-106L')
        fill(page, 'input[placeholder="Web Design & Development"]', 'ICT Lab')
        page.locator('.secpick[data-code=A] input').uncheck()
        page.click('[data-act=plan-save]'); page.wait_for_selector('.tabs .tab')
        page.click('[data-nav*="Lab Att"]'); page.click('th[data-act=week][data-c="0"]'); page.click('#modal [data-x=allP]'); page.click('#backbtn')
        page.click('#backbtn')
        shot(page, '12_home_courses', full=True)
        # ---- Drive
        page.click('#syncbtn')
        fill(page, '[data-cfg=url]', f'http://127.0.0.1:{PORT}/exec')
        fill(page, '[data-cfg=key]', 'test-secret')
        fill(page, '[data-cfg=folder]', 'https://drive.google.com/drive/folders/1AbCdEfGhIjKlMnOpQrStUv')
        page.click('[data-act=sync-test]')
        wait_status(page, ['Synced'], 60)
        files = sorted(glob.glob(os.path.join(DRIVE, '**', '*.xlsx'), recursive=True))
        print('files:', [os.path.relpath(f, DRIVE) for f in files])
        assert len(files) == 3, files
        assert all(os.sep.join(['Department of Computing', 'BSCS Batch 2024 5th semester (Fall 2026)']) in f for f in files)
        shot(page, '13_sync_page', full=True)
        page.click('#backbtn')
        # ---- offline edits queue, then upload
        f1 = [f for f in files if 'CS-309' in f][0]; m1 = hashlib.md5(open(f1, 'rb').read()).hexdigest()
        page.evaluate('window.__mock.online = false; window.__nativeOnline(false)')
        page.click('.crow:has-text("CS-309")'); page.click('[data-nav*="|Assignments"]')
        page.click('td.e[data-r="0"][data-c="0"]'); page.fill('#edin', '18'); page.press('#edin', 'Enter'); page.click('.nav.done')
        time.sleep(0.4)
        assert 'Offline' in page.locator('#syncbtn').inner_text(), page.locator('#syncbtn').inner_text()
        page.click('#backbtn'); page.click('#backbtn')
        page.reload(); page.wait_for_selector('#main .card'); page.evaluate('window.__mock.online = false')
        page.click('.crow:has-text("CS-309")'); page.click('[data-nav*="|Assignments"]')
        assert page.locator('td.e[data-r="0"][data-c="0"]').inner_text() == '18'
        page.click('#backbtn'); page.click('#backbtn')
        page.evaluate('window.__mock.online = true; window.__nativeOnline(true)')
        time.sleep(2); wait_status(page, ['Synced'], 60)
        assert hashlib.md5(open(f1, 'rb').read()).hexdigest() != m1, 'not re-uploaded'
        # ---- PC edit of CS-309: rename a section B student and a quiz mark → pulled; CS-106L (also section B) re-uploaded
        from openpyxl import load_workbook
        f3 = [f for f in files if 'CS-106L' in f][0]; m3 = hashlib.md5(open(f3, 'rb').read()).hexdigest()
        wb = load_workbook(f1)
        ws = wb['Students']
        ws['H8'] = 'Edited On PC'
        wb['A Quizzes']['D9'] = 2
        wb.save(f1)
        page.evaluate('window.__resume()'); time.sleep(3); wait_status(page, ['Synced'], 60); time.sleep(13); wait_status(page, ['Synced'], 60)
        page.click('.secchip[data-code=B]')
        assert page.locator('input[value="Edited On PC"]').count() == 1, 'class list not updated from PC edit'
        page.click('#backbtn')
        assert hashlib.md5(open(f3, 'rb').read()).hexdigest() != m3, 'course sharing section B not re-uploaded'
        from openpyxl import load_workbook as lw
        assert lw(f3)['Students']['C8'].value == 'Edited On PC', lw(f3)['Students']['C8'].value
        # ---- conflict on CS-103: PC edit + phone edit
        f2 = [f for f in files if 'CS-103' in f][0]
        wb = load_workbook(f2); wb['A Quizzes']['E8'] = 9; wb.save(f2)
        page.click('.crow:has-text("CS-103")'); page.click('[data-nav*="|Quizzes"]')
        page.click('td.e[data-r="0"][data-c="0"]'); page.fill('#edin', '4'); page.press('#edin', 'Enter'); page.click('.nav.done')
        page.click('#backbtn'); page.click('#backbtn')
        page.evaluate('window.__pause()')
        page.wait_for_selector('#modal:not([hidden]) >> text=choose a version', timeout=30000)
        shot(page, '14_conflict')
        page.click('#modal [data-x=phone]')
        time.sleep(1.5); wait_status(page, ['Synced'], 60)
        w2 = lw(f2)['A Quizzes']
        assert w2['D8'].value == 4 and w2['E8'].value in (None, ''), (w2['D8'].value, w2['E8'].value)
        print('server calls:', len(calls()), '| build mode:', page.evaluate('self.__wddBuildMode'))
        print('page errors:', errors or 'none')
    except Exception:
        shot(page, 'FAIL'); print('page errors:', errors)
        print('DEBUG loads:', page.evaluate('window.__loads'), 'LS at load:', page.evaluate('window.__lskeys0'), 'LS now:', page.evaluate('Object.keys(localStorage).map(k => k + ":" + localStorage.getItem(k).length)'), 'url:', page.url)
        srv.terminate(); raise
    # ---- migration of v1 data in a fresh profile
    ctx2 = b.new_context(viewport={'width': 393, 'height': 800}, device_scale_factor=2, is_mobile=True)
    pg = ctx2.new_page(); pg.set_default_timeout(15000)
    v1 = {'version': 1, 'settings': {'START': '2026-09-07', 'THR': 0.75, 'LEAVE': 'No', 'MIDD': None, 'FIND': None, 'WK_LMID': 8, 'WK_OEL': 15, 'WK_PROJ': 15, 'WK_LFIN': 16, 'W_Q': .15, 'W_A': .15, 'W_M': .3, 'W_F': .4, 'SH_T': 2/3, 'SH_L': 1/3, 'M_PERF': 6, 'M_REP': 4, 'M_LFIN': 5, 'M_LMID': 5, 'M_OEL': 5, 'M_PROJ': 8, 'P_DES': 3, 'P_VIVA': 3, 'CO4_PERF': .3, 'CO4_MID': .25, 'CO4_FIN': .25, 'CO4_VIVA': .2, 'CO5_PROJ': 1, 'PO5_CO4': 1, 'PO9_CO5': 1},
          'sections': {s: {'name': f'BSCS-5{s}', 'inst': 'Lec. Waqar Ismail', 'labInst': 'Lec. Waqar Ismail', 'lec': 0, 'lab': 1} for s in 'ABCD'},
          'max': {}, 'outc': {'CO4': {'code': 'CO4', 'kpi': .5, 'desc': 'x'}, 'CO5': {'code': 'CO5', 'kpi': .5, 'desc': 'y'}, 'PO5': {'code': 'PO5', 'kpi': .5, 'desc': ''}, 'PO9': {'code': 'PO9', 'kpi': .5, 'desc': ''}},
          'grades': [[0, 'F', 0], [50, 'D', 1], [85, 'A', 4]], 'schedule': {'dates': {}, 'notes': {}, 'activities': {}},
          'students': {'A': {'0': {'reg': '24-CS-001', 'name': 'Migrated Student'}}, 'B': {}, 'C': {}, 'D': {}},
          'labGroups': {s: {'custom': False, 'rows': {}, 'rem': {}} for s in 'ABCD'}, 'marks': {'A Quizzes': {'0,0': 8}, 'A Lab Perf': {'0,0': 4, '0,1': 5, '0,2': 3}}}
    v1sync = {'url': f'http://127.0.0.1:{PORT}/exec', 'key': 'test-secret', 'folder': '', 'name': 'old.xlsx', 'fileId': 'id-root', 'lastMd5': '', 'auto': False}
    pg.add_init_script(MOCK + f"\nif (!localStorage.getItem('A:state2')) {{ localStorage.setItem('A:state', {json.dumps(json.dumps(v1))}); localStorage.setItem('A:sync', {json.dumps(json.dumps(v1sync))}); }}")
    pg.goto(APP); pg.wait_for_selector('#main .card')
    assert pg.locator('.crow:has-text("CS-309")').count() == 1, 'migration did not create the course'
    pg.click('.crow:has-text("CS-309")'); pg.click('[data-nav*="|Quizzes"]')
    assert pg.locator('td.e[data-r="0"][data-c="0"]').inner_text() == '8'
    pg.screenshot(path=os.path.join(OUT, '15_migrated_quizzes.png'))
    s2 = json.loads(pg.evaluate("localStorage.getItem('A:sync2')"))
    assert s2['url'].endswith('/exec') and s2['key'] == 'test-secret', s2
    print('migration ok; page errors:', errors or 'none')
    b.close()
srv.terminate()
print('UI TEST PASSED')
