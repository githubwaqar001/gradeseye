"""Website sign-in end to end: faculty app (demo class) syncs to the mock Drive script and turns on the website dashboard →
website signin.html (served over http) → student sign-in, marks, result, own password → faculty sign-in, table, filters,
section results → demos. Saves screenshots for review."""
import json, os, subprocess, sys, time, shutil
from playwright.sync_api import sync_playwright

OUT = sys.argv[1]; os.makedirs(OUT, exist_ok=True)
PORT, WEB = 8777, 8791
URL = f'http://127.0.0.1:{PORT}/exec'
DRIVE = os.path.join(OUT, 'drive'); shutil.rmtree(DRIVE, ignore_errors=True)
srv = subprocess.Popen([sys.executable, os.path.join(os.path.dirname(__file__), 'mock_script.py'), str(PORT), DRIVE])
web = subprocess.Popen([sys.executable, '-m', 'http.server', str(WEB)], cwd='/home/claude/site/dist/site', stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1)
MOCK = open('/home/claude/apk/app/web/test/ui_test.py').read().split('MOCK = """')[1].split('"""')[0]
st = json.load(open('/home/claude/site/build/demo_state.json'))
cfg = {'url': URL, 'key': 'test-secret', 'folder': '', 'auto': True, 'folderName': '', 'scriptVersion': 0, 'epoch': 0, 'files': {}}
INIT = MOCK + "\nif (!localStorage.getItem('A:state2')) { localStorage.setItem('A:state2', %s); localStorage.setItem('A:sync2', %s); }" % (json.dumps(json.dumps(st)), json.dumps(json.dumps(cfg)))
errors = []
def control(): return json.loads(subprocess.check_output(['curl', '-s', f'http://127.0.0.1:{PORT}/control']))
def wait_for(cond, what, timeout=90):
    t0 = time.time()
    while time.time() - t0 < timeout:
        v = cond()
        if v: return v
        time.sleep(0.4)
    raise AssertionError('timed out waiting for ' + what)
def shot(pg, name, full=True): print('step', name, flush=True); pg.screenshot(path=os.path.join(OUT, name + '.png'), full_page=full)

with sync_playwright() as p:
    b = p.chromium.launch()
    try:
        # ---------------- faculty app: sync the demo class, turn on the website dashboard
        ctx = b.new_context(viewport={'width': 393, 'height': 820}, device_scale_factor=1, is_mobile=True, has_touch=True)
        t = ctx.new_page(); t.set_default_timeout(20000); t.on('pageerror', lambda e: errors.append('app: ' + str(e)))
        t.add_init_script(INIT); t.goto('file:///home/claude/apk/app/dist2/index.html'); t.wait_for_selector('.crow')
        wait_for(lambda: len(control()['portal']['courses']) == 3, 'student summaries published')
        t.click('#syncbtn'); t.wait_for_selector('#webpw1')
        t.fill('#webpw1', 'Dash2026board'); t.fill('#webpw2', 'Dash2026boardX'); t.click('[data-act=web-set]'); time.sleep(0.3)
        assert 'not the same' in t.locator('#toast').inner_text()
        t.fill('#webpw2', 'Dash2026board'); t.click('[data-act=web-set]')
        wait_for(lambda: control()['portal']['fdash'] and len(control()['portal']['fcourses']) == 3, 'faculty summaries published')
        wait_for(lambda: '3 of 3 course(s) on the dashboard' in t.locator('.card:has(#webpw1)').inner_text(), 'dashboard status in the app')
        t.locator('.card:has(#webpw1)').scroll_into_view_if_needed(); shot(t, 'w00_app_web_card', full=False)
        t.locator('.card:has(#webpw1) [data-act=copy-code]').click()
        code = t.locator('#modal textarea').input_value(); t.click('#modal [data-x=ok]')
        assert code.startswith('GE1-'), code
        pins = json.loads(t.evaluate("localStorage.getItem('A:state2')"))['portal']['pins']

        # ---------------- website: student
        wctx = b.new_context(viewport={'width': 1280, 'height': 900}); w = wctx.new_page(); w.set_default_timeout(20000)
        w.on('pageerror', lambda e: errors.append('web: ' + str(e)))
        w.goto(f'http://127.0.0.1:{WEB}/index.html'); w.click('a.navsign'); w.wait_for_selector('#f')
        assert 'Class code' in w.locator('#f').inner_text()
        w.goto(f'http://127.0.0.1:{WEB}/signin.html?c={code}'); w.wait_for_selector('#f')
        assert 'Lec. Faraz Ahmed' in w.locator('.class').inner_text()
        shot(w, 'w01_signin')
        w.fill('#reg', '24-CS-009'); w.fill('#pw', 'WRONGPIN'); w.click('#f button[type=submit]')
        w.wait_for_selector('.err'); assert 'not correct' in w.locator('.err').inner_text()
        w.fill('#pw', pins['24CS009']); w.click('#f button[type=submit]'); w.wait_for_selector('.citem')
        txt = w.locator('#app').inner_text()
        assert 'Fatima Chaudhry' in txt and w.locator('.citem').count() == 2 and 'Theory attendance' in txt, txt[:400]
        shot(w, 'w02_student_attendance')
        w.click('[data-tab=marks]'); assert 'Quiz 1' in w.locator('#app').inner_text(); shot(w, 'w03_student_marks')
        w.click('.citem:has-text("CS-103")'); w.click('[data-tab=result]'); assert 'Course total' in w.locator('#app').inner_text()
        w.click('[data-act=pwview]'); w.fill('#pw0', pins['24CS009']); w.fill('#pw1', 'Webpass2026'); w.fill('#pw2', 'Webpass2026'); w.click('[data-act=setpw]')
        wait_for(lambda: 'Change password' in w.locator('#app').inner_text(), 'password saved on the website', 20)
        w.reload(); w.wait_for_selector('.citem')       # session survives a reload in the same tab
        w.click('[data-act=signout]'); w.wait_for_selector('#f')
        w.fill('#reg', '24-CS-009'); w.fill('#pw', pins['24CS009']); w.click('#f button[type=submit]'); w.wait_for_selector('.err')
        assert 'not correct' in w.locator('.err').inner_text(), 'PIN still works after the password change'
        w.fill('#pw', 'Webpass2026'); w.click('#f button[type=submit]'); w.wait_for_selector('.citem')
        w.click('[data-act=signout]'); w.wait_for_selector('#f')
        # ---------------- website: faculty
        w.click('[data-role=faculty]'); w.fill('#pw', 'nope-nope-1'); w.click('#f button[type=submit]'); w.wait_for_selector('.err')
        assert 'not correct' in w.locator('.err').inner_text()
        w.fill('#pw', 'Dash2026board'); w.check('#keep'); w.click('#f button[type=submit]'); w.wait_for_selector('table.t')
        txt = w.locator('#app').inner_text()
        assert w.locator('.ccards .citem').count() == 3 and 'faculty dashboard' in txt.lower() and 'signed in to the student app' in txt, txt[:500]
        n_all = w.locator('table.t tbody tr').count(); assert n_all == 54, n_all
        shot(w, 'w04_faculty_students')
        w.click('[data-filter=short]'); n_short = w.locator('table.t tbody tr').count(); assert 0 < n_short < n_all, n_short
        w.click('[data-filter=all]'); w.fill('#q', 'fatima'); time.sleep(0.2); assert w.locator('table.t tbody tr').count() >= 1
        assert 'own password' in w.locator('table.t tbody').inner_text()
        w.fill('#q', ''); w.locator('#q').dispatch_event('input')
        w.click('th[data-sort=ct]'); first = w.locator('table.t tbody tr').first.inner_text(); w.click('th[data-sort=ct]'); assert w.locator('table.t tbody tr').first.inner_text() != first
        w.click('[data-fsec]:has-text("Section B")'); assert w.locator('table.t tbody tr').count() == 26
        w.click('[data-ftab=results]'); assert 'Average course total %' in w.locator('#app').inner_text(); shot(w, 'w05_faculty_results')
        w.click('.ccards .citem:has-text("CS-106L")'); w.click('[data-ftab=students]'); assert 'Lab att.' in w.locator('table.t thead').inner_text()
        # kept signed in across a new tab
        w2 = wctx.new_page(); w2.goto(f'http://127.0.0.1:{WEB}/signin.html'); w2.wait_for_selector('table.t'); w2.close()
        # ---------------- phone width + demos (no class code)
        mctx = b.new_context(viewport={'width': 390, 'height': 844}, color_scheme='dark'); m = mctx.new_page(); m.on('pageerror', lambda e: errors.append('mobile: ' + str(e)))
        m.goto(f'http://127.0.0.1:{WEB}/signin.html'); m.wait_for_selector('#f'); shot(m, 'w06_phone_signin')
        m.click('[data-act=demo-student]'); m.wait_for_selector('.citem'); assert 'Demo' in m.locator('.demo-band').inner_text()
        assert m.evaluate('document.documentElement.scrollWidth') <= 390; shot(m, 'w07_phone_student_demo')
        m.click('[data-act=leave-demo]'); m.click('[data-act=demo-faculty]'); m.wait_for_selector('table.t')
        assert m.evaluate('document.documentElement.scrollWidth') <= 390; shot(m, 'w08_phone_faculty_demo')
        # ---------------- turning the dashboard off in the app signs faculty out on the website
        t.click('[data-act=web-off]'); t.click('#modal [data-x="1"]')
        wait_for(lambda: not control()['portal']['fdash'], 'dashboard off')
        w.click('[data-act=refresh]'); w.wait_for_selector('#f'); assert 'sign in again' in w.locator('#app').inner_text().lower() or 'not turned on' in w.locator('#app').inner_text()
        print('page errors:', errors or 'none')
        assert not errors
        print('WEB TEST PASSED')
    finally:
        srv.terminate(); web.terminate(); b.close()
