// Builds a realistic fictional class (for website screenshots): two sections, three courses, eight weeks of data.
import fs from 'fs';
import { emptyState, newSemester, newSection, newCourse, defaultPlan } from '../src/model.js';
import { calc, setMark } from '../src/engine.js';
import { entryPages } from '../src/layout.js';
import { buildCourse, buildFacultyCourse, portalOf, setFlag, ensurePins, normReg } from '../src/portal.js';
const OUT = process.argv[2];
let seed = 20261006; const rnd = () => ((seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648);
const st = emptyState(); st.profile.instructor = 'Lec. Faraz Ahmed'; st.profile.university = 'HITEC University, Taxila';
const sem = newSemester({ dept: 'Department of Computing', program: 'BSCS', batch: '2024', semester: '5th', session: 'Fall 2026', start: '2026-08-17' });
const first = ['Hamza', 'Ayesha', 'Usman', 'Fatima', 'Bilal', 'Zainab', 'Ahmed', 'Hira', 'Saad', 'Maryam', 'Umar', 'Iqra', 'Hassan', 'Noor', 'Talha', 'Areeba', 'Daniyal', 'Mahnoor', 'Shayan', 'Laiba', 'Haris', 'Khadija', 'Rayyan', 'Sana', 'Abdullah', 'Eman', 'Faizan', 'Rida', 'Moiz', 'Anaya'];
const last = ['Tariq', 'Siddiqui', 'Javed', 'Raza', 'Qureshi', 'Malik', 'Butt', 'Shah', 'Iqbal', 'Chaudhry', 'Mirza', 'Hashmi', 'Nawaz', 'Aslam', 'Zafar'];
let k = 0;
for (const [code, n] of [['A', 28], ['B', 26]]) {
  const x = newSection(code, `BSCS-5${code}`);
  for (let i = 0; i < n; i++) { k++; x.students[i] = { reg: `24-CS-${String(k).padStart(3, '0')}`, name: `${first[(k * 7) % first.length]} ${last[(k * 11) % last.length]}`, rem: '' }; }
  sem.sections.push(x);
}
st.semesters.push(sem);
const [A, B] = sem.sections;
const c1 = newCourse(sem, { code: 'CS-309', title: 'Web Design & Development', type: 'TL', credit: '3(2+1)', instructor: st.profile.instructor });
const c2 = newCourse(sem, { code: 'CS-103', title: 'Discrete Structures', type: 'T', credit: '3(3+0)', secIds: [A.id], instructor: st.profile.instructor });
const c3 = newCourse(sem, { code: 'CS-106L', title: 'ICT Lab', type: 'L', credit: '1(0+1)', secIds: [B.id], instructor: st.profile.instructor });
c2.plan.final.on = true;
st.courses.push(c1, c2, c3);
const ability = {}; let s = 0;
for (const sec of sem.sections) for (const r of Object.keys(sec.students)) ability[`${sec.id}|${r}`] = 0.48 + 0.47 * ((Math.sin(++s * 12.9898) * 43758.5453) % 1 + 1) % 1;
const WEEKS = 8;
for (const c of st.courses) {
  const R = calc(st, c), Lo = R.Lo;
  for (const p of entryPages(Lo)) for (const x of Lo.secs) {
    const ros = p.sec ? R.sec[x.id].roster : R.lab[x.id].roster;
    let cols, held;
    if (p.kind === 'att') { cols = WEEKS; held = WEEKS; }
    else if (p.kind === 'items') { cols = p.comp.cols.length; held = 1; }
    else if (p.kind === 'exp') { cols = p.comp.cols.length; held = p.comp.crit.length * 7; }
    else if (p.id === 'Lab Mid' || (c.id === c2.id && p.id === 'Mid Exam')) { cols = p.comp.cols.length; held = cols; }
    else continue;
    ros.forEach((st_, r) => {
      if (!st_.name) return;
      const a = ability[`${x.id}|${r}`] ?? 0.7;
      for (let ci = 0; ci < Math.min(held, cols); ci++) {
        if (p.kind === 'att') { const u = rnd(); setMark(c, x.id, p.id, r, ci, u < 0.12 + (0.9 - a) * 0.35 ? (u < 0.03 ? 'L' : 'A') : 'P'); continue; }
        const mx = p.comp.cols[ci].max, v = Math.max(0, Math.min(1, a + (rnd() - 0.5) * 0.3));
        setMark(c, x.id, p.id, r, ci, Math.round(v * mx * 2) / 2);
      }
    });
  }
}
// student app: share all three, release CS-103
const pt = portalOf(st); pt.on = true; pt.used = true;
for (const c of st.courses) setFlag(st, c.id, 'publish', true);
setFlag(st, c2.id, 'release', true);
ensurePins(st, st.courses);
fs.writeFileSync(`${OUT}/demo_state.json`, JSON.stringify(st));
// what one student (section A, row 2) sees
// pick a typical student: theory attendance between 78% and 90%, first quiz 6–8 out of 10
const cand = Object.values(A.students).map(x => { const d = buildCourse(st, c1).students[normReg(x.reg)]; return { x, d }; })
  .filter(({ d }) => d && d.att[0].pct >= 0.78 && d.att[0].pct <= 0.9 && d.marks[0].items[0] && d.marks[0].items[0].g >= 6 && d.marks[0].items[0].g <= 8);
const me = (cand[1] || cand[0]).x, key = normReg(me.reg);
const courses = st.courses.map(c => { const d = buildCourse(st, c); const m = d.students[key]; if (!m) return null; delete d.students; d.me = m; d.updated = Date.parse('2026-10-06T09:40:00+05:00'); return d; }).filter(Boolean);
fs.writeFileSync(`${OUT}/demo_student.json`, JSON.stringify({ ok: true, reg: me.reg, name: me.name, title: `${st.profile.instructor} · ${st.profile.university}`, courses, own: true, token: 'demo', time: Date.now() }));
// sign-ins for the faculty list
const logins = {}; let n = 0;
for (const sec of sem.sections) for (const x of Object.values(sec.students)) { n++; if (n % 5 === 0 || n % 7 === 0) continue; const t = Date.parse('2026-10-06T08:00:00+05:00') - Math.floor(rnd() * 5 * 86400000); logins[normReg(x.reg)] = { f: t - 86400000 * 3, l: t, n: 1 + Math.floor(rnd() * 9), s: t + 3600000, pw: rnd() < 0.55 }; }
fs.writeFileSync(`${OUT}/demo_logins.json`, JSON.stringify(logins));
const fcourses = st.courses.map(c => Object.assign(buildFacultyCourse(st, c), { updated: Date.parse('2026-10-06T09:40:00+05:00') }));
fs.writeFileSync(`${OUT}/demo_faculty.json`, JSON.stringify({ ok: true, title: `${st.profile.instructor} · ${st.profile.university}`, courses: fcourses, logins, time: Date.now() }));
console.log('student', me.reg, me.name, 'courses', courses.length, 'logins', Object.keys(logins).length);
