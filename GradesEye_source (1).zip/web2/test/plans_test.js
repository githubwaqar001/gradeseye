import fs from 'fs';
import { emptyState, newSemester, newSection, newCourse, defaultPlan } from '../src/model.js';
import { calc, setMark, isNum } from '../src/engine.js';
import { entryPages } from '../src/layout.js';
import { buildRegister } from '../src/workbook.js';
import { readCourseXlsx } from '../src/ximport.js';

const OUT = process.argv[2];
let seed = 7; const rnd = () => ((seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648);
const st = emptyState(); st.profile.instructor = 'Lec. Test Teacher';
const sem = newSemester({ dept: 'Department of Computing', program: 'BSCS', batch: '2024', semester: '5th', session: 'Fall 2026', start: '2026-09-07' });
const N = { A: 25, B: 18, C: 12 };
let k = 0;
for (const code of ['A', 'B', 'C']) {
  const x = newSection(code, `BSCS-5${code}`);
  for (let i = 0; i < N[code]; i++) { k++; x.students[i] = { reg: `24-CS-${String(k).padStart(3, '0')}`, name: `Stu ${code}${i + 1}`, rem: '' }; }
  sem.sections.push(x);
}
sem.sections[1].students[N.B + 1] = { reg: '', name: 'No Reg', rem: '' };
st.semesters.push(sem);
const [A, B, C] = sem.sections;
// 1: theory + lab, 3 sections, custom lab group A with C's first student
const c1 = newCourse(sem, { code: 'CS-309', title: 'Web Design & Development', type: 'TL', credit: '3(2+1)', instructor: 'Lec. T' });
c1.labGroups[A.id] = { custom: true, rows: {}, rem: {} };
for (let i = 0; i < N.A; i++) c1.labGroups[A.id].rows[i] = { reg: A.students[i].reg, name: A.students[i].name };
c1.labGroups[A.id].rows[N.A] = { reg: C.students[0].reg, name: C.students[0].name };
c1.labGroups[C.id] = { custom: true, rows: {}, rem: {} };
for (let i = 1; i < N.C; i++) c1.labGroups[C.id].rows[i - 1] = { reg: C.students[i].reg, name: C.students[i].name };
c1.plan.leave = 'Yes'; c1.plan.thr = 0.8;
// 2: theory only, 3 quizzes, 1 assignment, mid 4 Qs, no final
const p2 = defaultPlan('T');
p2.quizzes.items = [{ label: 'Quiz 1', max: 10, week: 3 }, { label: 'Quiz 2', max: 15, week: 7 }, { label: 'Quiz 3', max: 10, week: 12 }];
p2.assignments.items = [{ label: 'Assignment 1', max: 25, week: 6 }];
p2.mid.qs = [10, 10, 5, 5]; p2.final.on = false; p2.quizzes.weight = 0.2; p2.assignments.weight = 0.2; p2.mid.weight = 0.6;
const c2 = newCourse(sem, { code: 'CS-103', title: 'Discrete Structures', type: 'T', credit: '3(3+0)', secIds: [A.id, B.id], plan: p2 });
// 3: lab only: 10 experiments, no reports / lab mid / OEL
const p3 = defaultPlan('L');
p3.lab.exps = 10; p3.lab.reports.on = false; p3.lab.mid.on = false; p3.lab.oel.on = false; p3.lab.perf.marks = 10; p3.lab.final.marks = 10;
const c3 = newCourse(sem, { code: 'CS-106L', title: 'ICT Lab', type: 'L', credit: '1(0+1)', secIds: [B.id, C.id], plan: p3 });
// 4: theory + lab, one section, mixed CLOs and weighted PLOs
const p4 = defaultPlan('TL');
p4.clos = [{ id: 'k1', code: 'CLO-1', kpi: 0.5, desc: 'theory', w: { Q: 0.2, M: 0.3, F: 0.5 } }, { id: 'k2', code: 'CLO-2', kpi: 0.6, desc: 'mixed', w: { A: 0.3, LPERF: 0.4, PROJ: 0.3 } }, { id: 'k3', code: 'CLO-3', kpi: 0.5, desc: 'lab', w: { LREP: 1 } }];
p4.plos = [{ id: 'p1', code: 'PLO-1', kpi: 0.5, desc: '', w: { k1: 0.6, k2: 0.4 } }, { id: 'p2', code: 'PLO-3', kpi: 0.55, desc: '', w: { k3: 1 } }, { id: 'p3', code: 'PLO-5', kpi: 0.5, desc: '', w: { k2: 1 } }];
p4.shares = { T: 0.75, L: 0.25 };
const c4 = newCourse(sem, { code: 'CS-210', title: 'Databases', type: 'TL', credit: '4(3+1)', secIds: [A.id], plan: p4 });
c4.dates.MIDD = '2026-11-03';
c4.schedule.dates[`${A.id}|lec|3`] = '2026-09-25';
st.courses.push(c1, c2, c3, c4);
const { calc: _ } = { calc };
for (const c of st.courses) {
  const R = calc(st, c), Lo = R.Lo;
  for (const p of entryPages(Lo)) for (const s of Lo.secs) {
    const ros = p.sec ? R.sec[s.id].roster : R.lab[s.id].roster;
    const cols = p.kind === 'att' ? Array.from({ length: Lo.weeks }, () => ({})) : p.comp.cols;
    const heldN = p.kind === 'att' ? 9 : p.kind === 'exp' ? (s.code === 'B' ? 0 : p.comp.crit.length * 6) : p.id === 'Final Exam' ? (s.code === 'A' ? cols.length : 0) : p.id === 'Quizzes' ? 2 : p.id === 'Project' ? (s.code === 'B' ? 4 : cols.length) : cols.length;
    ros.forEach((x, r) => { if (!x.name) return; for (let ci = 0; ci < Math.min(heldN, cols.length); ci++) {
      if (rnd() < 0.05) continue;
      if (p.kind === 'att') setMark(c, s.id, p.id, r, ci, ['P', 'P', 'P', 'A', 'L'][Math.floor(rnd() * 5)]);
      else setMark(c, s.id, p.id, r, ci, Math.round(rnd() * cols[ci].max * 2) / 2);
    } });
  }
}
const checks = [];
for (const [ci, c] of st.courses.entries()) {
  const R = calc(st, c), Lo = R.Lo;
  const { wb, meta } = buildRegister(st, c);
  const fname = `${OUT}/course${ci + 1}.xlsx`;
  fs.writeFileSync(fname, await wb.build('nodebuffer'));
  const exp = [];
  const put = (sheet, ref, v) => exp.push([sheet, ref, isNum(v) || typeof v === 'string' ? v : '']);
  for (const s of Lo.secs) {
    const F = meta.FINAL[s.id], fsn = F.sheet.replace(/^'|'$/g, '');
    R.sec[s.id].final.forEach((o, r) => {
      const row = 8 + r;
      if (!o) { put(fsn, `C${row}`, ''); return; }
      for (const [key, col] of Object.entries(F.FC)) {
        let v;
        if (key.startsWith('th|')) v = o.th[key.slice(3)];
        else if (key.startsWith('lab|')) v = o.lab[Lo.labComps.findIndex(x => x.id === key.slice(4))];
        else if (key.startsWith('clo|')) v = o.clo[key.slice(4)];
        else if (key.startsWith('plo|')) v = o.plo[key.slice(4)];
        else v = o[key];
        put(fsn, `${col}${row}`, v);
      }
    });
    if (Lo.clos.length) { const CL = meta.CLOS[s.id], sn = CL.sheet.replace(/^'|'$/g, ''); R.sec[s.id].clo.forEach((o, r) => { if (!o) return; for (const k of Lo.clos) { put(sn, `${CL.pct[k.id]}${8 + r}`, o.pct[k.id]); put(sn, `${CL.st[k.id]}${8 + r}`, o.st[k.id]); } }); }
    if (Lo.plos.length) { const PL = meta.PLOS[s.id], sn = PL.sheet.replace(/^'|'$/g, ''); R.sec[s.id].plo.forEach((o, r) => { if (!o) return; for (const p of Lo.plos) { put(sn, `${PL.pct[p.id]}${8 + r}`, o.pct[p.id]); put(sn, `${PL.st[p.id]}${8 + r}`, o.st[p.id]); } }); }
    if (Lo.L && Lo.labComps.length) { const T = meta.LB[`${s.id}|total`], sn = T.sheet.replace(/^'|'$/g, ''); R.lab[s.id].total.rows.forEach((o, r) => { if (!o) return; put(sn, `${T.total}${8 + r}`, o.T); put(sn, `${T.pct}${8 + r}`, o.P); }); }
  }
  let row = 6;
  for (const x of R.results.rows) {
    if (x.head) put('Section Results', `B${row}`, x.head);
    else { put('Section Results', `B${row}`, x.label); x.vals.forEach((v, k) => put('Section Results', `${String.fromCharCode(67 + k)}${row}`, v)); put('Section Results', `${String.fromCharCode(67 + x.vals.length)}${row}`, x.all); }
    row++;
  }
  checks.push({ file: fname, exp });
  // round trip through the reader
  const back = await readCourseXlsx(st, c, fs.readFileSync(fname));
  const strip = o => JSON.stringify({ ...o, created: 0 });
  const same = strip(back.course) === strip(c);
  if (!same) for (const k of Object.keys(c)) if (JSON.stringify(c[k]) !== JSON.stringify(back.course[k])) {
    if (k === 'marks') { for (const sk of new Set([...Object.keys(c.marks), ...Object.keys(back.course.marks)])) { const a = c.marks[sk] || {}, b = back.course.marks[sk] || {}; const ks = new Set([...Object.keys(a), ...Object.keys(b)]); const d = [...ks].filter(x => a[x] !== b[x]); if (d.length) console.log('  marks diff', sk, d.slice(0, 5).map(x => [x, a[x], b[x]])); } }
    else console.log('ROUNDTRIP DIFF', c.code, k, JSON.stringify(c[k]).slice(0, 300), '|', JSON.stringify(back.course[k]).slice(0, 300));
  }
  const stuSame = Lo.secs.every(s => JSON.stringify(back.students[s.id]) === JSON.stringify(sem.sections.find(x => x.id === s.id).students));
  console.log(c.code, c.type, 'sheets', wb.sheets.length, 'roundtrip', same && stuSame, 'warnings', back.warnings.length);
}
fs.writeFileSync(`${OUT}/checks.json`, JSON.stringify(checks));
