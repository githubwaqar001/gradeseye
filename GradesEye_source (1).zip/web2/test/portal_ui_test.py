"""Teacher app + student app, phone-sized, against the mock Drive script (v3):
teacher turns on the student app → courses and PIN hashes are published → PIN list and Excel slips →
student signs in (wrong PIN, right PIN) → home, attendance, marks, result (released / not released) →
offline cache → teacher gives a new PIN → student is signed out → course hidden → class-code linking → app switched off."""
import base64, io, json, os, subprocess, sys, time, shutil
from playwright.sync_api import sync_playwright

APP = 'file:///home/claude/apk/app/dist2/index.html'
STU = 'file:///home/claude/apk/app/dist-student/index.html'
OUT = sys.argv[1]; os.makedirs(OUT, exist_ok=True)
PORT = 8776
URL = f'http://127.0.0.1:{PORT}/exec'
DRIVE = os.path.join(OUT, 'drive'); shutil.rmtree(DRIVE, ignore_errors=True)
srv = subprocess.Popen([sys.executable, os.path.join(os.path.dirname(__file__), 'mock_script.py'), str(PORT), DRIVE])
time.sleep(0.8)
MOCK = open('/home/claude/apk/app/web/test/ui_test.py').read().split('MOCK = """')[1].split('"""')[0]
MOCK = MOCK.replace("window.__mock.files.push({ name, len: b64.length });", "window.__mock.files.push({ name, mime, b64 });")
TITLE = 'Lec. Test Teacher · HITEC University, Taxila'
def stu_mock(prefix, config):
    return MOCK.replace("'A:' + k", f"'{prefix}:' + k").replace("version: () => '1.0-test',", f"version: () => '1.0-test', config: () => {json.dumps(json.dumps(config)) if config else 'null'},")
errors = []
def shot(page, name, full=False):
    print('step', name, flush=True); page.screenshot(path=os.path.join(OUT, name + '.png'), full_page=full)
def fill(page, sel, val):
    page.fill(sel, val); page.locator(sel).press('Tab')
def control():
    return json.loads(subprocess.check_output(['curl', '-s', f'http://127.0.0.1:{PORT}/control']))
def wait_for(cond, what, timeout=60):
    t0 = time.time()
    while time.time() - t0 < timeout:
        v = cond()
        if v: return v
        time.sleep(0.4)
    raise AssertionError('timed out waiting for ' + what)
def published(cid):
    p = os.path.join(DRIVE, '_portal', f'course_{cid}.json')
    return json.load(open(p)) if os.path.exists(p) else None
def wait_status(page, words, timeout=60):
    return wait_for(lambda: any(w in page.locator('#syncbtn').inner_text() for w in words), f'status {words}', timeout)

with sync_playwright() as p:
    b = p.chromium.launch()
    def phone():
        ctx = b.new_context(viewport={'width': 393, 'height': 820}, device_scale_factor=2, is_mobile=True, has_touch=True)
        pg = ctx.new_page(); pg.set_default_timeout(15000); pg.on('pageerror', lambda e: errors.append(str(e)))
        return ctx, pg
    tctx, t = phone()
    t.add_init_script(MOCK)
    try:
        # ---------------- teacher: semester, two sections, two courses, a few marks
        t.goto(APP); t.wait_for_selector('#main .card')
        t.click('[data-act=new-sem]')
        for ph, v in [('Department of Computing', 'Department of Computing'), ('BSCS', 'BSCS'), ('2024', '2024'), ('5th', '5th'), ('Fall 2026', 'Fall 2026')]:
            fill(t, f'input[placeholder="{ph}"]', v)
        fill(t, 'input[placeholder="Lec. …"]', 'Lec. Test Teacher')
        t.click('[data-act=create-sem]')
        for code in ['A', 'B']: t.fill('#newsec-code', code); t.click('[data-act=add-sec]')
        names = ['Ali Test', 'Sara Sample', 'Hamza Demo', 'Ayesha Example', 'Usman Mock', 'Zainab Trial']
        reg = 0
        for k, (code, n) in enumerate([('A', 6), ('B', 5)]):
            t.locator('.secedit').nth(k).locator('[data-classlist]').click(); t.click('[data-act=paste]')
            lines = []
            for i in range(n): reg += 1; lines.append(f'24-CS-{reg:03d}\t{names[i]} {code}')
            if code == 'B': lines += ['24-CS-009\tDuplicate Person', 'N/A\tNo Number Person']
            t.fill('#m-paste', '\n'.join(lines)); t.click('#modal [data-x="1"]'); t.click('#backbtn')
        t.click('[data-act=new-course]')
        fill(t, 'input[placeholder="CS-309"]', 'CS-309'); fill(t, 'input[placeholder="Web Design & Development"]', 'Web Design & Development')
        t.click('[data-act=plan-save]'); t.wait_for_selector('.tabs .tab')
        t.click('[data-nav*="Theory Att"]')
        for w in (0, 1, 2): t.click(f'th[data-act=week][data-c="{w}"]'); t.click('#modal [data-x=allP]')
        t.click('td.e[data-r="1"][data-c="1"]'); t.click('.attb.A'); t.click('td.e[data-r="0"][data-c="2"]'); t.click('.attb.L'); t.click('.nav.done')
        t.click('#backbtn'); t.click('[data-nav*="|Quizzes"]'); t.click('td.e[data-r="0"][data-c="0"]')
        for v in ['8', '6', '9.5', '7', '5', '6']: t.fill('#edin', v); t.press('#edin', 'Enter')
        if t.locator('.nav.done').count(): t.click('.nav.done')
        t.click('#backbtn')
        t.click('[data-nav*="|Mid Exam"]'); t.click('td.e[data-r="0"][data-c="0"]')
        for v in ['7', '8', '6', '9', '5']: t.fill('#edin', v); t.click('[data-act=ed-right]')
        t.click('.nav.done'); t.click('#backbtn')
        t.click('[data-nav*="Lab Att"]'); t.click('th[data-act=week][data-c="0"]'); t.click('#modal [data-x=allP]'); t.click('#backbtn')
        t.click('[data-nav*="Lab Perf"]'); t.click('td.e[data-r="0"][data-c="0"]')
        for v in [4, 5, 3]: t.click(f'.quick button[data-v="{v}"]')
        t.click('.nav.done'); t.click('#backbtn'); t.click('#backbtn')
        t.click('[data-act=new-course]'); t.click('.seg button:has-text("Theory course")')
        fill(t, 'input[placeholder="CS-309"]', 'CS-103'); fill(t, 'input[placeholder="Web Design & Development"]', 'Discrete Structures')
        t.locator('.secpick[data-code=B] input').uncheck()
        t.click('[data-act=plan-save]'); t.wait_for_selector('.tabs .tab')
        t.click('[data-nav*="|Quizzes"]'); t.click('td.e[data-r="0"][data-c="0"]'); t.fill('#edin', '7'); t.press('#edin', 'Enter'); t.click('.nav.done')
        t.click('#backbtn'); t.click('#backbtn')
        time.sleep(0.6)
        state = json.loads(t.evaluate("localStorage.getItem('A:state2')"))
        cid = {c['code']: c['id'] for c in state['courses']}
        # ---------------- Drive, then the student app
        t.click('#syncbtn')
        fill(t, '[data-cfg=url]', URL); fill(t, '[data-cfg=key]', 'test-secret')
        t.click('[data-act=sync-test]'); wait_status(t, ['Synced'])
        assert control()['portal']['courses'] == [], 'published before the student app was turned on'
        t.locator('label.cb:has-text("Turn on the student app") input').check()
        wait_for(lambda: len(control()['portal']['courses']) == 2 and control()['portal']['npins'] == 10, 'two courses + 10 PINs published (3 students with Reg. No problems left out)')
        c = control()['portal']; assert c['open'] and c['title'] == TITLE, c
        wait_for(lambda: '2 of 2 course(s) shared' in t.locator('#stustatus').inner_text(), 'status line')
        shot(t, 'p01_teacher_student_card', full=True)
        pub = published(cid['CS-309'])
        assert pub['released'] is False and all('res' not in s for s in pub['students'].values()), 'results visible before release'
        assert '24CS009' not in pub['students'] and 'NA' not in pub['students'] and len(pub['students']) == 10, sorted(pub['students'])
        fin = [g for g in pub['students']['24CS001']['marks'] if g['k'] == 'Final Exam'][0]
        assert fin.get('hidden') and fin['items'] == [], fin
        assert all(it.get('avg') is None for g in pub['students']['24CS001']['marks'] for it in g['items']), 'class averages before release'
        a1 = pub['students']['24CS001']
        assert a1['name'] == 'Ali Test A' and a1['att'][0]['P'] == 2 and a1['att'][0]['L'] == 1 and a1['att'][0]['held'] == 3, a1['att'][0]
        assert pub['students']['24CS002']['att'][0]['A'] == 1
        assert a1['marks'][0]['items'][0]['g'] == 8
        pins_file = json.load(open(os.path.join(DRIVE, '_portal', 'pins.json')))
        assert all(len(h) == 64 for h in pins_file['pins'].values()), 'PINs must be stored only as hashes'
        # ---------------- course page: release results, PIN list, slips
        t.click('#backbtn'); t.click('.crow:has-text("CS-309")')
        wait_for(lambda: 'Students can see this course' in t.locator('.pnote').inner_text(), 'course note')
        t.locator('label.cb:has-text("release results") input').check()
        wait_for(lambda: (published(cid['CS-309']) or {}).get('released') is True, 'released')
        rel = published(cid['CS-309'])['students']['24CS001']
        assert rel['res']['grade'] and rel['marks'][0]['items'][0]['avg'] == round((8 + 6 + 9.5 + 7 + 5 + 6) / 6, 1), rel['marks'][0]['items'][0]
        assert '3 students cannot sign in' in t.locator('.card:has-text("Student app")').inner_text()
        t.locator('.card:has-text("Student app")').scroll_into_view_if_needed(); shot(t, 'p02_course_student_card')
        t.click('[data-nav^="pins|"]'); t.wait_for_selector('.pinrow')
        rows = t.locator('.pinrow')
        assert rows.count() == 13, rows.count()
        pin1 = rows.nth(0).locator('.pp').inner_text().strip()
        assert len(pin1) == 9 and pin1[4] == '-' and all(ch in '23456789ABCDEFGHJKMNPQRSTUVWXYZ' for ch in pin1.replace('-', '')), pin1
        for fn in os.listdir(os.path.join(DRIVE, '_portal')): assert pin1.replace('-', '') not in open(os.path.join(DRIVE, '_portal', fn)).read(), 'plain PIN found in ' + fn
        ptxt = t.locator('.pinlist').inner_text()
        assert ptxt.count('same Reg. No as') == 2 and 'not a usable Reg. No' in ptxt, ptxt
        shot(t, 'p03_pins')
        t.click('[data-act=pin-xlsx]'); time.sleep(1.5)
        f = [x for x in t.evaluate('window.__mock.files') if x['name'].endswith('PINs.xlsx')][-1]
        from openpyxl import load_workbook
        wb = load_workbook(io.BytesIO(base64.b64decode(f['b64'])))
        assert wb.sheetnames == ['A', 'B'], wb.sheetnames
        ws = wb['A']; assert ws['B6'].value == '24-CS-001' and ws['D6'].value == pin1, (ws['B6'].value, ws['D6'].value)
        open(os.path.join(OUT, 'pin_slips.xlsx'), 'wb').write(base64.b64decode(f['b64']))
        print('PIN slips:', f['name'], wb.sheetnames, ws.max_row - 5, 'rows in A')
        t.click('#backbtn'); t.click('#backbtn')
        # class code
        t.click('#syncbtn'); t.click('[data-act=copy-code]')
        code = t.locator('#modal textarea').input_value(); t.click('#modal [data-x=ok]')
        assert code.startswith('GE1-'), code
        t.click('[data-act="stu-apk"][data-mode=share]'); time.sleep(0.4)
        assert 'Android app' in t.locator('#toast').inner_text()
        t.click('[data-act=gen-key]'); key = t.locator('#modal .mono').inner_text()
        assert len(key) == 24 and t.locator('[data-cfg=key]').input_value() == key; t.click('#modal [data-x=ok]')
        fill(t, '[data-cfg=key]', 'test-secret')   # not saved: the test keeps the mock's key
        t.click('#backbtn')

        # ---------------- student app (built-in connection)
        sctx, s = phone()
        s.add_init_script(stu_mock('S', {'v': 1, 'u': URL, 't': TITLE}) + "\nif (sessionStorage.getItem('off') === '1') window.__mock.online = false;")
        s.goto(STU); s.wait_for_selector('#reg')
        assert TITLE in s.locator('#main').inner_text()
        shot(s, 'p04_student_login')
        s.fill('#reg', '24-cs-001'); s.fill('#pin', 'ZZZZZZ'); s.click('[data-act=login]')
        s.wait_for_selector('.err'); assert 'not correct' in s.locator('.err').inner_text()
        s.fill('#pin', pin1.lower()); s.click('[data-act=login]')
        s.wait_for_selector('.ccard'); assert s.locator('.ccard').count() == 2
        home = s.locator('#main').inner_text()
        assert 'Ali Test A' in home and 'Grade' in home and 'Theory 66.7% · short' in home and 'Lab 100%' in home, home
        shot(s, 'p05_student_home')
        s.click('.ccard:has-text("CS-309")'); s.wait_for_selector('.ring')
        att = s.locator('#main').inner_text()
        assert '3 of 16 classes held' in att and 'Leave' in att and 'Short attendance' in att and 'Attend the next 1 class in a row' in att, att
        shot(s, 'p06_student_attendance', full=True)
        s.click('[data-tab=marks]'); txt = s.locator('#main').inner_text()
        assert 'Quiz 1' in txt and '8' in txt and 'Class average' in txt and 'Mid-Term Exam' in txt and '35' in txt, txt
        shot(s, 'p07_student_marks', full=True)
        s.click('[data-tab=result]'); txt = s.locator('#main').inner_text()
        assert 'Course total' in txt and 'Grade' in txt and 'How marks are counted' in txt and '4.8 / 6 (80%)' in txt, txt
        shot(s, 'p08_student_result', full=True)
        s.click('#backbtn'); s.click('.ccard:has-text("CS-103")'); s.click('[data-tab=result]')
        assert 'not released' in s.locator('#main').inner_text()
        s.click('[data-tab=marks]'); assert 'Shown when your teacher releases the results' in s.locator('#main').inner_text()
        s.click('#backbtn')
        # offline: refresh and reopen show saved results
        s.evaluate('window.__mock.online = false'); s.click('#refresh'); time.sleep(0.4)
        assert 'Offline' in s.locator('#main').inner_text()
        s.evaluate("sessionStorage.setItem('off', '1')"); s.reload(); s.wait_for_selector('.ccard'); time.sleep(0.5); assert s.locator('.ccard').count() == 2 and 'Offline' in s.locator('#main').inner_text()
        shot(s, 'p09_student_offline')
        s.evaluate("sessionStorage.removeItem('off'); window.__mock.online = true")
        # ---------------- student sets an own password; the PIN stops working
        assert 'Set your own password' in s.locator('#main').inner_text() and 'softonicBank Co.' in s.locator('#main').inner_text()
        s.click('.foot [data-act=pwview]'); s.wait_for_selector('#pw0')
        s.fill('#pw0', pin1); s.fill('#pw1', 'Garden2026x'); s.fill('#pw2', 'Garden2026y'); s.click('[data-act=setpw]')
        assert 'not the same' in s.locator('#pwerr').inner_text()
        s.fill('#pw2', 'Garden2026x'); s.fill('#pw0', 'WRONG-PIN1'); s.click('[data-act=setpw]')
        wait_for(lambda: 'not correct' in s.locator('#pwerr').inner_text(), 'wrong current PIN refused', 15)
        assert s.locator('#pw1').input_value() == 'Garden2026x', 'typed fields must survive an error'
        s.evaluate('window.__nativeOnline(true)'); assert s.locator('#pw1').input_value() == 'Garden2026x', 'network event wiped the form'
        shot(s, 'p10_student_password')
        s.fill('#pw0', pin1); s.click('[data-act=setpw]'); s.wait_for_selector('.ccard')
        txt = s.locator('#main').inner_text(); assert 'Change password' in txt and 'Set your own password' not in txt, txt
        s.click('[data-act=logout]'); s.wait_for_selector('#pin')
        s.fill('#reg', '24-CS-001'); s.fill('#pin', pin1); s.click('[data-act=login]'); s.wait_for_selector('.err')
        assert 'not correct' in s.locator('.err').inner_text(), 'the PIN still works after setting a password'
        s.fill('#pin', 'Garden2026x'); s.click('[data-act=login]'); s.wait_for_selector('.ccard')
        # ---------------- faculty: who has signed in
        t.click('.crow:has-text("CS-309")'); t.click('[data-nav^="logins|"]')
        wait_for(lambda: '1 of 13 students have signed in' in t.locator('#main').inner_text(), 'sign-in list')
        txt = t.locator('#main').inner_text(); assert '1 use their own password' in txt and 'own password' in t.locator('.lrow').nth(0).inner_text(), txt
        assert t.locator('.lst.ok').count() == 1
        t.click('[data-act=logins-filter][data-f=out]'); assert t.locator('.lrow').count() == 12
        t.click('[data-act=logins-filter][data-f=all]')
        shot(t, 'p11_teacher_signins', full=True)
        t.click('#backbtn'); t.click('#backbtn')
        # ---------------- teacher gives a new PIN → student is signed out
        t.click('.crow:has-text("CS-309")'); t.click('[data-nav^="pins|"]'); t.wait_for_selector('.pinrow')
        old_hash = json.load(open(os.path.join(DRIVE, '_portal', 'pins.json')))['pins']['24CS001']
        t.locator('.pinrow').nth(0).locator('[data-act=pin-new]').click(); t.click('#modal [data-x="1"]')
        pin2 = t.locator('.pinrow').nth(0).locator('.pp').inner_text().strip(); assert pin2 != pin1
        wait_for(lambda: json.load(open(os.path.join(DRIVE, '_portal', 'pins.json')))['pins']['24CS001'] != old_hash, 'new PIN published')
        s.click('#refresh'); s.wait_for_selector('#pin')
        assert 'sign in again' in s.locator('.info').inner_text()
        assert json.loads(s.evaluate("localStorage.getItem('S:session')")) is None
        s.fill('#pin', pin2); s.click('[data-act=login]'); s.wait_for_selector('.ccard')
        sess = json.loads(s.evaluate("localStorage.getItem('S:session')"))
        assert sess['token'] and 'pin' not in sess and pin2.replace('-', '') not in json.dumps(sess), sess
        # ---------------- teacher hides CS-103
        t.click('#backbtn'); t.click('#backbtn'); t.click('.crow:has-text("CS-103")')
        t.locator('label.cb:has-text("Show this course") input').uncheck()
        wait_for(lambda: published(cid['CS-103']) is None, 'CS-103 unpublished')
        s.click('#refresh'); time.sleep(1.2); assert s.locator('.ccard').count() == 1
        # a second student only sees their own record
        s.click('[data-act=logout]'); s.wait_for_selector('#pin')
        time.sleep(0.6); pins = json.loads(t.evaluate("localStorage.getItem('A:state2')"))['portal']['pins']
        s.fill('#reg', '24-CS-008'); s.fill('#pin', pins['24CS008']); s.click('[data-act=login]'); s.wait_for_selector('.ccard')
        txt = s.locator('#main').inner_text(); assert 'Sara Sample B' in txt and 'Ali Test' not in txt, txt
        # sign-out while a slow refresh is still running, then another student signs in with Enter: no mix-up
        subprocess.check_output(['curl', '-s', f'http://127.0.0.1:{PORT}/control?delay=2'])
        s.click('#refresh'); time.sleep(0.2); s.click('[data-act=logout]'); s.wait_for_selector('#pin')
        s.fill('#reg', '24-CS-002'); s.fill('#pin', pins['24CS002']); s.press('#pin', 'Enter')
        time.sleep(5.5); subprocess.check_output(['curl', '-s', f'http://127.0.0.1:{PORT}/control?delay=0'])
        txt = s.locator('#main').inner_text()
        assert 'Sara Sample A' in txt and 'Sara Sample B' not in txt, txt
        assert json.loads(s.evaluate("localStorage.getItem('S:data')"))['name'] == 'Sara Sample A'
        # faculty list now shows three students; the new PIN cleared Ali's own password
        t.click('#backbtn'); t.click('.crow:has-text("CS-309")'); t.click('[data-nav^="logins|"]'); t.click('[data-act=logins-refresh]')
        wait_for(lambda: '3 of 13 students have signed in' in t.locator('#main').inner_text(), 'three sign-ins')
        assert '0 use their own password' in t.locator('#main').inner_text()
        t.click('#backbtn')
        # ---------------- unlinked copy + class code
        uctx, u = phone(); u.add_init_script(stu_mock('U', None))
        u.goto(STU); u.wait_for_selector('#code'); shot(u, 'p12_student_link')
        u.fill('#code', 'nonsense'); u.click('[data-act=connect]'); assert 'not right' in u.locator('.err').inner_text()
        u.fill('#code', code); u.click('[data-act=connect]'); u.wait_for_selector('#reg')
        assert TITLE in u.locator('#main').inner_text() and u.locator('[data-act=unlink]').count() == 1
        # ---------------- student app switched off
        t.click('#backbtn'); t.click('#syncbtn'); t.locator('label.cb:has-text("Turn on the student app") input').uncheck()
        wait_for(lambda: control()['portal']['open'] is False and control()['portal']['courses'] == [], 'switched off')
        s.click('#refresh'); time.sleep(1.2)
        assert 'switched off' in s.locator('#main').inner_text(), s.locator('#main').inner_text()
        calls = control()['calls']
        print('student calls:', calls.count('student'), 'hello:', calls.count('hello'), 'publish:', calls.count('publish'), 'unpublish:', calls.count('unpublish'), 'pins:', calls.count('pins'))
        print('page errors:', errors or 'none')
        assert not errors
        print('PORTAL UI TEST PASSED')
    except Exception:
        for pg_, nm in [(t, 'FAIL_teacher')] + ([(s, 'FAIL_student')] if 's' in dir() else []):
            try: shot(pg_, nm)
            except Exception: pass
        print('page errors:', errors); srv.terminate(); raise
    srv.terminate(); b.close()
