// Run apps-script/Code.gs in Node with in-memory stand-ins for the Google services it uses.
import fs from 'fs'; import vm from 'vm'; import crypto from 'crypto';
const code = fs.readFileSync('/home/claude/apk/app/apps-script/Code.gs', 'utf8');
let reads = 0, idn = 0;
const files = new Map(), folders = new Map();
const mkFolder = (name) => { const f = { id: 'F' + (++idn), name, trashed: false, kids: [], files: [],
  getId: () => f.id, getName: () => f.name, isTrashed: () => f.trashed,
  getFoldersByName: n => iter(f.kids.filter(k => k.name === n)), createFolder: n => { const k = mkFolder(n); f.kids.push(k); return k; },
  getFilesByName: n => iter(f.files.filter(k => k.name === n)),
  createFile: blob => { const x = mkFile(blob.name, blob.text); f.files.push(x); return x; } }; folders.set(f.id, f); return f; };
const mkFile = (name, text) => { const x = { id: 'D' + (++idn), name, text, trashed: false, getId: () => x.id, getName: () => x.name, isTrashed: () => x.trashed,
  setTrashed: t => { x.trashed = t; }, setContent: t => { x.text = t; }, getBlob: () => ({ getDataAsString: () => { reads++; return x.text; } }) }; files.set(x.id, x); return x; };
const iter = a => { let i = 0; return { hasNext: () => i < a.length, next: () => a[i++] }; };
const root = mkFolder('My Drive');
const props = {}; const cache = new Map();
const byteSize = s => Buffer.byteLength(s, 'utf8');
const G = {
  PropertiesService: { getScriptProperties: () => ({ getProperty: k => props[k] ?? null, getProperties: () => Object.assign({}, props), setProperty: (k, v) => { if (byteSize(v) > 9000) throw new Error('property too big'); props[k] = v; } }) },
  CacheService: { getScriptCache: () => ({
    get: k => (cache.has(k) ? cache.get(k) : null),
    put: (k, v) => { if (byteSize(v) > 102400) throw new Error('cache value too big'); cache.set(k, v); },
    getAll: ks => Object.fromEntries(ks.filter(k => cache.has(k)).map(k => [k, cache.get(k)])),
    putAll: (o) => { for (const [k, v] of Object.entries(o)) { if (byteSize(v) > 102400) throw new Error('cache value too big ' + byteSize(v)); cache.set(k, v); } },
    remove: k => cache.delete(k), removeAll: ks => ks.forEach(k => cache.delete(k)) }) },
  DriveApp: { getRootFolder: () => root, getFolderById: id => { const f = folders.get(id); if (!f) throw new Error('no folder'); return f; }, getFileById: id => { const f = files.get(id); if (!f) throw new Error('no file'); return f; } },
  Utilities: { newBlob: (text, mime, name) => ({ text, mime, name }), sleep: () => {}, getUuid: () => crypto.randomUUID(),
    computeHmacSha256Signature: (v, k) => Array.from(crypto.createHmac('sha256', k).update(v, 'utf8').digest()).map(b => (b > 127 ? b - 256 : b)), DigestAlgorithm: { SHA_256: 'sha256', MD5: 'md5' }, Charset: { UTF_8: 'utf8' },
    computeDigest: (alg, s) => Array.from(crypto.createHash(alg).update(s, 'utf8').digest()).map(b => (b > 127 ? b - 256 : b)) },
  ContentService: { MimeType: { JSON: 'json' }, createTextOutput: s => ({ s, setMimeType() { return this; } }) },
  LockService: { getScriptLock: () => ({ waitLock() {}, tryLock() { return true; }, releaseLock() {} }) },
  Session: { getEffectiveUser: () => ({ getEmail: () => 'teacher@example.edu' }) },
  ScriptApp: { getOAuthToken: () => 'tok' }, UrlFetchApp: { fetch: () => { throw new Error('not used'); } },
  console, JSON, Date, Math, Object, String, Number, Array, Error,
};
function load(secret) {
  const ctx = vm.createContext({ ...G });
  vm.runInContext(code.replace("const SECRET = 'change-this-secret';", `const SECRET = ${JSON.stringify(secret)};`), ctx);
  return body => JSON.parse(ctx.doPost({ postData: { contents: JSON.stringify(body) } }).s);
}
const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) process.exitCode = 1; };
let post = load('short-key');
ok(/too short/.test(post({ action: 'ping', key: 'short-key' }).error), 'short secret refused for teacher actions');
post = load('change-this-secret');
ok(/set your own SECRET/.test(post({ action: 'ping', key: 'change-this-secret' }).error), 'default secret refused');
const KEY = 'Xy7pQ2mN9vR4tK8wL3zA5bC6';
post = load(KEY);
ok(post({ action: 'ping', key: 'wrong-key-123456' }).error === 'Wrong secret key.', 'wrong key refused');
const ping = post({ action: 'ping', key: KEY });
ok(ping.ok && ping.version === 5 && ping.portal.open === false, 'ping v5');
ok(/switched off/.test(post({ action: 'student', reg: '24-CS-001', pin: 'ABC234' }).error), 'student refused before pins are published');
ok(post({ action: 'hello' }).open === false, 'hello: closed');
// publish the sample course made by the teacher app's summary builder
const course = JSON.parse(fs.readFileSync('' + (process.argv[2] || '/tmp/claude-0/pt/sample_course1.json') + '', 'utf8'));
const pub = post({ action: 'publish', key: KEY, courseId: course.id, data: JSON.stringify(course) });
ok(pub.ok && pub.rev === 1, 'publish course');
ok(post({ action: 'publish', key: KEY, courseId: '../x', data: '{}' }).ok === false, 'bad course id refused');
const salt = 'a1b2c3d4', regs = Object.keys(course.students), pins = {}, plain = {};
regs.forEach((k, i) => { plain[k] = 'K' + String(23456 + i).slice(-5).replace(/[01]/g, '7'); pins[k] = crypto.createHash('sha256').update(`${salt}|${k}|${plain[k]}`).digest('hex'); });
const pr = post({ action: 'pins', key: KEY, salt, title: 'Lec. Test · HITEC', open: true, pins });
ok(pr.ok && pr.students === regs.length, 'pins published');
const h = post({ action: 'hello' });
ok(h.ok && h.open && h.title === 'Lec. Test · HITEC', 'hello: open with title');
const k0 = regs[0], rec0 = course.students[k0];
reads = 0;
const s1 = post({ action: 'student', reg: rec0.reg.toLowerCase(), pin: plain[k0].toLowerCase() });
ok(s1.ok && s1.courses.length === 1 && s1.courses[0].me.reg === rec0.reg && s1.name === rec0.name, 'student login (case-insensitive reg + PIN)');
ok(typeof s1.token === 'string' && s1.token.startsWith(k0 + '.') && s1.token.length > 60, 'sign-in token returned');
ok(!('students' in s1.courses[0]) && JSON.stringify(s1).indexOf(course.students[regs[1]].name + '"') < 0, 'reply has only this student (no classmates)');
ok(reads === 0, `published data served from cache right after publishing (drive reads ${reads})`);
const s2 = post({ action: 'student', token: s1.token });
ok(s2.ok && s2.courses.length === 1 && s2.name === rec0.name, 'refresh with token (no PIN)');
ok(post({ action: 'student', token: k0 + '.' + '0'.repeat(64) }).expired === true, 'forged token refused');
ok(post({ action: 'student', token: regs[1] + s1.token.slice(k0.length) }).expired === true, "another student's Reg. No with my token refused");
const k1 = regs[1];
for (let i = 0; i < 5; i++) post({ action: 'student', reg: course.students[k1].reg, pin: 'WRONG9' });
ok(/not correct/.test(post({ action: 'student', reg: course.students[k1].reg, pin: 'WRONG9' }).error), '6th wrong PIN still "not correct"');
const locked = post({ action: 'student', reg: course.students[k1].reg, pin: plain[k1] });
ok(locked.locked === true, 'Reg. No locked after 6 wrong PINs (even with the right PIN)');
ok(post({ action: 'student', reg: 'NOSUCH-1', pin: 'ABC234' }).error === 'Reg. No or PIN is not correct.', 'unknown Reg. No: same message');
// republish with a change, cache must not serve stale data
course.students[k0].name = 'Renamed Student';
post({ action: 'publish', key: KEY, courseId: course.id, data: JSON.stringify(course) });
ok(post({ action: 'student', token: s1.token }).name === 'Renamed Student', 'republished data visible (no stale cache)');
// new PIN for k0: old token stops working
const pins2 = Object.assign({}, pins, { [k0]: crypto.createHash('sha256').update(`${salt}|${k0}|NEWPIN23`).digest('hex') });
post({ action: 'pins', key: KEY, salt, title: 'Lec. Test · HITEC', open: true, pins: pins2, keep: [course.id] });
ok(post({ action: 'student', token: s1.token }).expired === true, 'old token refused after a new PIN');
ok(post({ action: 'student', reg: rec0.reg, pin: 'newpin23' }).ok, 'new PIN works');
// ---- student sets an own password
const tok = post({ action: 'student', reg: rec0.reg, pin: 'NEWPIN23' }).token;
ok(post({ action: 'password', token: tok, current: 'WRONGPIN', next: 'mypass123' }).error === 'Your current PIN is not correct.', 'password change needs the current PIN');
ok(/letters and numbers/.test(post({ action: 'password', token: tok, current: 'NEWPIN23', next: 'onlyletters' }).error), 'weak password refused');
ok(/Reg. No/.test(post({ action: 'password', token: tok, current: 'NEWPIN23', next: 'x' + k0.toLowerCase() + '1' }).error), 'password containing the Reg. No refused');
ok(/too easy/.test(post({ action: 'password', token: tok, current: 'NEWPIN23', next: 'Password123' }).error), 'common password refused');
ok(/too easy/.test(post({ action: 'password', token: tok, current: 'NEWPIN23', next: '1234567a' }).error), 'mostly-digits password refused');
const ch = post({ action: 'password', token: tok, current: 'newpin23', next: 'Sunny2026day' });
ok(ch.ok && ch.token && ch.token !== tok, 'password changed, new token');
ok(post({ action: 'student', token: tok }).expired === true, 'old token stops working after the password change');
ok(post({ action: 'student', token: ch.token }).ok, 'new token works');
ok(post({ action: 'student', reg: rec0.reg, pin: 'NEWPIN23' }).error === 'Reg. No or password is not correct.', 'the PIN no longer works');
ok(post({ action: 'student', reg: rec0.reg, pin: 'sunny2026day' }).ok === false, 'password is case-sensitive');
const sp = post({ action: 'student', reg: rec0.reg, pin: 'Sunny2026day' });
ok(sp.ok && sp.own === true, 'own password works');
ok(post({ action: 'password', token: 'x.y', current: 'a', next: 'b' }).expired === true, 'password change without a valid token refused');
// ---- faculty: who has signed in
const lg = post({ action: 'logins', key: KEY });
ok(lg.ok && lg.logins[k0] && lg.logins[k0].n >= 4 && lg.logins[k0].pw === true && lg.logins[k0].f <= lg.logins[k0].l, 'sign-in list: count, times, own-password flag');
ok(!lg.logins[regs[2]], 'students who never signed in are not listed');
ok(post({ action: 'logins', key: 'wrong-key-123456' }).ok === false, 'sign-in list needs the secret key');
// ---- a new PIN from the teacher clears the own password
const pins3 = Object.assign({}, pins2, { [k0]: crypto.createHash('sha256').update(`${salt}|${k0}|RESET777`).digest('hex') });
post({ action: 'pins', key: KEY, salt, title: 'Lec. Test · HITEC', open: true, pins: pins3, keep: [course.id] });
ok(post({ action: 'student', reg: rec0.reg, pin: 'Sunny2026day' }).ok === false, 'own password voided by a new PIN');
const rs = post({ action: 'student', reg: rec0.reg, pin: 'reset777' });
ok(rs.ok && rs.own === false, 'new PIN works again');
ok(post({ action: 'logins', key: KEY }).logins[k0].pw === false, 'sign-in list: own-password flag cleared');
// ---- website dashboard for the teacher
ok(/not turned on/.test(post({ action: 'faculty', password: 'whatever123' }).error), 'faculty dashboard off by default');
ok(post({ action: 'fpass', key: KEY, password: 'short1' }).ok === false, 'short dashboard password refused');
ok(post({ action: 'fpass', key: KEY, password: KEY }).ok === false, 'dashboard password equal to the secret refused');
ok(post({ action: 'fpass', password: 'Dashboard2026' }).error === 'Wrong secret key.', 'setting the dashboard password needs the secret key');
ok(post({ action: 'fpass', key: KEY, password: 'Dashboard2026' }).on === true, 'dashboard password set');
const fc = { v: 1, id: 'cX1', code: 'CS-1', name: 'CS-1 Test', sections: [{ id: 's1', code: 'A', students: [{ reg: '24-CS-001', key: '24CS001', name: 'Test One' }] }] };
ok(post({ action: 'fpublish', key: KEY, courseId: 'cX1', data: JSON.stringify(fc), title: 'Lec. Test' }).ok, 'faculty summary published');
ok(post({ action: 'fpublish', key: KEY, courseId: 'cX2', data: '{"students":{}}' }).ok === false, 'faculty summary without sections refused');
ok(post({ action: 'faculty', password: 'dashboard2026' }).error === 'That dashboard password is not correct.', 'dashboard password is case-sensitive');
const fl = post({ action: 'faculty', password: 'Dashboard2026' });
ok(fl.ok && fl.courses.length === 1 && fl.courses[0].sections[0].students[0].name === 'Test One' && fl.title === 'Lec. Test' && fl.logins && fl.token.startsWith('F.'), 'faculty sign-in returns courses, sign-ins and a token');
ok(post({ action: 'faculty', token: fl.token }).ok, 'faculty token works');
ok(post({ action: 'faculty', token: 'F.' + '0'.repeat(64) }).expired === true, 'forged faculty token refused');
ok(post({ action: 'student', token: fl.token }).expired === true, 'faculty token is not a student token');
post({ action: 'fpass', key: KEY, password: 'Changed2026x' });
ok(post({ action: 'faculty', token: fl.token }).expired === true, 'old faculty token stops working after a password change');
ok(post({ action: 'fsync', key: KEY, keep: [] }).courses === 0 && post({ action: 'faculty', password: 'Changed2026x' }).courses.length === 0, 'fsync removes courses not kept');
for (let i = 0; i < 10; i++) post({ action: 'faculty', password: 'wrong-' + i });
ok(post({ action: 'faculty', password: 'Changed2026x' }).locked === true, 'dashboard locked after 10 wrong passwords');
post({ action: 'fpass', key: KEY, clear: true });
ok(post({ action: 'faculty', password: 'Changed2026x' }).off === true, 'dashboard turned off');
// a bad entry is skipped, not fatal
const pr2 = post({ action: 'pins', key: KEY, salt, title: 'x', open: true, pins: Object.assign({}, pins3, { 'BAD KEY': 'zz' }), keep: [course.id] });
ok(pr2.ok && pr2.skipped === 1, 'malformed PIN entry skipped');
// keep-list: a course missing from it is removed (e.g. deleted while disconnected)
const s3 = (post({ action: 'pins', key: KEY, salt, title: 'x', open: true, pins: pins3, keep: [] }), post({ action: 'student', reg: rec0.reg, pin: 'RESET777' }));
ok(s3.ok && s3.courses.length === 0, 'course not in keep-list removed');
post({ action: 'pins', key: KEY, salt, title: 'x', open: false, pins: {}, keep: [] });
ok(post({ action: 'student', reg: rec0.reg, pin: 'RESET777' }).off === true, 'student app switched off');
const pf = root.kids.find(f => f.name === 'GradesEye student data (private)');
ok(pf && pf.files.filter(f => !f.trashed).map(f => f.name).sort().join(',') === 'passwords.json,pins.json', 'data folder is in the root of My Drive: ' + pf.files.map(f => f.name + (f.trashed ? '(trashed)' : '')).join(', '));
const props0 = JSON.parse(props.portal);
ok(!!props0.tokenKey && Object.keys(props0.courses).length === 0, 'token key kept; no courses left published');
console.log('cache items', cache.size, 'props bytes', byteSize(props.portal));
