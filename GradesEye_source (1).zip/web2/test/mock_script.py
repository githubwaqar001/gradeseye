"""Local stand-in for the Google Apps Script web app (same JSON protocol as apps-script/Code.gs).
POST /exec answers with 302 to /echo?id=... like Google does; GET /echo returns the JSON.
Files live in DIR; 'modified' is the file mtime in ms."""
import base64, hashlib, hmac, json, os, sys, time, uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DIR = sys.argv[2] if len(sys.argv) > 2 else '/tmp/mockdrive'
SECRET = 'test-secret'
os.makedirs(DIR, exist_ok=True)
pending = {}
state = {'online': True, 'calls': []}


def path_of(req, create=False):
    folder = req.get('folderId') or 'root'
    d = os.path.join(DIR, folder, *[p for p in (req.get('path') or []) if p])
    if create: os.makedirs(d, exist_ok=True)
    return os.path.join(d, req.get('name') or 'register.xlsx')


def out(p):
    st = os.stat(p)
    return {'ok': True, 'exists': True, 'fileId': 'id-' + hashlib.md5(p.encode()).hexdigest()[:12], 'name': os.path.basename(p),
            'modified': int(st.st_mtime * 1000), 'url': 'https://drive.google.com/file/d/mock/view', 'size': st.st_size,
            'md5': hashlib.md5(open(p, 'rb').read()).hexdigest()}


VERSION = int(os.environ.get('MOCK_VERSION', '5'))
portal = {'courses': {}, 'pins': None, 'title': '', 'open': False, 'fails': {}, 'tokkey': uuid.uuid4().hex, 'pw': {}, 'logins': {}, 'fdash': None, 'fcourses': {}, 'ffail': 0, 'ftitle': ''}
PDIR = os.path.join(DIR, '_portal'); os.makedirs(PDIR, exist_ok=True)
norm = lambda s: ''.join(ch for ch in str(s or '').upper() if ch.isalnum() and ch.isascii())


def token(reg, cred):
    return reg + '.' + hmac.new(portal['tokkey'].encode(), f'{reg}|{cred}'.encode(), hashlib.sha256).hexdigest()


def pw_hash(salt, reg, pw):
    h = hashlib.sha256(f'{salt}|{reg}|{pw}'.encode()).hexdigest()
    for _ in range(199): h = hashlib.sha256(f'{h}|{salt}'.encode()).hexdigest()
    return h


def own(reg):
    allp = portal['pins']['pins']; e = portal['pw'].get(reg)
    return e if e and reg in allp and e['b'] == allp[reg] else None


def cred(reg):
    o = own(reg); return o['h'] if o else portal['pins']['pins'][reg]


def check_token(t):
    t = str(t or ''); reg = t.split('.', 1)[0] if '.' in t else ''
    return reg if reg and reg in portal['pins']['pins'] and t == token(reg, cred(reg)) else None


def record(reg, sign_in):
    now = int(time.time() * 1000); o = portal['logins'].setdefault(reg, {})
    if sign_in: o['f'] = o.get('f') or now; o['l'] = now; o['n'] = o.get('n', 0) + 1
    o['s'] = now


def student(req):
    a = req.get('action'); state['calls'].append(a)
    if a == 'hello': return {'ok': True, 'version': VERSION, 'title': portal['title'], 'open': bool(portal['open'] and portal['pins'])}
    if not portal['open'] or not portal['pins']: return {'ok': False, 'off': True, 'error': 'The student app is switched off at the moment. Ask your teacher.'}
    allp = portal['pins']['pins']
    if a == 'password':
        reg = check_token(req.get('token'))
        if not reg: return {'ok': False, 'expired': True, 'error': 'Please sign in again with your PIN or password.'}
        o = own(reg); cur = str(req.get('current') or '').strip()
        good = pw_hash(o['s'], reg, cur) == o['h'] if o else hashlib.sha256(f"{portal['pins']['salt']}|{reg}|{norm(cur)}".encode()).hexdigest() == allp[reg]
        if not good: return {'ok': False, 'error': 'Your current password is not correct.' if o else 'Your current PIN is not correct.'}
        nxt = str(req.get('next') or '').strip()
        if len(nxt) < 8: return {'ok': False, 'error': 'Use at least 8 characters.'}
        if not any(ch.isalpha() for ch in nxt) or not any(ch.isdigit() for ch in nxt): return {'ok': False, 'error': 'Use both letters and numbers.'}
        if reg in norm(nxt): return {'ok': False, 'error': 'Do not use your Reg. No in your password.'}
        letters = ''.join(ch for ch in nxt.lower() if 'a' <= ch <= 'z')
        if len(letters) < 3 or letters in ['password', 'passw', 'pass', 'qwerty', 'qwertyuiop', 'asdf', 'zxcvbn', 'abc', 'abcd', 'abcde', 'abcdef', 'iloveyou', 'love', 'pakistan', 'welcome', 'admin', 'letmein', 'hitec', 'student', 'test', 'user', 'computer', 'secret', 'login']: return {'ok': False, 'error': 'That password is too easy to guess. Mix a few words with numbers.'}
        salt = uuid.uuid4().hex; portal['pw'][reg] = {'s': salt, 'h': pw_hash(salt, reg, nxt), 'b': allp[reg], 't': int(time.time() * 1000)}
        return {'ok': True, 'token': token(reg, portal['pw'][reg]['h'])}
    if req.get('token'):
        reg = check_token(req['token'])
        if not reg: return {'ok': False, 'expired': True, 'error': 'Please sign in again with your PIN or password.'}
        sign_in = False
    else:
        reg, given = norm(req.get('reg')), str(req.get('pin') or '').strip()
        if not reg or len(reg) > 40 or not given: return {'ok': False, 'error': 'Enter your Reg. No and your PIN or password.'}
        if portal['fails'].get(reg, 0) >= 6: return {'ok': False, 'locked': True, 'error': 'Too many wrong tries for this Reg. No. Wait 15 minutes and try again.'}
        o = own(reg) if reg in allp else None
        good = reg in allp and (pw_hash(o['s'], reg, given) == o['h'] if o else hashlib.sha256(f"{portal['pins']['salt']}|{reg}|{norm(given)}".encode()).hexdigest() == allp[reg])
        if not good:
            portal['fails'][reg] = portal['fails'].get(reg, 0) + 1
            return {'ok': False, 'error': 'Reg. No or password is not correct.' if o else 'Reg. No or PIN is not correct.'}
        portal['fails'].pop(reg, None); sign_in = True
    courses = []
    for cid, text in portal['courses'].items():
        d = json.loads(text); me = d.get('students', {}).get(reg)
        if not me: continue
        c = {k: v for k, v in d.items() if k != 'students'}; c['me'] = me; courses.append(c)
    record(reg, sign_in)
    first = courses[0]['me'] if courses else None
    return {'ok': True, 'reg': first['reg'] if first else req.get('reg'), 'name': first['name'] if first else '', 'title': portal['title'], 'courses': courses,
            'time': int(time.time() * 1000), 'own': bool(own(reg)), 'token': token(reg, cred(reg))}


def faculty(req):
    state['calls'].append('faculty')
    if not portal['fdash']: return {'ok': False, 'off': True, 'error': 'The website dashboard is not turned on. In the GradesEye app open Drive and app settings → Website dashboard.'}
    ftok = 'F.' + hmac.new(portal['tokkey'].encode(), ('FACULTY|' + portal['fdash']['h']).encode(), hashlib.sha256).hexdigest()
    if req.get('token'):
        if req['token'] != ftok: return {'ok': False, 'expired': True, 'error': 'Please sign in again with your dashboard password.'}
    else:
        if portal['ffail'] >= 10: return {'ok': False, 'locked': True, 'error': 'Too many wrong passwords. Wait 15 minutes and try again.'}
        if pw_hash(portal['fdash']['s'], 'FACULTY', str(req.get('password') or '')) != portal['fdash']['h']:
            portal['ffail'] += 1; return {'ok': False, 'error': 'That dashboard password is not correct.'}
        portal['ffail'] = 0
    lst = {r: dict(o, pw=bool(portal['pins'] and own(r))) for r, o in portal['logins'].items()}
    return {'ok': True, 'token': ftok, 'title': portal['ftitle'] or portal['title'], 'courses': [json.loads(t) for t in portal['fcourses'].values()], 'logins': lst, 'time': int(time.time() * 1000), 'version': VERSION}


def handle(req):
    if req.get('action') in ('hello', 'student', 'password'): return student(req)
    if req.get('action') == 'faculty': return faculty(req)
    if req.get('key') != SECRET: return {'ok': False, 'error': 'Wrong secret key.'}
    a = req.get('action'); state['calls'].append(a)
    p = path_of(req)
    if a == 'ping': return {'ok': True, 'version': VERSION, 'user': 'teacher@example.edu', 'folder': {'id': req.get('folderId') or 'root', 'name': 'Registers'}}
    if a in ('publish', 'unpublish', 'pins') and VERSION < 3: return {'ok': False, 'error': 'Unknown action: ' + a}
    if a in ('fpass', 'fpublish', 'fsync') and VERSION < 5: return {'ok': False, 'error': 'Unknown action: ' + a}
    if a == 'fpass':
        if req.get('clear'): portal['fdash'] = None; return {'ok': True, 'on': False, 'version': VERSION}
        pw = str(req.get('password') or '')
        if len(pw) < 10: return {'ok': False, 'error': 'Use at least 10 characters with letters and numbers for the dashboard password.'}
        salt = uuid.uuid4().hex; portal['fdash'] = {'s': salt, 'h': pw_hash(salt, 'FACULTY', pw)}; portal['ffail'] = 0
        return {'ok': True, 'on': True, 'version': VERSION}
    if a == 'fpublish':
        d = json.loads(req['data']); assert isinstance(d.get('sections'), list)
        portal['fcourses'][req['courseId']] = req['data']; portal['ftitle'] = req.get('title') or portal['ftitle']
        open(os.path.join(PDIR, 'faculty_' + req['courseId'] + '.json'), 'w').write(req['data'])
        return {'ok': True, 'rev': 1, 'version': VERSION}
    if a == 'fsync':
        keep = req.get('keep') or []
        for cid in list(portal['fcourses']):
            if cid not in keep:
                portal['fcourses'].pop(cid, None)
                try: os.remove(os.path.join(PDIR, 'faculty_' + cid + '.json'))
                except OSError: pass
        return {'ok': True, 'courses': len(portal['fcourses']), 'version': VERSION}
    if a == 'logins':
        if VERSION < 4: return {'ok': False, 'error': 'Unknown action: ' + a}
        lst = {r: dict(o, pw=bool(portal['pins'] and own(r))) for r, o in portal['logins'].items()}
        return {'ok': True, 'logins': lst, 'time': int(time.time() * 1000), 'version': VERSION}
    if a == 'publish':
        d = json.loads(req['data']); assert isinstance(d.get('students'), dict)
        portal['courses'][req['courseId']] = req['data']
        open(os.path.join(PDIR, 'course_' + req['courseId'] + '.json'), 'w').write(req['data'])
        return {'ok': True, 'rev': 1, 'version': VERSION}
    if a == 'unpublish':
        portal['courses'].pop(req['courseId'], None)
        try: os.remove(os.path.join(PDIR, 'course_' + req['courseId'] + '.json'))
        except OSError: pass
        return {'ok': True}
    if a == 'pins':
        if isinstance(req.get('keep'), list):
            for cid in list(portal['courses']):
                if cid not in req['keep']:
                    portal['courses'].pop(cid, None)
                    try: os.remove(os.path.join(PDIR, 'course_' + cid + '.json'))
                    except OSError: pass
        portal['pins'] = {'salt': req.get('salt', ''), 'pins': req.get('pins') or {}}; portal['title'] = req.get('title', ''); portal['open'] = bool(req.get('open'))
        open(os.path.join(PDIR, 'pins.json'), 'w').write(json.dumps(portal['pins']))
        return {'ok': True, 'students': len(portal['pins']['pins']), 'version': VERSION}
    if a == 'info': return out(p) if os.path.exists(p) else {'ok': True, 'exists': False}
    if a == 'load':
        if not os.path.exists(p): return {'ok': False, 'error': 'not found'}
        o = out(p); o['data'] = base64.b64encode(open(p, 'rb').read()).decode(); return o
    if a == 'save':
        if os.path.exists(p) and not req.get('force') and hashlib.md5(open(p, 'rb').read()).hexdigest() != (req.get('baseMd5') or ''):
            return {'ok': False, 'conflict': True, 'modified': int(os.stat(p).st_mtime * 1000)}
        p = path_of(req, True)
        open(p, 'wb').write(base64.b64decode(req['data']))
        return out(p)
    return {'ok': False, 'error': 'Unknown action'}


class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def cors(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Headers', '*')

    def do_OPTIONS(self):
        self.send_response(204); self.cors(); self.end_headers()

    def do_GET(self):
        if self.path.startswith('/control'):
            q = self.path.split('?', 1)[1] if '?' in self.path else ''
            if 'online=0' in q: state['online'] = False
            if 'online=1' in q: state['online'] = True
            if 'delay=' in q: state['delay'] = float(q.split('delay=')[1].split('&')[0])
            body = json.dumps(dict(state, portal={'courses': list(portal['courses']), 'open': portal['open'], 'title': portal['title'], 'npins': len((portal['pins'] or {}).get('pins', {})), 'fcourses': list(portal['fcourses']), 'fdash': bool(portal['fdash'])})).encode()
        elif self.path.startswith('/echo'):
            rid = self.path.split('id=')[1]
            body = json.dumps(pending.pop(rid, {'ok': False, 'error': 'expired'})).encode()
        else:
            body = json.dumps({'ok': True, 'app': 'mock'}).encode()
        self.send_response(200); self.cors(); self.send_header('Content-Type', 'application/json'); self.end_headers(); self.wfile.write(body)

    def do_POST(self):
        n = int(self.headers.get('Content-Length', 0)); raw = self.rfile.read(n)
        if not state['online']:
            self.send_response(503); self.cors(); self.end_headers(); return
        try:
            req = json.loads(raw)
            if state.get('delay') and req.get('action') == 'student': time.sleep(state['delay'])
            res = handle(req)
        except Exception as e: res = {'ok': False, 'error': str(e)}
        rid = uuid.uuid4().hex; pending[rid] = res
        self.send_response(302); self.cors(); self.send_header('Location', f'/echo?id={rid}'); self.end_headers()


ThreadingHTTPServer(('127.0.0.1', int(sys.argv[1])), H).serve_forever()
