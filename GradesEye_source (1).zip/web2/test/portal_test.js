import fs from 'fs';
import { emptyState, newSemester, newSection, newCourse, defaultPlan } from '../src/model.js';
import { calc, setMark, isNum } from '../src/engine.js';
import { entryPages } from '../src/layout.js';
import { buildRegister } from '../src/workbook.js';
import { buildCourse, setFlag, studentsOf, normReg, portalOf, ensurePins } from '../src/portal.js';

const OUT = process.argv[2];
let seed = 7; const rnd = () => ((seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648);
const st = emptyState(); st.profile.instructor = 'Lec. Test Teacher';
const sem = newSemester({ dept: 'Department of Computing', program: 'BSCS', batch: '2024', semester: '5th', session: 'Fall 2026', start: '2026-09-07' });
const N = { A: 25, B: 18, C: 12 };
let k = 0;
for (const code of ['A', 'B', 'C']) {
  const x = newSection(code, `BSCS-5${code}`);
  for (let i = 0; i < N[code]; i++) { k++; x.students[i] = { reg: `24-CS-${String(k).padStart(3, '0')}`, name: `Stu ${code}${i + 1}`, rem: '' }; }
  sem.sections.push(x);
}
sem.sections[1].students[N.B + 1] = { reg: '', name: 'No Reg', rem: '' };
st.semesters.push(sem);
const [A, B, C] = sem.sections;
// 1: theory + lab, 3 sections, custom lab group A with C's first student
const c1 = newCourse(sem, { code: 'CS-309', title: 'Web Design & Development', type: 'TL', credit: '3(2+1)', instructor: 'Lec. T' });
c1.labGroups[A.id] = { custom: true, rows: {}, rem: {} };
for (let i = 0; i < N.A; i++) c1.labGroups[A.id].rows[i] = { reg: A.students[i].reg, name: A.students[i].name };
c1.labGroups[A.id].rows[N.A] = { reg: C.students[0].reg, name: C.students[0].name };
c1.labGroups[C.id] = { custom: true, rows: {}, rem: {} };
for (let i = 1; i < N.C; i++) c1.labGroups[C.id].rows[i - 1] = { reg: C.students[i].reg, name: C.students[i].name };
c1.plan.leave = 'Yes'; c1.plan.thr = 0.8;
// 2: theory only, 3 quizzes, 1 assignment, mid 4 Qs, no final
const p2 = defaultPlan('T');
p2.quizzes.items = [{ label: 'Quiz 1', max: 10, week: 3 }, { label: 'Quiz 2', max: 15, week: 7 }, { label: 'Quiz 3', max: 10, week: 12 }];
p2.assignments.items = [{ label: 'Assignment 1', max: 25, week: 6 }];
p2.mid.qs = [10, 10, 5, 5]; p2.final.on = false; p2.quizzes.weight = 0.2; p2.assignments.weight = 0.2; p2.mid.weight = 0.6;
const c2 = newCourse(sem, { code: 'CS-103', title: 'Discrete Structures', type: 'T', credit: '3(3+0)', secIds: [A.id, B.id], plan: p2 });
// 3: lab only: 10 experiments, no reports / lab mid / OEL
const p3 = defaultPlan('L');
p3.lab.exps = 10; p3.lab.reports.on = false; p3.lab.mid.on = false; p3.lab.oel.on = false; p3.lab.perf.marks = 10; p3.lab.final.marks = 10;
const c3 = newCourse(sem, { code: 'CS-106L', title: 'ICT Lab', type: 'L', credit: '1(0+1)', secIds: [B.id, C.id], plan: p3 });
// 4: theory + lab, one section, mixed CLOs and weighted PLOs
const p4 = defaultPlan('TL');
p4.clos = [{ id: 'k1', code: 'CLO-1', kpi: 0.5, desc: 'theory', w: { Q: 0.2, M: 0.3, F: 0.5 } }, { id: 'k2', code: 'CLO-2', kpi: 0.6, desc: 'mixed', w: { A: 0.3, LPERF: 0.4, PROJ: 0.3 } }, { id: 'k3', code: 'CLO-3', kpi: 0.5, desc: 'lab', w: { LREP: 1 } }];
p4.plos = [{ id: 'p1', code: 'PLO-1', kpi: 0.5, desc: '', w: { k1: 0.6, k2: 0.4 } }, { id: 'p2', code: 'PLO-3', kpi: 0.55, desc: '', w: { k3: 1 } }, { id: 'p3', code: 'PLO-5', kpi: 0.5, desc: '', w: { k2: 1 } }];
p4.shares = { T: 0.75, L: 0.25 };
const c4 = newCourse(sem, { code: 'CS-210', title: 'Databases', type: 'TL', credit: '4(3+1)', secIds: [A.id], plan: p4 });
c4.dates.MIDD = '2026-11-03';
c4.schedule.dates[`${A.id}|lec|3`] = '2026-09-25';
st.courses.push(c1, c2, c3, c4);
const { calc: _ } = { calc };
for (const c of st.courses) {
  const R = calc(st, c), Lo = R.Lo;
  for (const p of entryPages(Lo)) for (const s of Lo.secs) {
    const ros = p.sec ? R.sec[s.id].roster : R.lab[s.id].roster;
    const cols = p.kind === 'att' ? Array.from({ length: Lo.weeks }, () => ({})) : p.comp.cols;
    const heldN = p.kind === 'att' ? 9 : p.kind === 'exp' ? (s.code === 'B' ? 0 : p.comp.crit.length * 6) : p.id === 'Final Exam' ? (s.code === 'A' ? cols.length : 0) : p.id === 'Quizzes' ? 2 : p.id === 'Project' ? (s.code === 'B' ? 4 : cols.length) : cols.length;
    ros.forEach((x, r) => { if (!x.name) return; for (let ci = 0; ci < Math.min(heldN, cols.length); ci++) {
      if (rnd() < 0.05) continue;
      if (p.kind === 'att') setMark(c, s.id, p.id, r, ci, ['P', 'P', 'P', 'A', 'L'][Math.floor(rnd() * 5)]);
      else setMark(c, s.id, p.id, r, ci, Math.round(rnd() * cols[ci].max * 2) / 2);
    } });
  }
}

const checks = [], summary = [];
for (const [ci, c] of st.courses.entries()) {
  setFlag(st, c.id, 'release', true);
  const { wb, meta } = buildRegister(st, c);
  const fname = `${OUT}/pcourse${ci + 1}.xlsx`;
  fs.writeFileSync(fname, await wb.build('nodebuffer'));
  const P = buildCourse(st, c), Lo = calc(st, c).Lo;
  const text = JSON.stringify(P);
  const exp = [], problems = [];
  const put = (sheet, ref, v) => exp.push([sheet, ref, isNum(v) || typeof v === 'string' ? v : '']);
  const list = studentsOf(st, c);
  let n = 0;
  for (const x of list) {
    if (!x.key) { if (Object.values(P.students).some(r => r.name === x.name)) problems.push('student without Reg. No published: ' + x.name); continue; }
    const rec = P.students[x.key]; n++;
    if (!rec || rec.name !== x.name) { problems.push('missing ' + x.reg); continue; }
    const F = meta.FINAL[x.secId], sn = F.sheet.replace(/^'|'$/g, ''), row = 8 + x.r;
    for (const a of rec.att) {
      if (a.none) continue;
      const p = a.days.filter(d => d[1] === 'P').length, l = a.days.filter(d => d[1] === 'L').length;
      if (p !== a.P || l !== a.L || a.days.length !== a.held) problems.push(`days mismatch ${x.reg} ${a.k}`);
      put(sn, `${F.FC[a.k === 'Theory' ? 'tattp' : 'lattp']}${row}`, a.pct);
    }
    for (const g of rec.marks) {
      const comp = Lo.comps.find(cc => cc.title === g.k);
      if (comp.sec) put(sn, `${F.FC['th|' + comp.id]}${row}`, g.kind === 'items' ? (g.tot ? g.tot.g : '') : g.items.length ? (g.items[0].g === null ? 0 : g.items[0].g) : '');
      else put(sn, `${F.FC['lab|' + comp.id]}${row}`, g.sc ? g.sc.g : '');
    }
    const r = rec.res;
    put(sn, `${F.FC.ct}${row}`, r.ct); put(sn, `${F.FC.grade}${row}`, r.grade);
    if (Lo.T) put(sn, `${F.FC.thpct}${row}`, r.th);
    if (Lo.L && Lo.labComps.length) put(sn, `${F.FC.labtot}${row}`, r.lab.g);
  }
  checks.push({ file: fname, exp });
  summary.push({ code: c.code, students: n, published: Object.keys(P.students).length, kb: Math.round(text.length / 102.4) / 10, problems });
  if (ci === 0) fs.writeFileSync(`${OUT}/sample_course1.json`, JSON.stringify(P, null, 1));
}
// PINs: unique per Reg. No, same across courses
const added = ensurePins(st, st.courses), pins = portalOf(st).pins;
const pinOk = Object.values(pins).every(p => /^[2-9A-HJKMNP-Z]{8}$/.test(p));
console.log(JSON.stringify(summary, null, 1));
console.log('pins added', added, 'count', Object.keys(pins).length, 'format ok', pinOk, 'distinct', new Set(Object.values(pins)).size);
fs.writeFileSync(`${OUT}/checks.json`, JSON.stringify(checks));
