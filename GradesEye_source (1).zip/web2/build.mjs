// Bundle the web app into one self-contained dist/index.html (CSS + JS + template inline) for the APK's assets.
import * as esbuild from 'esbuild';
import fs from 'fs';

const wkr = await esbuild.build({ entryPoints: ['src/worker.js'], bundle: true, write: false, format: 'iife', target: ['chrome64'], minify: true, legalComments: 'none', loader: { '.json': 'json' } });
fs.writeFileSync('src/worker_code.gen.js', 'export default ' + JSON.stringify(wkr.outputFiles[0].text) + ';\n');
const r = await esbuild.build({
  entryPoints: ['src/main.js'], bundle: true, write: false, format: 'iife', target: ['chrome64'],
  minify: true, legalComments: 'none', loader: { '.json': 'json', '.gs': 'text' },
});
const js = r.outputFiles[0].text.replace(/<\/script/gi, '<\\/script');
const html = fs.readFileSync('src/index.html', 'utf8').replace('<script>/*APP*/</script>', () => `<script>${js}</script>`);
fs.mkdirSync('../dist2', { recursive: true });
fs.writeFileSync('../dist2/index.html', html);
console.log('dist2/index.html', (html.length / 1024).toFixed(0), 'KB');
