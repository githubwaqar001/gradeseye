// Which pages and columns a course register has, derived from its plan. Shared by the engine, the Excel
// generator and the screens, so all three always agree.
import { NROW, semOf } from './model.js';

export const LAB_ORDER = ['LPERF', 'LREP', 'LFIN', 'LMID', 'OEL', 'PROJ'];      // order of the Lab Total columns
export const COMP_NAMES = { Q: 'Quizzes', A: 'Assignments', M: 'Mid exam', F: 'Final exam', LPERF: 'Lab performance', LREP: 'Lab reports', LMID: 'Lab mid', LFIN: 'Lab final', OEL: 'OEL viva', PROJ: 'Project' };
export const MARK_KEY = { LPERF: 'M_PERF', LREP: 'M_REP', LMID: 'M_LMID', LFIN: 'M_LFIN', OEL: 'M_OEL', PROJ: 'M_PROJ' };
export const WEIGHT_KEY = { Q: 'W_Q', A: 'W_A', M: 'W_M', F: 'W_F' };

export function layout(c, sem) {
  const P = c.plan, T = c.type !== 'L', L = c.type !== 'T';
  const secs = c.secIds.map(id => sem.sections.find(x => x.id === id)).filter(Boolean);
  const comps = [];
  const items = (id, page, title, short, color, list, weight) => comps.push({
    id, page, title, short, kind: 'items', sec: true, color, weight,
    cols: list.map((it, i) => ({ label: it.label || `${short} ${i + 1}`, max: Number(it.max) || 0, maxKey: `${id}|${i}`, week: Number(it.week) || 1 })),
  });
  const exam = (id, page, title, short, color, x) => comps.push({
    id, page, title, short, kind: 'exam', sec: true, color, weight: Number(x.weight) || 0, week: Number(x.week) || 1, dateKey: id === 'M' ? 'MIDD' : 'FIND',
    cols: x.qs.map((m, i) => ({ label: `Q${i + 1}`, max: Number(m) || 0, maxKey: `${id}|${i}` })),
  });
  if (T) {
    if (P.quizzes.items.length) items('Q', 'Quizzes', 'Quizzes', 'Quiz', '#C00000', P.quizzes.items, Number(P.quizzes.weight) || 0);
    if (P.assignments.items.length) items('A', 'Assignments', 'Assignments', 'Assignment', '#7030A0', P.assignments.items, Number(P.assignments.weight) || 0);
    if (P.mid.on && P.mid.qs.length) exam('M', 'Mid Exam', 'Mid-Term Exam', 'Mid exam', '#2F5597', P.mid);
    if (P.final.on && P.final.qs.length) exam('F', 'Final Exam', 'Final Exam', 'Final exam', '#833C0B', P.final);
  }
  if (L) {
    const lb = P.lab, n = Number(lb.exps) || 0;
    const exp = (id, page, title, x, color) => {
      const cols = [];
      for (let e = 1; e <= n; e++) x.crit.forEach(([ab, lab, mx], j) => cols.push({ label: ab, long: lab, max: Number(mx) || 0, maxKey: `${id}|${j}`, exp: e, j }));
      comps.push({ id, page, title, short: COMP_NAMES[id], kind: 'exp', sec: false, color, marks: Number(x.marks) || 0, crit: x.crit, exps: n, cols });
    };
    const single = (id, page, title, x, color) => comps.push({
      id, page, title, short: COMP_NAMES[id], kind: 'single', sec: false, color, marks: Number(x.marks) || 0, week: Number(x.week) || 1, crit: x.crit,
      cols: x.crit.map(([ab, lab, mx], j) => ({ label: lab, short: ab, max: Number(mx) || 0, maxKey: `${id}|${j}` })),
    });
    if (lb.perf.on && n) exp('LPERF', 'Lab Perf', 'Lab Performance', lb.perf, '#5B9BD5');
    if (lb.reports.on && n) exp('LREP', 'Lab Reports', 'Lab Reports', lb.reports, '#9E7BC4');
    if (lb.mid.on) single('LMID', 'Lab Mid', 'Lab Mid Exam', lb.mid, '#2F5597');
    if (lb.final.on) single('LFIN', 'Lab Final', 'Lab Final Exam', lb.final, '#833C0B');
    if (lb.oel.on) single('OEL', 'OEL', 'Open-Ended Lab', lb.oel, '#B45F06');
    if (lb.project.on) {
      const pr = lb.project;
      comps.push({
        id: 'PROJ', page: 'Project', title: 'Project', short: 'Project', kind: 'project', sec: false, color: '#1F7A5A', marks: Number(pr.marks) || 0, week: Number(pr.week) || 1,
        des: { scale: Number(pr.des.scale) || 0, crit: pr.des.crit }, viva: { scale: Number(pr.viva.scale) || 0, crit: pr.viva.crit },
        cols: [...pr.des.crit.map(([ab, lab, mx], j) => ({ label: lab, short: ab, max: Number(mx) || 0, maxKey: `PROJD|${j}`, block: 'des' })),
          ...pr.viva.crit.map(([ab, lab, mx], j) => ({ label: lab, short: ab, max: Number(mx) || 0, maxKey: `PROJV|${j}`, block: 'viva' }))],
      });
    }
  }
  const byId = Object.fromEntries(comps.map(x => [x.id, x]));
  const theory = comps.filter(x => x.sec), labComps = LAB_ORDER.map(id => byId[id]).filter(Boolean);
  const clos = (P.clos || []).map(k => ({ ...k, w: Object.fromEntries(Object.entries(k.w || {}).filter(([id, w]) => byId[id] && Number(w) > 0)) }));
  const cloIds = new Set(clos.map(k => k.id));
  const plos = (P.plos || []).map(p => ({ ...p, w: Object.fromEntries(Object.entries(p.w || {}).filter(([id, w]) => cloIds.has(id) && Number(w) > 0)) }));
  const usedComps = comps.filter(x => clos.some(k => k.w[x.id]));
  const pages = [];
  if (T) pages.push({ id: 'Theory Att', title: 'Theory Attendance', kind: 'att', att: 'lec', sec: true, group: 'Attendance' });
  if (L) pages.push({ id: 'Lab Att', title: 'Lab Attendance', kind: 'att', att: 'lab', sec: false, group: 'Attendance' });
  for (const x of comps) pages.push({ id: x.page, title: x.title, kind: x.kind, sec: x.sec, comp: x, group: x.sec ? 'Theory assessments' : 'Lab assessments' });
  if (L && labComps.length) pages.push({ id: 'Lab Total', title: 'Lab Total', kind: 'labtotal', sec: false, group: 'Totals, outcomes and result' });
  if (clos.length) pages.push({ id: 'CLO', title: 'CLO Sheet', kind: 'clo', sec: true, group: 'Totals, outcomes and result' });
  if (plos.length) pages.push({ id: 'PLO', title: 'PLO Sheet', kind: 'plo', sec: true, group: 'Totals, outcomes and result' });
  pages.push({ id: 'Final Sheet', title: 'Final Sheet', kind: 'final', sec: true, group: 'Totals, outcomes and result' });
  const labTotalMax = labComps.reduce((a, x) => a + x.marks, 0);
  return { T, L, secs, comps, byId, theory, labComps, clos, plos, usedComps, pages, page: Object.fromEntries(pages.map(p => [p.id, p])), weeks: Number(sem.weeks) || 16, labTotalMax, nrow: NROW };
}

// fingerprint of everything that decides where cells are in the workbook
export function layoutSig(c, sem) {
  const P = c.plan, lb = P.lab;
  const parts = [c.type, (sem.weeks || 16), c.secIds.map(id => { const s = sem.sections.find(x => x.id === id); return s ? s.code : '?'; }).join(','),
    P.quizzes.items.length, P.assignments.items.length, P.mid.on ? P.mid.qs.length : 0, P.final.on ? P.final.qs.length : 0,
    c.type !== 'T' ? [lb.exps, lb.perf.on && lb.perf.crit.length, lb.reports.on && lb.reports.crit.length, lb.mid.on && lb.mid.crit.length, lb.final.on && lb.final.crit.length, lb.oel.on && lb.oel.crit.length,
      lb.project.on && `${lb.project.des.crit.length}/${lb.project.viva.crit.length}`].join(':') : '-',
    P.grades.length, (P.clos || []).map(k => k.id).join(','), (P.plos || []).map(p => p.id).join(',')];
  const s = JSON.stringify(parts);
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
  return h.toString(36);
}

export const entryPages = Lo => Lo.pages.filter(p => ['att', 'items', 'exam', 'exp', 'single', 'project'].includes(p.kind));
export function entryCols(Lo, page) {
  const p = Lo.page[page];
  if (!p) return [];
  if (p.kind === 'att') return Array.from({ length: Lo.weeks }, (_, w) => ({ label: `Week ${w + 1}`, week: w + 1 }));
  return p.comp ? p.comp.cols : [];
}
export { semOf };
