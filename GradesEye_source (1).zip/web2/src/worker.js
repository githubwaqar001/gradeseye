// Background worker: builds a course workbook without blocking the screen.
import { buildXlsx } from './workbook.js';
self.onmessage = async e => {
  const { id, state, courseId } = e.data;
  try {
    const c = state.courses.find(x => x.id === courseId);
    const bytes = await buildXlsx(state, c, 'uint8array');
    self.postMessage({ id, bytes }, [bytes.buffer]);
  } catch (err) {
    self.postMessage({ id, error: String((err && err.message) || err) });
  }
};
