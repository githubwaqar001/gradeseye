// Builds the Excel register of one course from its plan (port of the Python builder, generalised):
// Home, Settings, Schedule, Section Results, Students, Lab Groups and, per section, attendance, every assessment,
// Lab Total, CLO and PLO sheets with charts and the combined Final Sheet. Returns the workbook and the input-cell map.
import { Workbook, colName as L, colNum as CI, qs } from './xlsxwriter.js';
import { NROW, FIRST, DAYS, PALETTE, TINTS, semOf, courseLabel, semesterLabel } from './model.js';
import { layout, layoutSig, LAB_ORDER, MARK_KEY, WEIGHT_KEY } from './layout.js';
import { parseISO, getMark, activity } from './engine.js';

const LAST = FIRST + NROW - 1;
const NAVY = '1F3864', LIGHT = 'D9E2F3', GREY = 'F2F2F2', YELLOW = 'FFF2CC', MAXF = 'E2EFDA', BLUE = '0000FF';
const WEEKFILL = ['FFFFFF', 'EEF3FA'];
const C = { h: 'center', v: 'center', wrap: true }, LFT = { h: 'left', v: 'center', wrap: true }, RGT = { h: 'right', v: 'center' };
const toSerial = iso => parseISO(iso) / 86400000 + 25569;
const hex = c => String(c).replace('#', '');

function st({ bg, fg = '000000', b = false, sz = 9, align = C, fmt, border = true, i = false }) {
  return { font: { b, i, sz, color: fg }, fill: bg || null, border: border ? 'A6B4C8' : null, align, fmt };
}
function val(v) { return typeof v === 'string' && v.startsWith('=') ? { f: v.slice(1) } : v; }
const SID = new WeakMap();
function cell(ws, r, c, v, bg, fg = '000000', bold = false, size = 9, align = C, fmt, border = true, italic = false) {
  let m = SID.get(ws.wb); if (!m) { m = new Map(); SID.set(ws.wb, m); }
  const k = `${bg}|${fg}|${bold}|${size}|${align === C ? 'C' : align === LFT ? 'L' : align === RGT ? 'R' : JSON.stringify(align)}|${fmt}|${border}|${italic}`;
  let id = m.get(k);
  if (id === undefined) { id = ws.wb.styles.id(st({ bg, fg, b: bold, sz: size, align, fmt, border, i: italic })); m.set(k, id); }
  ws.setId(r, c, val(v), id);
}
function text(ws, r, c, v, font = {}) { ws.set(r, c, val(v), { font: { sz: 10, ...font }, align: font.align }); }
function note(ws, r, c, t, size = 9) { ws.set(r, c, t, { font: { i: true, color: '595959', sz: size } }); }
const bar = (color, max = 1) => ({ type: 'bar', color, max });
const eq = (value, dxf) => ({ type: 'eq', value, dxf });
const OKD = { fill: 'C6EFCE', color: '006100' }, BADD = { fill: 'FFC7CE', color: '9C0006', b: true };

export function buildRegister(state, course) {
  const sem = semOf(state, course), Lo = layout(course, sem), P = course.plan;
  const wb = new Workbook();
  wb.props = { title: `${courseLabel(course)} — ${semesterLabel(sem)}`, creator: state.profile.instructor || 'GradesEye' };
  const TITLE = courseLabel(course), SESSION = sem.session || '';
  const secs = Lo.secs, TAB = {}, TINT = {};
  secs.forEach((s, i) => { TAB[s.id] = hex(PALETTE[i % PALETTE.length]); TINT[s.id] = hex(TINTS[i % TINTS.length]); });
  const map = { settings: {}, sections: {}, grades: null, max: {}, clos: {}, cloW: {}, plos: {}, ploW: {}, schedule: { cols: {} }, roster: {}, entries: {}, labCustom: {} };

  // ==================================================================== Settings
  const S = wb.add('Settings');
  S.grid = false;
  [[1, 3], [2, 46], [3, 14], [4, 18], [5, 18], [6, 12], [7, 12], [8, 3], [9, 46], [10, 12], [11, 12], [12, 12], [13, 12], [14, 12]].forEach(([c, w]) => S.width(c, w));
  text(S, 1, 2, `${TITLE} — Settings`, { sz: 15, b: true, color: NAVY });
  text(S, 2, 2, `${semesterLabel(sem)} · ${sem.dept || ''} · ${state.profile.university || ''} · yellow cells are inputs`, { color: '595959' });
  text(S, 5, 2, 'How to use this workbook', { sz: 11, b: true, color: NAVY });
  const howto = [
    '1. Home lists every sheet as a button; every sheet has a  ⌂ Home  button. This sheet holds dates, weights, maximum marks, the grade scale and the CLO/PLO set-up.',
    '2. Students lists each section (up to 100). Lab Groups copies them; a lab group can also have its own list. Lab results reach each student by Reg. No.',
    '3. Each section has one sheet per assessment; Lab Total, CLO and PLO sheets and the Final Sheet combine them. Section Results compares the sections.',
    '4. An assessment counts once any student has marks in it, so totals and percentages show the current standing during the semester.',
    '5. Grey cells are formulas. This file is kept in step with the GradesEye app (© 2026 softonicBank Co.): the app writes its data here and loads changes typed here on its next sync.',
  ];
  howto.forEach((t, i) => { S.set(6 + i, 2, t, { font: { sz: 10 }, align: LFT }); S.merge(6 + i, 2, 6 + i, 11); S.height(6 + i, 27); });
  const CFG = {};
  const title = (r, c, t) => text(S, r, c, t, { sz: 11, b: true, color: NAVY });
  const table = (r, col, headers, rows) => {
    headers.forEach((h, j) => cell(S, r, col + j, h, NAVY, 'FFFFFF', true, 10));
    r++;
    for (const [lab, v, fmt, key, nt] of rows) {
      const tot = key && key.endsWith('TOTAL');
      cell(S, r, col, lab, tot ? LIGHT : null, '000000', tot, 10, LFT);
      cell(S, r, col + 1, v, tot ? GREY : YELLOW, tot ? '000000' : BLUE, true, 10, C, fmt);
      if (key) { CFG[key] = `Settings!$${L(col + 1)}$${r}`; if (!tot) map.settings[key] = `${L(col + 1)}${r}`; }
      if (nt) note(S, r, col + 2, nt);
      if (tot && fmt === '0%') S.addCF(`${L(col + 1)}${r}`, { type: 'expr', formula: `ROUND(${L(col + 1)}${r},4)<>1`, dxf: BADD });
      r++;
    }
    return r + 1;
  };
  title(13, 2, 'General settings');
  const startRow = 15;
  const gen = [['Week 1 starts on (Monday)', toSerial(sem.start), 'dd-mmm-yyyy', 'START', 'Monday of the first teaching week.'],
    ['Minimum attendance (theory and lab)', Number(P.thr), '0%', 'THR', 'University rule: 75%.'],
    ['Count Leave (L) as present? (Yes / No)', P.leave || 'No', '@', 'LEAVE', 'Yes = approved leave does not lower the percentage.']];
  const exams = Lo.theory.filter(x => x.kind === 'exam');
  for (const x of exams) gen.push([`Theory ${x.id === 'M' ? 'mid-term' : 'final'} exam date`, course.dates[x.dateKey] ? toSerial(course.dates[x.dateKey]) : `=C${startRow}+7*${x.week - 1}`, 'dd-mmm-yyyy', x.dateKey, `Default: Monday of week ${x.week}.`]);
  const wkKeys = { LMID: ['WK_LMID', 'Lab mid exam — in week'], OEL: ['WK_OEL', 'Open-ended lab (OEL) — in week'], PROJ: ['WK_PROJ', 'Project evaluation — in week'], LFIN: ['WK_LFIN', 'Lab final exam — in week'] };
  for (const id of ['LMID', 'OEL', 'PROJ', 'LFIN']) if (Lo.byId[id]) gen.push([wkKeys[id][1], Lo.byId[id].week, '0', wkKeys[id][0], 'Date = that week\'s lab day of each lab group.']);
  let r = table(14, 2, ['Setting', 'Value'], gen);
  S.addDV(map.settings.LEAVE, { type: 'list', f1: '"Yes,No"' });
  const wkCells = ['WK_LMID', 'WK_OEL', 'WK_PROJ', 'WK_LFIN'].filter(k => map.settings[k]).map(k => map.settings[k]);
  if (wkCells.length) S.addDV(wkCells.join(' '), { type: 'whole', op: 'between', f1: '1', f2: String(Lo.weeks) });
  title(r, 2, 'Sections (days after Monday: 0 = Mon, 1 = Tue, 2 = Wed, 3 = Thu, 4 = Fri, 5 = Sat)');
  r++;
  ['Section', 'Name', 'Theory instructor', 'Lab instructor', 'Lecture day', 'Lab day'].forEach((h, j) => cell(S, r, 2 + j, h, NAVY, 'FFFFFF', true, 10));
  const SECROW = {};
  secs.forEach((s, i) => {
    const rr = r + 1 + i, x = course.sec[s.id] || {};
    SECROW[s.id] = rr; map.sections[s.id] = rr;
    cell(S, rr, 2, `Section ${s.code}`, LIGHT, '000000', true, 10);
    [s.name || s.code, x.inst || '', x.labInst || '', Number(x.lec) || 0, Number(x.lab) || 0].forEach((v, j) => cell(S, rr, 3 + j, v, YELLOW, BLUE, false, 10, j >= 3 ? C : LFT));
  });
  S.addDV(`F${r + 1}:G${r + secs.length}`, { type: 'whole', op: 'between', f1: '0', f2: '6' });
  const SECNAME = s => `Settings!$C$${SECROW[s.id]}`, SECINST = s => `Settings!$D$${SECROW[s.id]}`, LABINST = s => `Settings!$E$${SECROW[s.id]}`;
  r += secs.length + 2;
  if (Lo.theory.length) {
    title(r, 2, 'Theory weights (must add up to 100%)');
    const rows = Lo.theory.map(x => [x.title, x.weight, '0.0%', WEIGHT_KEY[x.id], '']);
    const first = r + 2;
    r = table(r + 1, 2, ['Component', 'Weight'], [...rows, ['Theory total', `=SUM(C${first}:C${first + rows.length - 1})`, '0%', 'W_TTOTAL', '']]);
  }
  if (Lo.T && Lo.L) {
    title(r, 2, 'Course weights (must add up to 100%)');
    const first = r + 2;
    r = table(r + 1, 2, ['Component', 'Weight'], [['Theory share', Number(P.shares.T), '0.0%', 'SH_T', course.credit || ''], ['Lab share', Number(P.shares.L), '0.0%', 'SH_L', ''], ['Course total', `=SUM(C${first}:C${first + 1})`, '0%', 'SH_TOTAL', '']]);
  }
  if (Lo.labComps.length) {
    title(r, 2, `Lab total — marks of each lab component`);
    const rows = Lo.labComps.map(x => [x.title, x.marks, '0.##', MARK_KEY[x.id], '']);
    const first = r + 2;
    r = table(r + 1, 2, ['Component', 'Marks'], [...rows, ['Lab total', `=SUM(C${first}:C${first + rows.length - 1})`, '0.##', 'M_TOTAL', '']]);
  }
  if (Lo.byId.PROJ) {
    title(r, 2, 'Project — inside its marks');
    r = table(r + 1, 2, ['Part', 'Scaled to'], [['Project design', Lo.byId.PROJ.des.scale, '0.##', 'P_DES', 'Project = (design + viva) / (design + viva scale) × project marks'], ['Project viva', Lo.byId.PROJ.viva.scale, '0.##', 'P_VIVA', '']]);
  }
  const LEFT_END = r;
  // right column: grade scale and maximum marks
  title(13, 9, 'Grade scale (from %)');
  ['Grade from %', 'Grade', 'Grade point'].forEach((h, j) => cell(S, 14, 9 + j, h, NAVY, 'FFFFFF', true, 10));
  P.grades.forEach(([m, g, gp], i) => { const rr = 15 + i; cell(S, rr, 9, Number(m), YELLOW, BLUE, false, 10); cell(S, rr, 10, g, YELLOW, BLUE, true, 10); cell(S, rr, 11, Number(gp), YELLOW, BLUE, false, 10, C, '0.00'); });
  const G0 = 15, G1 = 15 + P.grades.length - 1;
  map.grades = { first: G0, n: P.grades.length };
  const GMIN = `Settings!$I$${G0}:$I$${G1}`, GNAME = `Settings!$J$${G0}:$J$${G1}`;
  note(S, G1 + 1, 9, 'Keep the rows in ascending order.');
  const MAX = {};
  let rr = G1 + 3;
  if (Lo.theory.length) {
    title(rr, 9, 'Maximum marks — theory'); rr++;
    cell(S, rr, 9, 'Assessment: item', NAVY, 'FFFFFF', true, 10); cell(S, rr, 10, 'Max', NAVY, 'FFFFFF', true, 10);
    for (const x of Lo.theory) for (const col of x.cols) { rr++; MAX[col.maxKey] = `Settings!$J$${rr}`; map.max[col.maxKey] = `J${rr}`; cell(S, rr, 9, `${x.title}: ${col.label}`, null, '000000', false, 10, LFT); cell(S, rr, 10, col.max, YELLOW, BLUE, true, 10, C, '0.##'); }
    rr += 2;
  }
  if (Lo.labComps.length) {
    title(rr, 9, 'Maximum marks — lab rubric'); rr++;
    cell(S, rr, 9, 'Assessment: criterion', NAVY, 'FFFFFF', true, 10); cell(S, rr, 10, 'Max', NAVY, 'FFFFFF', true, 10);
    for (const x of Lo.labComps) {
      const parts = x.kind === 'project' ? [...x.des.crit.map((c, j) => [`PROJD|${j}`, 'Project design', c]), ...x.viva.crit.map((c, j) => [`PROJV|${j}`, 'Project viva', c])]
        : x.crit.map((c, j) => [`${x.id}|${j}`, x.kind === 'exp' ? `${x.title} (each exp.)` : x.title, c]);
      for (const [key, nm, c] of parts) { rr++; MAX[key] = `Settings!$J$${rr}`; map.max[key] = `J${rr}`; cell(S, rr, 9, `${nm}: ${c[1]}`, null, '000000', false, 10, LFT); cell(S, rr, 10, Number(c[2]) || 0, YELLOW, BLUE, true, 10, C, '0.##'); }
    }
    rr += 2;
  }
  // outcomes and their weights (below both columns)
  r = Math.max(LEFT_END, rr) + 1;
  const OUT = {};
  const outTable = (list, label, kind) => {
    title(r, 2, label);
    ['Outcome', 'Code', 'KPI', 'Description'].forEach((h, j) => cell(S, r + 1, 2 + j, h, NAVY, 'FFFFFF', true, 10));
    S.merge(r + 1, 5, r + 1, 11);
    list.forEach((k, i) => {
      const row = r + 2 + i;
      cell(S, row, 2, `${kind} ${i + 1}`, null, '000000', false, 10, LFT);
      cell(S, row, 3, k.code, YELLOW, BLUE, true, 10); cell(S, row, 4, Number(k.kpi), YELLOW, BLUE, true, 10, C, '0%');
      cell(S, row, 5, k.desc || '', YELLOW, BLUE, false, 9, LFT); S.merge(row, 5, row, 11);
      OUT[k.id] = { code: `Settings!$C$${row}`, kpi: `Settings!$D$${row}` };
      (kind === 'CLO' ? map.clos : map.plos)[k.id] = row;
    });
    r += list.length + 3;
  };
  const W = {};
  // weights grid: one row per assessment (or CLO), one column per outcome, totals underneath
  const matrix = (list, rowsDef, rowHead, label, mapKey) => {
    title(r, 2, label);
    cell(S, r + 1, 2, rowHead, NAVY, 'FFFFFF', true, 10);
    list.forEach((k, j) => cell(S, r + 1, 3 + j, `=${OUT[k.id].code}`, NAVY, 'FFFFFF', true, 10));
    rowsDef.forEach(([id, h], i) => {
      const row = r + 2 + i;
      cell(S, row, 2, h, LIGHT, '000000', true, 10, LFT);
      list.forEach((k, j) => {
        const w = Number(k.w[id]) || 0;
        cell(S, row, 3 + j, w || null, YELLOW, BLUE, true, 10, C, '0%');
        W[`${k.id}|${id}`] = `Settings!$${L(3 + j)}$${row}`; mapKey[`${k.id}|${id}`] = `${L(3 + j)}${row}`;
      });
    });
    const tr = r + 2 + rowsDef.length;
    cell(S, tr, 2, 'Total (each column should be 100%)', GREY, '000000', true, 10, LFT);
    list.forEach((k, j) => {
      const cl = L(3 + j);
      cell(S, tr, 3 + j, `=SUM(${cl}${r + 2}:${cl}${tr - 1})`, GREY, '000000', true, 10, C, '0%');
      S.addCF(`${cl}${tr}`, { type: 'expr', formula: `ROUND(${cl}${tr},4)<>1`, dxf: BADD });
    });
    if (list.length > 5) S.width(8, 12);
    r = tr + 2;
  };
  if (Lo.clos.length) {
    outTable(Lo.clos, 'Course learning outcomes (CLOs)', 'CLO');
    matrix(Lo.clos, Lo.comps.map(x => [x.id, x.title]), 'Assessment', 'CLO weights — share of each assessment in each CLO', map.cloW);
  }
  if (Lo.plos.length) {
    outTable(Lo.plos, 'Programme learning outcomes (PLOs)', 'PLO');
    matrix(Lo.plos, Lo.clos.map(k => [k.id, `=${OUT[k.id].code}`]), 'CLO', 'PLO weights — share of each CLO in each PLO', map.ploW);
  }
  note(S, r, 2, 'Weights, KPIs and outcome codes are editable. A blank weight counts as 0.');
  S.print = { orient: 'portrait', paper: 9, fitW: 1, fitH: 0 };
  S.set(1, 26, `layout:${layoutSig(course, sem)}`, { font: { sz: 7, color: 'BFBFBF' } });   // structure fingerprint (do not edit)
  map.sig = layoutSig(course, sem);

  // ==================================================================== Schedule
  const SC = wb.add('Schedule');
  SC.grid = false;
  text(SC, 1, 1, `${TITLE} — ${Lo.weeks}-week Schedule`, { sz: 14, b: true, color: NAVY });
  text(SC, 2, 1, 'Dates are formulas from Settings (week 1 Monday and each section\'s lecture/lab day) — overwrite any date that differs, e.g. a holiday.', { color: '595959' });
  SC.width(1, 3); SC.width(2, 10);
  const DATECOL = {};
  let col = 3;
  const hdr = [['Week', NAVY]];
  for (const s of secs) {
    DATECOL[s.id] = {};
    if (Lo.T) { DATECOL[s.id].lec = L(col); hdr.push([`${s.code} Lecture`, TAB[s.id]]); SC.width(col, 13); col++; }
    if (Lo.L) { DATECOL[s.id].lab = L(col); hdr.push([`${s.code} Lab`, TAB[s.id]]); SC.width(col, 13); col++; }
  }
  const ACTC = col, NOTEC = col + 1;
  SC.width(ACTC, 44); SC.width(NOTEC, 28);
  hdr.push(['Lab experiment / activity', NAVY], ['Notes', NAVY]);
  hdr.forEach(([h, bg], j) => cell(SC, 5, 2 + j, h, bg, 'FFFFFF', true, 10));
  const SCH0 = 6;
  map.schedule = { first: SCH0, cols: DATECOL, activity: L(ACTC), notes: L(NOTEC) };
  for (let w = 1; w <= Lo.weeks; w++) {
    const row = SCH0 + w - 1, bg = WEEKFILL[w % 2];
    cell(SC, row, 2, `Week ${w}`, bg, '000000', false, 10);
    for (const s of secs) for (const kind of ['lec', 'lab']) {
      const cl = DATECOL[s.id][kind]; if (!cl) continue;
      const o = course.schedule.dates[`${s.id}|${kind}|${w}`];
      cell(SC, row, CI(cl), o ? toSerial(o) : `=${CFG.START}+7*${w - 1}+Settings!$${kind === 'lec' ? 'F' : 'G'}$${SECROW[s.id]}`, o ? 'FFF7DF' : bg, '000000', !!o, 10, C, 'ddd dd-mmm');
    }
    cell(SC, row, ACTC, activity(course, Lo, w) || null, bg, '000000', false, 10, LFT);
    cell(SC, row, NOTEC, course.schedule.notes[w] || null, bg, '000000', false, 10, LFT);
  }
  SC.freeze = [6, 3];
  SC.print = { orient: 'landscape', paper: 9, fitW: 1, fitH: 0, rows: [5, 5] };
  const DATE = (s, kind, w) => `Schedule!$${DATECOL[s.id][kind]}$${SCH0 + Math.min(Math.max(1, w), Lo.weeks) - 1}`;
  const LABWEEK = (s, key) => `INDEX(Schedule!$${DATECOL[s.id].lab}$${SCH0}:$${DATECOL[s.id].lab}$${SCH0 + Lo.weeks - 1},${CFG[key]})`;

  // ==================================================================== rosters
  const BLK = {}, REGC = {}, NAMEC = {}, REMC = {};
  secs.forEach((s, i) => { BLK[s.id] = 1 + 5 * i; REGC[s.id] = L(BLK[s.id] + 1); NAMEC[s.id] = L(BLK[s.id] + 2); REMC[s.id] = L(BLK[s.id] + 3); map.roster[s.id] = { reg: REGC[s.id], name: NAMEC[s.id], rem: REMC[s.id] }; });
  const roster = (name, heading, sub, linked) => {
    const R_ = wb.add(name);
    text(R_, 1, 1, `${TITLE} — ${heading}`, { sz: 14, b: true, color: NAVY }); text(R_, 2, 1, sub, { color: '595959' });
    for (const s of secs) {
      const b = BLK[s.id];
      [5, 13, 28, 16].forEach((w, j) => R_.width(b + j, w));
      if (b > 1) R_.width(b - 1, 2);
      cell(R_, 4, b, `="${linked ? 'Lab group' : 'Section'} ${s.code} — "&${SECNAME(s)}`, TAB[s.id], 'FFFFFF', true, 11);
      R_.merge(4, b, 4, b + 3);
      R_.set(6, b, { f: `"Students: "&SUMPRODUCT(--(${NAMEC[s.id]}${FIRST}:${NAMEC[s.id]}${LAST}<>""))` }, { font: { b: true, sz: 9 }, align: { h: 'left' } });
      ['Sr.', 'Reg. No', 'Student name', 'Remarks'].forEach((h, j) => cell(R_, 7, b + j, h, NAVY, 'FFFFFF', true, 10));
      const sec = sem.sections.find(x => x.id === s.id), lg = course.labGroups[s.id] || { custom: false, rows: {}, rem: {} };
      if (linked) map.labCustom[s.id] = !!lg.custom;
      for (let i = 0; i < NROW; i++) {
        const row = FIRST + i;
        cell(R_, row, b, i + 1, GREY);
        if (linked && !lg.custom) {
          cell(R_, row, b + 1, `=IF(Students!${REGC[s.id]}${row}="","",Students!${REGC[s.id]}${row})`, 'F7F9FC');
          cell(R_, row, b + 2, `=IF(Students!${NAMEC[s.id]}${row}="","",Students!${NAMEC[s.id]}${row})`, 'F7F9FC', '000000', false, 9, LFT);
        } else {
          const x = linked ? lg.rows[i] : sec.students[i];
          cell(R_, row, b + 1, (x && x.reg) || null); cell(R_, row, b + 2, (x && x.name) || null, null, '000000', false, 9, LFT);
        }
        const rem = linked ? lg.rem && lg.rem[i] : sec.students[i] && sec.students[i].rem;
        cell(R_, row, b + 3, rem || null, null, '000000', false, 9, LFT);
      }
    }
    R_.freeze = [FIRST, 1];
    R_.print = { orient: 'landscape', paper: 9, fitW: 1, fitH: 0, rows: [4, 7] };
    return R_;
  };
  roster('Students', `Class Lists (${secs.length} section${secs.length > 1 ? 's' : ''}, up to ${NROW} students each)`, 'Each section\'s students; every theory sheet and the Final Sheet of a section use this list (same row on every sheet).', false);
  if (Lo.L) roster('Lab Groups', 'Lab Groups', 'By default a lab group = its section (pale cells are formulas). If lab groups differ, type the Reg. No and name over them. Lab sheets use these lists.', true);

  // ==================================================================== per-section sheets
  const SH = {}, ATT = {}, TH = {}, LB = {}, FINAL = {}, CLOS = {}, PLOS = {};
  const sheetName = (s, short) => `${s.code} ${short}`;
  const scaffold = (s, short, heading, isSec, extra = '') => {
    const name = sheetName(s, short), ws = wb.add(name);
    ws.tab = TAB[s.id]; ws.zoom = 90;
    const ros = isSec ? 'Students' : qs('Lab Groups');
    text(ws, 1, 1, `${TITLE} — Section ${s.code}: ${heading}`, { sz: 14, b: true, color: NAVY });
    text(ws, 2, 1, `="${isSec ? 'Section' : 'Lab group'} ${s.code} ("&${SECNAME(s)}&")   ·   ${SESSION}   ·   ${isSec ? 'Instructor' : 'Lab instructor'}: "&${isSec ? SECINST(s) : LABINST(s)}&"${extra}"`, { color: '595959' });
    [[1, 5], [2, 12], [3, 26]].forEach(([c, w]) => ws.width(c, w));
    [[1, 'Sr.'], [2, 'Reg. No'], [3, 'Student name']].forEach(([c, h]) => { cell(ws, 4, c, h, TAB[s.id], 'FFFFFF', true); cell(ws, 5, c, null, TAB[s.id]); ws.merge(4, c, 5, c); });
    cell(ws, 6, 1, '', LIGHT); cell(ws, 6, 2, '', LIGHT); cell(ws, 6, 3, 'Date →', LIGHT, '000000', false, 8);
    cell(ws, 7, 1, '', LIGHT); cell(ws, 7, 2, '', LIGHT); cell(ws, 7, 3, 'Maximum marks →', LIGHT, '000000', false, 8);
    for (let r_ = FIRST; r_ <= LAST; r_++) {
      cell(ws, r_, 1, r_ - FIRST + 1);
      cell(ws, r_, 2, `=IF(${ros}!${REGC[s.id]}${r_}="","",${ros}!${REGC[s.id]}${r_})`, GREY);
      cell(ws, r_, 3, `=IF(${ros}!${NAMEC[s.id]}${r_}="","",${ros}!${NAMEC[s.id]}${r_})`, GREY, '000000', false, 9, LFT);
    }
    ws.height(5, 30);
    ws.freeze = [FIRST, 4];
    ws.print = { orient: 'landscape', paper: 9, fitW: 1, fitH: 0, rows: [4, 7], cols: ['A', 'C'] };
    SH[`${s.id}|${short}`] = qs(name);
    return ws;
  };
  const HELD = c => `(COUNT(${c}$${FIRST}:${c}$${LAST})>0)`;
  const BLANK = r_ => `$C${r_}=""`;
  const groupHeader = (ws, c0, c1, t, color, size = 9) => { cell(ws, 4, c0, t, color, 'FFFFFF', true, size); if (c1 > c0) ws.merge(4, c0, 4, c1); };
  const entryCols = (ws, s, page, cols, maxrefs, width = 6.5, shade = null, page2 = null) => {
    const sheet = ws.name;
    map.entries[sheet] = { secId: s.id, page, cols: (map.entries[sheet] ? map.entries[sheet].cols : []).concat(cols) };
    cols.forEach((cl, k) => {
      cell(ws, 7, CI(cl), `=${maxrefs[k]}`, MAXF, '375623', true);
      ws.width(CI(cl), width);
      const ci = (map.entries[sheet].cols.length - cols.length) + k;
      for (let i = 0; i < NROW; i++) {
        const v = getMark(course, s.id, page, i, ci);
        cell(ws, FIRST + i, CI(cl), v === null ? null : v, shade, page2 === 'att' ? '000000' : '000000', page2 === 'att', 9, C, page2 === 'att' ? null : '0.##');
      }
      if (page2 !== 'att') ws.addDV(`${cl}${FIRST}:${cl}${LAST}`, { type: 'decimal', op: 'between', f1: '0', f2: `$${cl}$7`, title: 'Marks', error: 'Enter a number from 0 to the maximum marks in row 7.' });
    });
  };
  const formulaCol = (ws, cl, header, row7, perRow, o = {}) => {
    const { fmt = '0.##', width = 9, bold = false, bg = GREY, headBg = 'C9DAF0', mergeHead = true, row7fmt = '"/ "0.##' } = o;
    const ci = CI(cl);
    cell(ws, 5, ci, header, headBg, '000000', true, 8);
    if (mergeHead) { cell(ws, 6, ci, null, headBg); ws.merge(5, ci, 6, ci); }
    cell(ws, 7, ci, row7, MAXF, '375623', true, 9, C, row7fmt);
    ws.width(ci, width);
    for (let r_ = FIRST; r_ <= LAST; r_++) cell(ws, r_, ci, perRow(r_), bg, '000000', bold, 9, fmt.includes('%') ? RGT : C, fmt);
  };
  const stats = (ws, c0, c1, pctCols = []) => {
    [['Class average', 'AVERAGE'], ['Highest', 'MAX'], ['Lowest', 'MIN']].forEach(([lab, fn], k) => {
      const r_ = LAST + 2 + k;
      cell(ws, r_, 3, lab, LIGHT, '000000', true, 9, LFT);
      for (let ci = c0; ci <= c1; ci++) { const cl = L(ci); cell(ws, r_, ci, `=IF(COUNT(${cl}${FIRST}:${cl}${LAST})=0,"",${fn}(${cl}${FIRST}:${cl}${LAST}))`, GREY, '000000', true, 8, C, pctCols.includes(cl) ? '0.0%' : '0.0'); }
    });
  };

  const attendance = (s, kind) => {
    const sec = kind === 'lec', label = sec ? 'Theory' : 'Lab', page = sec ? 'Theory Att' : 'Lab Att';
    const A = scaffold(s, `${label} Att`, `${label} Attendance (${Lo.weeks} weeks)`, sec, '   ·   P = Present, A = Absent, L = Leave');
    A.get(7, 3) && A.set(7, 3, 'Class held (auto ✓) →', st({ bg: LIGHT, sz: 8 }));
    const W0 = 4, WL = W0 + Lo.weeks - 1, c0 = L(W0), c1 = L(WL);
    const names = ['Present (P)', 'Leave (L)', 'Absent (A)', `${label} attendance %`, 'Status'];
    const S0 = WL + 1, SC_ = Object.fromEntries(names.map((n, i) => [n, L(S0 + i)])), PCT = SC_[`${label} attendance %`];
    A.set(2, S0 + 1, 'Min. %', { font: { sz: 9, b: true } });
    cell(A, 2, S0 + 2, `=Settings!$C$${CFG.THR.split('$')[2]}`, GREY, '000000', true, 9, C, '0%', false);
    A.set(2, S0 + 3, 'Leave = present?', { font: { sz: 9, b: true } });
    cell(A, 2, S0 + 4, `=${CFG.LEAVE}`, GREY, '000000', true, 9, C, null, false);
    const THRC = `$${L(S0 + 2)}$2`, LEAVEC = `$${L(S0 + 4)}$2`;
    for (let w = 1; w <= Lo.weeks; w++) {
      const ci = W0 + w - 1, cl = L(ci);
      cell(A, 4, ci, `Week ${w}`, w % 2 ? '2E5C9A' : NAVY, 'FFFFFF', true, 8);
      const n = Lo.L && !sec ? Number(P.lab.exps) || 0 : 0;
      cell(A, 5, ci, sec ? 'Lecture' : (w <= n ? `Exp. ${String(w).padStart(2, '0')}` : 'Lab'), LIGHT, '000000', false, 7);
      cell(A, 6, ci, `=${DATE(s, kind, w)}`, WEEKFILL[w % 2], '000000', false, 8, C, 'dd-mmm');
      cell(A, 7, ci, `=IF(COUNTA(${cl}${FIRST}:${cl}${LAST})>0,1,0)`, MAXF, '375623', false, 9, C, '"✓";;');
      A.width(ci, 6.6);
    }
    groupHeader(A, S0, S0 + names.length - 1, 'Summary (formulas)', NAVY);
    names.forEach((n, i) => {
      const isp = n.endsWith('%');
      cell(A, 5, S0 + i, n, LIGHT, '000000', true, 8); cell(A, 6, S0 + i, null, LIGHT); A.merge(5, S0 + i, 6, S0 + i);
      cell(A, 7, S0 + i, isp ? `=SUM($${c0}$7:$${c1}$7)` : '', MAXF, '375623', true, 8, C, isp ? '"held: "0' : null);
      A.width(S0 + i, [9, 8, 8, 22, 10][i]);
    });
    const HELDC = `$${PCT}$7`;
    entryCols(A, s, page, Array.from({ length: Lo.weeks }, (_, w) => L(W0 + w)), Array.from({ length: Lo.weeks }, () => '""'), 6.6, null, 'att');
    for (let w = 1; w <= Lo.weeks; w++) { const ci = W0 + w - 1, cl = L(ci); cell(A, 7, ci, `=IF(COUNTA(${cl}${FIRST}:${cl}${LAST})>0,1,0)`, MAXF, '375623', false, 9, C, '"✓";;'); for (let i = 0; i < NROW; i++) A.style(FIRST + i, ci, st({ bg: WEEKFILL[w % 2], b: true })); }
    for (let r_ = FIRST; r_ <= LAST; r_++) {
      const rng = `${c0}${r_}:${c1}${r_}`, b = BLANK(r_);
      const f = {
        'Present (P)': `=IF(${b},"",COUNTIF(${rng},"P"))`, 'Leave (L)': `=IF(${b},"",COUNTIF(${rng},"L"))`, 'Absent (A)': `=IF(${b},"",COUNTIF(${rng},"A"))`,
        [`${label} attendance %`]: `=IF(OR(${b},${HELDC}=0),"",(${SC_['Present (P)']}${r_}+IF(${LEAVEC}="Yes",${SC_['Leave (L)']}${r_},0))/${HELDC})`,
        Status: `=IF(${PCT}${r_}="","",IF(${PCT}${r_}>=${THRC},"Eligible","Short"))`,
      };
      names.forEach((n, i) => cell(A, r_, S0 + i, f[n], GREY, '000000', false, 9, n.endsWith('%') ? RGT : C, n.endsWith('%') ? '0.0%' : null));
    }
    const CR1 = LAST + 2, CR2 = LAST + 3;
    cell(A, CR1, 3, 'Present (count)', LIGHT, '000000', true, 9, LFT); cell(A, CR2, 3, 'Class attendance %', LIGHT, '000000', true, 9, LFT);
    const nstud = `SUMPRODUCT(--($C$${FIRST}:$C$${LAST}<>""))`;
    for (let w = 1; w <= Lo.weeks; w++) {
      const cl = L(W0 + w - 1);
      cell(A, CR1, W0 + w - 1, `=IF(${cl}$7=0,"",COUNTIF(${cl}${FIRST}:${cl}${LAST},"P"))`, GREY, '000000', false, 8);
      cell(A, CR2, W0 + w - 1, `=IF(OR(${cl}$7=0,${nstud}=0),"",COUNTIF(${cl}${FIRST}:${cl}${LAST},"P")/${nstud})`, GREY, '000000', false, 8, C, '0%');
    }
    cell(A, CR1, S0 + 2, 'Students', LIGHT, '000000', true); cell(A, CR1, S0 + 3, `=${nstud}`, GREY, '000000', true, 9, C, '0');
    cell(A, CR2, S0 + 2, 'Class average', LIGHT, '000000', true); cell(A, CR2, S0 + 3, `=IF(COUNT(${PCT}${FIRST}:${PCT}${LAST})=0,"",AVERAGE(${PCT}${FIRST}:${PCT}${LAST}))`, GREY, '000000', true, 9, C, '0.0%');
    cell(A, CR1, S0 + 4, `=COUNTIF(${SC_.Status}${FIRST}:${SC_.Status}${LAST},"Short")&" short"`, GREY, 'C00000', true);
    const grid = `${c0}${FIRST}:${c1}${LAST}`;
    A.addDV(grid, { type: 'list', f1: '"P,A,L"', title: 'Attendance', error: 'Enter P (present), A (absent) or L (leave).' });
    for (const [v, bg, fg] of [['P', 'C6EFCE', '006100'], ['A', 'FFC7CE', '9C0006'], ['L', 'FFEB9C', '9C5700']]) A.addCF(grid, eq(`"${v}"`, { fill: bg, color: fg, b: true }));
    const prng = `${PCT}${FIRST}:${PCT}${LAST}`;
    A.addCF(prng, bar(sec ? '2E75B6' : '70AD47'));
    A.addCF(prng, { type: 'expr', formula: `AND(ISNUMBER(${PCT}${FIRST}),${PCT}${FIRST}<${THRC})`, dxf: { color: 'C00000', b: true } });
    A.addCF(`${c0}${CR2}:${c1}${CR2}`, bar('A9D08E'));
    const stc = `${SC_.Status}${FIRST}:${SC_.Status}${LAST}`;
    A.addCF(stc, eq('"Short"', BADD)); A.addCF(stc, eq('"Eligible"', OKD));
    ATT[`${s.id}|${kind}`] = { sheet: qs(A.name), present: SC_['Present (P)'], pct: PCT, status: SC_.Status };
  };

  const theoryComp = (s, x) => {
    const ws = scaffold(s, x.page, x.kind === 'exam' ? `${x.title} (Q1–Q${x.cols.length})` : x.title, true);
    const cols = x.cols.map((_, i) => L(4 + i));
    groupHeader(ws, 4, 3 + cols.length, x.title, hex(x.color));
    x.cols.forEach((c, i) => {
      cell(ws, 5, CI(cols[i]), c.label, LIGHT, '000000', true, 8);
      cell(ws, 6, CI(cols[i]), x.kind === 'items' ? `=${DATE(s, 'lec', c.week)}` : `=${CFG[x.dateKey]}`, YELLOW, BLUE, false, 7, C, 'dd-mmm-yy');
    });
    if (x.kind === 'exam' && cols.length > 1) ws.merge(6, 4, 6, 3 + cols.length);
    entryCols(ws, s, x.page, cols, x.cols.map(c => MAX[c.maxKey]), x.kind === 'items' ? 10 : 6);
    const T = L(4 + cols.length), Pc = L(5 + cols.length);
    groupHeader(ws, CI(T), CI(Pc), 'Total (formulas)', NAVY);
    const rng = r_ => `${cols[0]}${r_}:${cols[cols.length - 1]}${r_}`;
    if (x.kind === 'items') {
      const heldmax = cols.map(c => `${HELD(c)}*${c}$7`).join('+');
      formulaCol(ws, T, `${x.short} total`, `=${heldmax}`, r_ => `=IF(OR(${BLANK(r_)},${T}$7=0),"",SUM(${rng(r_)}))`, { bold: true });
    } else {
      const anyheld = cols.map(HELD).join('+');
      formulaCol(ws, T, 'Exam total', `=SUM(${cols[0]}7:${cols[cols.length - 1]}7)`, r_ => `=IF(OR(${BLANK(r_)},(${anyheld})=0),"",SUM(${rng(r_)}))`, { bold: true });
    }
    formulaCol(ws, Pc, 'Percentage', '', r_ => `=IF(OR(${T}${r_}="",N(${T}$7)=0),"",${T}${r_}/${T}$7)`, { fmt: '0.0%', width: 18 });
    ws.addCF(`${Pc}${FIRST}:${Pc}${LAST}`, bar(hex(x.color) === 'C00000' ? 'E06666' : hex(x.color)));
    note(ws, 4, CI(Pc) + 2, x.kind === 'items' ? 'Row 7 of the total shows the maximum of the items already held.' : 'The exam counts as held once any marks are entered; blank questions count as 0.');
    stats(ws, 4, CI(Pc), [Pc]);
    TH[`${s.id}|${x.id}`] = { sheet: qs(ws.name), total: T, pct: Pc };
  };

  const experiments = (s, x) => {
    const legend = '   ·   ' + x.crit.map(([ab, lab, mx]) => `${ab} = ${lab} (0-${mx})`).join(', ');
    const ws = scaffold(s, x.page, `${x.title} (${x.exps} experiments)`, false, legend.replace(/"/g, "'"));
    const np = x.crit.length;
    let col_ = 4; const totals = [], entries = [];
    for (let n = 1; n <= x.exps; n++) {
      const c0 = col_, pc = x.crit.map((_, j) => L(col_ + j)); col_ += np;
      const tc = L(col_); col_++;
      groupHeader(ws, c0, col_ - 1, `Exp. No. ${n}`, n % 2 ? '2E5C9A' : NAVY, 8);
      x.crit.forEach(([ab], j) => cell(ws, 5, CI(pc[j]), ab, LIGHT, '000000', true, 8));
      cell(ws, 6, c0, `=${DATE(s, 'lab', n)}`, WEEKFILL[n % 2], '000000', false, 7, C, 'dd-mmm');
      for (let k = c0 + 1; k < col_; k++) cell(ws, 6, k, null, WEEKFILL[n % 2]);
      ws.merge(6, c0, 6, col_ - 1);
      entryCols(ws, s, x.page, pc, x.crit.map((_, j) => MAX[`${x.id}|${j}`]), 4.4, WEEKFILL[n % 2]);
      const held = pc.map(HELD).join('+');
      formulaCol(ws, tc, 'Total', `=SUM(${pc[0]}7:${pc[pc.length - 1]}7)`, r_ => `=IF(OR(${BLANK(r_)},(${held})=0),"",SUM(${pc[0]}${r_}:${pc[pc.length - 1]}${r_}))`, { width: 5.2, bold: true, mergeHead: false });
      totals.push(tc); entries.push(...pc);
    }
    const s0 = col_, cols = Object.fromEntries(['N', 'SUM', 'PCT', 'SC'].map((k, i) => [k, L(s0 + i)]));
    groupHeader(ws, s0, s0 + 3, 'Summary (formulas)', NAVY);
    const tlist = r_ => totals.map(t => `${t}${r_}`).join(',');
    formulaCol(ws, cols.N, 'Experiments marked', `=${totals.map(HELD).join('+')}`, r_ => `=IF(${BLANK(r_)},"",COUNT(${tlist(r_)}))`, { width: 11, row7fmt: '"held: "0' });
    formulaCol(ws, cols.SUM, 'Total of held experiments', `=${totals.map(t => `${HELD(t)}*${t}$7`).join('+')}`, r_ => `=IF(OR(${BLANK(r_)},${cols.SUM}$7=0),"",SUM(${tlist(r_)}))`, { width: 12, bold: true });
    formulaCol(ws, cols.PCT, 'Percentage', '', r_ => `=IF(${cols.SUM}${r_}="","",${cols.SUM}${r_}/${cols.SUM}$7)`, { fmt: '0.0%', width: 16 });
    formulaCol(ws, cols.SC, 'Marks (scaled)', `=${CFG[MARK_KEY[x.id]]}`, r_ => `=IF(${cols.PCT}${r_}="","",${cols.PCT}${r_}*${CFG[MARK_KEY[x.id]]})`, { width: 11, bold: true, headBg: 'FCE4D6' });
    ws.addCF(`${cols.PCT}${FIRST}:${cols.PCT}${LAST}`, bar(hex(x.color)));
    stats(ws, 4, s0 + 3, [cols.PCT]);
    ws.print.paper = 8;
    LB[`${s.id}|${x.id}`] = { sheet: qs(ws.name), sc: cols.SC };
  };

  const single = (s, x) => {
    const ws = scaffold(s, x.page, x.title, false);
    const pc = x.cols.map((_, j) => L(4 + j));
    groupHeader(ws, 4, 3 + pc.length, x.title, hex(x.color));
    x.cols.forEach((c, j) => cell(ws, 5, CI(pc[j]), `${c.label} (0–${c.max})`, LIGHT, '000000', true, 8));
    const wk = { LMID: 'WK_LMID', LFIN: 'WK_LFIN', OEL: 'WK_OEL' }[x.id];
    cell(ws, 6, 4, `=${LABWEEK(s, wk)}`, YELLOW, BLUE, false, 8, C, 'dd-mmm-yy');
    for (let k = 5; k <= 3 + pc.length; k++) cell(ws, 6, k, null, YELLOW);
    if (pc.length > 1) ws.merge(6, 4, 6, 3 + pc.length);
    entryCols(ws, s, x.page, pc, x.cols.map(c => MAX[c.maxKey]), 15);
    const T = L(4 + pc.length), SCc = L(5 + pc.length), held = pc.map(HELD).join('+');
    groupHeader(ws, CI(T), CI(SCc), 'Total (formulas)', NAVY);
    formulaCol(ws, T, 'Total', `=SUM(${pc[0]}7:${pc[pc.length - 1]}7)`, r_ => `=IF(OR(${BLANK(r_)},(${held})=0),"",SUM(${pc[0]}${r_}:${pc[pc.length - 1]}${r_}))`, { width: 11, bold: true });
    formulaCol(ws, SCc, 'Marks (scaled)', `=${CFG[MARK_KEY[x.id]]}`, r_ => `=IF(OR(${T}${r_}="",N(${T}$7)=0),"",${T}${r_}/${T}$7*${CFG[MARK_KEY[x.id]]})`, { width: 16, bold: true, headBg: 'FCE4D6' });
    ws.addCF(`${SCc}${FIRST}:${SCc}${LAST}`, bar(hex(x.color), `$${SCc}$7`));
    stats(ws, 4, CI(SCc));
    LB[`${s.id}|${x.id}`] = { sheet: qs(ws.name), sc: SCc };
  };

  const project = (s, x) => {
    const ws = scaffold(s, 'Project', 'Project (design and viva quantification)', false);
    const blocks = [['des', 'Project Design Quantification', 'P_DES', '1F7A5A', 'PROJD'], ['viva', 'Project Viva Quantification', 'P_VIVA', '7030A0', 'PROJV']];
    let col_ = 4; const out = {};
    for (const [b, title_, key, color, mk] of blocks) {
      const crit = x[b].crit;
      const pc = crit.map((_, j) => L(col_ + j)); col_ += crit.length;
      const T = L(col_), SCc = L(col_ + 1); col_ += 2;
      groupHeader(ws, CI(pc[0]), CI(SCc), title_, color);
      crit.forEach(([ab, lab, mx], j) => cell(ws, 5, CI(pc[j]), `${lab} (0–${mx})`, LIGHT, '000000', true, 8));
      cell(ws, 6, CI(pc[0]), `=${LABWEEK(s, 'WK_PROJ')}`, YELLOW, BLUE, false, 8, C, 'dd-mmm-yy');
      for (let k = CI(pc[0]) + 1; k <= CI(pc[pc.length - 1]); k++) cell(ws, 6, k, null, YELLOW);
      if (pc.length > 1) ws.merge(6, CI(pc[0]), 6, CI(pc[pc.length - 1]));
      entryCols(ws, s, 'Project', pc, crit.map((_, j) => MAX[`${mk}|${j}`]), 13);
      const held = pc.map(HELD).join('+');
      formulaCol(ws, T, 'Total', `=SUM(${pc[0]}7:${pc[pc.length - 1]}7)`, r_ => `=IF(OR(${BLANK(r_)},(${held})=0),"",SUM(${pc[0]}${r_}:${pc[pc.length - 1]}${r_}))`, { width: 10, bold: true });
      formulaCol(ws, SCc, 'Scaled', `=${CFG[key]}`, r_ => `=IF(OR(${T}${r_}="",N(${T}$7)=0),"",${T}${r_}/${T}$7*${CFG[key]})`, { width: 10, bold: true });
      out[b] = SCc;
    }
    const Pc = L(col_);
    groupHeader(ws, col_, col_, 'Design project', NAVY);
    const d = out.des, v = out.viva;
    formulaCol(ws, Pc, 'Project marks', `=${CFG.M_PROJ}`, r_ => `=IF(AND(${d}${r_}="",${v}${r_}=""),"",(N(${d}${r_})+N(${v}${r_}))/(IF(${d}${r_}="",0,${d}$7)+IF(${v}${r_}="",0,${v}$7))*${CFG.M_PROJ})`, { width: 18, bold: true, headBg: 'FCE4D6' });
    ws.addCF(`${Pc}${FIRST}:${Pc}${LAST}`, bar('B45F06', `$${Pc}$7`));
    note(ws, 4, col_ + 2, 'Project = (design scaled + viva scaled) / (design + viva scale) × project marks, using only the parts already marked.');
    stats(ws, 4, col_);
    LB[`${s.id}|PROJ`] = { sheet: qs(ws.name), sc: Pc };
  };

  const labTotal = s => {
    const ws = scaffold(s, 'Lab Total', `Lab Total (out of ${Lo.labTotalMax})`, false);
    const cols = Lo.labComps.map((_, i) => L(4 + i));
    groupHeader(ws, 4, 3 + cols.length, 'LAB TOTAL — from the lab assessment sheets', '1F7A5A');
    Lo.labComps.forEach((x, i) => {
      const src = LB[`${s.id}|${x.id}`];
      formulaCol(ws, cols[i], x.title, `=${CFG[MARK_KEY[x.id]]}`, r_ => `=IF(OR(${BLANK(r_)},${src.sheet}!${src.sc}${r_}=""),"",${src.sheet}!${src.sc}${r_})`, { width: 11, headBg: LIGHT });
    });
    const T = L(4 + cols.length), HM = L(5 + cols.length), Pc = L(6 + cols.length);
    groupHeader(ws, CI(T), CI(Pc), 'Total (formulas)', NAVY);
    formulaCol(ws, T, 'Lab total', `=${CFG.M_TOTAL}`, r_ => `=IF(OR(${BLANK(r_)},COUNT(${cols[0]}${r_}:${cols[cols.length - 1]}${r_})=0),"",SUM(${cols[0]}${r_}:${cols[cols.length - 1]}${r_}))`, { width: 11, bold: true, headBg: 'FCE4D6' });
    formulaCol(ws, HM, 'Maximum of components marked', '', r_ => `=IF(${T}${r_}="","",${cols.map(c => `IF(${c}${r_}="",0,${c}$7)`).join('+')})`, { width: 12 });
    formulaCol(ws, Pc, 'Lab percentage', '', r_ => `=IF(OR(${T}${r_}="",N(${HM}${r_})=0),"",${T}${r_}/${HM}${r_})`, { fmt: '0.0%', width: 18 });
    ws.addCF(`${Pc}${FIRST}:${Pc}${LAST}`, bar('70AD47'));
    stats(ws, 4, CI(Pc), [Pc]);
    LB[`${s.id}|total`] = { sheet: qs(ws.name), cols: Object.fromEntries(Lo.labComps.map((x, i) => [x.id, cols[i]])), total: T, pct: Pc };
  };

  for (const s of secs) {
    if (Lo.T) attendance(s, 'lec');
    if (Lo.L) attendance(s, 'lab');
    for (const x of Lo.comps) {
      if (x.sec) theoryComp(s, x);
      else if (x.kind === 'exp') experiments(s, x);
      else if (x.kind === 'single') single(s, x);
      else project(s, x);
    }
    if (Lo.L && Lo.labComps.length) labTotal(s);
  }

  // ---- Final Sheet, CLO and PLO (section lists)
  const finalSheet = s => {
    const ws = scaffold(s, 'Final Sheet', 'Final Sheet (all marks, attendance, CLO/PLO and result)', true, '   ·   all formulas; lab results are matched by Reg. No from the student\'s lab group');
    ws.zoom = 85;
    ws.set(7, 3, 'Maximum / held →', st({ bg: LIGHT, sz: 8 }));
    const cols = [];
    if (Lo.T) {
      for (const x of Lo.theory) cols.push(['Theory marks', x.short === 'Quiz' ? 'Quizzes' : x.short === 'Assignment' ? 'Assignments' : x.short, 'th', x]);
      cols.push(['Theory marks', 'Theory %', 'thpct', null]);
      cols.push(['Theory attendance', 'Classes attended', 'tatt', null], ['Theory attendance', 'Theory attendance %', 'tattp', null], ['Theory attendance', 'Status', 'tatts', null]);
    }
    if (Lo.L) {
      cols.push(['Lab marks', 'Lab group', 'grp', null]);
      for (const x of Lo.labComps) cols.push(['Lab marks', x.short, 'lab', x]);
      if (Lo.labComps.length) cols.push(['Lab marks', `Lab total (${Lo.labTotalMax})`, 'labtot', null], ['Lab marks', 'Lab %', 'labpct', null]);
    }
    for (const k of Lo.clos) cols.push(['Outcomes', `=${OUT[k.id].code}&" %"`, 'clo', k]);
    for (const p of Lo.plos) cols.push(['Outcomes', `=${OUT[p.id].code}`, 'plo', p]);
    if (Lo.L) cols.push(['Lab attendance', 'Labs attended', 'latt', null], ['Lab attendance', 'Lab attendance %', 'lattp', null], ['Lab attendance', 'Status', 'latts', null]);
    cols.push(['Result', 'Course total %', 'ct', null], ['Result', 'Grade', 'grade', null], ['Result', 'Remarks', 'rem', null]);
    const F0 = 4, FL = F0 + cols.length - 1, HG = L(FL + 1), HR = L(FL + 2);
    const FC = {};
    cols.forEach(([g, h, k, src], i) => { FC[k === 'th' || k === 'lab' || k === 'clo' || k === 'plo' ? `${k}|${src.id}` : k] = L(F0 + i); });
    ws.set(2, FL - 1, 'Min. %', { font: { sz: 9, b: true } });
    cell(ws, 2, FL, `=${CFG.THR}`, GREY, '000000', true, 9, C, '0%', false);
    const THRF = `$${L(FL)}$2`;
    const GC = { 'Theory marks': '7030A0', 'Theory attendance': '2E75B6', 'Lab marks': '1F7A5A', Outcomes: 'B45F06', 'Lab attendance': '548235', Result: 'C00000' };
    const span = {};
    cols.forEach(([g], i) => (span[g] = span[g] || []).push(F0 + i));
    for (const [g, cl] of Object.entries(span)) groupHeader(ws, cl[0], cl[cl.length - 1], g, GC[g]);
    const width = { th: 9, thpct: 14, tatt: 9, tattp: 14, tatts: 9, grp: 6, lab: 8, labtot: 9, labpct: 14, clo: 12, plo: 12, latt: 9, lattp: 14, latts: 9, ct: 14, grade: 7, rem: 26 };
    const TA = ATT[`${s.id}|lec`];
    cols.forEach(([g, h, k, src], i) => {
      const ci = F0 + i, strong = ['thpct', 'labtot', 'labpct', 'ct', 'clo'].includes(k);
      cell(ws, 5, ci, h, strong ? 'C9DAF0' : LIGHT, '000000', strong, 8); cell(ws, 6, ci, null, strong ? 'C9DAF0' : LIGHT); ws.merge(5, ci, 6, ci);
      const r7 = k === 'th' ? `=${TH[`${s.id}|${src.id}`].sheet}!${TH[`${s.id}|${src.id}`].total}7` : k === 'lab' ? `=${CFG[MARK_KEY[src.id]]}` : k === 'labtot' ? `=${CFG.M_TOTAL}` : k === 'tatt' ? `=${TA.sheet}!$${TA.pct}$7` : '';
      cell(ws, 7, ci, r7, MAXF, '375623', true, 9, C, k === 'tatt' ? '"held: "0' : '"/ "0.##');
      ws.width(ci, width[k]);
    });
    const groups = secs;
    const labreg = groups.map(g => `${qs('Lab Groups')}!$${REGC[g.id]}$${FIRST}:$${REGC[g.id]}$${LAST}`);
    if (Lo.L) { ws.hide(CI(HG)); ws.hide(CI(HR)); }
    for (let r_ = FIRST; r_ <= LAST; r_++) {
      const b = BLANK(r_), grp = `$${HG}${r_}`, row = `$${HR}${r_}`;
      if (Lo.L) {
        ws.set(r_, CI(HG), { f: `IF($B${r_}="",0,` + groups.map((_, i) => `IF(ISNUMBER(MATCH($B${r_},${labreg[i]},0)),${i + 1},`).join('') + '0' + ')'.repeat(groups.length + 1) });
        ws.set(r_, CI(HR), { f: `IF(${grp}=0,0,MATCH($B${r_},CHOOSE(${grp},${labreg.join(',')}),0))` });
      }
      const lab = (sheetOf, col__) => {
        const refs = groups.map(g => `${sheetOf(g)}!${col__}$${FIRST}:${col__}$${LAST}`).join(',');
        const v = `INDEX(CHOOSE(${grp},${refs}),${row})`;
        return `=IF(OR(${b},${grp}=0),"",IF(${v}="","",${v}))`;
      };
      const LT = g => LB[`${g.id}|total`].sheet;
      cols.forEach(([g, h, k, src], i) => {
        let v, fmt = '0.##', al = C, bold = false, bg = GREY;
        if (k === 'th') { const t = TH[`${s.id}|${src.id}`]; v = `=IF(OR(${b},${t.sheet}!${t.total}${r_}=""),"",${t.sheet}!${t.total}${r_})`; bg = 'FFFFFF'; }
        else if (k === 'thpct') {
          const parts = Lo.theory.map(x => [TH[`${s.id}|${x.id}`], CFG[WEIGHT_KEY[x.id]]]);
          const num = parts.map(([t, w]) => `IF(${t.sheet}!${t.pct}${r_}="",0,${w}*${t.sheet}!${t.pct}${r_})`).join('+');
          const den = parts.map(([t, w]) => `IF(${t.sheet}!${t.pct}${r_}="",0,${w})`).join('+');
          v = `=IF(OR(${b},(${den})=0),"",(${num})/(${den}))`; fmt = '0.0%'; al = RGT; bold = true;
        } else if (k === 'tatt') v = `=IF(OR(${b},${TA.sheet}!$${TA.pct}$7=0),"",${TA.sheet}!${TA.present}${r_}&" / "&${TA.sheet}!$${TA.pct}$7)`;
        else if (k === 'tattp') { v = `=IF(OR(${b},${TA.sheet}!${TA.pct}${r_}=""),"",${TA.sheet}!${TA.pct}${r_})`; fmt = '0.0%'; al = RGT; }
        else if (k === 'tatts') v = `=IF(OR(${b},${TA.sheet}!${TA.status}${r_}=""),"",${TA.sheet}!${TA.status}${r_})`;
        else if (k === 'grp') v = `=IF(${b},"",IF(${grp}=0,"—",CHOOSE(${grp},${groups.map(g => `"${g.code.replace(/"/g, '')}"`).join(',')})))`;
        else if (k === 'lab') { v = lab(LT, LB[`${groups[0].id}|total`].cols[src.id]); bg = 'FFFFFF'; }
        else if (k === 'labtot') { v = lab(LT, LB[`${groups[0].id}|total`].total); bold = true; }
        else if (k === 'labpct') { v = lab(LT, LB[`${groups[0].id}|total`].pct); fmt = '0.0%'; al = RGT; bold = true; }
        else if (k === 'clo') { v = `=IF(OR(${b},${CLOS[s.id].sheet}!${CLOS[s.id].pct[src.id]}${r_}=""),"",${CLOS[s.id].sheet}!${CLOS[s.id].pct[src.id]}${r_})`; fmt = '0.0%'; al = RGT; }
        else if (k === 'plo') { v = `=IF(OR(${b},${PLOS[s.id].sheet}!${PLOS[s.id].st[src.id]}${r_}=""),"",${PLOS[s.id].sheet}!${PLOS[s.id].st[src.id]}${r_})`; fmt = null; }
        else if (k === 'latt') {
          const A_ = g => ATT[`${g.id}|lab`];
          const pres = groups.map(g => `${A_(g).sheet}!${A_(groups[0]).present}$${FIRST}:${A_(groups[0]).present}$${LAST}`).join(',');
          const held = groups.map(g => `${A_(g).sheet}!$${A_(groups[0]).pct}$7`).join(',');
          v = `=IF(OR(${b},${grp}=0),"",IF(CHOOSE(${grp},${held})=0,"",INDEX(CHOOSE(${grp},${pres}),${row})&" / "&CHOOSE(${grp},${held})))`;
        } else if (k === 'lattp') { v = lab(g => ATT[`${g.id}|lab`].sheet, ATT[`${groups[0].id}|lab`].pct); fmt = '0.0%'; al = RGT; }
        else if (k === 'latts') { v = lab(g => ATT[`${g.id}|lab`].sheet, ATT[`${groups[0].id}|lab`].status); fmt = null; }
        else if (k === 'ct') {
          const tp = FC.thpct, lp = FC.labpct;
          if (Lo.T && Lo.L && lp) v = `=IF(OR(${b},AND(${tp}${r_}="",${lp}${r_}="")),"",(IF(${tp}${r_}="",0,${CFG.SH_T}*${tp}${r_})+IF(${lp}${r_}="",0,${CFG.SH_L}*${lp}${r_}))/(IF(${tp}${r_}="",0,${CFG.SH_T})+IF(${lp}${r_}="",0,${CFG.SH_L})))`;
          else { const one = Lo.T ? tp : lp; v = one ? `=IF(OR(${b},${one}${r_}=""),"",${one}${r_})` : '=""'; }
          fmt = '0.0%'; al = RGT; bold = true;
        } else if (k === 'grade') { v = `=IF(${FC.ct}${r_}="","",INDEX(${GNAME},MATCH(ROUND(${FC.ct}${r_}*100,2),${GMIN},1)))`; fmt = null; bold = true; }
        else if (k === 'rem') {
          const conds = [];
          if (Lo.L) conds.push([`${FC.grp}${r_}="—"`, 'Not in any lab group']);
          if (Lo.T && Lo.L) conds.push([`AND(${FC.tatts}${r_}="Short",${FC.latts}${r_}="Short")`, 'Short attendance: theory and lab']);
          if (Lo.T) conds.push([`${FC.tatts}${r_}="Short"`, 'Short attendance: theory']);
          if (Lo.L) conds.push([`${FC.latts}${r_}="Short"`, 'Short attendance: lab']);
          v = `=IF(${b},"",IF($B${r_}="","Reg. No missing",` + conds.map(([c_, t]) => `IF(${c_},"${t}",`).join('') + '""' + ')'.repeat(conds.length + 2);
          fmt = null; al = LFT;
        }
        cell(ws, r_, F0 + i, v, bg, '000000', bold, k === 'rem' ? 8 : 9, al, fmt);
      });
    }
    const pcs = cols.filter(([, , k]) => ['thpct', 'labpct', 'clo', 'tattp', 'lattp', 'ct'].includes(k)).map(([, , k, src]) => FC[src && (k === 'clo') ? `clo|${src.id}` : k]);
    [['Class average', 'AVERAGE'], ['Highest', 'MAX'], ['Lowest', 'MIN']].forEach(([lab_, fn], kk) => {
      const r_ = LAST + 2 + kk;
      cell(ws, r_, 3, lab_, LIGHT, '000000', true, 9, LFT);
      cols.forEach(([, , k], i) => {
        if (!['th', 'thpct', 'tattp', 'lab', 'labtot', 'labpct', 'clo', 'lattp', 'ct'].includes(k)) return;
        const c_ = L(F0 + i);
        cell(ws, r_, F0 + i, `=IF(COUNT(${c_}${FIRST}:${c_}${LAST})=0,"",${fn}(${c_}${FIRST}:${c_}${LAST}))`, GREY, '000000', true, 8, C, pcs.includes(c_) ? '0.0%' : '0.0');
      });
    });
    for (const key of ['tatts', 'latts']) if (FC[key]) cell(ws, LAST + 2, CI(FC[key]), `=COUNTIF(${FC[key]}${FIRST}:${FC[key]}${LAST},"Short")&" short"`, GREY, 'C00000', true, 8);
    const bars = [['thpct', '9E7BC4'], ['labpct', '70AD47'], ['tattp', '2E75B6'], ['lattp', '548235'], ['ct', 'C00000'], ...Lo.clos.map(k => [`clo|${k.id}`, 'F4B183'])];
    for (const [key, color] of bars) if (FC[key]) ws.addCF(`${FC[key]}${FIRST}:${FC[key]}${LAST}`, bar(color));
    for (const key of ['tattp', 'lattp']) if (FC[key]) ws.addCF(`${FC[key]}${FIRST}:${FC[key]}${LAST}`, { type: 'expr', formula: `AND(ISNUMBER(${FC[key]}${FIRST}),${FC[key]}${FIRST}<${THRF})`, dxf: { color: 'C00000', b: true } });
    for (const key of ['tatts', 'latts', ...Lo.plos.map(p => `plo|${p.id}`)]) {
      if (!FC[key]) continue;
      const rg = `${FC[key]}${FIRST}:${FC[key]}${LAST}`;
      ws.addCF(rg, eq('"Short"', BADD)); ws.addCF(rg, eq('"Not achieved"', BADD)); ws.addCF(rg, eq('"Eligible"', OKD)); ws.addCF(rg, eq('"Achieved"', OKD));
    }
    ws.addCF(`${FC.grade}${FIRST}:${FC.grade}${LAST}`, eq('"F"', BADD));
    ws.addCF(`${FC.rem}${FIRST}:${FC.rem}${LAST}`, { type: 'expr', formula: `LEN(${FC.rem}${FIRST})>0`, dxf: { color: 'C00000' } });
    ws.print.paper = 8;
    FINAL[s.id] = { sheet: qs(ws.name), FC };
  };

  const summaryBlock = (ws, c0, rows, title_, chartTitle, chartRow) => {
    const hdr_ = ['Outcome', 'KPI', 'Class average', 'Students assessed', 'Students ≥ KPI', '% of students ≥ KPI', 'Class result'];
    cell(ws, 4, c0, title_, NAVY, 'FFFFFF', true, 10); ws.merge(4, c0, 4, c0 + hdr_.length - 1);
    hdr_.forEach((h, j) => { cell(ws, 5, c0 + j, h, LIGHT, '000000', true, 8); ws.width(c0 + j, 12); });
    rows.forEach(([code, kpi, pc], i) => {
      const r_ = 6 + i, rng = `${pc}${FIRST}:${pc}${LAST}`;
      const vals = [`=${code}`, `=${kpi}`, `=IF(COUNT(${rng})=0,"",AVERAGE(${rng}))`, `=COUNT(${rng})`, `=COUNTIF(${rng},">="&${kpi})`, `=IF(COUNT(${rng})=0,"",COUNTIF(${rng},">="&${kpi})/COUNT(${rng}))`, `=IF(COUNT(${rng})=0,"",IF(AVERAGE(${rng})>=${kpi},"Attained","Not attained"))`];
      const fm = [null, '0%', '0.0%', '0', '0', '0.0%', null];
      vals.forEach((v, j) => cell(ws, r_, c0 + j, v, GREY, '000000', j === 0 || j === 6, 9, C, fm[j]));
    });
    const res = `${L(c0 + 6)}6:${L(c0 + 6)}${5 + rows.length}`;
    ws.addCF(res, eq('"Attained"', OKD)); ws.addCF(res, eq('"Not attained"', BADD));
    note(ws, 7 + rows.length, c0, 'Class result: attained when the class average reaches the KPI.');
    const sn = qs(ws.name), r1 = 6, r2 = 5 + rows.length;
    ws.chart({
      title: chartTitle, pct: true, max: 1, labels: true, yTitle: 'Percent', at: { c: c0, r: chartRow, w: 7, h: 17 },
      cats: `${sn}!$${L(c0)}$${r1}:$${L(c0)}$${r2}`,
      series: [[1, 'BFBFBF'], [2, '2E75B6'], [5, '70AD47']].map(([j, color]) => ({ nameRef: `${sn}!$${L(c0 + j)}$5`, vals: `${sn}!$${L(c0 + j)}$${r1}:$${L(c0 + j)}$${r2}`, color })),
    });
  };

  const cloSheet = s => {
    const ws = scaffold(s, 'CLO', 'CLO-based Class Grades Sheet', true);
    const F = FINAL[s.id];
    const comps = Lo.usedComps, cc = {};
    comps.forEach((x, i) => (cc[x.id] = L(4 + i)));
    if (comps.length) groupHeader(ws, 4, 3 + comps.length, 'Assessment attainment (% of marks)', '1F7A5A');
    for (const x of comps) {
      const cl = cc[x.id];
      formulaCol(ws, cl, x.short === 'Quiz' ? 'Quizzes' : x.short === 'Assignment' ? 'Assignments' : x.short, '', r_ => {
        if (x.sec) { const t = TH[`${s.id}|${x.id}`]; return `=IF(OR(${BLANK(r_)},${t.sheet}!${t.pct}${r_}=""),"",${t.sheet}!${t.pct}${r_})`; }
        const fc = F.FC[`lab|${x.id}`];
        return `=IF(OR(${BLANK(r_)},${F.sheet}!${fc}${r_}=""),"",${F.sheet}!${fc}${r_}/${CFG[MARK_KEY[x.id]]})`;
      }, { fmt: '0.0%', width: 11 });
    }
    let col_ = 4 + comps.length;
    const pct = {}, stc = {};
    for (const k of Lo.clos) {
      const P_ = L(col_), S_ = L(col_ + 1); col_ += 2;
      cell(ws, 4, CI(P_), `=${OUT[k.id].code}&" (KPI = "&TEXT(${OUT[k.id].kpi},"0%")&")"`, TAB[s.id], 'FFFFFF', true); cell(ws, 4, CI(S_), null, TAB[s.id]); ws.merge(4, CI(P_), 4, CI(S_));
      const ws_ = Object.entries(k.w);
      const num = r_ => ws_.map(([id]) => `IF(${cc[id]}${r_}="",0,${W[`${k.id}|${id}`]}*${cc[id]}${r_})`).join('+');
      const den = r_ => ws_.map(([id]) => `IF(${cc[id]}${r_}="",0,${W[`${k.id}|${id}`]})`).join('+');
      formulaCol(ws, P_, `=${OUT[k.id].code}&" total (100%)"`, '', r_ => (ws_.length ? `=IF(OR(${BLANK(r_)},(${den(r_)})=0),"",(${num(r_)})/(${den(r_)}))` : '=""'), { fmt: '0.0%', width: 15, bold: true });
      formulaCol(ws, S_, 'Status', '', r_ => `=IF(${P_}${r_}="","",IF(${P_}${r_}>=${OUT[k.id].kpi},"Achieved","Not achieved"))`, { fmt: '@', width: 12 });
      ws.addCF(`${P_}${FIRST}:${P_}${LAST}`, bar('2E75B6'));
      const rg = `${S_}${FIRST}:${S_}${LAST}`; ws.addCF(rg, eq('"Achieved"', OKD)); ws.addCF(rg, eq('"Not achieved"', BADD));
      pct[k.id] = P_; stc[k.id] = S_;
    }
    stats(ws, 4, col_ - 1, [...Object.values(cc), ...Object.values(pct)]);
    ws.width(col_, 3);
    summaryBlock(ws, col_ + 1, Lo.clos.map(k => [OUT[k.id].code, OUT[k.id].kpi, pct[k.id]]), 'Class summary — course learning outcomes', `Section ${s.code}: CLO attainment`, 9 + Lo.clos.length);
    CLOS[s.id] = { sheet: qs(ws.name), pct, st: stc };
  };
  const ploSheet = s => {
    const ws = scaffold(s, 'PLO', 'PLO-based Class Grades Sheet', true);
    const CL = CLOS[s.id];
    let col_ = 4;
    const pct = {}, stc = {};
    for (const p of Lo.plos) {
      const ws_ = Object.entries(p.w);
      const srcCols = ws_.map(([id]) => [id, L(col_++)]);
      const P_ = L(col_), S_ = L(col_ + 1); col_ += 2;
      cell(ws, 4, CI(srcCols.length ? srcCols[0][1] : P_), `=${OUT[p.id].code}&" (KPI = "&TEXT(${OUT[p.id].kpi},"0%")&")"`, TAB[s.id], 'FFFFFF', true);
      ws.merge(4, CI(srcCols.length ? srcCols[0][1] : P_), 4, CI(S_));
      for (const [id, cl] of srcCols) {
        const k = Lo.clos.find(x => x.id === id);
        cell(ws, 5, CI(cl), `=${OUT[id].code}`, LIGHT, '000000', true, 8);
        cell(ws, 6, CI(cl), `=${W[`${p.id}|${id}`]}`, YELLOW, '000000', false, 8, C, '"weight "0%');
        cell(ws, 7, CI(cl), '', MAXF);
        ws.width(CI(cl), 12);
        for (let r_ = FIRST; r_ <= LAST; r_++) cell(ws, r_, CI(cl), `=IF(OR(${BLANK(r_)},${CL.sheet}!${CL.pct[id]}${r_}=""),"",${CL.sheet}!${CL.pct[id]}${r_})`, GREY, '000000', false, 9, RGT, '0.0%');
        void k;
      }
      const num = r_ => srcCols.map(([id, cl]) => `IF(${cl}${r_}="",0,${W[`${p.id}|${id}`]}*${cl}${r_})`).join('+');
      const den = r_ => srcCols.map(([id, cl]) => `IF(${cl}${r_}="",0,${W[`${p.id}|${id}`]})`).join('+');
      formulaCol(ws, P_, 'Total 100%', '', r_ => (srcCols.length ? `=IF(OR(${BLANK(r_)},(${den(r_)})=0),"",(${num(r_)})/(${den(r_)}))` : '=""'), { fmt: '0.0%', width: 15, bold: true });
      formulaCol(ws, S_, 'Status', '', r_ => `=IF(${P_}${r_}="","",IF(${P_}${r_}>=${OUT[p.id].kpi},"Achieved","Not achieved"))`, { fmt: '@', width: 12 });
      ws.addCF(`${P_}${FIRST}:${P_}${LAST}`, bar('7030A0'));
      const rg = `${S_}${FIRST}:${S_}${LAST}`; ws.addCF(rg, eq('"Achieved"', OKD)); ws.addCF(rg, eq('"Not achieved"', BADD));
      pct[p.id] = P_; stc[p.id] = S_;
    }
    stats(ws, 4, col_ - 1, Array.from({ length: col_ - 4 }, (_, i) => L(4 + i)));
    ws.width(col_, 3);
    summaryBlock(ws, col_ + 1, Lo.plos.map(p => [OUT[p.id].code, OUT[p.id].kpi, pct[p.id]]), 'Class summary — programme learning outcomes', `Section ${s.code}: PLO attainment`, 9 + Lo.plos.length);
    PLOS[s.id] = { sheet: qs(ws.name), pct, st: stc };
  };
  // Final Sheet needs CLO/PLO sheet columns and CLO needs Final lab columns: compute the CLO/PLO column letters first
  for (const s of secs) {
    const comps = Lo.usedComps.length;
    let col_ = 4 + comps; const pct = {}, stc = {};
    for (const k of Lo.clos) { pct[k.id] = L(col_); stc[k.id] = L(col_ + 1); col_ += 2; }
    CLOS[s.id] = { sheet: qs(sheetName(s, 'CLO')), pct, st: stc };
    col_ = 4; const ppct = {}, pst = {};
    for (const p of Lo.plos) { col_ += Object.keys(p.w).length; ppct[p.id] = L(col_); pst[p.id] = L(col_ + 1); col_ += 2; }
    PLOS[s.id] = { sheet: qs(sheetName(s, 'PLO')), pct: ppct, st: pst };
  }
  for (const s of secs) {
    finalSheet(s);
    if (Lo.clos.length) cloSheet(s);
    if (Lo.plos.length) ploSheet(s);
  }

  // ==================================================================== Section Results
  const SR = wb.add('Section Results');
  SR.tab = NAVY; SR.grid = false;
  text(SR, 1, 1, `${TITLE} — Section-wise Results`, { sz: 14, b: true, color: NAVY });
  text(SR, 2, 1, `${semesterLabel(sem)}   ·   all values are formulas from the Final Sheets`, { color: '595959' });
  const nS = secs.length, ALLC = 3 + nS;
  SR.width(1, 3); SR.width(2, 46); for (let i = 0; i < nS + 1; i++) SR.width(3 + i, 15);
  cell(SR, 5, 2, 'Measure', NAVY, 'FFFFFF', true, 10);
  secs.forEach((s, k) => cell(SR, 5, 3 + k, `="Section ${s.code}"&CHAR(10)&${SECNAME(s)}`, TAB[s.id], 'FFFFFF', true, 10));
  cell(SR, 5, ALLC, 'All sections', NAVY, 'FFFFFF', true, 10);
  SR.height(5, 30);
  const rng = (s, key) => `${FINAL[s.id].sheet}!${FINAL[s.id].FC[key]}${FIRST}:${FINAL[s.id].FC[key]}${LAST}`;
  const allr = key => secs.map(s => rng(s, key)).join(',');
  const avg = key => [s => `=IFERROR(AVERAGE(${rng(s, key)}),"")`, `=IFERROR(AVERAGE(${allr(key)}),"")`];
  const mx_ = (key, fn) => [s => `=IF(COUNT(${rng(s, key)})=0,"",${fn}(${rng(s, key)}))`, `=IF(COUNT(${allr(key)})=0,"",${fn}(${allr(key)}))`];
  const cntEq = (key, v) => [s => `=COUNTIF(${rng(s, key)},"${v}")`, '=' + secs.map(s => `COUNTIF(${rng(s, key)},"${v}")`).join('+')];
  const nm = s => `${FINAL[s.id].sheet}!$C$${FIRST}:$C$${LAST}`;
  const cnt = s => `SUMPRODUCT(--(${nm(s)}<>""))`;
  const graded = s => `SUMPRODUCT(--(${rng(s, 'grade')}<>""))`;
  const passed = s => `(${graded(s)}-COUNTIF(${rng(s, 'grade')},"F"))`;
  const share = (key, kpi) => [s => `=IF(COUNT(${rng(s, key)})=0,"",COUNTIF(${rng(s, key)},">="&${kpi})/COUNT(${rng(s, key)}))`,
    `=IF(COUNT(${allr(key)})=0,"",(` + secs.map(s => `COUNTIF(${rng(s, key)},">="&${kpi})`).join('+') + `)/COUNT(${allr(key)}))`];
  const rows = [['Enrolment and classes']];
  rows.push(['Students in section', s => `=${cnt(s)}`, '=' + secs.map(cnt).join('+'), '0', false]);
  if (Lo.T) rows.push(['Lectures held', s => `=${ATT[`${s.id}|lec`].sheet}!$${ATT[`${s.id}|lec`].pct}$7`, '', '0', false]);
  if (Lo.L) rows.push(['Labs held (lab group of the same section)', s => `=${ATT[`${s.id}|lab`].sheet}!$${ATT[`${s.id}|lab`].pct}$7`, '', '0', false]);
  rows.push(['Attendance']);
  if (Lo.T) { rows.push(['Average theory attendance %', ...avg('tattp'), '0.0%', true]); rows.push(['Students short in theory attendance', ...cntEq('tatts', 'Short'), '0', false]); }
  if (Lo.L) { rows.push(['Average lab attendance %', ...avg('lattp'), '0.0%', true]); rows.push(['Students short in lab attendance', ...cntEq('latts', 'Short'), '0', false]); }
  if (Lo.T) {
    rows.push(['Theory marks (class averages)']);
    for (const x of Lo.theory) {
      const nmx = x.short === 'Quiz' ? 'Quizzes' : x.short === 'Assignment' ? 'Assignments' : x.short;
      const hm = 'MAX(' + secs.map(s => `${TH[`${s.id}|${x.id}`].sheet}!$${TH[`${s.id}|${x.id}`].total}$7`).join(',') + ')';
      const held = secs.map(s => `COUNT(${TH[`${s.id}|${x.id}`].sheet}!$${TH[`${s.id}|${x.id}`].total}$${FIRST}:$${TH[`${s.id}|${x.id}`].total}$${LAST})`).join('+');
      rows.push([`=IF((${held})=0,"${nmx} (not held yet)","${nmx} (out of "&TEXT(${hm},"0.##")&")")`, ...avg(`th|${x.id}`), '0.0', false]);
    }
    rows.push(['Theory %', ...avg('thpct'), '0.0%', true]);
  }
  if (Lo.L && Lo.labComps.length) {
    rows.push(['Lab marks (class averages)']);
    for (const x of Lo.labComps) rows.push([`="${x.short} (out of "&TEXT(${CFG[MARK_KEY[x.id]]},"0.##")&")"`, ...avg(`lab|${x.id}`), '0.0', false]);
    rows.push([`="Lab total (out of "&TEXT(${CFG.M_TOTAL},"0.##")&")"`, ...avg('labtot'), '0.0', false]);
    rows.push(['Lab %', ...avg('labpct'), '0.0%', true]);
  }
  if (Lo.clos.length || Lo.plos.length) rows.push(['Course and programme learning outcomes']);
  const OUTROWS = {};
  for (const k of Lo.clos) {
    rows.push([`="Average "&${OUT[k.id].code}&" attainment"`, ...avg(`clo|${k.id}`), '0.0%', true]);
    rows.push([`="Students achieving "&${OUT[k.id].code}&" (≥ KPI)"`, ...share(`clo|${k.id}`, OUT[k.id].kpi), '0.0%', true]);
    OUTROWS[k.id] = rows.length;
  }
  for (const p of Lo.plos) {
    const key = `plo|${p.id}`;
    rows.push([`="Students achieving "&${OUT[p.id].code}`,
      s => `=IF(COUNTA(${rng(s, key)})-COUNTBLANK(${rng(s, key)})=0,"",COUNTIF(${rng(s, key)},"Achieved")/(COUNTIF(${rng(s, key)},"Achieved")+COUNTIF(${rng(s, key)},"Not achieved")))`,
      '=IFERROR((' + secs.map(s => `COUNTIF(${rng(s, key)},"Achieved")`).join('+') + ')/(' + secs.map(s => `COUNTIF(${rng(s, key)},"Achieved")+COUNTIF(${rng(s, key)},"Not achieved")`).join('+') + '),"")', '0.0%', true]);
    OUTROWS[p.id] = rows.length;
  }
  rows.push(['Result']);
  rows.push(['Average course total %', ...avg('ct'), '0.0%', true], ['Highest course total %', ...mx_('ct', 'MAX'), '0.0%', true], ['Lowest course total %', ...mx_('ct', 'MIN'), '0.0%', true]);
  rows.push(['Students passed (grade D or better)', s => `=${passed(s)}`, '=' + secs.map(passed).join('+'), '0', false]);
  rows.push(['Students failed (F)', ...cntEq('grade', 'F'), '0', false]);
  rows.push(['Pass rate', s => `=IF(${graded(s)}=0,"",${passed(s)}/${graded(s)})`, `=IF((${secs.map(graded).join('+')})=0,"",(${secs.map(passed).join('+')})/(${secs.map(graded).join('+')}))`, '0.0%', true]);
  let r2 = 6; const ROWAT = {};
  rows.forEach(([lab, fn, allf, fmt, isbar], i) => {
    if (fn === undefined) { cell(SR, r2, 2, lab, LIGHT, NAVY, true, 10, LFT); for (let c_ = 3; c_ <= ALLC; c_++) cell(SR, r2, c_, '', LIGHT); }
    else {
      cell(SR, r2, 2, lab, null, '000000', false, 10, LFT);
      secs.forEach((s, k) => cell(SR, r2, 3 + k, fn(s), GREY, '000000', false, 10, fmt.includes('%') ? RGT : C, fmt));
      cell(SR, r2, ALLC, allf, 'E7E6E6', '000000', true, 10, fmt.includes('%') ? RGT : C, fmt);
      if (isbar) SR.addCF(`C${r2}:${L(ALLC)}${r2}`, bar('5B9BD5'));
    }
    ROWAT[i + 1] = r2; r2++;
  });
  r2++;
  const outs = [...Lo.clos, ...Lo.plos];
  const OA0 = r2;
  if (outs.length) {
    cell(SR, r2, 2, 'Students achieving the KPI (% of assessed)', NAVY, 'FFFFFF', true, 10, LFT);
    secs.forEach((s, k) => cell(SR, r2, 3 + k, `Section ${s.code}`, TAB[s.id], 'FFFFFF', true, 10));
    cell(SR, r2, ALLC, 'All sections', NAVY, 'FFFFFF', true, 10);
    outs.forEach((k, i) => {
      const rr_ = r2 + 1 + i, src = ROWAT[OUTROWS[k.id]];
      cell(SR, rr_, 2, `=${OUT[k.id].code}`, null, '000000', true, 10, LFT);
      for (let c_ = 3; c_ <= ALLC; c_++) cell(SR, rr_, c_, `=${L(c_)}${src}`, GREY, '000000', false, 10, RGT, '0.0%');
    });
    r2 += outs.length + 2;
  }
  const GD0 = r2;
  cell(SR, r2, 2, 'Grade distribution (students per grade)', NAVY, 'FFFFFF', true, 10, LFT);
  secs.forEach((s, k) => cell(SR, r2, 3 + k, `Section ${s.code}`, TAB[s.id], 'FFFFFF', true, 10));
  cell(SR, r2, ALLC, 'All sections', NAVY, 'FFFFFF', true, 10);
  P.grades.forEach((_, i) => {
    const rr_ = r2 + 1 + i, gref = `Settings!$J$${G1 - i}`;
    cell(SR, rr_, 2, `=${gref}`, null, '000000', false, 10, LFT);
    secs.forEach((s, k) => cell(SR, rr_, 3 + k, `=COUNTIF(${rng(s, 'grade')},${gref})`, GREY, '000000', false, 10));
    cell(SR, rr_, ALLC, `=SUM(C${rr_}:${L(ALLC - 1)}${rr_})`, 'E7E6E6', '000000', true, 10);
  });
  const GD1 = r2 + P.grades.length;
  secs.forEach((s, k) => SR.addCF(`${L(3 + k)}${GD0 + 1}:${L(3 + k)}${GD1}`, { type: 'bar', color: TAB[s.id], max: 'max' }));
  const srn = qs('Section Results');
  if (outs.length) SR.chart({ title: 'CLO / PLO attainment by section', yTitle: 'Students ≥ KPI', pct: true, max: 1, labels: false, at: { c: 2, r: GD1 + 2, w: nS + 2, h: 17 },
    cats: `${srn}!$B$${OA0 + 1}:$B$${OA0 + outs.length}`, series: secs.map((s, k) => ({ nameRef: `${srn}!$${L(3 + k)}$${OA0}`, vals: `${srn}!$${L(3 + k)}$${OA0 + 1}:$${L(3 + k)}$${OA0 + outs.length}`, color: TAB[s.id] })) });
  SR.chart({ title: 'Grade distribution by section', yTitle: 'Students', pct: false, labels: false, at: { c: 2, r: GD1 + (outs.length ? 20 : 2), w: nS + 2, h: 17 },
    cats: `${srn}!$B$${GD0 + 1}:$B$${GD1}`, series: secs.map((s, k) => ({ nameRef: `${srn}!$${L(3 + k)}$${GD0}`, vals: `${srn}!$${L(3 + k)}$${GD0 + 1}:$${L(3 + k)}$${GD1}`, color: TAB[s.id] })) });
  SR.print = { orient: 'portrait', paper: 9, fitW: 1, fitH: 0 };

  // ==================================================================== Home + buttons
  const H = wb.add('Home');
  H.tab = 'C00000'; H.grid = false;
  const button = (ws, r_, c_, target, label, bg, fg = 'FFFFFF', size = 10, mergeTo = null, height = null) => {
    ws.set(r_, c_, label, { font: { b: true, sz: size, color: fg }, fill: bg, align: { h: 'center', v: 'center', wrap: true }, border: { l: { style: 'medium', color: 'FFFFFF' }, r: { style: 'medium', color: 'FFFFFF' }, t: { style: 'medium', color: 'FFFFFF' }, b: { style: 'medium', color: 'FFFFFF' } } });
    ws.link(r_, c_, `${qs(target)}!A1`, `Go to ${target}`);
    if (mergeTo) ws.merge(r_, c_, r_, mergeTo);
    if (height) ws.height(r_, height);
  };
  const ncol = Math.max(4, nS);
  H.width(1, 3);
  for (let i = 0; i < ncol; i++) { H.width(2 + 2 * i, 26); H.width(3 + 2 * i, 2); }
  const lastCol = 2 + 2 * (ncol - 1);
  text(H, 2, 2, TITLE, { sz: 20, b: true, color: NAVY }); H.height(2, 30);
  text(H, 3, 2, `Attendance, Marks, CLO/PLO and Results Register — ${semesterLabel(sem)}${course.credit ? ' · ' + course.credit : ''}`, { sz: 11, color: '595959' });
  text(H, 4, 2, `${sem.dept || ''}${state.profile.university ? '   ·   ' + state.profile.university : ''}${state.profile.instructor ? '   ·   Instructor: ' + state.profile.instructor : ''}`, { color: '595959' });
  note(H, 6, 2, 'Click a button to open a sheet. Every sheet has a  ⌂ Home  button (top left) that brings you back here.', 10);
  H.merge(6, 2, 6, lastCol);
  text(H, 8, 2, 'Course set-up and results', { sz: 12, b: true, color: NAVY });
  const gen_ = [['Settings', 'Settings', 'Weights, max marks, grades, CLO/PLO', '404040'], ['Schedule', 'Schedule', `${Lo.weeks}-week dates of all sections`, '595959'], ['Students', 'Class Lists', 'Students of each section', '1F3864']];
  if (Lo.L) gen_.push(['Lab Groups', 'Lab Groups', 'Lab group lists', '1F7A5A']);
  gen_.forEach(([sheet, label, nt, bg], i) => { const c_ = 2 + 2 * i; button(H, 9, c_, sheet, label, bg, 'FFFFFF', 11, null, 32); H.set(10, c_, nt, { font: { sz: 8, i: true, color: '7F7F7F' }, align: C }); });
  button(H, 11, 2, 'Section Results', 'Section-wise Results  ·  attendance, marks, CLO/PLO attainment and grades', 'C00000', 'FFFFFF', 11, lastCol, 32);
  text(H, 13, 2, 'Section sheets', { sz: 12, b: true, color: NAVY });
  const groups_ = {};
  Lo.pages.forEach(p => (groups_[p.group] = groups_[p.group] || []).push(p));
  let maxRow = 14;
  secs.forEach((s, i) => {
    const c_ = 2 + 2 * i;
    H.set(14, c_, { f: `"Section ${s.code}  ·  "&${SECNAME(s)}` }, { font: { sz: 12, b: true, color: 'FFFFFF' }, fill: TAB[s.id], align: C });
    H.set(15, c_, { f: `"Students: "&SUMPRODUCT(--(Students!$${NAMEC[s.id]}$${FIRST}:$${NAMEC[s.id]}$${LAST}<>""))` }, { font: { sz: 9, color: '595959' }, align: C });
    let rr_ = 16;
    for (const [g, pages] of Object.entries(groups_)) {
      H.set(rr_, c_, g, { font: { sz: 8, b: true, color: '7F7F7F' }, align: { h: 'left', v: 'bottom' } }); H.height(rr_, 16); rr_++;
      for (const p of pages) {
        const fin = p.id === 'Final Sheet';
        button(H, rr_, c_, sheetName(s, p.id), p.title, fin ? TAB[s.id] : TINT[s.id], fin ? 'FFFFFF' : TAB[s.id], 10, null, 24); rr_++;
      }
    }
    maxRow = Math.max(maxRow, rr_);
  });
  H.height(14, 28);
  note(H, maxRow + 1, 2, 'Lab group = the section of the same code unless you change Lab Groups. Lab results reach the Final Sheet by Reg. No.', 9);
  H.print = { orient: 'portrait', paper: 9, fitW: 1, fitH: 1 };
  for (const ws of wb.sheets) {
    if (ws.name === 'Home') continue;
    const c_ = ['Settings', 'Section Results', 'Schedule'].includes(ws.name) ? 2 : 1;
    button(ws, 3, c_, 'Home', '⌂ Home', 'C00000', 'FFFFFF', 10, c_ === 1 ? 2 : null);
    ws.height(3, 22);
  }
  const order = ['Home', 'Settings', 'Schedule', 'Section Results', 'Students'];
  if (Lo.L) order.push('Lab Groups');
  for (const s of secs) for (const p of Lo.pages) order.push(sheetName(s, p.id));
  wb.order = order;
  if (order.length !== wb.sheets.length) throw new Error('sheet order mismatch');
  return { wb, map, Lo, meta: { FINAL, CLOS, PLOS, LB, TH, SR: { ROWAT, OUTROWS, OA0, GD0 } } };
}

export async function buildXlsx(state, course, type = 'uint8array') {
  const { wb } = buildRegister(state, course);
  return wb.build(type);
}
export { DAYS };
