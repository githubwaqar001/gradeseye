// Google Drive sync for many registers (one Excel file per course) through the user's Apps Script web app.
// Every edit is saved on the phone first; each course file is rewritten when online (debounced) and edits made to it
// in Excel are loaded back. Changes are recognised by the MD5 checksum Drive reports, never by the phone clock.
import { store, http, isOnline } from './platform.js';
import { buildBytes } from './offload.js';
import { readCourseXlsx, LayoutError } from './ximport.js';
import { md5hex, bytesToBase64 } from './md5.js';
import { semOf, fileNameOf, folderPathOf } from './model.js';

const DEBOUNCE = 12000, POLL = 5 * 60000;
function safeJSON(t) { try { return t ? JSON.parse(t) : null; } catch (e) { return null; } }

export const cfg = Object.assign({ url: '', key: '', folder: '', auto: true, folderName: '', scriptVersion: 0, epoch: 0, files: {} }, safeJSON(store.load('sync2')) || {});
export function saveCfg() { store.save('sync2', JSON.stringify(cfg)); }
export const configured = () => !!(cfg.url && cfg.key);

// carry over the connection of the single-course app (v1)
export function migrateV1Sync(courseId) {
  const v1 = safeJSON(store.load('sync'));
  if (!v1 || store.load('sync2')) return;
  Object.assign(cfg, { url: v1.url || '', key: v1.key || '', folder: v1.folder || '', auto: v1.auto !== false, folderName: v1.folderName || '' });
  if (courseId && v1.fileId) cfg.files[courseId] = { fileId: v1.fileId, webLink: v1.webLink || '', lastMd5: v1.lastMd5 || '', pendingUpload: v1.pendingUpload && v1.pendingUpload.md5 ? { md5: v1.pendingUpload.md5, ver: 0 } : null, editVersion: 1, syncedVersion: 0, lastSync: v1.lastSync || 0, lastError: '' };
  saveCfg();
}

export const fileOf = id => cfg.files[id] || (cfg.files[id] = { fileId: '', webLink: '', lastMd5: '', pendingUpload: null, editVersion: 1, syncedVersion: 0, lastSync: 0, lastError: '' });
export const dirty = id => { const f = fileOf(id); return f.editVersion > f.syncedVersion; };

let hooks = null, timer = null, busy = false, queued = null;
const inflight = new Set();
const status = {};                 // per course: synced | pending | offline | syncing | error | conflict | local
const conflicts = {};
export const courseStatus = id => (!configured() ? 'local' : status[id] || (dirty(id) ? (isOnline() ? 'pending' : 'offline') : 'synced'));
export const conflictOf = id => conflicts[id] || null;
export function overall(ids) {
  if (!configured()) return { status: 'local', pending: 0 };
  const sts = ids.map(courseStatus), pending = ids.reduce((a, id) => a + Math.max(0, fileOf(id).editVersion - fileOf(id).syncedVersion), 0);
  for (const s of ['conflict', 'syncing', 'error', 'offline', 'pending']) if (sts.includes(s)) return { status: s, pending };
  return { status: 'synced', pending };
}
function set(id, s) { if (s === null) delete status[id]; else status[id] = s; if (s !== 'conflict') delete conflicts[id]; hooks && hooks.onStatus(); }

export function init(h) {
  hooks = h;
  window.__nativeOnline = on => { if (on) schedule(1500); else hooks.onStatus(); };
  window.addEventListener('online', () => schedule(1500));
  window.addEventListener('offline', () => hooks.onStatus());
  setInterval(() => { if (configured() && cfg.auto && isOnline() && !busy) syncAll(); }, POLL);
  if (configured() && cfg.auto) schedule(2500);
  hooks.onStatus();
}

export function edited(ids) {
  for (const id of ids) { const f = fileOf(id); f.editVersion++; if (status[id] !== 'conflict' && status[id] !== 'syncing') delete status[id]; }
  saveCfg();
  hooks.onStatus();
  if (configured() && cfg.auto) schedule(DEBOUNCE);
}
export function forgetCourse(id) { delete cfg.files[id]; delete status[id]; delete conflicts[id]; saveCfg(); }

let nextOpts = {};
export function schedule(ms, opts = {}) {
  clearTimeout(timer);
  if (!configured()) return;
  nextOpts = Object.assign({}, nextOpts, opts);
  timer = setTimeout(() => { const o = nextOpts; nextOpts = {}; syncAll(o); }, ms);
}

class SyncError extends Error { constructor(kind, msg) { super(msg); this.kind = kind; } }
const folderIdOf = link => {
  const s = String(link || '').trim();
  if (!s) return '';
  const m = /\/folders\/([\w-]+)/.exec(s) || /[?&]id=([\w-]+)/.exec(s);
  if (m) return m[1];
  return /^[\w-]{10,}$/.test(s) ? s : '';
};
export { folderIdOf };

export async function api(action, extra = {}) {
  const body = JSON.stringify(Object.assign({ action, key: cfg.key.trim(), folderId: folderIdOf(cfg.folder) }, extra));
  const r = await http(cfg.url.trim(), body);
  if (!r.status) throw new SyncError('network', 'No connection to Google (' + (r.text || 'network error') + ')');
  let j;
  try { j = JSON.parse(r.text); } catch (e) {
    throw new SyncError('setup', `The Drive script did not answer correctly (HTTP ${r.status}). Check the web app URL (it ends with /exec) and that it was deployed with access "Anyone".`);
  }
  if (!j.ok && !j.conflict) throw new SyncError('server', j.error || 'The Drive script reported an error.');
  return j;
}
export async function testConnection() {
  const j = await api('ping');
  cfg.folderName = j.folder ? j.folder.name : ''; cfg.scriptVersion = j.version || 1;
  saveCfg();
  return j;
}

const target = (st, c) => { const f = fileOf(c.id), sem = semOf(st, c); return { fileId: f.fileId, name: fileNameOf(c), path: folderPathOf(sem) }; };

// sync every course (sequentially). opts.manual = started by the user
export async function syncAll(opts = {}) {
  if (!configured()) return { ok: false, reason: 'not-configured' };
  if (!isOnline()) { hooks.onStatus(); return { ok: false, reason: 'offline' }; }
  if (busy) { queued = Object.assign(queued || {}, opts); return { ok: false, reason: 'busy' }; }
  busy = true; clearTimeout(timer);
  const results = [];
  try {
    for (const c of hooks.getState().courses.slice()) {
      if (conflicts[c.id] && !opts.manual) continue;
      if (inflight.has(c.id)) continue;
      if (!opts.manual && !dirty(c.id) && Date.now() - (fileOf(c.id).lastCheck || 0) < 60000 && !opts.check) continue;
      results.push(await syncCourse(c.id, opts));
      if (results[results.length - 1].reason === 'network') break;
    }
    if (hooks.afterSync && !results.some(r => r.reason === 'network')) await hooks.afterSync();
  } finally {
    busy = false;
    if (queued) { const q = queued; queued = null; setTimeout(() => syncAll(q), 300); }
    else if (hooks.getState().courses.some(c => dirty(c.id) && !conflicts[c.id] && status[c.id] !== 'error') && cfg.auto) schedule(DEBOUNCE);
    hooks.onStatus();
  }
  return { ok: results.every(r => r.ok), results };
}

// opts.force: 'phone' = overwrite the Drive file with phone data, 'drive' = replace phone data with the Drive file
export async function syncCourse(id, opts = {}) {
  if (inflight.has(id)) return { ok: false, reason: 'busy', id };
  inflight.add(id);
  try { return await syncCourse_(id, opts); } finally { inflight.delete(id); }
}
class Reset extends Error {}
async function syncCourse_(id, opts) {
  const st = hooks.getState(), c = st.courses.find(x => x.id === id);
  if (!c) return { ok: false, reason: 'gone' };
  const f = fileOf(id), force = opts.force || null, epoch = cfg.epoch;
  const alive = () => { if (cfg.epoch !== epoch || !hooks.getState().courses.some(x => x.id === id)) throw new Reset(); };
  set(id, 'syncing');
  try {
    const info = await api('info', target(st, c));
    alive();
    f.lastCheck = Date.now();
    if (info.exists && Object.entries(cfg.files).some(([oid, of]) => oid !== id && of.fileId && of.fileId === info.fileId))
      throw new SyncError('setup', 'Another course already uses this Excel file. Give this course a different code or title.');
    const md5 = info.exists ? info.md5 || '' : '';
    if (info.exists) { f.fileId = info.fileId; f.webLink = info.url || f.webLink; }
    if (f.pendingUpload && md5 && md5 === f.pendingUpload.md5) { f.lastMd5 = md5; f.syncedVersion = Math.max(f.syncedVersion, f.pendingUpload.ver); f.pendingUpload = null; }
    saveCfg();
    if (force === 'drive') {
      if (!info.exists) throw new SyncError('server', 'There is no Excel file for this course in Drive yet.');
      if (!(await pull(c))) return raise(id, { during: true, modified: info.modified });
      return done(id, 'loaded');
    }
    const changedElsewhere = info.exists && md5 !== f.lastMd5;
    if (changedElsewhere && force !== 'phone') {
      const neverSynced = !f.lastMd5;
      if (neverSynced ? !hooks.hasCourseData(c) : !dirty(id)) {
        if (hooks.isEditing()) { set(id, null); schedule(20000); return { ok: false, reason: 'editing', id }; }
        if (!(await pull(c))) return raise(id, { during: true, modified: info.modified });
        return done(id, 'loaded');
      }
      return raise(id, { neverSynced, modified: info.modified });
    }
    if (dirty(id) || !info.exists || force === 'phone') {
      const st2 = hooks.getState(), c2 = st2.courses.find(x => x.id === id);
      if (!c2) return { ok: false, reason: 'gone', id };
      const ver = f.editVersion;
      const bytes = await buildBytes(st2, c2);
      alive();
      const sum = md5hex(bytes);
      f.pendingUpload = { md5: sum, ver }; saveCfg();
      const res = await api('save', Object.assign(target(st2, c2), { data: bytesToBase64(bytes), baseMd5: info.exists ? md5 : '', force: force === 'phone' }));
      alive();
      if (res.conflict) { f.pendingUpload = null; saveCfg(); return raise(id, { neverSynced: !f.lastMd5, modified: res.modified }); }
      f.fileId = res.fileId; f.webLink = res.url || f.webLink; f.lastMd5 = res.md5 || sum; f.pendingUpload = null; f.syncedVersion = ver;
      return done(id, 'saved');
    }
    return done(id, 'checked');
  } catch (e) {
    if (e instanceof Reset) { set(id, null); return { ok: false, reason: 'reset', id }; }
    if (e instanceof LayoutError) return raise(id, { layout: true, message: e.message });
    f.lastError = e.message; saveCfg();
    set(id, e.kind === 'network' ? 'offline' : 'error');
    return { ok: false, reason: e.kind || 'error', error: e.message, id };
  }
}
function done(id, what) {
  const f = fileOf(id);
  f.lastSync = Date.now(); f.lastError = ''; saveCfg();
  set(id, null);
  return { ok: true, what, id };
}
function raise(id, c) {
  conflicts[id] = c; status[id] = 'conflict'; hooks.onStatus();
  hooks.onConflict(id, c);
  return { ok: false, reason: 'conflict', id };
}
async function pull(c) {
  const f = fileOf(c.id), v = f.editVersion, st = hooks.getState(), epoch = cfg.epoch;
  const j = await api('load', target(st, c));
  if (cfg.epoch !== epoch) throw new Reset();
  const live = hooks.getState().courses.find(x => x.id === c.id);
  if (!live) throw new Reset();
  const res = await readCourseXlsx(hooks.getState(), live, j.data);
  if (f.editVersion !== v) return false;
  hooks.applyPull(c.id, res);
  f.fileId = j.fileId; f.webLink = j.url || f.webLink; f.lastMd5 = j.md5 || '';
  f.syncedVersion = f.editVersion; f.pendingUpload = null;
  saveCfg();
  return true;
}
export async function resolveConflict(id, choice) {
  for (let i = 0; i < 600 && (busy || inflight.has(id)); i++) await new Promise(r => setTimeout(r, 300));
  delete conflicts[id];
  return syncCourse(id, { force: choice, manual: true });
}
export function resetFiles() { cfg.epoch = (cfg.epoch || 0) + 1; cfg.portal = null; for (const f of Object.values(cfg.files)) Object.assign(f, { fileId: '', webLink: '', lastMd5: '', pendingUpload: null }); saveCfg(); }
export function disconnect() { cfg.epoch = (cfg.epoch || 0) + 1; cfg.portal = null; Object.assign(cfg, { url: '', key: '' }); for (const f of Object.values(cfg.files)) Object.assign(f, { fileId: '', webLink: '', lastMd5: '', pendingUpload: null, syncedVersion: 0, editVersion: 1 }); saveCfg(); hooks.onStatus(); }
