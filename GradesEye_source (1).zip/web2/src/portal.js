// Student app ("GradesEye Student"): per-course summaries of each student's own attendance and marks, PINs, and
// publishing them through the Drive script. Students never get the teacher's key: the script answers a student
// only with that student's own record, after checking Reg. No + PIN (stored in Drive as salted SHA-256 hashes).
import { calc, isNum, getMark, schedDate, examDate, activity } from './engine.js';
import { semOf, semesterLabel, courseLabel, NROW } from './model.js';
import { api, cfg, saveCfg, configured, dirty, conflictOf, courseStatus, fileOf } from './sync.js';
import { isOnline } from './platform.js';
import { md5hex } from './md5.js';
import { sha256hex } from './sha256.js';
import { Workbook } from './xlsxwriter.js';

export const normReg = s => String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
const PIN_CHARS = '23456789ABCDEFGHJKMNPQRSTUVWXYZ';          // no 0/O, 1/I/L look-alikes
function rnd(n) { const a = new Uint32Array(n); crypto.getRandomValues(a); return a; }
export const makePin = () => Array.from(rnd(8), x => PIN_CHARS[x % PIN_CHARS.length]).join('');   // 31^8 ≈ 8.5·10^11
export const fmtPin = p => (p && p.length === 8 ? `${p.slice(0, 4)}-${p.slice(4)}` : p || '');
// a Reg. No can sign in only if it has a number and a sensible length (placeholders like "N/A" or "-" cannot)
export const validKey = k => k.length >= 3 && k.length <= 40 && /\d/.test(k);
export function strongKey(len = 24) {
  const A = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  return Array.from(rnd(len), x => A[x % A.length]).join('');
}
const enc = s => new TextEncoder().encode(s);

// ------------------------------------------------------------------ settings kept in the register data
export function portalOf(st) {
  if (!st.portal) st.portal = { on: false, salt: '', pins: {}, courses: {} };
  const p = st.portal;
  p.pins = p.pins || {}; p.courses = p.courses || {};
  if (!p.salt) p.salt = Array.from(rnd(4), x => x.toString(16).padStart(8, '0')).join('');
  return p;
}
export const flagsOf = (st, id) => Object.assign({ publish: false, release: false }, portalOf(st).courses[id] || {});
export function setFlag(st, id, k, v) { const p = portalOf(st); p.courses[id] = Object.assign(flagsOf(st, id), { [k]: !!v }); }
export const portalTitle = st => [st.profile.instructor, st.profile.university].filter(Boolean).join(' · ') || 'My courses';

// students of a course = the class lists of its sections (lab-only students are matched to these by Reg. No)
export function studentsOf(st, c) {
  const sem = semOf(st, c), out = [];
  if (!sem) return out;
  for (const id of c.secIds) {
    const s = sem.sections.find(x => x.id === id); if (!s) continue;
    for (let r = 0; r < NROW; r++) { const x = s.students[r]; if (x && x.name) out.push({ secId: id, code: s.code, secName: s.name, r, reg: x.reg || '', name: x.name, key: normReg(x.reg) }); }
  }
  return out;
}
// Reg. Nos that cannot be used: invalid ones, and one Reg. No used by two different students (they would share a PIN)
export function regIssues(st, courses) {
  const names = new Map(), invalid = new Set();
  for (const c of courses) for (const x of studentsOf(st, c)) {
    if (!x.reg) continue;
    if (!validKey(x.key)) { invalid.add(x.key); continue; }
    const nm = x.name.toLowerCase().replace(/\s+/g, ' ').trim();
    if (!names.has(x.key)) names.set(x.key, new Map());
    names.get(x.key).set(nm, x.name);
  }
  const dup = new Map([...names].filter(([, m]) => m.size > 1).map(([k, m]) => [k, [...m.values()]]));
  return { dup, invalid, bad: new Set([...dup.keys(), ...invalid]) };
}
// give every student (with a usable Reg. No) of these courses a PIN; true when something was added
export function ensurePins(st, courses) {
  const p = portalOf(st); let added = false;
  for (const c of courses) for (const x of studentsOf(st, c)) if (validKey(x.key) && !p.pins[x.key]) { p.pins[x.key] = makePin(); added = true; }
  return added;
}
export const sharedCourses = st => (portalOf(st).on ? st.courses.filter(c => flagsOf(st, c.id).publish) : []);
// first time the student app is turned on: share the courses of the latest semester
export function firstTurnOn(st) {
  const p = portalOf(st);
  if (p.used) return;
  p.used = true;
  const starts = st.semesters.map(s => s.start || '').sort();
  const latest = starts[starts.length - 1];
  for (const c of st.courses) { const sem = semOf(st, c); if (sem && (sem.start || '') === latest && !p.courses[c.id]) setFlag(st, c.id, 'publish', true); }
}
export function newPin(st, key) { portalOf(st).pins[key] = makePin(); }

// ------------------------------------------------------------------ one course → what its students may see
const r4 = v => (isNum(v) ? Math.round(v * 1e4) / 1e4 : null);
const nn = v => (isNum(v) ? v : null);
const pctTxt = v => `${Math.round(v * 1000) / 10}%`;

// End-of-term parts (final exam, lab final) are shown only after the teacher releases the results; class averages too,
// and only with at least 5 marks (rounded), so that classmates' marks cannot be worked out from them.
const HIDE_UNTIL_RELEASE = new Set(['F', 'LFIN']);
export function buildCourse(st, c, bad = new Set()) {
  const R = calc(st, c), Lo = R.Lo, sem = R.sem, P = c.plan, fl = flagsOf(st, c.id), W = Lo.weeks;
  const avgOf = a => { const v = a.filter(isNum); return fl.release && v.length >= 5 ? Math.round((v.reduce((x, y) => x + y, 0) / v.length) * 10) / 10 : null; };
  const scheme = [];
  if (Lo.T && Lo.theory.length) scheme.push('Theory: ' + Lo.theory.map(t => `${t.title} ${pctTxt(t.weight)}`).join(' · '));
  if (Lo.L && Lo.labComps.length) scheme.push(`Lab (out of ${Lo.labTotalMax}): ` + Lo.labComps.map(x => `${x.title} ${x.marks}`).join(' · '));
  if (Lo.T && Lo.L) scheme.push(`Course total: theory ${pctTxt(Number(P.shares.T) || 0)} + lab ${pctTxt(Number(P.shares.L) || 0)}`);
  const head = { v: 1, id: c.id, code: c.code, title: c.title, name: courseLabel(c), type: c.type, credit: c.credit || '', sem: semesterLabel(sem), dept: sem.dept || '',
    weeks: W, thr: Number(P.thr) || 0, leave: String(P.leave).toLowerCase() === 'yes', released: !!fl.release, scheme };
  const regIdx = Lo.secs.map(s => R.lab[s.id].roster.map(x => String(x.reg).trim().toLowerCase()));
  const memo = new Map(), avgMemo = (k, f) => { if (!memo.has(k)) memo.set(k, f()); return memo.get(k); };
  const att = (kind, A, secId, page, r, kindKey) => {
    const row = A.rows[r], days = [];
    A.held.forEach((h, w) => { if (h) days.push([schedDate(sem, c, secId, kindKey, w + 1), String(getMark(c, secId, page, r, w) || '').toUpperCase()]); });
    return { k: kind, held: A.heldN, P: row.P, L: row.L, A: row.A, pct: r4(row.pct), st: row.status, days };
  };
  const allBlank = parts => parts.every(p => p[1] === null);
  const students = {};
  for (const sec of Lo.secs) {
    const S = R.sec[sec.id], so = c.sec[sec.id] || {};
    S.roster.forEach((x, r) => {
      if (!x.name || !x.reg) return;
      const key = normReg(x.reg); if (!validKey(key) || bad.has(key)) return;
      const rec = { reg: x.reg, name: x.name, sec: sec.name || sec.code, code: sec.code, inst: so.inst || '', att: [], marks: [] };
      if (Lo.T) rec.att.push(att('Theory', S['Theory Att'], sec.id, 'Theory Att', r, 'lec'));
      let lab = null;
      if (Lo.L) {
        const reg = String(x.reg).trim().toLowerCase();
        for (let g = 0; g < Lo.secs.length && !lab; g++) { const k = regIdx[g].indexOf(reg); if (k >= 0) lab = { id: Lo.secs[g].id, code: Lo.secs[g].code, r: k }; }
        if (lab) rec.att.push(Object.assign(att('Lab', R.lab[lab.id]['Lab Att'], lab.id, 'Lab Att', lab.r, 'lab'), { grp: lab.code, inst: (c.sec[lab.id] || {}).labInst || '' }));
        else rec.att.push({ k: 'Lab', none: true });
      }
      for (const t of Lo.theory) {
        const X = S[t.id];
        if (!fl.release && HIDE_UNTIL_RELEASE.has(t.id)) { rec.marks.push({ k: t.title, kind: t.kind, n: 1, items: [], hidden: true }); continue; }
        if (t.kind === 'items') {
          const items = [];
          t.cols.forEach((col, i) => {
            if (!X.held[i]) return;
            items.push({ l: col.label, g: nn(getMark(c, sec.id, t.page, r, i)), m: col.max, d: schedDate(sem, c, sec.id, 'lec', Math.min(col.week, W)),
              avg: avgMemo(`${sec.id}|${t.id}|${i}`, () => avgOf(S.roster.map((y, rr) => (y.name ? getMark(c, sec.id, t.page, rr, i) : null)))) });
          });
          rec.marks.push({ k: t.title, kind: 'items', n: t.cols.length, items, tot: items.length ? { g: r4(X.rows[r].T), m: X.T7 } : null });
        } else {
          const items = [];
          if (X.any) {
            const parts = t.cols.map((col, i) => [col.label, nn(getMark(c, sec.id, t.page, r, i)), col.max]);
            items.push({ l: 'Your marks', g: allBlank(parts) ? null : r4(X.rows[r].T), m: X.T7, d: examDate(sem, c, t), parts,
              avg: avgMemo(`${sec.id}|${t.id}`, () => avgOf(X.rows.map(o => o && o.T))) });
          }
          rec.marks.push({ k: t.title, kind: 'exam', n: 1, items });
        }
      }
      if (lab) {
        const B = R.lab[lab.id], lr = lab.r;
        for (const x2 of Lo.labComps) {
          const E = B[x2.id], row = E.rows[lr], items = [];
          if (!fl.release && HIDE_UNTIL_RELEASE.has(x2.id)) { rec.marks.push({ k: x2.title, kind: x2.kind, n: 1, items: [], hidden: true }); continue; }
          if (x2.kind === 'exp') {
            const np = x2.crit.length;
            for (let e = 0; e < x2.exps; e++) {
              if (!E.expHeld[e]) continue;
              const parts = x2.crit.map((cr, j) => [cr[1], nn(getMark(c, lab.id, x2.page, lr, e * np + j)), Number(cr[2]) || 0]);
              items.push({ l: activity(c, Lo, e + 1) || `Exp. ${e + 1}`, g: allBlank(parts) ? null : r4(row.tot[e]), m: E.emax, d: schedDate(sem, c, lab.id, 'lab', Math.min(e + 1, W)), parts,
                avg: avgMemo(`${lab.id}|${x2.id}|${e}`, () => avgOf(E.rows.map(o => o && o.tot[e]))) });
            }
            rec.marks.push({ k: x2.title, kind: 'exp', n: x2.exps, items, sc: items.length ? { g: r4(row.SC), m: x2.marks } : null });
          } else if (x2.kind === 'single') {
            if (E.any) {
              const parts = x2.cols.map((col, j) => [col.label, nn(getMark(c, lab.id, x2.page, lr, j)), col.max]);
              items.push({ l: 'Your marks', g: allBlank(parts) ? null : r4(row.T), m: E.T7, d: schedDate(sem, c, lab.id, 'lab', Math.min(x2.week, W)), parts,
                avg: avgMemo(`${lab.id}|${x2.id}`, () => avgOf(E.rows.map(o => o && o.T))) });
            }
            rec.marks.push({ k: x2.title, kind: 'single', n: 1, items, sc: items.length ? { g: r4(row.SC), m: x2.marks } : null });
          } else {
            for (const [nm, label] of [['des', 'Design and implementation'], ['viva', 'Viva']]) {
              const b = E.blocks[nm]; if (!b.held) continue;
              const parts = b.idx.map(i => [x2.cols[i].label, nn(getMark(c, lab.id, x2.page, lr, i)), x2.cols[i].max]);
              items.push({ l: label, g: allBlank(parts) ? null : r4(row[nm].T), m: b.T7, d: schedDate(sem, c, lab.id, 'lab', Math.min(x2.week, W)), parts,
                avg: avgMemo(`${lab.id}|${x2.id}|${nm}`, () => avgOf(E.rows.map(o => o && o[nm].T))) });
            }
            rec.marks.push({ k: x2.title, kind: 'project', n: 2, items, sc: items.length ? { g: r4(row.P), m: x2.marks } : null });
          }
        }
      }
      if (fl.release) {
        const f = S.final[r];
        rec.res = { ct: r4(f.ct), grade: f.grade || '', rem: f.rem || '' };
        if (Lo.T) rec.res.th = r4(f.thpct);
        if (Lo.L) { const lt = lab && R.lab[lab.id].total && R.lab[lab.id].total.rows[lab.r]; rec.res.lab = { g: r4(f.labtot), m: Lo.labTotalMax, held: lt ? nn(lt.HM) : null, pct: r4(f.labpct) }; }
      }
      students[key] = rec;
    });
  }
  return Object.assign(head, { students });
}

// ------------------------------------------------------------------ publishing (after each Drive sync)
export function pstate() {
  if (!cfg.portal) cfg.portal = { hashes: {}, pinsSig: '', lastError: '', lastPublish: 0 };
  cfg.portal.hashes = cfg.portal.hashes || {};
  return cfg.portal;
}
export const publishedCount = () => Object.keys(pstate().hashes).length;
const memo = new Map();
let busy = false;
// a course is published only when the phone and its Drive Excel file agree (synced, no conflict)
export const readyToPublish = id => !dirty(id) && !conflictOf(id) && courseStatus(id) !== 'error' && !!fileOf(id).lastMd5;

// ------------------------------------------------------------------ faculty web dashboard: the whole course (all students),
// readable on the website only with the dashboard password the teacher sets in this app
export const webOf = st => portalOf(st).web || { on: false };
export function buildFacultyCourse(st, c) {
  const R = calc(st, c), Lo = R.Lo, sem = R.sem, P = c.plan, fl = flagsOf(st, c.id);
  const regIdx = Lo.secs.map(s => R.lab[s.id].roster.map(x => String(x.reg).trim().toLowerCase()));
  const sections = Lo.secs.map(sec => {
    const S = R.sec[sec.id], so = c.sec[sec.id] || {}, TA = Lo.T ? S['Theory Att'] : null;
    const students = [];
    S.roster.forEach((x, r) => {
      if (!x.name) return;
      const f = S.final[r], row = { r, reg: x.reg || '', key: normReg(x.reg), name: x.name };
      if (TA) { const a = TA.rows[r]; row.tatt = { P: a.P, L: a.L, A: a.A, held: TA.heldN, pct: r4(a.pct), st: a.status }; }
      if (Lo.L) {
        const reg = String(x.reg).trim().toLowerCase();
        let lab = null;
        for (let g = 0; g < Lo.secs.length && !lab && reg; g++) { const k = regIdx[g].indexOf(reg); if (k >= 0) lab = { id: Lo.secs[g].id, code: Lo.secs[g].code, r: k }; }
        if (lab) { const LA = R.lab[lab.id]['Lab Att'], a = LA.rows[lab.r]; row.latt = { grp: lab.code, P: a.P, L: a.L, A: a.A, held: LA.heldN, pct: r4(a.pct), st: a.status }; }
        else row.latt = { grp: '', none: true };
      }
      row.th = {}; for (const t of Lo.theory) row.th[t.id] = r4(f.th[t.id]);
      row.lab = f.lab.map(r4);
      row.thpct = r4(f.thpct); row.labtot = r4(f.labtot); row.labpct = r4(f.labpct);
      row.ct = r4(f.ct); row.grade = f.grade || ''; row.rem = f.rem || '';
      row.clo = {}; for (const k of Lo.clos) row.clo[k.id] = r4(f.clo[k.id]);
      students.push(row);
    });
    const max = {}; for (const t of Lo.theory) max[t.id] = S[t.id].T7;
    return { id: sec.id, code: sec.code, name: sec.name || sec.code, inst: so.inst || '', labInst: so.labInst || '',
      held: { theory: TA ? TA.heldN : null, lab: Lo.L ? R.lab[sec.id]['Lab Att'].heldN : null }, max, students };
  });
  const results = { rows: R.results.rows.map(x => (x.head ? { head: x.head } : { label: x.label, vals: x.vals.map(v => (typeof v === 'number' ? r4(v) : v)), all: typeof x.all === 'number' ? r4(x.all) : x.all, fmt: x.fmt })),
    grades: R.results.grades };
  return { v: 1, id: c.id, code: c.code, title: c.title, name: courseLabel(c), type: c.type, credit: c.credit || '', sem: semesterLabel(sem), dept: sem.dept || '',
    weeks: Lo.weeks, thr: Number(P.thr) || 0, leave: String(P.leave).toLowerCase() === 'yes', shared: !!(portalOf(st).on && fl.publish), released: !!fl.release,
    theory: Lo.theory.map(t => ({ id: t.id, title: t.title, short: t.short, weight: t.weight })), labComps: Lo.labComps.map(x => ({ id: x.id, title: x.title, short: x.short, marks: x.marks })),
    labTotalMax: Lo.labTotalMax, clos: Lo.clos.map(k => ({ id: k.id, code: k.code, kpi: Number(k.kpi) })), shares: { T: Number(P.shares.T) || 0, L: Number(P.shares.L) || 0 },
    sections, results };
}
// set (or clear, with an empty password) the website dashboard password; the script keeps only a salted, repeated hash
export async function setWebPassword(st, password) {
  const r = await api('fpass', password ? { password } : { clear: true });
  if (r.version) cfg.scriptVersion = Math.max(cfg.scriptVersion || 0, r.version);
  const p = portalOf(st);
  p.web = password ? { on: true, at: Date.now() } : { on: false, at: Date.now() };
  const pc = pstate(); pc.fhashes = {}; pc.fkeepSig = pc.fkeepSig || ''; saveCfg();
  return r;
}

export async function publish(h) {
  const st0 = h.getState(), p0 = portalOf(st0), pc0 = pstate();
  const doStudents = !!p0.used, doWeb = !!(webOf(st0).on || pc0.fkeepSig);
  if (busy || (!doStudents && !doWeb) || !configured() || !isOnline()) return { ok: false };
  busy = true;
  const pc = pstate(), errs = [];
  try {
    const st = h.getState(), p = portalOf(st);
    if (doStudents) {
      const want = sharedCourses(st);
      if (p.on && ensurePins(st, want)) h.saveState();
      const { bad } = regIssues(st, want);
      for (const c of want) {
        if (!readyToPublish(c.id)) continue;
        try {
          const f = fileOf(c.id), badHere = studentsOf(st, c).filter(x => bad.has(x.key)).map(x => x.key).sort();
          const key = [f.editVersion, f.lastMd5, JSON.stringify(flagsOf(st, c.id)), badHere.join(',')].join('|');
          let m = memo.get(c.id);
          if (!m || m.key !== key) { const text = JSON.stringify(buildCourse(st, c, bad)); m = { key, text, sig: md5hex(enc(text)) }; memo.set(c.id, m); }
          if (pc.hashes[c.id] === m.sig) continue;
          const body = JSON.parse(m.text); body.updated = Date.now();
          const r = await api('publish', { courseId: c.id, data: JSON.stringify(body) });
          if (r.version) cfg.scriptVersion = Math.max(cfg.scriptVersion || 0, r.version);
          pc.hashes[c.id] = m.sig; pc.lastPublish = Date.now(); saveCfg();
        } catch (e) {
          if (e.kind === 'network' || /Unknown action/i.test(String(e.message))) throw e;
          errs.push(`${courseLabel(c)}: ${e.message || e}`);
        }
      }
      // PIN hashes + which courses stay published (the script removes any other one, also after a reconnect)
      const pins = {};
      if (p.on) for (const c of want) for (const x of studentsOf(st, c)) if (validKey(x.key) && !bad.has(x.key) && p.pins[x.key]) pins[x.key] = sha256hex(`${p.salt}|${x.key}|${p.pins[x.key]}`);
      const keep = want.map(c => c.id).sort(), title = portalTitle(st);
      const sig = md5hex(enc(JSON.stringify([p.on, p.salt, title, keep, Object.keys(pins).sort().map(k => [k, pins[k]])])));
      if (sig !== pc.pinsSig) {
        const r = await api('pins', { open: !!p.on, salt: p.salt, title, pins, keep });
        if (r.version) cfg.scriptVersion = Math.max(cfg.scriptVersion || 0, r.version);
        pc.pinsSig = sig; pc.lastPublish = Date.now();
        for (const id of Object.keys(pc.hashes)) if (!keep.includes(id)) delete pc.hashes[id];
      }
      pc.lastError = errs.join(' · ');
    }
    if (doWeb) await publishWeb(st, pc);
    return { ok: !errs.length };
  } catch (e) {
    const msg = String(e.message || e);
    pc.lastError = /Unknown action/i.test(msg) ? 'Your Drive script is an older version. Copy the new script (version 5) into script.google.com and deploy a new version.' : e.kind === 'network' ? pc.lastError : msg;
    return { ok: false, error: pc.lastError };
  } finally {
    busy = false; saveCfg(); h.onStatus && h.onStatus();
  }
}
// every course that is in step with Drive goes to the faculty dashboard; the script removes the others
const fmemo = new Map();
async function publishWeb(st, pc) {
  const on = webOf(st).on, errs = [];
  pc.fhashes = pc.fhashes || {};
  if (on) for (const c of st.courses) {
    if (!readyToPublish(c.id)) continue;
    try {
      const f = fileOf(c.id), key = [f.editVersion, f.lastMd5, JSON.stringify(flagsOf(st, c.id)), portalOf(st).on].join('|');
      let m = fmemo.get(c.id);
      if (!m || m.key !== key) { const text = JSON.stringify(buildFacultyCourse(st, c)); m = { key, text, sig: md5hex(enc(text)) }; fmemo.set(c.id, m); }
      if (pc.fhashes[c.id] === m.sig) continue;
      const body = JSON.parse(m.text); body.updated = Date.now();
      await api('fpublish', { courseId: c.id, data: JSON.stringify(body), title: portalTitle(st) });
      pc.fhashes[c.id] = m.sig; pc.webPublish = Date.now(); saveCfg();
    } catch (e) {
      if (e.kind === 'network') throw e;
      if (/Unknown action/i.test(String(e.message))) { pc.webError = 'Update your Drive script to version 5 to use the website dashboard.'; return; }
      errs.push(`${courseLabel(c)}: ${e.message || e}`);
    }
  }
  const keep = on ? st.courses.map(c => c.id).sort() : [];
  const sig = md5hex(enc(JSON.stringify([on, keep])));
  if (sig !== pc.fkeepSig) {
    try { await api('fsync', { keep }); } catch (e) {
      if (e.kind === 'network') throw e;
      pc.webError = /Unknown action/i.test(String(e.message)) ? 'Update your Drive script to version 5 to use the website dashboard.' : String(e.message || e); return;
    }
    pc.fkeepSig = on ? sig : '';
    for (const id of Object.keys(pc.fhashes)) if (!keep.includes(id)) delete pc.fhashes[id];
    pc.webPublish = Date.now();
  }
  pc.webError = errs.join(' · ');
}

// the student app accepts only a Google Apps Script web-app address (a local address is allowed for tests)
export const validScriptUrl = u => /^https:\/\/script\.google\.com\/(macros|a\/macros\/[\w.-]+)\/s\/[\w-]+\/exec$/.test(String(u || '').trim()) || /^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?\/exec$/.test(String(u || '').trim());
// who has signed in to the student app (kept on the phone for offline viewing)
export async function fetchLogins() {
  try {
    const j = await api('logins');
    if (j.version) cfg.scriptVersion = Math.max(cfg.scriptVersion || 0, j.version);
    const pc = pstate();
    pc.logins = { time: Date.now(), data: j.logins || {} };
    saveCfg();
    return { ok: true };
  } catch (e) {
    const msg = String(e.message || e);
    return { ok: false, error: /Unknown action/i.test(msg) ? 'Update your Drive script to version 5 to see who has signed in.' : msg };
  }
}
export const loginsOf = () => pstate().logins || null;
// connection details students need (built into the student app, or pasted as a class code)
export const connectionOf = st => ({ v: 1, u: cfg.url.trim(), t: portalTitle(st) });
export function classCode(st) {
  const b = btoa(String.fromCharCode(...enc(JSON.stringify(connectionOf(st)))));
  return 'GE1-' + b.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

// ------------------------------------------------------------------ PIN slips (Excel, one sheet per section)
export async function pinWorkbook(st, c) {
  const wb = new Workbook(), p = portalOf(st), list = studentsOf(st, c), { bad } = regIssues(st, sharedCourses(st).concat([c]));
  wb.props = { title: `${courseLabel(c)} student app PINs`, creator: st.profile.instructor || 'GradesEye' };
  const bySec = new Map();
  list.forEach(x => { if (!bySec.has(x.secId)) bySec.set(x.secId, []); bySec.get(x.secId).push(x); });
  const thin = { l: { color: '808080' }, r: { color: '808080' }, t: { color: '808080' }, b: { color: '808080' } };
  const dashed = { l: { style: 'dashed', color: '808080' }, r: { style: 'dashed', color: '808080' }, t: { style: 'dashed', color: '808080' }, b: { style: 'dashed', color: '808080' } };
  const used = new Set();
  for (const [, xs] of bySec) {
    let name = String(xs[0].code || 'Section').replace(/[\\/?*[\]:]/g, ' ').slice(0, 25) || 'Section';
    while (used.has(name)) name += '_';
    used.add(name);
    const sh = wb.add(name);
    sh.width(1, 6); sh.width(2, 18); sh.width(3, 30); sh.width(4, 14); sh.width(5, 52);
    sh.set(1, 1, `${courseLabel(c)} — student app sign-in PINs`, { font: { b: true, sz: 13, color: '1F3864' } });
    sh.set(2, 1, `Section ${xs[0].code}${xs[0].secName ? ' (' + xs[0].secName + ')' : ''} · ${portalTitle(st)}`, { font: { i: true, color: '595959' } });
    sh.set(3, 1, 'Cut along the dashed lines and give each student their own slip. A PIN works for all of your courses.', { font: { sz: 9, color: '595959' } });
    const hs = { font: { b: true, color: 'FFFFFF' }, fill: '1F3864', border: thin, align: { h: 'center', v: 'center' } };
    ['#', 'Reg. No', 'Student name', 'PIN', 'Slip'].forEach((t, i) => sh.set(5, i + 1, t, hs));
    xs.forEach((x, i) => {
      const r = 6 + i, pin = x.key && !bad.has(x.key) ? fmtPin(p.pins[x.key] || '') : '';
      sh.height(r, 30);
      sh.set(r, 1, i + 1, { border: thin, align: { h: 'center', v: 'center' } });
      sh.set(r, 2, x.reg || '(no Reg. No)', { border: thin, align: { v: 'center' }, font: x.reg ? {} : { color: 'C00000' } });
      sh.set(r, 3, x.name, { border: thin, align: { v: 'center' } });
      sh.set(r, 4, pin || '—', { border: thin, align: { h: 'center', v: 'center' }, font: { b: true, sz: 14 } });
      sh.set(r, 5, pin ? `GradesEye Student · Reg. No ${x.reg} · PIN ${pin} · after signing in you can set your own password · keep it private` : 'Fix this Reg. No in the class list (missing, not a real number, or used by another student) to get a PIN', { border: dashed, align: { v: 'center', wrap: true }, font: { sz: 9 } });
    });
    sh.freeze = [6, 1];
    sh.print = { orient: 'portrait', paper: 9, fitW: 1, fitH: 0, rows: [5, 5], cols: null };
  }
  if (!wb.sheets.length) wb.add('PINs').set(1, 1, 'No students yet');
  return wb.build('uint8array');
}
