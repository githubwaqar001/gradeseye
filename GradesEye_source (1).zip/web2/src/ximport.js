// Reads the input cells of a course workbook (edited in Excel / Google Sheets on a PC) back into the app:
// settings, plan values, section names and instructors, schedule, class lists, lab groups, attendance and marks.
import JSZip from 'jszip';
import { NROW, FIRST, semOf } from './model.js';
import { layout, layoutSig, entryPages, MARK_KEY, WEIGHT_KEY } from './layout.js';

export class LayoutError extends Error {}
import { buildRegister } from './workbook.js';
import { isoOf, isNum } from './engine.js';

const unesc = s => String(s)
  .replace(/_x([0-9A-Fa-f]{4})_/g, (_, h) => String.fromCharCode(parseInt(h, 16)))
  .replace(/&#x([0-9a-fA-F]+);/g, (_, h) => String.fromCodePoint(parseInt(h, 16)))
  .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(Number(d)))
  .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
export const fromSerial = n => isoOf(Math.round((Number(n) - 25569) * 86400000));

async function sheetPaths(zip) {
  const wb = await zip.file('xl/workbook.xml').async('string');
  const rels = await zip.file('xl/_rels/workbook.xml.rels').async('string');
  const target = {};
  for (const m of rels.matchAll(/<Relationship\b[^>]*>/g)) {
    const id = /\bId="([^"]+)"/.exec(m[0]), t = /\bTarget="([^"]+)"/.exec(m[0]);
    if (id && t) target[id[1]] = t[1].startsWith('/') ? t[1].slice(1) : 'xl/' + t[1].replace(/^\.\//, '');
  }
  const out = {};
  for (const m of wb.matchAll(/<(?:\w+:)?sheet\b[^>]*>/g)) {
    const name = /\bname="([^"]*)"/.exec(m[0]), rid = /\br:id="([^"]+)"/.exec(m[0]) || /\b\w+:id="([^"]+)"/.exec(m[0]);
    if (name && rid) out[unesc(name[1])] = target[rid[1]];
  }
  return out;
}
function parseShared(xml) {
  if (!xml) return [];
  const out = [];
  for (const m of xml.matchAll(/<si>([\s\S]*?)<\/si>|<si\/>/g)) {
    const body = (m[1] || '').replace(/<rPh\b[\s\S]*?<\/rPh>/g, '');
    out.push(unesc([...body.matchAll(/<t\b[^>]*>([\s\S]*?)<\/t>|<t\b[^>]*\/>/g)].map(x => x[1] || '').join('')));
  }
  return out;
}
function parseCells(xml, ss) {
  const cells = new Map();
  for (const m of xml.matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
    const attrs = m[1], inner = m[2] || '';
    const r = /\br="([A-Z]+\d+)"/.exec(attrs);
    if (!r) continue;
    const t = (/\bt="(\w+)"/.exec(attrs) || [])[1] || 'n';
    const f = /<f\b/.test(inner), v = /<v>([\s\S]*?)<\/v>/.exec(inner);
    let val = '';
    if (t === 's') val = v ? ss[Number(v[1])] ?? '' : '';
    else if (t === 'inlineStr') val = unesc([...inner.matchAll(/<t\b[^>]*>([\s\S]*?)<\/t>/g)].map(x => x[1]).join(''));
    else if (t === 'str' || t === 'e') val = v ? unesc(v[1]) : '';
    else if (t === 'b') val = v ? v[1] === '1' : '';
    else val = v && v[1] !== '' ? Number(v[1]) : '';
    cells.set(r[1], { v: val, f });
  }
  return cells;
}

// returns { course (updated copy), students: {secId: {r: {reg,name,rem}}}, sectionNames: {secId: name}, warnings }
export async function readCourseXlsx(state, course, data) {
  const zip = await JSZip.loadAsync(data, typeof data === 'string' ? { base64: true } : {});
  const paths = await sheetPaths(zip);
  for (const need of ['Settings', 'Students']) if (!paths[need]) throw new Error(`This is not a register workbook made by the app (sheet "${need}" not found).`);
  const ssFile = zip.file('xl/sharedStrings.xml');
  const ss = parseShared(ssFile ? await ssFile.async('string') : '');
  const cache = {};
  const sheet = async name => { if (!cache[name]) cache[name] = paths[name] ? parseCells(await zip.file(paths[name]).async('string'), ss) : new Map(); return cache[name]; };
  const sem = semOf(state, course);
  const { map } = buildRegister(state, course);
  const Lo = layout(course, sem);
  const c = JSON.parse(JSON.stringify(course)), P = c.plan, warn = [];
  const S = await sheet('Settings');
  const sigCell = S.get('Z1'), sig = sigCell && typeof sigCell.v === 'string' && sigCell.v.startsWith('layout:') ? sigCell.v.slice(7) : '';
  if (sig !== layoutSig(course, sem)) throw new LayoutError(sig ? 'The Excel file in Drive was made with different course settings (number of sections, quizzes, questions, experiments or outcomes), so it cannot be loaded into the app safely.' : 'The Excel file in Drive was made by an older version of the app, so it cannot be loaded into the app safely.');
  const get = (sh, ref) => sh.get(ref) || { v: '', f: false };
  const txt = v => (v === '' || v === null || v === undefined ? '' : typeof v === 'number' ? String(v) : String(v).trim());
  const num = (ref, set) => { const v = get(S, ref).v; if (isNum(v)) set(v); };
  const M = map.settings;
  if (M.THR) num(M.THR, v => (P.thr = v));
  if (M.LEAVE) { const v = txt(get(S, M.LEAVE).v); if (v) P.leave = /^y/i.test(v) ? 'Yes' : 'No'; }
  for (const k of ['MIDD', 'FIND']) if (M[k]) { const cl = get(S, M[k]); c.dates[k] = !cl.f && isNum(cl.v) ? fromSerial(cl.v) : null; }
  let start = null;
  if (M.START) { const v = get(S, M.START).v; if (isNum(v)) start = fromSerial(v); }
  const lb = P.lab;
  const WK = { WK_LMID: lb.mid, WK_LFIN: lb.final, WK_OEL: lb.oel, WK_PROJ: lb.project };
  for (const [k, o] of Object.entries(WK)) if (M[k]) num(M[k], v => (o.week = Math.round(v)));
  const W = { W_Q: P.quizzes, W_A: P.assignments, W_M: P.mid, W_F: P.final };
  for (const [k, o] of Object.entries(W)) if (M[k]) num(M[k], v => (o.weight = v));
  if (M.SH_T) num(M.SH_T, v => (P.shares.T = v));
  if (M.SH_L) num(M.SH_L, v => (P.shares.L = v));
  const MK = { M_PERF: lb.perf, M_REP: lb.reports, M_LMID: lb.mid, M_LFIN: lb.final, M_OEL: lb.oel, M_PROJ: lb.project };
  for (const [k, o] of Object.entries(MK)) if (M[k]) num(M[k], v => (o.marks = v));
  if (M.P_DES) num(M.P_DES, v => (lb.project.des.scale = v));
  if (M.P_VIVA) num(M.P_VIVA, v => (lb.project.viva.scale = v));
  const sectionNames = {};
  for (const [secId, row] of Object.entries(map.sections)) {
    const x = c.sec[secId] || (c.sec[secId] = {});
    const name = txt(get(S, `C${row}`).v); if (name) sectionNames[secId] = name;
    const inst = get(S, `D${row}`).v, li = get(S, `E${row}`).v, lec = get(S, `F${row}`).v, lab = get(S, `G${row}`).v;
    x.inst = txt(inst); x.labInst = txt(li);
    if (isNum(lec)) x.lec = Math.max(0, Math.min(6, Math.round(lec))); if (isNum(lab)) x.lab = Math.max(0, Math.min(6, Math.round(lab)));
  }
  const grades = [];
  for (let i = 0; i < map.grades.n; i++) {
    const r = map.grades.first + i, mn = get(S, `I${r}`).v, g = get(S, `J${r}`).v, gp = get(S, `K${r}`).v;
    if (isNum(mn) && g !== '') grades.push([mn, txt(g), isNum(gp) ? gp : 0]);
  }
  if (grades.length) P.grades = grades;
  const setMax = (key, v) => {
    const [id, j] = key.split('|'), i = Number(j);
    if (id === 'Q') P.quizzes.items[i].max = v; else if (id === 'A') P.assignments.items[i].max = v;
    else if (id === 'M') P.mid.qs[i] = v; else if (id === 'F') P.final.qs[i] = v;
    else if (id === 'PROJD') lb.project.des.crit[i][2] = v; else if (id === 'PROJV') lb.project.viva.crit[i][2] = v;
    else { const o = { LPERF: lb.perf, LREP: lb.reports, LMID: lb.mid, LFIN: lb.final, OEL: lb.oel }[id]; if (o) o.crit[i][2] = v; }
  };
  for (const [key, ref] of Object.entries(map.max)) { const v = get(S, ref).v; if (isNum(v)) setMax(key, v); }
  for (const [id, row] of Object.entries(map.clos)) {
    const k = P.clos.find(x => x.id === id); if (!k) continue;
    const code = txt(get(S, `C${row}`).v), kpi = get(S, `D${row}`).v; if (code) k.code = code; if (isNum(kpi)) k.kpi = kpi; k.desc = txt(get(S, `E${row}`).v);
  }
  for (const [id, row] of Object.entries(map.plos)) {
    const p = P.plos.find(x => x.id === id); if (!p) continue;
    const code = txt(get(S, `C${row}`).v), kpi = get(S, `D${row}`).v; if (code) p.code = code; if (isNum(kpi)) p.kpi = kpi; p.desc = txt(get(S, `E${row}`).v);
  }
  for (const [key, ref] of Object.entries(map.cloW)) { const [kid, cid] = key.split('|'); const k = P.clos.find(x => x.id === kid); if (!k) continue; const v = get(S, ref).v; if (isNum(v) && v > 0) k.w[cid] = v; else delete k.w[cid]; }
  for (const [key, ref] of Object.entries(map.ploW)) { const [pid, kid] = key.split('|'); const p = P.plos.find(x => x.id === pid); if (!p) continue; const v = get(S, ref).v; if (isNum(v) && v > 0) p.w[kid] = v; else delete p.w[kid]; }
  // schedule
  const SC = await sheet('Schedule');
  c.schedule.dates = {}; c.schedule.notes = {};
  const defAct = w => { const n = Lo.L ? Number(P.lab.exps) || 0 : 0; return w <= n ? `Exp. ${String(w).padStart(2, '0')}` : ''; };
  for (let w = 1; w <= Lo.weeks; w++) {
    const r = map.schedule.first + w - 1;
    for (const [secId, cols] of Object.entries(map.schedule.cols)) for (const kind of ['lec', 'lab']) {
      if (!cols[kind]) continue;
      const cl = get(SC, `${cols[kind]}${r}`);
      if (!cl.f && isNum(cl.v)) c.schedule.dates[`${secId}|${kind}|${w}`] = fromSerial(cl.v);
    }
    const a = txt(get(SC, `${map.schedule.activity}${r}`).v);
    if (a !== defAct(w)) c.schedule.activities[w] = a; else delete c.schedule.activities[w];
    const n = txt(get(SC, `${map.schedule.notes}${r}`).v); if (n) c.schedule.notes[w] = n;
  }
  // class lists and lab groups
  const ST = await sheet('Students'), LG = await sheet('Lab Groups');
  const students = {};
  for (const [secId, cols] of Object.entries(map.roster)) {
    const list = (students[secId] = {});
    for (let i = 0; i < NROW; i++) {
      const r = FIRST + i, reg = txt(get(ST, `${cols.reg}${r}`).v), name = txt(get(ST, `${cols.name}${r}`).v), rem = txt(get(ST, `${cols.rem}${r}`).v);
      if (reg || name || rem) list[i] = { reg, name, rem };
    }
    if (!Lo.L) continue;
    const lg = c.labGroups[secId] || (c.labGroups[secId] = { custom: false, rows: {}, rem: {} });
    let custom = false;
    for (let i = 0; i < NROW && !custom; i++) for (const col of [cols.reg, cols.name]) { const cl = LG.get(`${col}${FIRST + i}`); if (!cl || !cl.f) { custom = true; break; } }
    lg.custom = custom; lg.rem = {};
    if (custom) lg.rows = {};
    for (let i = 0; i < NROW; i++) {
      const r = FIRST + i, rem = txt(get(LG, `${cols.rem}${r}`).v);
      if (rem) lg.rem[i] = rem;
      if (custom) {
        const cr = get(LG, `${cols.reg}${r}`), cn = get(LG, `${cols.name}${r}`), stu = students[secId][i] || {};
        const reg = cr.f ? (txt(cr.v) || stu.reg || '') : txt(cr.v), name = cn.f ? (txt(cn.v) || stu.name || '') : txt(cn.v);
        if (reg || name) lg.rows[i] = { reg, name };
      }
    }
  }
  // marks and attendance
  for (const [sheetName, e] of Object.entries(map.entries)) {
    const sh = await sheet(sheetName), page = Lo.page[e.page], key = `${e.secId}|${e.page}`;
    const m = {};
    for (let i = 0; i < NROW; i++) for (let k = 0; k < e.cols.length; k++) {
      const cl = sh.get(`${e.cols[k]}${FIRST + i}`);
      if (!cl || cl.f || cl.v === '' || cl.v === null) continue;
      let v = cl.v;
      if (page && page.kind === 'att') {
        v = String(v).trim().toUpperCase();
        if (!['P', 'A', 'L'].includes(v)) { warn.push(`${sheetName} ${e.cols[k]}${FIRST + i}: "${cl.v}" is not P, A or L`); continue; }
      } else {
        if (typeof v !== 'number') v = Number(String(v).trim());
        if (!isNum(v)) { warn.push(`${sheetName} ${e.cols[k]}${FIRST + i}: "${cl.v}" is not a number`); continue; }
      }
      m[`${i},${k}`] = v;
    }
    c.marks[key] = m;
  }
  return { course: c, students, sectionNames, start, warnings: warn };
}
export { entryPages, MARK_KEY, WEIGHT_KEY };
