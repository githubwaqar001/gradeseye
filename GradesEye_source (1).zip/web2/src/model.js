// Data model v2: departments → semesters (with sections and shared class lists) → courses / labs (one register each).
export const NROW = 100;                         // students per list (rows 8–107 in Excel)
export const FIRST = 8;
export const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
export const PALETTE = ['#2E75B6', '#548235', '#C55A11', '#7030A0', '#00808C', '#B4005A', '#6D5D00', '#3F51B5'];
export const TINTS = ['#DEEBF7', '#E2EFDA', '#FBE5D6', '#E4DFEC', '#D5EEF0', '#F6D9E6', '#EEEAD0', '#DFE3F5'];
export const TYPE_NAME = { TL: 'Theory + Lab', T: 'Theory course', L: 'Lab course' };

export const uid = p => p + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const clone = o => JSON.parse(JSON.stringify(o));

export function nextMonday(from = new Date()) {
  const d = new Date(Date.UTC(from.getFullYear(), from.getMonth(), from.getDate()));
  const add = (8 - d.getUTCDay()) % 7;
  return new Date(d.getTime() + add * 86400000).toISOString().slice(0, 10);
}

export function emptyState() {
  return { version: 2, profile: { university: 'HITEC University, Taxila', instructor: '' }, semesters: [], courses: [], updated: Date.now() };
}

export function newSemester(p = {}) {
  return {
    id: uid('s'), dept: p.dept || '', program: p.program || '', batch: p.batch || '', semester: p.semester || '',
    session: p.session || '', start: p.start || nextMonday(), weeks: Number(p.weeks) || 16, sections: [],
  };
}
export function newSection(code, name) { return { id: uid('x'), code: String(code).trim(), name: String(name || '').trim(), students: {} }; }

const PERF = [['SK', 'Subject Knowledge', 5], ['DA', 'Data Analysis & Interpretation', 5], ['AC', 'Ability to Conduct Exp.', 5]];
const REP = [['PR', 'Presentation', 5], ['CC', 'Calculation / Coding', 5], ['OB', 'Observations / Program Results', 5]];
const VIVA = [['RA', 'Responsiveness to Questions / Accuracy', 10], ['DK', 'Depth of Subject Knowledge', 10]];
export const GRADES = [[0, 'F', 0], [50, 'D', 1.0], [54, 'D+', 1.33], [58, 'C-', 1.67], [61, 'C', 2.0], [64, 'C+', 2.33],
  [68, 'B-', 2.67], [71, 'B', 3.0], [75, 'B+', 3.33], [80, 'A-', 3.67], [85, 'A', 4.0]];

export function defaultPlan(type) {
  const T = type !== 'L', L = type !== 'T';
  const plan = {
    thr: 0.75, leave: 'No',
    shares: { T: T && L ? 2 / 3 : T ? 1 : 0, L: T && L ? 1 / 3 : L ? 1 : 0 },
    quizzes: { weight: 0.15, items: T ? [{ label: 'Quiz 1', max: 10, week: 5 }, { label: 'Quiz 2', max: 10, week: 14 }] : [] },
    assignments: { weight: 0.15, items: T ? [{ label: 'Assignment 1', max: 20, week: 8 }, { label: 'Assignment 2', max: 20, week: 15 }] : [] },
    mid: { on: T, weight: 0.30, week: 9, qs: [10, 10, 10, 10, 10] },
    final: { on: T, weight: 0.40, week: 17, qs: Array(10).fill(10) },
    lab: {
      exps: L ? 14 : 0,
      perf: { on: L, marks: 6, crit: clone(PERF) },
      reports: { on: L, marks: 4, crit: clone(REP) },
      mid: { on: L, marks: 5, week: 8, crit: clone(PERF) },
      final: { on: L, marks: 5, week: 16, crit: clone(PERF) },
      oel: { on: L, marks: 5, week: 15, crit: clone(VIVA) },
      project: {
        on: L, marks: 8, week: 15,
        des: { scale: 3, crit: [['PC', 'Project Complexity', 5], ['IC', 'Implementation and Completion', 5], ['TA', 'Testing and Analysis', 5], ['AP', 'Appearance', 5]] },
        viva: { scale: 3, crit: [['RA', 'Responsiveness to Questions / Accuracy', 2.5], ['DK', 'Depth of Subject Knowledge', 2.5]] },
      },
    },
    clos: [], plos: [],
    grades: clone(GRADES),
  };
  if (L) {
    plan.clos = [
      { id: 'k1', code: 'CO4', kpi: 0.5, desc: 'Use modern web tools to build and test web applications (lab).', w: { LPERF: 0.30, LMID: 0.25, LFIN: 0.25, OEL: 0.20 } },
      { id: 'k2', code: 'CO5', kpi: 0.5, desc: 'Demonstrate a complete project (design, implementation, viva).', w: { PROJ: 1 } },
    ];
    plan.plos = [
      { id: 'p1', code: 'PO5', kpi: 0.5, desc: 'Modern Tool Usage.', w: { k1: 1 } },
      { id: 'p2', code: 'PO9', kpi: 0.5, desc: 'Individual and Team Work.', w: { k2: 1 } },
    ];
  } else {
    plan.clos = [
      { id: 'k1', code: 'CO1', kpi: 0.5, desc: 'Understand and explain the core concepts.', w: { Q: 0.25, M: 0.75 } },
      { id: 'k2', code: 'CO2', kpi: 0.5, desc: 'Apply the concepts to solve problems.', w: { A: 0.25, F: 0.75 } },
    ];
    plan.plos = [
      { id: 'p1', code: 'PO1', kpi: 0.5, desc: 'Academic Education.', w: { k1: 1 } },
      { id: 'p2', code: 'PO2', kpi: 0.5, desc: 'Knowledge for Solving Computing Problems.', w: { k2: 1 } },
    ];
  }
  return plan;
}

export function newCourse(sem, p) {
  const type = p.type || 'TL';
  const c = {
    id: uid('c'), semId: sem.id, code: (p.code || '').trim(), title: (p.title || '').trim(), type, credit: p.credit || '',
    secIds: p.secIds ? p.secIds.slice() : sem.sections.map(x => x.id),
    plan: p.plan || defaultPlan(type),
    sec: {}, dates: { MIDD: null, FIND: null }, schedule: { dates: {}, notes: {}, activities: {} }, labGroups: {}, marks: {},
    created: Date.now(),
  };
  ensureCourse(c, sem, p.instructor || '');
  return c;
}

// make sure every section of the course has its settings and lab group entry
export function ensureCourse(c, sem, instructor = '') {
  c.sec = c.sec || {}; c.labGroups = c.labGroups || {}; c.marks = c.marks || {};
  c.schedule = Object.assign({ dates: {}, notes: {}, activities: {} }, c.schedule);
  c.dates = Object.assign({ MIDD: null, FIND: null }, c.dates);
  c.secIds.forEach((id, i) => {
    if (!c.sec[id]) c.sec[id] = { inst: instructor, labInst: instructor, lec: Math.min(i, 5), lab: Math.min(i + 1, 5) };
    if (!c.labGroups[id]) c.labGroups[id] = { custom: false, rows: {}, rem: {} };
  });
  return c;
}

export const semOf = (st, c) => st.semesters.find(s => s.id === c.semId);
export const courseById = (st, id) => st.courses.find(c => c.id === id);
export const semesterLabel = s => [s.program && `${s.program}${s.batch ? ' ' + s.batch : ''}`, s.semester && `${s.semester} semester`, s.session].filter(Boolean).join(' · ') || 'Semester';
export const courseLabel = c => [c.code, c.title].filter(Boolean).join(' ') || 'Course';
export function safeName(s) { return String(s).replace(/[\\/:*?"<>|[\]#%]+/g, ' ').replace(/\s+/g, ' ').trim(); }
export function fileNameOf(c) { return safeName(`${courseLabel(c)}${c.type === 'L' ? '' : ''}`).slice(0, 80) + '.xlsx'; }
export function folderPathOf(sem) {
  const semName = [sem.program, sem.batch && `Batch ${sem.batch}`, sem.semester && `${sem.semester} semester`].filter(Boolean).join(' ');
  return [safeName(sem.dept || 'Department'), safeName(`${semName || 'Semester'}${sem.session ? ' (' + sem.session + ')' : ''}`)];
}

// ------------------------------------------------------------------ migration from the single-course app (v1)
const V1_SECS = ['A', 'B', 'C', 'D'];
export function migrateV1(v1, activitiesDefault = []) {
  const st = emptyState();
  if (!v1 || !v1.settings) return st;
  const instructor = (v1.sections && v1.sections.A && v1.sections.A.inst) || '';
  st.profile.instructor = instructor;
  const anyStudents = V1_SECS.some(s => v1.students && v1.students[s] && Object.values(v1.students[s]).some(x => x && (x.name || x.reg)));
  const anyMarks = v1.marks && Object.values(v1.marks).some(m => m && Object.keys(m).length);
  if (!anyStudents && !anyMarks) return st;
  const S = v1.settings;
  const sem = newSemester({ dept: 'Department of Computing', program: 'BSCS', batch: '2024', semester: '5th', session: 'Fall 2026', start: S.START });
  const ids = {};
  for (const s of V1_SECS) {
    const x = newSection(s, (v1.sections && v1.sections[s] && v1.sections[s].name) || `BSCS-5${s}`);
    x.students = clone((v1.students && v1.students[s]) || {});
    sem.sections.push(x); ids[s] = x.id;
  }
  st.semesters.push(sem);
  const plan = defaultPlan('TL');
  const mx = (k, d) => (v1.max && typeof v1.max[k] === 'number' ? v1.max[k] : d);
  plan.thr = S.THR ?? 0.75; plan.leave = S.LEAVE || 'No';
  plan.shares = { T: S.SH_T ?? 2 / 3, L: S.SH_L ?? 1 / 3 };
  plan.quizzes.weight = S.W_Q ?? 0.15; plan.assignments.weight = S.W_A ?? 0.15; plan.mid.weight = S.W_M ?? 0.3; plan.final.weight = S.W_F ?? 0.4;
  plan.quizzes.items.forEach(it => (it.max = mx(`Quizzes|${it.label}`, it.max)));
  plan.assignments.items.forEach(it => (it.max = mx(`Assignments|${it.label}`, it.max)));
  plan.mid.qs = plan.mid.qs.map((m, i) => mx(`Mid Exam|Q${i + 1}`, m));
  plan.final.qs = plan.final.qs.map((m, i) => mx(`Final Exam|Q${i + 1}`, m));
  const L = plan.lab;
  L.perf.marks = S.M_PERF ?? 6; L.reports.marks = S.M_REP ?? 4; L.mid.marks = S.M_LMID ?? 5; L.final.marks = S.M_LFIN ?? 5; L.oel.marks = S.M_OEL ?? 5; L.project.marks = S.M_PROJ ?? 8;
  L.mid.week = S.WK_LMID ?? 8; L.final.week = S.WK_LFIN ?? 16; L.oel.week = S.WK_OEL ?? 15; L.project.week = S.WK_PROJ ?? 15;
  L.project.des.scale = S.P_DES ?? 3; L.project.viva.scale = S.P_VIVA ?? 3;
  for (const [grp, obj] of [['Lab Perf', L.perf], ['Lab Reports', L.reports], ['Lab Mid', L.mid], ['Lab Final', L.final], ['OEL', L.oel], ['Project Design', L.project.des], ['Project Viva', L.project.viva]])
    obj.crit.forEach(c => (c[2] = mx(`${grp}|${c[0]}`, c[2])));
  const o = v1.outc || {};
  plan.clos[0] = Object.assign(plan.clos[0], { code: o.CO4?.code || 'CO4', kpi: o.CO4?.kpi ?? 0.5, desc: o.CO4?.desc ?? plan.clos[0].desc, w: { LPERF: S.CO4_PERF ?? 0.3, LMID: S.CO4_MID ?? 0.25, LFIN: S.CO4_FIN ?? 0.25, OEL: S.CO4_VIVA ?? 0.2 } });
  plan.clos[1] = Object.assign(plan.clos[1], { code: o.CO5?.code || 'CO5', kpi: o.CO5?.kpi ?? 0.5, desc: o.CO5?.desc ?? plan.clos[1].desc, w: { PROJ: S.CO5_PROJ ?? 1 } });
  plan.plos[0] = Object.assign(plan.plos[0], { code: o.PO5?.code || 'PO5', kpi: o.PO5?.kpi ?? 0.5, desc: o.PO5?.desc ?? plan.plos[0].desc, w: { k1: S.PO5_CO4 ?? 1 } });
  plan.plos[1] = Object.assign(plan.plos[1], { code: o.PO9?.code || 'PO9', kpi: o.PO9?.kpi ?? 0.5, desc: o.PO9?.desc ?? plan.plos[1].desc, w: { k2: S.PO9_CO5 ?? 1 } });
  if (Array.isArray(v1.grades) && v1.grades.length) plan.grades = clone(v1.grades);
  const c = newCourse(sem, { code: 'CS-309', title: 'Web Design & Development', type: 'TL', credit: '3(2+1)', plan, instructor });
  c.id = 'c_wdd_v1';
  for (const s of V1_SECS) {
    const id = ids[s], vs = (v1.sections && v1.sections[s]) || {};
    c.sec[id] = { inst: vs.inst || instructor, labInst: vs.labInst || instructor, lec: vs.lec ?? 0, lab: vs.lab ?? 1 };
    const lg = (v1.labGroups && v1.labGroups[s]) || { custom: false, rows: {}, rem: {} };
    c.labGroups[id] = clone(lg);
  }
  c.dates = { MIDD: S.MIDD || null, FIND: S.FIND || null };
  const sch = v1.schedule || {};
  for (const [k, v] of Object.entries(sch.dates || {})) { const [s, kind, w] = k.split('|'); if (ids[s]) c.schedule.dates[`${ids[s]}|${kind}|${w}`] = v; }
  c.schedule.notes = clone(sch.notes || {});
  activitiesDefault.forEach((a, i) => { c.schedule.activities[i + 1] = a; });
  Object.assign(c.schedule.activities, clone(sch.activities || {}));
  for (const [k, m] of Object.entries(v1.marks || {})) {
    const s = k[0], page = k.slice(2);
    if (ids[s] && m) c.marks[`${ids[s]}|${page}`] = clone(m);
  }
  st.courses.push(c);
  return st;
}

export function normaliseState(st) {
  if (!st || st.version !== 2) return emptyState();
  st.profile = Object.assign({ university: 'HITEC University, Taxila', instructor: '' }, st.profile);
  st.semesters = st.semesters || []; st.courses = st.courses || [];
  for (const c of st.courses) { const sem = semOf(st, c); if (sem) { c.secIds = c.secIds.filter(id => sem.sections.some(x => x.id === id)); ensureCourse(c, sem); } }
  return st;
}
