// Bridge to the Android shell (window.Android); falls back to browser APIs for desktop preview and tests.
const A = typeof window !== 'undefined' ? window.Android : undefined;
export const native = !!A;

export const store = {
  load(key) {
    try { return A ? A.load(key) : localStorage.getItem('wdd:' + key); } catch (e) { return null; }
  },
  save(key, text) {
    try { return A ? A.save(key, text) : (localStorage.setItem('wdd:' + key, text), true); } catch (e) { return false; }
  },
  backups() {
    try { return A && A.backups ? JSON.parse(A.backups()) : []; } catch (e) { return []; }
  },
  readBackup(name) {
    try { return A && A.readBackup ? A.readBackup(name) : null; } catch (e) { return null; }
  },
};

export function isOnline() {
  try { return A ? !!A.online() : navigator.onLine !== false; } catch (e) { return true; }
}

let seq = 0;
const pending = {};
window.__nativeHttp = (id, status) => {
  const done = pending[id];
  delete pending[id];
  let text = '';
  try { text = A.take(id) || ''; } catch (e) { text = String(e); }
  if (!done) return;
  done({ status: Number(status), text });
};

export function http(url, body) {
  if (A) {
    return new Promise(resolve => {
      const id = 'h' + ++seq + '_' + Date.now();
      const timer = setTimeout(() => { if (pending[id]) { delete pending[id]; resolve({ status: 0, text: 'timed out' }); } }, 240000);
      pending[id] = r => { clearTimeout(timer); resolve(r); };
      A.http(id, url, body === undefined ? null : body);
    });
  }
  return fetch(url, { method: body == null ? 'GET' : 'POST', body, headers: { 'Content-Type': 'text/plain;charset=utf-8' }, redirect: 'follow' })
    .then(async r => ({ status: r.status, text: await r.text() }), e => ({ status: 0, text: String(e && e.message || e) }));
}

const saving = {};
window.__nativeSaved = (id, ok) => { const f = saving[id]; delete saving[id]; if (f) f(!!ok); };
export function saveFile(name, mime, base64) {
  if (A) {
    return new Promise(resolve => { const id = 's' + ++seq; saving[id] = resolve; A.saveFile(id, name, mime, base64); });
  }
  const a = document.createElement('a');
  a.href = `data:${mime};base64,${base64}`;
  a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  return Promise.resolve(true);
}

export function openUrl(url) {
  if (A) A.openUrl(url); else window.open(url, '_blank');
}

export function appVersion() {
  try { return A ? A.version() : 'web'; } catch (e) { return '?'; }
}

// teacher app only: make a copy of the student app with this connection built in, then save or share it
export function studentApk(mode, configJson, name) {
  if (!A || !A.studentApk) return Promise.resolve('unsupported');
  return new Promise(resolve => { const id = 'a' + ++seq; saving[id] = resolve; A.studentApk(id, mode, configJson, name); });
}
