// Minimal .xlsx writer (SpreadsheetML) with the features the register needs:
// styled cells, formulas, merges, column widths, row heights, freeze panes, data validation, conditional formatting
// (data bars, cell-is, expressions), internal hyperlinks, clustered bar charts, print set-up and tab colours.
import JSZip from 'jszip';

export const colName = n => { let s = ''; while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); } return s; };
export const colNum = s => s.split('').reduce((a, ch) => a * 26 + ch.charCodeAt(0) - 64, 0);
export const ref = (r, c) => colName(c) + r;
export const qs = name => `'${String(name).replace(/'/g, "''")}'`;
const x = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
  .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');
const argb = c => 'FF' + String(c).replace('#', '').toUpperCase();

const BUILTIN_FMT = { General: 0, '0': 1, '0.00': 2, '0%': 9, '0.00%': 10, '@': 49 };

class Styles {
  constructor() {
    this.fonts = ['<font><sz val="10"/><name val="Arial"/><family val="2"/></font>'];
    this.fills = ['<fill><patternFill patternType="none"/></fill>', '<fill><patternFill patternType="gray125"/></fill>'];
    this.borders = ['<border><left/><right/><top/><bottom/><diagonal/></border>'];
    this.numFmts = []; this.fmtIds = {};
    this.xfs = ['<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'];
    this.cache = new Map([['{}', 0]]);
    this.dxfs = []; this.dxfCache = new Map();
    this.fontCache = new Map(); this.fillCache = new Map(); this.borderCache = new Map();
  }
  font(f = {}) {
    const k = JSON.stringify(f);
    if (this.fontCache.has(k)) return this.fontCache.get(k);
    const xml = `<font>${f.b ? '<b/>' : ''}${f.i ? '<i/>' : ''}${f.u ? '<u/>' : ''}<sz val="${f.sz || 10}"/>${f.color ? `<color rgb="${argb(f.color)}"/>` : ''}<name val="Arial"/><family val="2"/></font>`;
    this.fonts.push(xml); const id = this.fonts.length - 1; this.fontCache.set(k, id); return id;
  }
  fill(c) {
    if (!c) return 0;
    if (this.fillCache.has(c)) return this.fillCache.get(c);
    this.fills.push(`<fill><patternFill patternType="solid"><fgColor rgb="${argb(c)}"/><bgColor indexed="64"/></patternFill></fill>`);
    const id = this.fills.length - 1; this.fillCache.set(c, id); return id;
  }
  border(b) {
    if (!b) return 0;
    const k = typeof b === 'string' ? b : b === true ? 'A6B4C8' : JSON.stringify(b);
    if (this.borderCache.has(k)) return this.borderCache.get(k);
    let xml;
    if (typeof b === 'object') {
      const side = (n, s) => (s ? `<${n} style="${s.style || 'thin'}"><color rgb="${argb(s.color || 'A6B4C8')}"/></${n}>` : `<${n}/>`);
      xml = `<border>${side('left', b.l)}${side('right', b.r)}${side('top', b.t)}${side('bottom', b.b)}<diagonal/></border>`;
    } else {
      const s = `style="thin"><color rgb="${argb(k)}"/>`;
      xml = `<border><left ${s}</left><right ${s}</right><top ${s}</top><bottom ${s}</bottom><diagonal/></border>`;
    }
    this.borders.push(xml); const id = this.borders.length - 1; this.borderCache.set(k, id); return id;
  }
  fmt(code) {
    if (code === undefined || code === null) return 0;
    if (BUILTIN_FMT[code] !== undefined) return BUILTIN_FMT[code];
    if (this.fmtIds[code]) return this.fmtIds[code];
    const id = 164 + this.numFmts.length;
    this.numFmts.push(`<numFmt numFmtId="${id}" formatCode="${x(code)}"/>`); this.fmtIds[code] = id; return id;
  }
  id(st) {
    if (!st) return 0;
    const k = JSON.stringify(st);
    if (this.cache.has(k)) return this.cache.get(k);
    const fontId = this.font(st.font), fillId = this.fill(st.fill), borderId = this.border(st.border), numFmtId = this.fmt(st.fmt);
    const a = st.align;
    const al = a ? `<alignment${a.h ? ` horizontal="${a.h}"` : ''}${a.v ? ` vertical="${a.v}"` : ''}${a.wrap ? ' wrapText="1"' : ''}/>` : '';
    this.xfs.push(`<xf numFmtId="${numFmtId}" fontId="${fontId}" fillId="${fillId}" borderId="${borderId}" xfId="0"${numFmtId ? ' applyNumberFormat="1"' : ''}${fontId ? ' applyFont="1"' : ''}${fillId ? ' applyFill="1"' : ''}${borderId ? ' applyBorder="1"' : ''}${al ? ' applyAlignment="1">' + al + '</xf>' : '/>'}`);
    const id = this.xfs.length - 1; this.cache.set(k, id); return id;
  }
  dxf(d) {
    const k = JSON.stringify(d);
    if (this.dxfCache.has(k)) return this.dxfCache.get(k);
    this.dxfs.push(`<dxf>${d.color || d.b ? `<font>${d.b ? '<b/>' : ''}${d.color ? `<color rgb="${argb(d.color)}"/>` : ''}</font>` : ''}${d.fill ? `<fill><patternFill><bgColor rgb="${argb(d.fill)}"/></patternFill></fill>` : ''}</dxf>`);
    const id = this.dxfs.length - 1; this.dxfCache.set(k, id); return id;
  }
  xml() {
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">` +
      (this.numFmts.length ? `<numFmts count="${this.numFmts.length}">${this.numFmts.join('')}</numFmts>` : '') +
      `<fonts count="${this.fonts.length}">${this.fonts.join('')}</fonts><fills count="${this.fills.length}">${this.fills.join('')}</fills>` +
      `<borders count="${this.borders.length}">${this.borders.join('')}</borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>` +
      `<cellXfs count="${this.xfs.length}">${this.xfs.join('')}</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>` +
      `<dxfs count="${this.dxfs.length}">${this.dxfs.join('')}</dxfs><tableStyles count="0" defaultTableStyle="TableStyleMedium2" defaultPivotStyle="PivotStyleLight16"/></styleSheet>`;
  }
}

export class Sheet {
  constructor(wb, name) {
    this.wb = wb; this.name = name; this.rows = new Map(); this.merges = []; this.cols = {}; this.heights = {};
    this.cf = []; this.dv = []; this.links = []; this.charts = []; this.freeze = null; this.tab = null; this.zoom = 100; this.grid = true;
    this.print = { orient: 'landscape', paper: 9, fitW: 1, fitH: 0, rows: null, cols: null };
    this.hiddenCols = new Set();
  }
  _row(r) { let m = this.rows.get(r); if (!m) { m = new Map(); this.rows.set(r, m); } return m; }
  // value: number | string | null | {f: 'FORMULA'} ; style: style object
  set(r, c, value, style) {
    const s = this.wb.styles.id(style);
    this._row(r).set(c, { v: value, s });
    return this;
  }
  setId(r, c, value, sid) { this._row(r).set(c, { v: value, s: sid }); return this; }
  style(r, c, style) { const cell = this._row(r).get(c); this._row(r).set(c, { v: cell ? cell.v : null, s: this.wb.styles.id(style) }); }
  get(r, c) { const m = this.rows.get(r); return m && m.get(c); }
  merge(r1, c1, r2, c2) { if (r1 !== r2 || c1 !== c2) this.merges.push(`${ref(r1, c1)}:${ref(r2, c2)}`); }
  width(c, w) { this.cols[c] = w; }
  hide(c) { this.hiddenCols.add(c); }
  height(r, h) { this.heights[r] = h; }
  addCF(sqref, rule) { this.cf.push({ sqref, rule }); }
  addDV(sqref, dv) { this.dv.push({ sqref, dv }); }
  link(r, c, target, tooltip) { this.links.push({ r, c, target, tooltip }); }
  chart(spec) { this.charts.push(spec); }

  xml(idx) {
    const sp = `<sheetPr>${this.tab ? `<tabColor rgb="${argb(this.tab)}"/>` : ''}<pageSetUpPr fitToPage="1"/></sheetPr>`;
    let view = `<sheetView workbookViewId="0"${this.grid ? '' : ' showGridLines="0"'}${this.zoom !== 100 ? ` zoomScale="${this.zoom}" zoomScaleNormal="${this.zoom}"` : ''}${idx === 0 ? ' tabSelected="1"' : ''}>`;
    if (this.freeze) {
      const [fr, fc] = this.freeze, tl = ref(fr, fc), xs = fc - 1, ys = fr - 1;
      const pane = xs && ys ? 'bottomRight' : ys ? 'bottomLeft' : 'topRight';
      view += `<pane${xs ? ` xSplit="${xs}"` : ''}${ys ? ` ySplit="${ys}"` : ''} topLeftCell="${tl}" activePane="${pane}" state="frozen"/><selection pane="${pane}" activeCell="${tl}" sqref="${tl}"/>`;
    }
    view += '</sheetView>';
    const colKeys = new Set([...Object.keys(this.cols).map(Number), ...this.hiddenCols]);
    const cols = [...colKeys].sort((a, b) => a - b).map(c => `<col min="${c}" max="${c}" width="${this.cols[c] || 9.14}"${this.cols[c] ? ' customWidth="1"' : ''}${this.hiddenCols.has(c) ? ' hidden="1"' : ''}/>`).join('');
    const rowNums = [...new Set([...this.rows.keys(), ...Object.keys(this.heights).map(Number)])].sort((a, b) => a - b);
    const parts = [];
    for (const r of rowNums) {
      const m = this.rows.get(r), h = this.heights[r];
      let s = `<row r="${r}"${h ? ` ht="${h}" customHeight="1"` : ''}>`;
      if (m) {
        for (const c of [...m.keys()].sort((a, b) => a - b)) {
          const { v, s: st } = m.get(c), rf = ref(r, c), sa = st ? ` s="${st}"` : '';
          if (v === null || v === undefined || v === '') s += `<c r="${rf}"${sa}/>`;
          else if (typeof v === 'number') s += isFinite(v) ? `<c r="${rf}"${sa}><v>${v}</v></c>` : `<c r="${rf}"${sa}/>`;
          else if (typeof v === 'object' && v.f !== undefined) s += `<c r="${rf}"${sa}${v.str ? ' t="str"' : ''}><f>${x(v.f.replace(/^=/, ''))}</f></c>`;
          else s += `<c r="${rf}"${sa} t="inlineStr"><is><t xml:space="preserve">${x(v)}</t></is></c>`;
        }
      }
      parts.push(s + '</row>');
    }
    let out = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">${sp}<sheetViews>${view}</sheetViews><sheetFormatPr defaultRowHeight="12.75"/>${cols ? `<cols>${cols}</cols>` : ''}<sheetData>${parts.join('')}</sheetData>`;
    if (this.merges.length) out += `<mergeCells count="${this.merges.length}">${this.merges.map(m => `<mergeCell ref="${m}"/>`).join('')}</mergeCells>`;
    let pri = 1;
    for (const { sqref, rule } of this.cf) {
      let r;
      if (rule.type === 'bar') r = `<cfRule type="dataBar" priority="${pri++}"><dataBar><cfvo type="num" val="0"/>${rule.max === 'max' ? '<cfvo type="max"/>' : `<cfvo type="num" val="${x(rule.max ?? 1)}"/>`}<color rgb="${argb(rule.color)}"/></dataBar></cfRule>`;
      else if (rule.type === 'eq') r = `<cfRule type="cellIs" dxfId="${this.wb.styles.dxf(rule.dxf)}" priority="${pri++}" operator="equal"><formula>${x(rule.value)}</formula></cfRule>`;
      else r = `<cfRule type="expression" dxfId="${this.wb.styles.dxf(rule.dxf)}" priority="${pri++}"><formula>${x(rule.formula)}</formula></cfRule>`;
      out += `<conditionalFormatting sqref="${sqref}">${r}</conditionalFormatting>`;
    }
    if (this.dv.length) {
      out += `<dataValidations count="${this.dv.length}">` + this.dv.map(({ sqref, dv }) =>
        `<dataValidation type="${dv.type}"${dv.op ? ` operator="${dv.op}"` : ''} allowBlank="1" showErrorMessage="1"${dv.title ? ` errorTitle="${x(dv.title)}"` : ''}${dv.error ? ` error="${x(dv.error)}"` : ''} sqref="${sqref}"><formula1>${x(dv.f1)}</formula1>${dv.f2 !== undefined ? `<formula2>${x(dv.f2)}</formula2>` : ''}</dataValidation>`).join('') + '</dataValidations>';
    }
    if (this.links.length) out += `<hyperlinks>${this.links.map(l => `<hyperlink ref="${ref(l.r, l.c)}" location="${x(l.target)}" display="${x(l.tooltip || '')}"${l.tooltip ? ` tooltip="${x(l.tooltip)}"` : ''}/>`).join('')}</hyperlinks>`;
    out += '<printOptions horizontalCentered="1"/><pageMargins left="0.4" right="0.4" top="0.5" bottom="0.5" header="0.3" footer="0.3"/>';
    out += `<pageSetup paperSize="${this.print.paper}" orientation="${this.print.orient}" fitToWidth="${this.print.fitW}" fitToHeight="${this.print.fitH}"/>`;
    if (this.charts.length) out += '<drawing r:id="rId1"/>';
    return out + '</worksheet>';
  }
}

function chartXml(spec) {
  const series = spec.series.map((s, i) => `<c:ser><c:idx val="${i}"/><c:order val="${i}"/><c:tx>${s.nameRef ? `<c:strRef><c:f>${x(s.nameRef)}</c:f></c:strRef>` : `<c:v>${x(s.name)}</c:v>`}</c:tx>` +
    `<c:spPr><a:solidFill><a:srgbClr val="${s.color.replace('#', '')}"/></a:solidFill><a:ln><a:solidFill><a:srgbClr val="${s.color.replace('#', '')}"/></a:solidFill></a:ln></c:spPr><c:invertIfNegative val="0"/>` +
    `<c:cat><c:strRef><c:f>${x(spec.cats)}</c:f></c:strRef></c:cat><c:val><c:numRef><c:f>${x(s.vals)}</c:f></c:numRef></c:val></c:ser>`).join('');
  const labels = spec.labels ? `<c:dLbls><c:numFmt formatCode="${x(spec.pct ? '0%' : '0')}" sourceLinked="0"/><c:spPr><a:noFill/><a:ln><a:noFill/></a:ln></c:spPr><c:txPr><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:defRPr sz="800"/></a:pPr><a:endParaRPr lang="en-US"/></a:p></c:txPr><c:showLegendKey val="0"/><c:showVal val="1"/><c:showCatName val="0"/><c:showSerName val="0"/><c:showPercent val="0"/><c:showBubbleSize val="0"/></c:dLbls>` : '';
  const title = t => `<c:title><c:tx><c:rich><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:defRPr sz="${t === spec.title ? 1200 : 900}" b="1"/></a:pPr><a:r><a:rPr lang="en-US" sz="${t === spec.title ? 1200 : 900}" b="1"/><a:t>${x(t)}</a:t></a:r></a:p></c:rich></c:tx><c:overlay val="0"/></c:title>`;
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<c:chartSpace xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">` +
    `<c:roundedCorners val="0"/><c:chart>${title(spec.title)}<c:autoTitleDeleted val="0"/><c:plotArea><c:layout/><c:barChart><c:barDir val="col"/><c:grouping val="clustered"/><c:varyColors val="0"/>${series}${labels}<c:gapWidth val="150"/><c:axId val="5001"/><c:axId val="5002"/></c:barChart>` +
    `<c:catAx><c:axId val="5001"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="0"/><c:axPos val="b"/><c:numFmt formatCode="General" sourceLinked="0"/><c:majorTickMark val="none"/><c:minorTickMark val="none"/><c:tickLblPos val="nextTo"/><c:crossAx val="5002"/><c:crosses val="autoZero"/><c:auto val="1"/><c:lblAlgn val="ctr"/><c:lblOffset val="100"/><c:noMultiLvlLbl val="0"/></c:catAx>` +
    `<c:valAx><c:axId val="5002"/><c:scaling><c:orientation val="minMax"/>${spec.max !== undefined ? `<c:max val="${spec.max}"/>` : ''}<c:min val="0"/></c:scaling><c:delete val="0"/><c:axPos val="l"/><c:majorGridlines><c:spPr><a:ln w="6350"><a:solidFill><a:srgbClr val="E5E7EB"/></a:solidFill></a:ln></c:spPr></c:majorGridlines>${spec.yTitle ? title(spec.yTitle) : ''}<c:numFmt formatCode="${spec.pct ? '0%' : 'General'}" sourceLinked="0"/><c:majorTickMark val="none"/><c:minorTickMark val="none"/><c:tickLblPos val="nextTo"/><c:crossAx val="5001"/><c:crosses val="autoZero"/><c:crossBetween val="between"/></c:valAx></c:plotArea>` +
    `<c:legend><c:legendPos val="b"/><c:overlay val="0"/></c:legend><c:plotVisOnly val="1"/><c:dispBlanksAs val="gap"/></c:chart><c:spPr><a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill><a:ln><a:solidFill><a:srgbClr val="D9D9D9"/></a:solidFill></a:ln></c:spPr></c:chartSpace>`;
}

export class Workbook {
  constructor() { this.sheets = []; this.styles = new Styles(); this.order = null; this.props = {}; }
  add(name) {
    if (this.sheets.some(s => s.name === name)) throw new Error('Duplicate sheet name ' + name);
    if (name.length > 31 || /[\\/?*[\]:]/.test(name)) throw new Error('Invalid sheet name ' + name);
    const s = new Sheet(this, name); this.sheets.push(s); return s;
  }
  sheet(name) { return this.sheets.find(s => s.name === name); }

  async build(type = 'uint8array') {
    const zip = new JSZip();
    const zfile = (n, d) => zip.file(n, d, { createFolders: false });
    const sheets = this.order ? this.order.map(n => this.sheet(n)) : this.sheets;
    let chartN = 0, drawN = 0;
    const ct = ['<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>',
      '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
      '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>',
      '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>',
      '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'];
    const wbRels = [], sheetEls = [], defined = [];
    sheets.forEach((s, i) => {
      const n = i + 1;
      zfile(`xl/worksheets/sheet${n}.xml`, s.xml(i));
      ct.push(`<Override PartName="/xl/worksheets/sheet${n}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`);
      wbRels.push(`<Relationship Id="rId${n}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${n}.xml"/>`);
      sheetEls.push(`<sheet name="${x(s.name)}" sheetId="${n}" r:id="rId${n}"/>`);
      const titles = [];
      if (s.print.cols) titles.push(`${qs(s.name)}!$${s.print.cols[0]}:$${s.print.cols[1]}`);
      if (s.print.rows) titles.push(`${qs(s.name)}!$${s.print.rows[0]}:$${s.print.rows[1]}`);
      if (titles.length) defined.push(`<definedName name="_xlnm.Print_Titles" localSheetId="${i}">${x(titles.join(','))}</definedName>`);
      if (s.charts.length) {
        drawN++;
        const anchors = [], drels = [];
        s.charts.forEach((spec, k) => {
          chartN++;
          zfile(`xl/charts/chart${chartN}.xml`, chartXml(spec));
          ct.push(`<Override PartName="/xl/charts/chart${chartN}.xml" ContentType="application/vnd.openxmlformats-officedocument.drawingml.chart+xml"/>`);
          drels.push(`<Relationship Id="rId${k + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart" Target="../charts/chart${chartN}.xml"/>`);
          const a = spec.at;
          anchors.push(`<xdr:twoCellAnchor editAs="oneCell"><xdr:from><xdr:col>${a.c - 1}</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>${a.r - 1}</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from><xdr:to><xdr:col>${a.c - 1 + a.w}</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>${a.r - 1 + a.h}</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to>` +
            `<xdr:graphicFrame macro=""><xdr:nvGraphicFramePr><xdr:cNvPr id="${k + 2}" name="Chart ${k + 1}"/><xdr:cNvGraphicFramePr/></xdr:nvGraphicFramePr><xdr:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/></xdr:xfrm><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/chart"><c:chart xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" r:id="rId${k + 1}"/></a:graphicData></a:graphic></xdr:graphicFrame><xdr:clientData/></xdr:twoCellAnchor>`);
        });
        zfile(`xl/drawings/drawing${drawN}.xml`, `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">${anchors.join('')}</xdr:wsDr>`);
        zfile(`xl/drawings/_rels/drawing${drawN}.xml.rels`, `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${drels.join('')}</Relationships>`);
        ct.push(`<Override PartName="/xl/drawings/drawing${drawN}.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/>`);
        zfile(`xl/worksheets/_rels/sheet${n}.xml.rels`, `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing${drawN}.xml"/></Relationships>`);
      }
    });
    const ns = sheets.length;
    wbRels.push(`<Relationship Id="rId${ns + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>`);
    zfile('[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">${ct.join('')}</Types>`);
    zfile('_rels/.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>`);
    zfile('xl/_rels/workbook.xml.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${wbRels.join('')}</Relationships>`);
    zfile('xl/workbook.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><workbookPr/><bookViews><workbookView xWindow="0" yWindow="0" windowWidth="28800" windowHeight="15000" activeTab="0"/></bookViews><sheets>${sheetEls.join('')}</sheets>${defined.length ? `<definedNames>${defined.join('')}</definedNames>` : ''}<calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>`);
    zfile('xl/styles.xml', this.styles.xml());
    const now = new Date().toISOString().replace(/\.\d+Z$/, 'Z');
    zfile('docProps/core.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${x(this.props.title || '')}</dc:title><dc:creator>${x(this.props.creator || 'WDD Register app')}</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">${now}</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">${now}</dcterms:modified></cp:coreProperties>`);
    zfile('docProps/app.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>Microsoft Excel</Application></Properties>`);
    return zip.generateAsync({ type, compression: 'DEFLATE', compressionOptions: { level: 3 }, mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  }
}
