// Runs workbook generation in a Web Worker (blob URL); falls back to the main thread if workers are unavailable.
import CODE from './worker_code.gen.js';
import { buildXlsx } from './workbook.js';

let w = null, seq = 0;
const pending = {};
function worker() {
  if (w !== null) return w;
  try {
    w = new Worker(URL.createObjectURL(new Blob([CODE], { type: 'text/javascript' })));
    w.onmessage = e => { const p = pending[e.data.id]; delete pending[e.data.id]; if (!p) return; if (e.data.error) p.fail(e.data.error); else p.resolve(e.data.bytes); };
    w.onerror = () => { w = false; for (const k of Object.keys(pending)) { const p = pending[k]; delete pending[k]; p.fail('worker failed'); } };
  } catch (e) { w = false; }
  return w;
}
export function buildBytes(state0, course0) {
  const state = JSON.parse(JSON.stringify(state0)), course = state.courses.find(x => x.id === course0.id);
  const direct = () => { self.__wddBuildMode = 'direct'; return buildXlsx(state, course, 'uint8array'); };
  const wk = worker();
  if (!wk) return direct();
  return new Promise((resolve, reject) => {
    const id = ++seq;
    pending[id] = { resolve: b => { self.__wddBuildMode = 'worker'; resolve(b); }, fail: () => direct().then(resolve, reject) };
    try { wk.postMessage({ id, state, courseId: course.id }); }
    catch (e) { delete pending[id]; direct().then(resolve, reject); }
  });
}
