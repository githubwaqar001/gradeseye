// Calculation engine for one course register. Every formula mirrors the Excel workbook made by workbook.js.
import { NROW, semOf } from './model.js';
import { layout, entryCols } from './layout.js';

export const isNum = v => typeof v === 'number' && isFinite(v);
// Excel compares with ~15 significant digits: 0.49999999999999994 >= 0.5 is TRUE there
export const ge = (a, b) => a >= b - 1e-9 * Math.max(1, Math.abs(b));
const N = v => (isNum(v) ? v : 0);
const sumNums = a => a.reduce((s, v) => s + (isNum(v) ? v : 0), 0);
export const markKey = (secId, page) => `${secId}|${page}`;
export function getMark(c, secId, page, r, col) {
  const m = c.marks[markKey(secId, page)];
  if (!m) return null;
  const v = m[`${r},${col}`];
  return v === undefined ? null : v;
}
export function setMark(c, secId, page, r, col, v) {
  const k = markKey(secId, page);
  const m = c.marks[k] || (c.marks[k] = {});
  if (v === null || v === undefined || v === '') delete m[`${r},${col}`]; else m[`${r},${col}`] = v;
}

// ------------------------------------------------------------------ dates
const DAY = 86400000;
export const parseISO = d => { const [y, m, dd] = String(d).slice(0, 10).split('-').map(Number); return Date.UTC(y, m - 1, dd); };
export const isoOf = t => new Date(t).toISOString().slice(0, 10);
export const addDays = (iso, n) => isoOf(parseISO(iso) + n * DAY);
export function fmtDate(iso, withYear = false, withDay = false) {
  if (!iso) return '';
  const d = new Date(parseISO(iso));
  const mon = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.getUTCMonth()];
  const day = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][d.getUTCDay()];
  return `${withDay ? day + ' ' : ''}${String(d.getUTCDate()).padStart(2, '0')}-${mon}${withYear ? '-' + d.getUTCFullYear() : ''}`;
}
export function autoDate(sem, c, secId, kind, w) {
  const off = Number((c.sec[secId] || {})[kind === 'lec' ? 'lec' : 'lab']) || 0;
  return addDays(sem.start, 7 * (w - 1) + off);
}
export const schedDate = (sem, c, secId, kind, w) => c.schedule.dates[`${secId}|${kind}|${w}`] || autoDate(sem, c, secId, kind, w);
export const examDate = (sem, c, comp) => c.dates[comp.dateKey] || addDays(sem.start, 7 * (comp.week - 1));
export function activity(c, Lo, w) {
  if (c.schedule.activities[w] !== undefined) return c.schedule.activities[w];
  const n = Lo.L ? Number(c.plan.lab.exps) || 0 : 0;
  return w <= n ? `Exp. ${String(w).padStart(2, '0')}` : '';
}
export function pageDates(sem, c, Lo, secId, pageId) {
  const p = Lo.page[pageId];
  if (!p) return [];
  if (p.kind === 'att') return Array.from({ length: Lo.weeks }, (_, i) => schedDate(sem, c, secId, p.att, i + 1));
  const x = p.comp;
  if (!x) return [];
  if (x.kind === 'items') return x.cols.map(col => schedDate(sem, c, secId, 'lec', Math.min(col.week, Lo.weeks)));
  if (x.kind === 'exam') return [examDate(sem, c, x)];
  if (x.kind === 'exp') return Array.from({ length: x.exps }, (_, i) => schedDate(sem, c, secId, 'lab', Math.min(i + 1, Lo.weeks)));
  return [schedDate(sem, c, secId, 'lab', Math.min(x.week, Lo.weeks))];
}

// ------------------------------------------------------------------ rosters
export function secRoster(sem, secId) {
  const sec = sem.sections.find(x => x.id === secId), out = [];
  for (let r = 0; r < NROW; r++) { const x = sec && sec.students[r]; out.push({ reg: (x && x.reg) || '', name: (x && x.name) || '' }); }
  return out;
}
export function labRoster(sem, c, secId) {
  const lg = c.labGroups[secId];
  if (!lg || !lg.custom) return secRoster(sem, secId);
  const out = [];
  for (let r = 0; r < NROW; r++) { const x = lg.rows[r]; out.push({ reg: (x && x.reg) || '', name: (x && x.name) || '' }); }
  return out;
}
export function gradeOf(plan, pct) {
  if (!isNum(pct)) return '';
  const v = Math.round((pct * 100 + 1e-9) * 100) / 100;
  let g = '#N/A';
  for (const [mn, name] of plan.grades) if (v >= Number(mn)) g = name;
  return g;
}
export const gradePoint = (plan, g) => { const row = plan.grades.find(r => r[1] === g); return row ? row[2] : ''; };

export function stats(values) {
  const v = values.filter(isNum);
  if (!v.length) return { avg: '', max: '', min: '', n: 0 };
  return { avg: v.reduce((a, b) => a + b, 0) / v.length, max: Math.max(...v), min: Math.min(...v), n: v.length };
}

// ------------------------------------------------------------------ engine
function heldCols(c, secId, page, n, numeric) {
  const held = new Array(n).fill(false), m = c.marks[markKey(secId, page)] || {};
  for (const k of Object.keys(m)) {
    const col = Number(k.split(',')[1]), v = m[k];
    if (col < n && v !== null && v !== '' && (!numeric || isNum(v))) held[col] = true;
  }
  return held;
}
const rowVals = (c, secId, page, r, n) => Array.from({ length: n }, (_, col) => getMark(c, secId, page, r, col));

export function calc(st, c) {
  const sem = semOf(st, c), Lo = layout(c, sem), P = c.plan;
  const R = { Lo, sem, sec: {}, lab: {} };
  const leave = String(P.leave).toLowerCase() === 'yes', thr = Number(P.thr);
  const att = (secId, page, roster) => {
    const n = Lo.weeks, held = heldCols(c, secId, page, n, false), heldN = held.filter(Boolean).length;
    const rows = roster.map((x, r) => {
      if (!x.name) return null;
      const v = rowVals(c, secId, page, r, n).map(a => (a ? String(a).toUpperCase() : ''));
      const p = v.filter(a => a === 'P').length, l = v.filter(a => a === 'L').length, a = v.filter(a => a === 'A').length;
      const pct = heldN === 0 ? '' : (p + (leave ? l : 0)) / heldN;
      return { P: p, L: l, A: a, pct, status: pct === '' ? '' : ge(pct, thr) ? 'Eligible' : 'Short' };
    });
    const named = roster.filter(x => x.name).length;
    const perWeek = held.map((h, w) => {
      if (!h) return { present: '', pct: '' };
      let present = 0;
      for (let r = 0; r < NROW; r++) if (String(getMark(c, secId, page, r, w) || '').toUpperCase() === 'P') present++;
      return { present, pct: named ? present / named : '' };
    });
    return { held, heldN, rows, perWeek };
  };
  for (const sec of Lo.secs) {
    const S = (R.sec[sec.id] = { roster: secRoster(sem, sec.id) });
    const B = (R.lab[sec.id] = { roster: labRoster(sem, c, sec.id) });
    if (Lo.T) S['Theory Att'] = att(sec.id, 'Theory Att', S.roster);
    if (Lo.L) B['Lab Att'] = att(sec.id, 'Lab Att', B.roster);
    for (const x of Lo.theory) {
      const n = x.cols.length, held = heldCols(c, sec.id, x.page, n, true), any = held.some(Boolean);
      const T7 = x.kind === 'items' ? x.cols.reduce((a, col, i) => a + (held[i] ? col.max : 0), 0) : x.cols.reduce((a, col) => a + col.max, 0);
      const rows = S.roster.map((st_, r) => {
        if (!st_.name) return null;
        const vals = rowVals(c, sec.id, x.page, r, n);
        const T = x.kind === 'items' ? (T7 === 0 ? '' : sumNums(vals)) : (!any ? '' : sumNums(vals));
        return { T, pct: T === '' || T7 === 0 ? '' : T / T7 };
      });
      S[x.id] = { held, T7, any, rows };
    }
    const anyNamed = B.roster.some(x => x.name);
    for (const x of Lo.labComps) {
      const n = x.cols.length, held = heldCols(c, sec.id, x.page, n, true);
      if (x.kind === 'exp') {
        const np = x.crit.length, emax = x.crit.reduce((a, cr) => a + (Number(cr[2]) || 0), 0);
        const expHeld = Array.from({ length: x.exps }, (_, e) => held.slice(e * np, e * np + np).some(Boolean));
        const expHeldT = expHeld.map(h => h && anyNamed);
        const SUM7 = expHeldT.reduce((a, h) => a + (h ? emax : 0), 0);
        const rows = B.roster.map((st_, r) => {
          if (!st_.name) return null;
          const vals = rowVals(c, sec.id, x.page, r, n);
          const tot = expHeld.map((h, e) => (h ? sumNums(vals.slice(e * np, e * np + np)) : ''));
          const SUM = SUM7 === 0 ? '' : sumNums(tot), PCT = SUM === '' ? '' : SUM / SUM7;
          return { tot, N: tot.filter(isNum).length, SUM, PCT, SC: PCT === '' ? '' : PCT * x.marks };
        });
        B[x.id] = { held, expHeld, heldCount: expHeldT.filter(Boolean).length, emax, SUM7, rows };
      } else if (x.kind === 'single') {
        const any = held.some(Boolean), T7 = x.cols.reduce((a, col) => a + col.max, 0);
        const rows = B.roster.map((st_, r) => {
          if (!st_.name) return null;
          const T = any ? sumNums(rowVals(c, sec.id, x.page, r, n)) : '';
          return { T, SC: T === '' || T7 === 0 ? '' : (T / T7) * x.marks };
        });
        B[x.id] = { held, any, T7, rows };
      } else {
        const blocks = { des: { idx: [], scale: x.des.scale }, viva: { idx: [], scale: x.viva.scale } };
        x.cols.forEach((col, i) => blocks[col.block].idx.push(i));
        for (const b of Object.values(blocks)) { b.held = b.idx.some(i => held[i]); b.T7 = b.idx.reduce((a, i) => a + x.cols[i].max, 0); }
        const rows = B.roster.map((st_, r) => {
          if (!st_.name) return null;
          const vals = rowVals(c, sec.id, x.page, r, n), o = {};
          for (const [nm, b] of Object.entries(blocks)) {
            const T = b.held ? sumNums(b.idx.map(i => vals[i])) : '';
            o[nm] = { T, SC: T === '' || b.T7 === 0 ? '' : (T / b.T7) * b.scale };
          }
          const d = o.des.SC, v = o.viva.SC, den = (d === '' ? 0 : blocks.des.scale) + (v === '' ? 0 : blocks.viva.scale);
          o.P = d === '' && v === '' ? '' : den === 0 ? '' : ((N(d) + N(v)) / den) * x.marks;
          return o;
        });
        B[x.id] = { held, blocks, rows };
      }
    }
    if (Lo.L && Lo.labComps.length) {
      B.total = {
        rows: B.roster.map((st_, r) => {
          if (!st_.name) return null;
          const v = Lo.labComps.map(x => { const row = B[x.id].rows[r]; const val = x.kind === 'project' ? row.P : row.SC; return isNum(val) ? val : ''; });
          const T = v.some(isNum) ? sumNums(v) : '';
          const HM = T === '' ? '' : v.reduce((a, val, i) => a + (isNum(val) ? Lo.labComps[i].marks : 0), 0);
          return { v, T, HM, P: T === '' || !HM ? '' : T / HM };
        }),
      };
    }
  }
  // Final sheet (section list; lab results matched by Reg. No in any lab group of this course)
  const regIndex = Lo.secs.map(s => R.lab[s.id].roster.map(x => String(x.reg).trim().toLowerCase()));
  for (const sec of Lo.secs) {
    const S = R.sec[sec.id];
    S.final = S.roster.map((x, r) => {
      if (!x.name) return null;
      const o = { th: {}, lab: Lo.labComps.map(() => ''), labtot: '', labpct: '', latt: '', lattp: '', latts: '', grp: '' };
      let num = 0, den = 0;
      for (const t of Lo.theory) { const row = S[t.id].rows[r]; o.th[t.id] = row.T; if (isNum(row.pct)) { num += t.weight * row.pct; den += t.weight; } }
      o.thpct = Lo.T ? (den === 0 ? '' : num / den) : '';
      if (Lo.T) { const TA = S['Theory Att'], ta = TA.rows[r]; o.tatt = TA.heldN === 0 ? '' : `${ta.P} / ${TA.heldN}`; o.tattp = ta.pct; o.tatts = ta.status; }
      if (Lo.L) {
        let gi = -1, row = -1;
        const reg = String(x.reg).trim().toLowerCase();
        if (reg) for (let g = 0; g < Lo.secs.length && gi < 0; g++) { const k = regIndex[g].indexOf(reg); if (k >= 0) { gi = g; row = k; } }
        o.grp = gi >= 0 ? Lo.secs[gi].code : '—';
        if (gi >= 0) {
          const B = R.lab[Lo.secs[gi].id], lt = B.total && B.total.rows[row];
          const la = B['Lab Att'], lr = la.rows[row];
          if (lt) { o.lab = lt.v.slice(); o.labtot = lt.T; o.labpct = lt.P; }
          if (lr) { o.latt = la.heldN === 0 ? '' : `${lr.P} / ${la.heldN}`; o.lattp = lr.pct; o.latts = lr.status; }
          else o.latt = la.heldN === 0 ? '' : ` / ${la.heldN}`;
        }
      }
      const tp = o.thpct, lp = o.labpct, sT = Number(P.shares.T) || 0, sL = Number(P.shares.L) || 0;
      if (Lo.T && Lo.L) o.ct = tp === '' && lp === '' ? '' : ((isNum(tp) ? sT * tp : 0) + (isNum(lp) ? sL * lp : 0)) / ((isNum(tp) ? sT : 0) + (isNum(lp) ? sL : 0));
      else o.ct = Lo.T ? tp : lp;
      if (!isFinite(o.ct)) o.ct = '';
      o.grade = gradeOf(P, o.ct);
      o.rem = !x.reg ? 'Reg. No missing' : Lo.L && o.grp === '—' ? 'Not in any lab group' :
        o.tatts === 'Short' && o.latts === 'Short' ? 'Short attendance: theory and lab' :
        o.tatts === 'Short' ? 'Short attendance: theory' : o.latts === 'Short' ? 'Short attendance: lab' : '';
      return o;
    });
    // CLO and PLO (section list)
    const labIdx = Object.fromEntries(Lo.labComps.map((x, i) => [x.id, i]));
    S.clo = S.roster.map((x, r) => {
      if (!x.name) return null;
      const f = S.final[r], v = {};
      for (const comp of Lo.usedComps) {
        if (comp.sec) v[comp.id] = S[comp.id].rows[r].pct;
        else { const val = f.lab[labIdx[comp.id]]; v[comp.id] = isNum(val) && comp.marks ? val / comp.marks : ''; }
        if (!isNum(v[comp.id])) v[comp.id] = '';
      }
      const pct = {}, st_ = {};
      for (const k of Lo.clos) {
        let n_ = 0, d_ = 0;
        for (const [id, w] of Object.entries(k.w)) if (isNum(v[id])) { n_ += Number(w) * v[id]; d_ += Number(w); }
        pct[k.id] = d_ === 0 ? '' : n_ / d_;
        st_[k.id] = pct[k.id] === '' ? '' : ge(pct[k.id], Number(k.kpi)) ? 'Achieved' : 'Not achieved';
      }
      return { v, pct, st: st_ };
    });
    S.plo = S.clo.map(cl => {
      if (!cl) return null;
      const pct = {}, st_ = {};
      for (const p of Lo.plos) {
        let n_ = 0, d_ = 0;
        for (const [id, w] of Object.entries(p.w)) if (isNum(cl.pct[id])) { n_ += Number(w) * cl.pct[id]; d_ += Number(w); }
        pct[p.id] = d_ === 0 ? '' : n_ / d_;
        st_[p.id] = pct[p.id] === '' ? '' : ge(pct[p.id], Number(p.kpi)) ? 'Achieved' : 'Not achieved';
      }
      return { pct, st: st_ };
    });
    S.final.forEach((f, r) => { if (f) { f.clo = S.clo[r].pct; f.plo = S.plo[r].st; } });
    S.cloSummary = summary(Lo.clos, k => S.clo.map(x => x && x.pct[k.id]));
    S.ploSummary = summary(Lo.plos, p => S.plo.map(x => x && x.pct[p.id]));
  }
  R.results = sectionResults(c, R);
  return R;
}

function summary(list, get) {
  return list.map(k => {
    const v = get(k).filter(isNum), kpi = Number(k.kpi);
    const avg = v.length ? v.reduce((a, b) => a + b, 0) / v.length : '', n_ge = v.filter(x => ge(x, kpi)).length;
    return { id: k.id, code: k.code, kpi, avg, n: v.length, ge: n_ge, share: v.length ? n_ge / v.length : '', result: v.length ? (ge(avg, kpi) ? 'Attained' : 'Not attained') : '' };
  });
}

export function fmtNum(v, dp = 2) {
  if (!isNum(v)) return v === null || v === undefined ? '' : String(v);
  return String(Math.round(v * 10 ** dp) / 10 ** dp);
}
export const fmtPct = (v, dp = 1) => (isNum(v) ? (v * 100).toFixed(dp) + '%' : '');

function sectionResults(c, R) {
  const Lo = R.Lo, ids = Lo.secs.map(s => s.id);
  const fin = id => R.sec[id].final.filter(Boolean);
  const col = (id, f) => fin(id).map(f), all = f => ids.flatMap(id => col(id, f));
  const avgOf = a => stats(a).avg, count = (a, v) => a.filter(x => x === v).length;
  const share = (a, kpi) => { const v = a.filter(isNum); return v.length ? v.filter(x => ge(x, kpi)).length / v.length : ''; };
  const ach = a => { const n = a.filter(x => x === 'Achieved' || x === 'Not achieved').length; return n ? count(a, 'Achieved') / n : ''; };
  const graded = a => a.filter(x => x !== '' && x !== null && x !== undefined);
  const rows = [], outRows = {};
  const add = (label, f, allv, fmt, bar) => rows.push({ label, vals: ids.map(f), all: allv, fmt, bar });
  const head = label => rows.push({ head: label });
  head('Enrolment and classes');
  add('Students in section', id => fin(id).length, ids.reduce((a, id) => a + fin(id).length, 0), 'int');
  if (Lo.T) add('Lectures held', id => R.sec[id]['Theory Att'].heldN, '', 'int');
  if (Lo.L) add('Labs held (lab group of the same section)', id => R.lab[id]['Lab Att'].heldN, '', 'int');
  head('Attendance');
  if (Lo.T) {
    add('Average theory attendance %', id => avgOf(col(id, o => o.tattp)), avgOf(all(o => o.tattp)), 'pct', true);
    add('Students short in theory attendance', id => count(col(id, o => o.tatts), 'Short'), count(all(o => o.tatts), 'Short'), 'int');
  }
  if (Lo.L) {
    add('Average lab attendance %', id => avgOf(col(id, o => o.lattp)), avgOf(all(o => o.lattp)), 'pct', true);
    add('Students short in lab attendance', id => count(col(id, o => o.latts), 'Short'), count(all(o => o.latts), 'Short'), 'int');
  }
  if (Lo.T) {
    head('Theory marks (class averages)');
    for (const t of Lo.theory) {
      const held = ids.some(id => R.sec[id][t.id].rows.some(r => r && isNum(r.T)));
      const hm = Math.max(...ids.map(id => R.sec[id][t.id].T7));
      add(held ? `${t.short === 'Quiz' ? 'Quizzes' : t.short === 'Assignment' ? 'Assignments' : t.short} (out of ${fmtNum(hm)})` : `${t.short === 'Quiz' ? 'Quizzes' : t.short === 'Assignment' ? 'Assignments' : t.short} (not held yet)`,
        id => avgOf(col(id, o => o.th[t.id])), avgOf(all(o => o.th[t.id])), 'num');
    }
    add('Theory %', id => avgOf(col(id, o => o.thpct)), avgOf(all(o => o.thpct)), 'pct', true);
  }
  if (Lo.L && Lo.labComps.length) {
    head('Lab marks (class averages)');
    Lo.labComps.forEach((x, i) => add(`${x.short} (out of ${fmtNum(x.marks)})`, id => avgOf(col(id, o => o.lab[i])), avgOf(all(o => o.lab[i])), 'num'));
    add(`Lab total (out of ${fmtNum(Lo.labTotalMax)})`, id => avgOf(col(id, o => o.labtot)), avgOf(all(o => o.labtot)), 'num');
    add('Lab %', id => avgOf(col(id, o => o.labpct)), avgOf(all(o => o.labpct)), 'pct', true);
  }
  if (Lo.clos.length || Lo.plos.length) head('Course and programme learning outcomes');
  for (const k of Lo.clos) {
    add(`Average ${k.code} attainment`, id => avgOf(col(id, o => o.clo[k.id])), avgOf(all(o => o.clo[k.id])), 'pct', true);
    add(`Students achieving ${k.code} (≥ KPI)`, id => share(col(id, o => o.clo[k.id]), Number(k.kpi)), share(all(o => o.clo[k.id]), Number(k.kpi)), 'pct', true);
    outRows[k.id] = rows[rows.length - 1];
  }
  for (const p of Lo.plos) {
    add(`Students achieving ${p.code}`, id => ach(col(id, o => o.plo[p.id])), ach(all(o => o.plo[p.id])), 'pct', true);
    outRows[p.id] = rows[rows.length - 1];
  }
  head('Result');
  add('Average course total %', id => avgOf(col(id, o => o.ct)), avgOf(all(o => o.ct)), 'pct', true);
  add('Highest course total %', id => stats(col(id, o => o.ct)).max, stats(all(o => o.ct)).max, 'pct', true);
  add('Lowest course total %', id => stats(col(id, o => o.ct)).min, stats(all(o => o.ct)).min, 'pct', true);
  const passed = a => graded(a).length - count(a, 'F');
  add('Students passed (grade D or better)', id => passed(col(id, o => o.grade)), passed(all(o => o.grade)), 'int');
  add('Students failed (F)', id => count(col(id, o => o.grade), 'F'), count(all(o => o.grade), 'F'), 'int');
  const rate = a => (graded(a).length ? passed(a) / graded(a).length : '');
  add('Pass rate', id => rate(col(id, o => o.grade)), rate(all(o => o.grade)), 'pct', true);
  const outcomes = [...Lo.clos, ...Lo.plos].map(k => ({ code: k.code, vals: outRows[k.id].vals, all: outRows[k.id].all }));
  const grades = c.plan.grades.slice().reverse().map(([, g]) => { const vals = ids.map(id => count(col(id, o => o.grade), g)); return { g, vals, all: vals.reduce((a, b) => a + b, 0) }; });
  return { rows, outcomes, grades };
}
