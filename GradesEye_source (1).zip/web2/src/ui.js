// GradesEye (faculty app) — screens: semesters → sections → courses/labs, and every page of each course register.
import {
  NROW, DAYS, PALETTE, TINTS, TYPE_NAME, emptyState, newSemester, newSection, newCourse, defaultPlan, ensureCourse, normaliseState,
  migrateV1, semOf, courseById, semesterLabel, courseLabel, fileNameOf, folderPathOf, uid, GRADES,
} from './model.js';
import { layout, entryCols, entryPages, LAB_ORDER, COMP_NAMES } from './layout.js';
import {
  calc, stats, getMark, setMark, isNum, fmtNum, fmtPct, fmtDate, schedDate, autoDate, examDate, pageDates, activity, gradePoint, markKey, addDays,
} from './engine.js';
import { barChart } from './charts.js';
import { buildBytes } from './offload.js';
import { readCourseXlsx } from './ximport.js';
import { store, saveFile, openUrl, appVersion, isOnline, studentApk } from './platform.js';
import * as portal from './portal.js';
import * as sync from './sync.js';
import { bytesToBase64 } from './md5.js';
import SCRIPT from '../../apps-script/Code.gs';

const WDD_ACTIVITIES = ['Exp. 01: Introduction to HTML', 'Exp. 02: HTML Tables and HTML Form Elements', 'Exp. 03: Introduction to CSS', 'Exp. 04: CSS Selectors, Positioning and Pseudo-classes',
  'Exp. 05: CSS Box Model and Layout', 'Exp. 06: JavaScript and the HTML DOM', 'Exp. 07: Introduction to jQuery', 'Exp. 08: Bootstrap Components and Buttons', 'Exp. 09: Bootstrap Theme',
  'Exp. 10: Bootstrap Template and Framework', 'Exp. 11: PHP Basics', 'Exp. 12: Form Handling in PHP', 'Exp. 13: PHP and MySQL Database', 'Exp. 14: WordPress', 'Open-ended lab / semester project', 'Lab final exam'];

// ------------------------------------------------------------------ state
function safe(t) { try { return t ? JSON.parse(t) : null; } catch (e) { return null; } }
function loadState() {
  const t = safe(store.load('state2'));
  if (t) return normaliseState(t);
  const v1 = safe(store.load('state'));
  if (v1) {
    const st = migrateV1(v1, WDD_ACTIVITIES);
    sync.migrateV1Sync(st.courses[0] && st.courses[0].id);
    store.save('state2', JSON.stringify(st));
    return st;
  }
  return emptyState();
}
let state = loadState();
const ui = Object.assign({ sec: {}, exp: {}, finalView: 'Summary' }, safe(store.load('ui2')) || {});
let stack = [{ v: 'home' }];
let sel = null, saveTimer = null, FIELDS = [];
const cache = new Map();
const Rc = c => { if (!cache.has(c.id)) cache.set(c.id, calc(state, c)); return cache.get(c.id); };
// edits are written 400 ms after the last change, but never later than 2 s after the first unsaved one
let pendingSince = 0;
function persistNow() { clearTimeout(saveTimer); saveTimer = null; pendingSince = 0; store.save('state2', JSON.stringify(state)); }
function persist() {
  clearTimeout(saveTimer);
  const now = Date.now();
  if (!pendingSince) pendingSince = now;
  if (now - pendingSince > 2000) return persistNow();
  saveTimer = setTimeout(persistNow, 400);
}
function saveUi() { store.save('ui2', JSON.stringify(ui)); }
const coursesOfSection = secId => state.courses.filter(c => c.secIds.includes(secId)).map(c => c.id);
function changed(ids) { state.updated = Date.now(); cache.clear(); persist(); if (ids && ids.length) sync.edited(ids); }
const hasCourseData = c => Object.values(c.marks).some(m => m && Object.keys(m).length) || (semOf(state, c) || { sections: [] }).sections.some(s => c.secIds.includes(s.id) && Object.keys(s.students).length);

// ------------------------------------------------------------------ helpers
const $ = q => document.querySelector(q);
const esc = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const pct = v => fmtPct(v), num = v => fmtNum(v);
const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;
const colorOf = (c, secId) => { const i = c.secIds.indexOf(secId); return PALETTE[(i < 0 ? 0 : i) % PALETTE.length]; };
const tintOf = (c, secId) => { const i = c.secIds.indexOf(secId); return TINTS[(i < 0 ? 0 : i) % TINTS.length]; };
const secOf = (sem, id) => sem.sections.find(x => x.id === id);
function barStyle(v, color, max = 1) {
  if (!isNum(v)) return '';
  const w = Math.max(0, Math.min(100, (v / (max || 1)) * 100));
  return `background:linear-gradient(90deg, ${color}55 0, ${color}55 ${w}%, transparent ${w}%)`;
}
const statusCls = v => (['Eligible', 'Achieved', 'Attained'].includes(v) ? 'ok' : ['Short', 'Not achieved', 'Not attained', 'F'].includes(v) ? 'bad' : '');
async function copyText(t) {
  try { await navigator.clipboard.writeText(t); return true; } catch (e) {
    const ta = document.createElement('textarea'); ta.value = t; ta.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(ta); ta.select();
    let ok = false; try { ok = document.execCommand('copy'); } catch (e2) { ok = false; } ta.remove(); return ok;
  }
}
function refreshPortalNotes() {
  const v = top();
  if (v.v === 'course') { const el = document.querySelector('.pnote'), c = courseById(state, v.course); if (el && c) el.innerHTML = portalNote(c); }
  else if (v.v === 'sync') { const el = $('#stustatus'); if (el) el.innerHTML = studentStatus(); const ws = $('#webstatus'); if (ws) ws.innerHTML = webStatus(); }
}
function toast(msg, ms = 2600) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), ms); }
function modal(html, opts = {}) {
  const m = $('#modal');
  m.innerHTML = `<div class="sheet">${html}</div>`; m.hidden = false;
  m.onclick = e => { if (e.target === m && !opts.sticky) closeModal(); };
  return m;
}
function closeModal() { const m = $('#modal'); m.hidden = true; m.innerHTML = ''; }
function confirmBox(title, text, okText, danger = false) {
  return new Promise(res => {
    modal(`<h3>${esc(title)}</h3><p>${text}</p><div class="btns"><button class="btn" data-x="0">Cancel</button><button class="btn ${danger ? 'danger' : 'primary'}" data-x="1">${esc(okText)}</button></div>`);
    $('#modal').querySelectorAll('[data-x]').forEach(b => (b.onclick = () => { closeModal(); res(b.dataset.x === '1'); }));
  });
}
// form fields: each input carries data-fid → setter registered for this render
function fid(setter, type = 'text') { FIELDS.push({ setter, type }); return FIELDS.length - 1; }
const inp = (value, setter, o = {}) => {
  const type = o.type || 'text';
  const shown = type === 'pct' ? (isNum(Number(value)) && value !== '' && value !== null ? Math.round(Number(value) * 10000) / 100 : '') : value ?? '';
  const html = type === 'date' ? 'type="date"' : ['num', 'int', 'pct'].includes(type) ? 'inputmode="decimal"' : '';
  return `<input class="${o.cls || (['num', 'int', 'pct'].includes(type) ? 'num' : '')}" ${html} data-fid="${fid(setter, type)}" value="${esc(shown)}" ${o.ph ? `placeholder="${esc(o.ph)}"` : ''} ${o.attrs || ''}>${type === 'pct' ? '<span class="unit">%</span>' : ''}`;
};
const sel_ = (value, options, setter, type = 'text') => `<select data-fid="${fid(setter, type)}">${options.map(([v, l]) => `<option value="${esc(v)}" ${String(v) === String(value) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>`;
const chk = (on, setter, label) => `<label class="cb"><input type="checkbox" data-fid="${fid(setter, 'check')}" ${on ? 'checked' : ''}> ${label}</label>`;
const tr = (label, ctl, note = '') => `<div class="trow"><span>${label}${note ? `<small>${note}</small>` : ''}</span><span class="ctl">${ctl}</span></div>`;

// ------------------------------------------------------------------ navigation
const top = () => stack[stack.length - 1];
function go(view) { closeEditor(); stack.push(view); render(true); }
function replaceTop(view) { closeEditor(); stack[stack.length - 1] = view; render(true); }
function back() {
  if (!$('#modal').hidden) { closeModal(); return true; }
  if (sel) { closeEditor(); return true; }
  if (stack.length > 1) { stack.pop(); render(true); if (sync.configured()) sync.schedule(1500); return true; }
  return false;
}
window.__back = () => (back() ? 'ok' : 'exit');
window.__resume = () => { if (sync.configured() && sync.cfg.auto) sync.schedule(1200, { check: true }); };
window.__pause = () => { persistNow(); if (sync.configured() && isOnline() && state.courses.some(c => sync.dirty(c.id))) sync.syncAll(); };

// ------------------------------------------------------------------ sync chips
const CHIP = { local: ['☁', 'Set up Drive', 'muted'], synced: ['✓', 'Synced', 'ok'], pending: ['●', 'Waiting', 'warn'], offline: ['⚠', 'Offline', 'warn'], syncing: ['↻', 'Syncing…', 'busy'], error: ['!', 'Sync problem', 'bad'], conflict: ['?', 'Choose version', 'bad'] };
function chip(status, pending = 0) {
  const m = CHIP[status] || ['', status, ''];
  const label = status === 'pending' && pending ? `${pending} to sync` : status === 'offline' && pending ? `Offline · ${pending} saved` : m[1];
  return `<span class="chip ${m[2]}">${m[0]} ${label}</span>`;
}
function onSyncStatus() {
  const o = sync.overall(state.courses.map(c => c.id));
  const b = $('#syncbtn'); if (b) b.innerHTML = chip(o.status, o.pending);
  const v = top();
  if (v.v === 'sync' || v.v === 'home' || v.v === 'course') document.querySelectorAll('[data-syncof]').forEach(el => { const id = el.dataset.syncof; el.innerHTML = chip(sync.courseStatus(id), Math.max(0, sync.fileOf(id).editVersion - sync.fileOf(id).syncedVersion)); });
}

// ------------------------------------------------------------------ render
const VIEWS = { logins: vLogins, home: vHome, semester: vSemester, classlist: vClassList, plan: vPlan, course: vCourse, sheet: vSheet, schedule: vSchedule, labgroups: vLabGroups, results: vResults, sync: vSync, pins: vPins };
function render(resetScroll = false) {
  const v = top();
  if (v.course && !courseById(state, v.course)) { stack = [{ v: 'home' }]; return render(true); }
  if (v.sem && !state.semesters.some(s => s.id === v.sem)) { stack = [{ v: 'home' }]; return render(true); }
  const main = $('#main');
  const keep = resetScroll ? 0 : main.scrollTop;
  const tw = main.querySelector('.tw'), keepTw = tw && !resetScroll ? [tw.scrollLeft, tw.scrollTop] : null;
  const t = titleOf(v);
  $('#title').innerHTML = `<b>${esc(t.title)}</b>${t.sub ? `<small>${esc(t.sub)}</small>` : ''}`;
  $('#top').style.background = t.color || '#1F3864';
  $('#backbtn').style.visibility = stack.length > 1 ? 'visible' : 'hidden';
  FIELDS = [];
  main.innerHTML = VIEWS[v.v](v);
  main.scrollTop = keep;
  const tw2 = main.querySelector('.tw');
  if (tw2) { sizeTable(); if (keepTw) { tw2.scrollLeft = keepTw[0]; tw2.scrollTop = keepTw[1]; } }
  if (sel) markSel(false);
  onSyncStatus();
}
function titleOf(v) {
  const c = v.course && courseById(state, v.course), sem = c ? semOf(state, c) : v.sem && state.semesters.find(s => s.id === v.sem);
  switch (v.v) {
    case 'home': return { title: 'GradesEye', sub: state.profile.instructor ? `${state.profile.instructor} · my semesters, sections and courses` : 'My semesters, sections and courses' };
    case 'semester': return { title: v.isNew ? 'Add a semester' : 'Semester', sub: sem ? semesterLabel(sem) : '' };
    case 'classlist': { const s = secOf(sem, v.sec); return { title: `Class list · ${s ? s.code : ''}`, sub: `${s ? s.name : ''} · ${semesterLabel(sem)}` }; }
    case 'plan': return { title: v.isNew ? 'Add a course or lab' : 'Course settings', sub: c ? courseLabel(c) : sem ? semesterLabel(sem) : '' };
    case 'course': return { title: courseLabel(c), sub: `${TYPE_NAME[c.type]} · ${semesterLabel(sem)}` };
    case 'sheet': { const s = secOf(sem, v.sec), Lo = Rc(c).Lo, p = Lo.page[v.page]; return { title: `${s.code} · ${p ? p.title : v.page}`, sub: `${c.code} · ${s.name || s.code}`, color: colorOf(c, v.sec) }; }
    case 'schedule': return { title: 'Schedule', sub: courseLabel(c) };
    case 'labgroups': return { title: 'Lab Groups', sub: courseLabel(c) };
    case 'results': return { title: 'Section-wise Results', sub: courseLabel(c) };
    case 'sync': return { title: 'Drive and app settings' };
    case 'pins': return { title: 'Student app PINs', sub: courseLabel(c) };
    case 'logins': return { title: 'Student sign-ins', sub: courseLabel(c) };
  }
  return { title: '' };
}
function sizeTable() {
  const tw = $('#main .tw'); if (!tw) return;
  const ed = $('#editor'), edh = ed.hidden ? 0 : ed.offsetHeight;
  tw.style.maxHeight = Math.max(220, window.innerHeight - tw.getBoundingClientRect().top - edh - 6) + 'px';
}
window.addEventListener('resize', () => { sizeTable(); if (sel) markSel(true); });

// ------------------------------------------------------------------ HOME
function homeSync() {
  if (!sync.configured()) return `<div class="note">Everything is saved on this phone. Connect Google Drive so each course gets its Excel file in your folder. <button class="btn small primary" data-go="sync">Connect Drive</button></div>`;
  const o = sync.overall(state.courses.map(c => c.id));
  return `<div class="note">${chip(o.status, o.pending)} ${plural(state.courses.length, 'Excel file')} in Drive${sync.cfg.folderName ? ` · folder “${esc(sync.cfg.folderName)}”` : ''} <button class="btn small" data-go="sync">Drive</button></div>`;
}
function courseRow(c) {
  const sem = semOf(state, c), secs = c.secIds.map(id => secOf(sem, id)).filter(Boolean);
  return `<button class="crow" data-open-course="${c.id}"><span class="ctype ${c.type}">${{ TL: 'T+L', T: 'T', L: 'Lab' }[c.type]}</span>
    <span class="cmain"><b>${esc(courseLabel(c))}</b><small>${esc(c.credit || '')}${c.credit ? ' · ' : ''}Sections ${secs.map(s => esc(s.code)).join(', ') || '—'}</small></span>
    <span data-syncof="${c.id}"></span></button>`;
}
function vHome() {
  const depts = {};
  state.semesters.forEach(s => (depts[s.dept || 'Department'] = depts[s.dept || 'Department'] || []).push(s));
  let h = `<div class="card hero"><div class="h1">My registers</div><div class="muted small">${esc(state.profile.instructor || 'Instructor')} · ${esc(state.profile.university || '')} <a data-go="sync">edit</a></div></div>${homeSync()}`;
  if (!state.semesters.length) {
    h += `<div class="card tip"><b>Start here</b><ol><li><b>Add a semester</b> — department, programme, batch, semester and session.</li><li><b>Add its sections</b> (A, B, C…) and their class lists.</li><li><b>Add a course or lab</b> for some or all sections — the register and its Excel file are made automatically.</li></ol>
      <button class="btn primary" data-act="new-sem">+ Add a semester</button></div>`;
  }
  for (const [dept, sems] of Object.entries(depts)) {
    h += `<div class="h2">${esc(dept)}</div>`;
    for (const s of sems) {
      const courses = state.courses.filter(c => c.semId === s.id);
      h += `<div class="card sem"><div class="row between"><div><b>${esc(semesterLabel(s))}</b><div class="muted small">Week 1: ${fmtDate(s.start, true, true)} · ${s.weeks} weeks</div></div><button class="btn small" data-open-sem="${s.id}">Edit</button></div>
        <div class="secchips">${s.sections.length ? s.sections.map((x, i) => `<button class="secchip" data-code="${esc(x.code)}" style="--c:${PALETTE[i % PALETTE.length]}" data-classlist="${s.id}|${x.id}">${esc(x.code)}<small>${Object.values(x.students).filter(y => y && y.name).length}</small></button>`).join('') : '<span class="muted small">No sections yet — tap Edit to add them.</span>'}</div>
        <div class="clist">${courses.map(courseRow).join('') || '<div class="muted small">No courses yet.</div>'}</div>
        ${s.sections.length ? `<button class="btn small" data-act="new-course" data-sem="${s.id}">+ Add course or lab</button>` : ''}</div>`;
    }
  }
  if (state.semesters.length) h += `<button class="tile wide" style="background:#1F3864" data-act="new-sem">+ Add a semester<small>Another department, programme, batch or session</small></button>`;
  h += `<div class="foot muted small">GradesEye ${esc(appVersion())} · © 2026 softonicBank Co. · each course is one Excel file in Drive: ${esc((sync.cfg.folderName || 'your folder'))} / Department / Programme Batch – Semester (Session)</div>`;
  return h;
}

// ------------------------------------------------------------------ SEMESTER
function vSemester(v) {
  const s = v.isNew ? v.draft : state.semesters.find(x => x.id === v.sem);
  const live = !v.isNew;
  const set = k => val => { s[k] = val; if (live) changed(state.courses.filter(c => c.semId === s.id).map(c => c.id)); };
  let h = `<div class="card"><div class="h3">Semester</div>
    ${tr('Department', inp(s.dept, set('dept'), { ph: 'Department of Computing' }))}
    ${tr('Programme', inp(s.program, set('program'), { ph: 'BSCS' }))}
    ${tr('Batch', inp(s.batch, set('batch'), { ph: '2024' }))}
    ${tr('Semester', inp(s.semester, set('semester'), { ph: '5th' }))}
    ${tr('Session', inp(s.session, set('session'), { ph: 'Fall 2026' }))}
    ${tr('Week 1 starts on (Monday)', inp(s.start, set('start'), { type: 'date' }), 'all dates follow from this')}
    ${tr('Teaching weeks', inp(s.weeks, v_ => { s.weeks = Math.max(1, Math.min(20, Math.round(v_))); if (live) changed(state.courses.filter(c => c.semId === s.id).map(c => c.id)); }, { type: 'int' }))}
    ${v.isNew && !state.profile.instructor ? tr('Your name (instructor)', inp(state.profile.instructor, val => { state.profile.instructor = val; persist(); }, { ph: 'Lec. …' }), 'filled in as the instructor of new courses') : ''}
    ${v.isNew ? `<div class="btns"><button class="btn primary" data-act="create-sem">Create semester</button></div>` : ''}</div>`;
  if (v.isNew) return h;
  h += `<div class="card"><div class="h3">Sections</div>
    ${s.sections.map((x, i) => `<div class="secedit" style="border-color:${PALETTE[i % PALETTE.length]}">
      <span class="code">${inp(x.code, val => renameSection(s, x, val), { cls: 'sc' })}</span>${inp(x.name, val => { x.name = val; changed(coursesOfSection(x.id)); }, { cls: 'sn', ph: 'Name, e.g. BSCS-5A' })}
      <button class="btn small" data-classlist="${s.id}|${x.id}">Class list (${Object.values(x.students).filter(y => y && y.name).length})</button>
      <button class="iconbtn" data-act="del-sec" data-sem="${s.id}" data-sec="${x.id}" aria-label="remove section">✕</button></div>`).join('') || '<div class="muted small">No sections yet.</div>'}
    <div class="addrow"><input id="newsec-code" placeholder="Code, e.g. A" maxlength="10"><input id="newsec-name" placeholder="Name, e.g. ${esc((s.program || 'BSCS') + '-' + (parseInt(s.semester) || '') + 'A')}"><button class="btn primary small" data-act="add-sec" data-sem="${s.id}">Add section</button></div>
    <div class="muted small">A section's class list is shared by every course you teach it.</div></div>`;
  const courses = state.courses.filter(c => c.semId === s.id);
  h += `<div class="card"><div class="h3">Courses and labs</div><div class="clist">${courses.map(courseRow).join('') || '<div class="muted small">None yet.</div>'}</div>
    ${s.sections.length ? `<button class="btn primary small" data-act="new-course" data-sem="${s.id}">+ Add course or lab</button>` : '<div class="muted small">Add a section first.</div>'}</div>
    <div class="card"><button class="btn danger small" data-act="del-sem" data-sem="${s.id}">Delete this semester</button></div>`;
  return h;
}
function renameSection(sem, x, val) {
  const code = String(val).trim();
  if (!code) return toast('A section needs a code');
  if (/[\\/?*[\]:]/.test(code) || code.length > 10) return toast('Use up to 10 letters or numbers');
  if (sem.sections.some(y => y !== x && y.code.toLowerCase() === code.toLowerCase())) return toast('Another section already has that code');
  x.code = code; changed(coursesOfSection(x.id)); render();
}

// ------------------------------------------------------------------ CLASS LIST (shared by courses)
function rosterRows(list, editable, onSet, kind, ctx) {
  const n = Math.min(NROW, Math.max(-1, ...Object.keys(list).filter(k => list[k] && (list[k].reg || list[k].name || list[k].rem)).map(Number)) + (editable ? 2 : 1));
  let h = '<div class="roster">';
  for (let r = 0; r < Math.max(n, editable ? 1 : 0); r++) {
    const x = list[r] || {};
    h += `<div class="srow ${!x.name && !x.reg ? 'blank' : ''}"><span class="sr">${r + 1}</span>`;
    if (editable) h += inp(x.reg || '', val => onSet(r, 'reg', val), { cls: 'reg', ph: 'Reg. No', attrs: 'autocapitalize="characters"' }) + inp(x.name || '', val => onSet(r, 'name', val), { cls: 'name', ph: 'Student name', attrs: 'autocapitalize="words" data-rerender="1"' });
    else h += `<span class="reg">${esc(x.reg || '')}</span><span class="name">${esc(x.name || '')}</span>`;
    h += `<button class="more" data-act="stu-more" data-kind="${kind}" data-ctx="${esc(ctx)}" data-r="${r}" aria-label="more">⋮</button>${(kind === 'lab' ? ctxRem(ctx, r) : x.rem) ? `<div class="remline">${esc(kind === 'lab' ? ctxRem(ctx, r) : x.rem)}</div>` : ''}</div>`;
  }
  return h + '</div>';
}
const ctxRem = (ctx, r) => { const [cid, sid] = ctx.split('|'); const c = courseById(state, cid); return (c && c.labGroups[sid] && c.labGroups[sid].rem[r]) || ''; };
function vClassList(v) {
  const sem = state.semesters.find(s => s.id === v.sem), s = secOf(sem, v.sec);
  const count = Object.values(s.students).filter(x => x && x.name).length;
  const users = state.courses.filter(c => c.secIds.includes(s.id));
  const onSet = (r, k, val) => {
    const cur = Object.assign({}, s.students[r], { [k]: val.replace(/\s+/g, ' ').trim() });
    if (cur.reg || cur.name || cur.rem) s.students[r] = cur; else delete s.students[r];
    changed(coursesOfSection(s.id));
  };
  return `<div class="card"><div class="row between"><div><b>Section ${esc(s.code)} — ${esc(s.name)}</b><div class="muted small">${count} students · up to ${NROW} · used by ${users.map(c => esc(c.code || c.title)).join(', ') || 'no course yet'}</div></div>
    <button class="btn small" data-act="paste" data-kind="sec" data-ctx="${sem.id}|${s.id}">Paste list</button></div></div>
    ${rosterRows(s.students, true, onSet, 'sec', `${sem.id}|${s.id}`)}
    <div class="muted small pad">Type the Reg. No and name; a new empty row appears below the last student. The same row is used on every sheet of every course of this section.</div>`;
}

// ------------------------------------------------------------------ COURSE PLAN (create / edit)
function vPlan(v) {
  const c = v.draft, sem = state.semesters.find(s => s.id === c.semId), P = c.plan, T = c.type !== 'L', L = c.type !== 'T';
  const Lo = layout(c, sem);
  const rr = () => render();
  const sum = a => a.reduce((x, y) => x + (Number(y) || 0), 0);
  const total = (label, val, isPct = true) => { const ok = !isPct || Math.abs(val - 1) < 1e-6; return `<div class="trow total ${ok ? '' : 'badbg'}"><span>${label}</span><b>${isPct ? pct(val).replace('.0%', '%') : num(val)}</b>${ok ? '' : '<span class="small">must be 100%</span>'}</div>`; };
  const stepper = (val, min, max, setter) => `<span class="stepper"><button data-step="${fid(() => setter(Math.max(min, val - 1)), 'btn')}">−</button><b>${val}</b><button data-step="${fid(() => setter(Math.min(max, val + 1)), 'btn')}">+</button></span>`;
  let h = '';
  h += `<div class="card"><div class="h3">Course or lab</div>
    <div class="seg">${['TL', 'T', 'L'].map(t => `<button class="${c.type === t ? 'on' : ''}" data-step="${fid(() => setType(c, t), 'btn')}">${TYPE_NAME[t]}</button>`).join('')}</div>
    ${tr('Course code', inp(c.code, val => { c.code = val; }, { ph: 'CS-309' }))}
    ${tr('Title', inp(c.title, val => { c.title = val; }, { ph: 'Web Design & Development' }))}
    ${tr('Credit hours', inp(c.credit, val => { c.credit = val; }, { ph: '3(2+1)' }))}
    <div class="h3 small">Sections taking it</div>
    <div class="secchips">${sem.sections.map((x, i) => `<label class="secpick" data-code="${esc(x.code)}" style="--c:${PALETTE[i % PALETTE.length]}"><input type="checkbox" data-fid="${fid(on => { if (on) { if (!c.secIds.includes(x.id)) c.secIds.push(x.id); c.secIds.sort((a, b) => sem.sections.findIndex(s => s.id === a) - sem.sections.findIndex(s => s.id === b)); ensureCourse(c, sem, state.profile.instructor); } else c.secIds = c.secIds.filter(id => id !== x.id); rr(); }, 'check')}" ${c.secIds.includes(x.id) ? 'checked' : ''}> ${esc(x.code)} <small>${esc(x.name)}</small></label>`).join('')}</div>
  </div>`;
  if (c.secIds.length) h += `<div class="card"><div class="h3">Teachers and days</div>${c.secIds.map(id => { const x = secOf(sem, id), o = c.sec[id]; return `<div class="secbox" style="border-color:${colorOf(c, id)}"><b style="color:${colorOf(c, id)}">Section ${esc(x.code)}</b>
      ${T ? tr('Theory instructor', inp(o.inst, val => { o.inst = val; })) : ''}${L ? tr('Lab instructor', inp(o.labInst, val => { o.labInst = val; })) : ''}
      ${T ? tr('Lecture day', sel_(o.lec, DAYS.map((d, i) => [i, d]), val => { o.lec = val; }, 'int')) : ''}${L ? tr('Lab day', sel_(o.lab, DAYS.map((d, i) => [i, d]), val => { o.lab = val; }, 'int')) : ''}</div>`; }).join('')}</div>`;
  h += `<div class="card"><div class="h3">Attendance</div>${tr('Minimum attendance', inp(P.thr, val => { P.thr = val; }, { type: 'pct' }))}${tr('Count Leave (L) as present?', sel_(P.leave, [['No', 'No'], ['Yes', 'Yes']], val => { P.leave = val; }))}</div>`;
  if (T) {
    const items = (key, nm, short) => { const x = P[key]; return `<div class="sub"><div class="row between"><b>${nm}</b>${stepper(x.items.length, 0, 10, n => { while (x.items.length < n) x.items.push({ label: `${short} ${x.items.length + 1}`, max: x.items[x.items.length - 1]?.max || 10, week: Math.min(sem.weeks, (x.items[x.items.length - 1]?.week || 2) + 3) }); x.items.length = n; rr(); })}</div>
      ${x.items.length ? tr('Weight in theory', inp(x.weight, val => { x.weight = val; }, { type: 'pct' })) + `<div class="itemgrid"><span class="gh">Item</span><span class="gh">Max</span><span class="gh">Week</span>${x.items.map(it => `${inp(it.label, val => { it.label = val || it.label; })}${inp(it.max, val => { it.max = val; }, { type: 'num' })}${inp(it.week, val => { it.week = Math.max(1, Math.min(sem.weeks, Math.round(val))); }, { type: 'int' })}`).join('')}</div>` : '<div class="muted small">None.</div>'}</div>`; };
    const exam = (key, nm) => { const x = P[key]; return `<div class="sub"><div class="row between">${chk(x.on, on => { x.on = on; rr(); }, `<b>${nm}</b>`)}${x.on ? stepper(x.qs.length, 1, 20, n => { while (x.qs.length < n) x.qs.push(x.qs[x.qs.length - 1] || 10); x.qs.length = n; rr(); }) : ''}</div>
      ${x.on ? tr('Weight in theory', inp(x.weight, val => { x.weight = val; }, { type: 'pct' })) + tr('In week', inp(x.week, val => { x.week = Math.max(1, Math.round(val)); }, { type: 'int' }), 'date = Monday of that week (change it in Settings of the Excel or here)') +
        `<div class="qgrid">${x.qs.map((m, i) => `<label><small>Q${i + 1}</small>${inp(m, val => { x.qs[i] = val; }, { type: 'num' })}</label>`).join('')}</div>` : ''}</div>`; };
    h += `<div class="card"><div class="h3">Theory assessments</div>${items('quizzes', 'Quizzes', 'Quiz')}${items('assignments', 'Assignments', 'Assignment')}${exam('mid', 'Mid-term exam')}${exam('final', 'Final exam')}
      ${total('Theory weights total', sum([P.quizzes.items.length ? P.quizzes.weight : 0, P.assignments.items.length ? P.assignments.weight : 0, P.mid.on ? P.mid.weight : 0, P.final.on ? P.final.weight : 0]))}</div>`;
  }
  if (L) {
    const lb = P.lab;
    const crit = list => `<div class="qgrid">${list.map(cr => `<label><small title="${esc(cr[1])}">${esc(cr[0])}</small>${inp(cr[2], val => { cr[2] = val; }, { type: 'num' })}</label>`).join('')}</div>`;
    const part = (x, nm, opts = {}) => `<div class="sub">${chk(x.on, on => { x.on = on; rr(); }, `<b>${nm}</b>`)}${x.on ? tr('Marks in lab total', inp(x.marks, val => { x.marks = val; }, { type: 'num' })) + (opts.week ? tr('In week', inp(x.week, val => { x.week = Math.max(1, Math.round(val)); }, { type: 'int' })) : '') + (x.crit ? `<div class="muted small">Criteria maximum marks${opts.each ? ' (each experiment)' : ''}: ${x.crit.map(cr => esc(cr[0] + ' = ' + cr[1])).join(', ')}</div>` + crit(x.crit) : '') : ''}</div>`;
    h += `<div class="card"><div class="h3">Lab assessments</div>${tr('Number of experiments', stepper(lb.exps, 0, 30, n => { lb.exps = n; rr(); }))}
      ${part(lb.perf, 'Lab performance', { each: true })}${part(lb.reports, 'Lab reports', { each: true })}${part(lb.mid, 'Lab mid exam', { week: true })}${part(lb.final, 'Lab final exam', { week: true })}${part(lb.oel, 'Open-ended lab (viva voce)', { week: true })}
      <div class="sub">${chk(lb.project.on, on => { lb.project.on = on; rr(); }, '<b>Project</b>')}${lb.project.on ? tr('Marks in lab total', inp(lb.project.marks, val => { lb.project.marks = val; }, { type: 'num' })) + tr('In week', inp(lb.project.week, val => { lb.project.week = Math.max(1, Math.round(val)); }, { type: 'int' })) +
        tr('Design scaled to', inp(lb.project.des.scale, val => { lb.project.des.scale = val; }, { type: 'num' })) + tr('Viva scaled to', inp(lb.project.viva.scale, val => { lb.project.viva.scale = val; }, { type: 'num' })) +
        `<div class="muted small">Design criteria: ${lb.project.des.crit.map(cr => esc(cr[0] + ' = ' + cr[1])).join(', ')}</div>${crit(lb.project.des.crit)}<div class="muted small">Viva criteria: ${lb.project.viva.crit.map(cr => esc(cr[0] + ' = ' + cr[1])).join(', ')}</div>${crit(lb.project.viva.crit)}` : ''}</div>
      ${total('Lab total', Lo.labTotalMax, false)}</div>`;
  }
  if (T && L) h += `<div class="card"><div class="h3">Course weights</div>${tr('Theory share', inp(P.shares.T, val => { P.shares.T = val; }, { type: 'pct' }), c.credit || '')}${tr('Lab share', inp(P.shares.L, val => { P.shares.L = val; }, { type: 'pct' }))}${total('Course total', sum([P.shares.T, P.shares.L]))}</div>`;
  // CLOs and PLOs
  h += `<div class="card"><div class="h3">Course learning outcomes (CLOs)</div>${P.clos.map((k, i) => `<div class="outbox"><div class="row between"><b>CLO ${i + 1}</b><button class="iconbtn" data-step="${fid(() => { P.clos.splice(i, 1); P.plos.forEach(p => delete p.w[k.id]); rr(); }, 'btn')}">✕</button></div>
      ${tr('Code', inp(k.code, val => { k.code = val || k.code; }))}${tr('KPI', inp(k.kpi, val => { k.kpi = val; }, { type: 'pct' }))}${tr('Description', inp(k.desc, val => { k.desc = val; }))}
      <div class="muted small">Share of each assessment in this CLO:</div><div class="qgrid wide">${Lo.comps.map(x => `<label><small>${esc(x.title)}</small>${inp(k.w[x.id] || '', val => { if (val > 0) k.w[x.id] = val; else delete k.w[x.id]; }, { type: 'pct' })}</label>`).join('')}</div>
      ${total(`${esc(k.code)} total`, sum(Lo.comps.map(x => k.w[x.id] || 0)))}</div>`).join('')}
    <button class="btn small" data-step="${fid(() => { const n = P.clos.length + 1; P.clos.push({ id: uid('k'), code: `CLO-${n}`, kpi: 0.5, desc: '', w: {} }); rr(); }, 'btn')}">+ Add CLO</button></div>`;
  h += `<div class="card"><div class="h3">Programme learning outcomes (PLOs)</div>${P.plos.map((p, i) => `<div class="outbox"><div class="row between"><b>PLO ${i + 1}</b><button class="iconbtn" data-step="${fid(() => { P.plos.splice(i, 1); rr(); }, 'btn')}">✕</button></div>
      ${tr('Code', inp(p.code, val => { p.code = val || p.code; }))}${tr('KPI', inp(p.kpi, val => { p.kpi = val; }, { type: 'pct' }))}${tr('Description', inp(p.desc, val => { p.desc = val; }))}
      <div class="muted small">Share of each CLO in this PLO:</div><div class="qgrid wide">${P.clos.map(k => `<label><small>${esc(k.code)}</small>${inp(p.w[k.id] || '', val => { if (val > 0) p.w[k.id] = val; else delete p.w[k.id]; }, { type: 'pct' })}</label>`).join('')}</div>
      ${total(`${esc(p.code)} total`, sum(P.clos.map(k => p.w[k.id] || 0)))}</div>`).join('')}
    <button class="btn small" data-step="${fid(() => { const n = P.plos.length + 1; P.plos.push({ id: uid('p'), code: `PLO-${n}`, kpi: 0.5, desc: '', w: {} }); rr(); }, 'btn')}">+ Add PLO</button></div>`;
  h += `<div class="card"><details><summary>Grade scale</summary><div class="gtable"><span class="gh">From %</span><span class="gh">Grade</span><span class="gh">GP</span>
    ${P.grades.map(g => `${inp(g[0], val => { g[0] = val; }, { type: 'num' })}${inp(g[1], val => { g[1] = val || g[1]; })}${inp(g[2], val => { g[2] = val; }, { type: 'num' })}`).join('')}</div></details></div>`;
  h += `<div class="savebar"><button class="btn" data-act="plan-cancel">Cancel</button><button class="btn primary" data-act="plan-save">${v.isNew ? 'Create register' : 'Save changes'}</button></div>`;
  return h;
}
function setType(c, t) {
  if (c.type === t) return;
  const old = c.plan, fresh = defaultPlan(t);
  if (t !== 'L' && old.quizzes.items.length) ['quizzes', 'assignments', 'mid', 'final'].forEach(k => (fresh[k] = old[k]));
  if (t !== 'T' && old.lab.exps) fresh.lab = old.lab;
  fresh.thr = old.thr; fresh.leave = old.leave; fresh.grades = old.grades;
  if (t !== 'L') { fresh.mid.on = fresh.mid.on || t !== 'L'; fresh.final.on = fresh.final.on || t !== 'L'; }
  c.type = t; c.plan = fresh; render();
}

// ------------------------------------------------------------------ COURSE (register home)
function vCourse(v) {
  const c = courseById(state, v.course), sem = semOf(state, c), R = Rc(c), Lo = R.Lo;
  if (!Lo.secs.length) return `<div class="card tip">This course has no sections. <button class="btn small primary" data-act="edit-plan" data-course="${c.id}">Course settings</button></div>`;
  const cur = ui.sec[c.id] && c.secIds.includes(ui.sec[c.id]) ? ui.sec[c.id] : c.secIds[0];
  const s = secOf(sem, cur), fin = R.sec[cur].final.filter(Boolean);
  const ct = stats(fin.map(o => o.ct)).avg, short = fin.filter(o => o.tatts === 'Short' || o.latts === 'Short').length;
  const groups = {};
  Lo.pages.forEach(p => (groups[p.group] = groups[p.group] || []).push(p));
  const f = sync.fileOf(c.id);
  return `<div class="card hero"><div class="h1">${esc(courseLabel(c))}</div><div class="muted">${esc(TYPE_NAME[c.type])}${c.credit ? ' · ' + esc(c.credit) : ''} · ${esc(semesterLabel(sem))}</div><div class="muted small">${esc(sem.dept)}</div></div>
  <div class="note"><span data-syncof="${c.id}"></span> ${esc(fileNameOf(c))}${f.lastSync ? ` · synced ${esc(new Date(f.lastSync).toLocaleString())}` : ''}
    <span class="row wrap">${f.webLink ? `<button class="btn small" data-act="open-drive" data-course="${c.id}">Open in Drive</button>` : ''}<button class="btn small" data-act="save-xlsx" data-course="${c.id}">Save Excel to phone</button></span></div>
  <div class="grid4">
    <button class="tile" style="background:#404040" data-act="edit-plan" data-course="${c.id}">Course settings<small>Assessments, weights, CLO/PLO</small></button>
    <button class="tile" style="background:#595959" data-nav="schedule|${c.id}">Schedule<small>${sem.weeks}-week dates</small></button>
    <button class="tile" style="background:#1F3864" data-classlist="${sem.id}|${cur}">Class list ${esc(s.code)}<small>${esc(s.name)}</small></button>
    ${Lo.L ? `<button class="tile" style="background:#1F7A5A" data-nav="labgroups|${c.id}">Lab Groups<small>Lab lists</small></button>` : `<button class="tile" style="background:#1F7A5A" data-act="open-sem" data-sem="${sem.id}">Semester<small>Sections and courses</small></button>`}
  </div>
  <button class="tile wide" style="background:#C00000" data-nav="results|${c.id}">Section-wise Results<small>Attendance, marks, CLO/PLO attainment and grades${Lo.secs.length > 1 ? ' of ' + Lo.secs.map(x => esc(x.code)).join(', ') : ''}</small></button>
  <div class="h2">Section sheets</div>
  <div class="tabs">${Lo.secs.map(x => `<button class="tab ${x.id === cur ? 'on' : ''}" style="--c:${colorOf(c, x.id)}" data-act="csec" data-course="${c.id}" data-sec="${x.id}">Section ${esc(x.code)}<small>${esc(x.name)}</small></button>`).join('')}</div>
  <div class="secsum" style="border-color:${colorOf(c, cur)}"><span><b>${fin.length}</b> students</span>${Lo.L ? `<span>Lab group: <b>${R.lab[cur].roster.filter(x => x.name).length}</b></span>` : ''}
    <span>Avg course total <b>${isNum(ct) ? pct(ct) : '—'}</b></span><span class="${short ? 'badtxt' : ''}"><b>${short}</b> short attendance</span></div>
  ${Object.entries(groups).map(([g, ps]) => `<div class="glabel">${esc(g)}</div><div class="grid2">${ps.map(p => `<button class="pbtn ${p.id === 'Final Sheet' ? 'strong' : ''}" style="--c:${colorOf(c, cur)};--t:${tintOf(c, cur)}" data-nav="sheet|${c.id}|${cur}|${esc(p.id)}">${esc(p.title)}</button>`).join('')}</div>`).join('')}
  ${studentCard(c)}
  <div class="card mt"><button class="btn danger small" data-act="del-course" data-course="${c.id}">Delete this course</button></div>`;
}

// ------------------------------------------------------------------ STUDENT APP (per course, PINs)
// students who cannot sign in until their Reg. No is fixed (no number / placeholder, or the same Reg. No as another student)
function issuesOf(c) {
  const { dup, invalid } = portal.regIssues(state, portal.sharedCourses(state).concat(c ? [c] : []));
  const list = c ? portal.studentsOf(state, c) : portal.sharedCourses(state).flatMap(x => portal.studentsOf(state, x));
  const bad = new Set(list.filter(x => !x.reg || invalid.has(x.key) || dup.has(x.key)).map(x => x.name + '|' + x.key));
  return { dup, invalid, count: bad.size };
}
function portalNote(c) {
  const p = portal.portalOf(state), pc = portal.pstate(), fl = portal.flagsOf(state, c.id);
  if (!sync.configured()) return 'Connect Google Drive first — the student app reads from your Drive.';
  if (!fl.publish) return 'Hidden from students.';
  if (pc.lastError) return `<span class="err">${esc(pc.lastError)}</span>`;
  if (pc.hashes[c.id] && portal.readyToPublish(c.id)) return `<span class="okt">✓ Students can see this course</span>${pc.lastPublish ? ` · last update ${esc(new Date(pc.lastPublish).toLocaleString())}` : ''}`;
  if (!portal.readyToPublish(c.id)) return 'Will be updated for students after this course syncs with Drive.';
  return p.on ? 'Will be shared at the next sync.' : '';
}
function studentCard(c) {
  const p = portal.portalOf(state), fl = portal.flagsOf(state, c.id);
  const flag = k => v => { portal.setFlag(state, c.id, k, v); persistNow(); if (sync.configured()) sync.schedule(1500); render(); };
  if (!p.on) return `<div class="card mt"><div class="h3">Student app</div><div class="muted small">Students can see their own attendance and marks in the GradesEye Student app, signed in with their Reg. No and a PIN. <a data-go="sync">Turn it on</a></div></div>`;
  const iss = fl.publish ? issuesOf(c) : { count: 0 };
  return `<div class="card mt"><div class="h3">Student app</div>
    ${chk(fl.publish, flag('publish'), 'Show this course in the student app')}
    ${fl.publish ? chk(fl.release, flag('release'), 'Release results: final exam, course total, grade and class averages') : ''}
    <div class="small muted pnote">${portalNote(c)}</div>
    ${iss.count ? `<div class="warnbox small">${plural(iss.count, 'student')} cannot sign in until the Reg. No is fixed — see PINs and slips.</div>` : ''}
    ${fl.publish ? `<div class="row wrap"><button class="btn small" data-nav="pins|${c.id}">PINs and slips</button><button class="btn small" data-nav="logins|${c.id}">Who has signed in</button></div>` : ''}</div>`;
}
function vPins(v) {
  const c = courseById(state, v.course), p = portal.portalOf(state);
  if (!p.on) return `<div class="card tip">Turn on the student app first. <button class="btn small primary" data-go="sync">Drive and app settings</button></div>`;
  if (portal.ensurePins(state, [c])) { persistNow(); if (sync.configured()) sync.schedule(1500); }
  const list = portal.studentsOf(state, c), { dup, invalid } = issuesOf(c);
  let h = `<div class="card"><b>Sign-in PINs</b><div class="muted small">Each student signs in to GradesEye Student with their Reg. No and their PIN, and can then set a password of their own. One PIN works for all your courses. Give each student only their own slip.</div>
    <div class="row wrap" style="margin-top:8px"><button class="btn primary small" data-act="pin-xlsx" data-course="${c.id}">Save PIN slips (Excel)</button></div></div><div class="pinlist">`;
  let sec = '';
  for (const x of list) {
    if (x.code !== sec) { sec = x.code; h += `<div class="glabel">Section ${esc(x.code)} · ${esc(x.secName)}</div>`; }
    const problem = !x.reg ? 'add the Reg. No' : invalid.has(x.key) ? 'not a usable Reg. No' : dup.has(x.key) ? `same Reg. No as ${dup.get(x.key).filter(n => n.toLowerCase() !== x.name.toLowerCase()).join(', ')}` : '';
    const pin = problem ? '' : p.pins[x.key];
    h += `<div class="pinrow"><span class="pr">${esc(x.reg || '—')}</span><span class="pn">${esc(x.name)}${problem ? `<small class="err">${esc(problem)}</small>` : ''}</span>
      ${pin ? `<span class="pp">${esc(portal.fmtPin(pin))}</span><button class="iconbtn" data-act="pin-new" data-key="${esc(x.key)}" data-name="${esc(x.name)}" aria-label="new PIN">↻</button>` : '<span class="pp none">no PIN</span><span></span>'}</div>`;
  }
  return h + (list.length ? '' : '<div class="muted small pad">No students in this course yet.</div>') + '</div><div class="muted small pad">↻ gives a student a new PIN (lost slip or forgotten password); the old PIN, and any password the student set, stop working after the next sync. Fix Reg. Nos in the section\'s class list.</div>';
}

// students of this course who have signed in to the student app (from the Drive script; last copy kept on the phone)
let loginsBusy = false, loginsErr = '', loginsTried = 0;
async function loadLogins() {
  if (loginsBusy || !sync.configured() || !isOnline()) return;
  loginsBusy = true;
  const r = await portal.fetchLogins();
  loginsBusy = false; loginsErr = r.ok ? '' : r.error;
  if (top().v === 'logins') render();
}
const fmtWhen = ms => (ms ? new Date(ms).toLocaleString([], { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '');
function vLogins(v) {
  const c = courseById(state, v.course), L = portal.loginsOf();
  if ((!L || Date.now() - L.time > 30000) && Date.now() - loginsTried > 30000) { loginsTried = Date.now(); setTimeout(loadLogins, 0); }
  const data = (L && L.data) || {}, list = portal.studentsOf(state, c), f = ui.loginFilter || 'all';
  const isIn = x => !!(x.key && data[x.key] && data[x.key].n);
  const n = list.filter(isIn).length, own = list.filter(x => isIn(x) && data[x.key].pw).length;
  let h = `<div class="card"><div class="row between"><div><b>${n} of ${list.length} students have signed in</b><div class="muted small">${own} use their own password${L ? ` · checked ${esc(fmtWhen(L.time))}` : ''}</div></div>
    <button class="btn small" data-act="logins-refresh">${loginsBusy ? 'Checking…' : 'Refresh'}</button></div>
    ${loginsErr ? `<div class="warnbox small">${esc(loginsErr)}</div>` : !sync.configured() ? '<div class="warnbox small">Connect Google Drive first.</div>' : !L ? `<div class="muted small">${isOnline() ? 'Checking…' : 'You are offline — connect to see who has signed in.'}</div>` : ''}
    <div class="seg" style="margin-top:8px">${[['all', 'All'], ['in', 'Signed in'], ['out', 'Not yet']].map(([k, l]) => `<button class="${f === k ? 'on' : ''}" data-act="logins-filter" data-f="${k}">${l}</button>`).join('')}</div></div><div class="pinlist">`;
  let sec = '';
  for (const x of list) {
    const o = x.key && data[x.key], signed = isIn(x);
    if ((f === 'in' && !signed) || (f === 'out' && signed)) continue;
    if (x.code !== sec) { sec = x.code; h += `<div class="glabel">Section ${esc(x.code)} · ${esc(x.secName)}</div>`; }
    h += `<div class="pinrow lrow"><span class="pr">${esc(x.reg || '—')}</span><span class="pn">${esc(x.name)}${signed ? `<small class="muted">last ${esc(fmtWhen(o.l))} · ${Number(o.n) || 0} sign-in${Number(o.n) === 1 ? '' : 's'}${o.s && o.s > o.l ? ` · opened ${esc(fmtWhen(o.s))}` : ''}${o.pw ? ' · own password' : ''}</small>` : ''}</span>
      <span class="lst ${signed ? 'ok' : ''}">${signed ? '✓ Signed in' : 'Not yet'}</span></div>`;
  }
  return h + '</div><div class="muted small pad">A student counts as signed in after entering their Reg. No with their PIN or password at least once.</div>';
}

// ------------------------------------------------------------------ SHEETS
function sheetHeader(c, secId, page, extra = '') {
  const sem = semOf(state, c), s = secOf(sem, secId), p = Rc(c).Lo.page[page], o = c.sec[secId] || {};
  return `<div class="sheethead"><span>${p.sec ? 'Section' : 'Lab group'} ${esc(s.code)} (${esc(s.name)}) · ${p.sec ? 'Instructor: ' + esc(o.inst || '—') : 'Lab instructor: ' + esc(o.labInst || '—')}</span>${extra}</div>`;
}
function noStudents(c, secId, page) {
  const sem = semOf(state, c), p = Rc(c).Lo.page[page];
  return `<div class="card tip">No students in ${p.sec ? 'this section' : 'this lab group'} yet. ${p.sec ? `<button class="btn small primary" data-classlist="${sem.id}|${secId}">Open class list</button>` : `<button class="btn small primary" data-nav="labgroups|${c.id}">Open Lab Groups</button>`}</div>`;
}
const rosterOf = (c, secId, page) => { const R = Rc(c); return R.Lo.page[page].sec ? R.sec[secId].roster : R.lab[secId].roster; };
const namedRows = (c, secId, page) => rosterOf(c, secId, page).map((x, r) => ({ r, ...x })).filter(x => x.name);
function vSheet(v) {
  const c = courseById(state, v.course), Lo = Rc(c).Lo, p = Lo.page[v.page];
  if (!p) return '<div class="card">This page is not part of the course any more.</div>';
  const fn = { att: tAtt, items: tTheory, exam: tTheory, exp: tExp, single: tSingle, project: tProject, labtotal: tLabTotal, clo: tCLO, plo: tPLO, final: tFinal }[p.kind];
  return fn(c, v.sec, v.page);
}
function table(c, secId, page, cols, rows, foot = []) {
  const color = colorOf(c, secId), groups = [], subs = [];
  cols.forEach(x => { const l = groups[groups.length - 1]; if (l && l.g === x.g) l.n++; else groups.push({ g: x.g, gc: x.gc, n: 1 }); });
  cols.forEach(x => { const l = subs[subs.length - 1]; if (l && x.mergeSub && l.sub === x.sub && l.g === x.g && x.sub !== undefined) l.n++; else subs.push({ sub: x.sub, g: x.g, n: 1 }); });
  const kind = Rc(c).Lo.page[page].kind;
  let h = `<div class="tw"><table class="t" style="--c:${color}"><thead>`;
  h += `<tr class="r1"><th class="c0" rowspan="4">#</th><th class="c1" rowspan="4">Student</th>${groups.map(g => `<th colspan="${g.n}" class="grp" style="background:${g.gc || color}">${esc(g.g)}</th>`).join('')}</tr>`;
  h += `<tr class="r2">${cols.map(x => `<th class="lab ${x.entry !== undefined ? 'ent' : 'calc'}" style="min-width:${x.w || 44}px" ${x.hact ? `data-act="${x.hact}" data-c="${x.entry}"` : ''}>${esc(x.h)}</th>`).join('')}</tr>`;
  h += `<tr class="r3">${subs.map(x => `<th colspan="${x.n}" class="sub">${esc(x.sub || '')}</th>`).join('')}</tr>`;
  h += `<tr class="r4">${cols.map(x => `<th class="mx">${esc(x.max ?? '')}</th>`).join('')}</tr></thead><tbody>`;
  for (const row of rows) {
    h += `<tr><td class="c0">${row.r + 1}</td><td class="c1"><div class="nm">${esc(row.name)}</div><div class="rg">${esc(row.reg)}</div></td>`;
    for (const x of cols) {
      if (x.entry !== undefined) {
        const val = getMark(c, secId, page, row.r, x.entry);
        h += `<td class="e ${kind === 'att' ? `att ${val || ''}` : ''}" data-r="${row.r}" data-c="${x.entry}">${esc(val ?? '')}</td>`;
      } else { const o = x.cell(row) || {}; h += `<td class="f ${o.cls || ''}" ${o.st ? `style="${o.st}"` : ''}>${esc(o.t ?? '')}</td>`; }
    }
    h += '</tr>';
  }
  h += '</tbody>';
  if (foot.length && rows.length) h += '<tfoot>' + foot.map(f => `<tr><td class="c0"></td><td class="c1"><b>${esc(f.label)}</b></td>${cols.map(x => `<td class="ft">${esc(f.cell(x) ?? '')}</td>`).join('')}</tr>`).join('') + '</tfoot>';
  return h + '</table></div>';
}
const statFoot = (getter, isPct = () => false) => ['Class average', 'Highest', 'Lowest'].map((label, i) => ({
  label, cell: x => { if (x.noStat) return ''; const s = stats(getter(x)), v = [s.avg, s.max, s.min][i]; return isNum(v) ? (isPct(x) ? pct(v) : num(v)) : ''; },
}));
const titleShort = x => (x.short === 'Quiz' ? 'Quizzes' : x.short === 'Assignment' ? 'Assignments' : x.short);

function tAtt(c, secId, page) {
  const R = Rc(c), Lo = R.Lo, p = Lo.page[page], rows = namedRows(c, secId, page), sem = semOf(state, c);
  if (!rows.length) return sheetHeader(c, secId, page) + noStudents(c, secId, page);
  const A = (p.sec ? R.sec[secId] : R.lab[secId])[page], dates = pageDates(sem, c, Lo, secId, page);
  const nexp = Lo.L ? Number(c.plan.lab.exps) || 0 : 0;
  const cols = [];
  for (let w = 1; w <= Lo.weeks; w++) cols.push({ g: `Wk ${w}`, gc: w % 2 ? '#2E5C9A' : '#1F3864', h: p.att === 'lec' ? 'Lec' : w <= nexp ? `Exp ${w}` : 'Lab', sub: fmtDate(dates[w - 1]), max: A.held[w - 1] ? '✓' : '', entry: w - 1, w: 40, hact: 'week' });
  const r_ = row => A.rows[row.r] || {};
  cols.push({ g: 'Summary', gc: '#1F3864', h: 'P', cell: row => ({ t: r_(row).P }), w: 32 }, { g: 'Summary', gc: '#1F3864', h: 'L', cell: row => ({ t: r_(row).L }), w: 32 }, { g: 'Summary', gc: '#1F3864', h: 'A', cell: row => ({ t: r_(row).A }), w: 32 });
  cols.push({ g: 'Summary', gc: '#1F3864', h: `${p.att === 'lec' ? 'Theory' : 'Lab'} %`, max: `held: ${A.heldN}`, w: 70, cell: row => ({ t: pct(r_(row).pct), cls: 'num' + (isNum(r_(row).pct) && r_(row).pct < c.plan.thr ? ' badtxt' : ''), st: barStyle(r_(row).pct, p.att === 'lec' ? '#2E75B6' : '#70AD47') }) });
  cols.push({ g: 'Summary', gc: '#1F3864', h: 'Status', w: 66, cell: row => ({ t: r_(row).status, cls: 'pill ' + statusCls(r_(row).status) }) });
  const foot = [{ label: 'Present', cell: x => (x.entry !== undefined ? A.perWeek[x.entry].present : '') },
    { label: 'Class %', cell: x => (x.entry !== undefined ? pct(A.perWeek[x.entry].pct).replace('.0%', '%') : x.h.endsWith('%') ? pct(stats(A.rows.map(y => y && y.pct)).avg) : x.h === 'Status' ? `${A.rows.filter(y => y && y.status === 'Short').length} short` : '') }];
  return sheetHeader(c, secId, page, `<span>Min. ${pct(c.plan.thr)} · Leave counts as present: ${esc(c.plan.leave)} · tap a week heading to mark the whole class</span>`) + table(c, secId, page, cols, rows, foot);
}
function tTheory(c, secId, page) {
  const R = Rc(c), Lo = R.Lo, x = Lo.page[page].comp, rows = namedRows(c, secId, page), sem = semOf(state, c);
  if (!rows.length) return sheetHeader(c, secId, page) + noStudents(c, secId, page);
  const T = R.sec[secId][x.id], dates = pageDates(sem, c, Lo, secId, page), items = x.kind === 'items';
  const cols = x.cols.map((col, i) => ({ g: x.title, gc: x.color, h: col.label, sub: fmtDate(items ? dates[i] : dates[0], true), max: num(col.max), entry: i, w: items ? 70 : 42, mergeSub: !items }));
  const r_ = row => T.rows[row.r] || {};
  cols.push({ g: 'Total', gc: '#1F3864', h: items ? `${x.short} total` : 'Exam total', max: `/ ${num(T.T7)}`, w: 64, cell: row => ({ t: num(r_(row).T), cls: 'num b' }), key: 'T' });
  cols.push({ g: 'Total', gc: '#1F3864', h: 'Percentage', w: 80, cell: row => ({ t: pct(r_(row).pct), cls: 'num', st: barStyle(r_(row).pct, x.color) }), key: 'pct' });
  const foot = statFoot(y => (y.entry !== undefined ? rows.map(z => getMark(c, secId, page, z.r, y.entry)) : rows.map(z => r_(z)[y.key])), y => y.key === 'pct');
  return sheetHeader(c, secId, page, `<span>${items ? 'Total counts only the items already held (any student has marks).' : 'The exam counts as held once any marks are entered; blank questions count as 0.'}</span>`) + table(c, secId, page, cols, rows, foot);
}
function tExp(c, secId, page) {
  const R = Rc(c), Lo = R.Lo, x = Lo.page[page].comp, rows = namedRows(c, secId, page), sem = semOf(state, c);
  if (!rows.length) return sheetHeader(c, secId, page) + noStudents(c, secId, page);
  const E = R.lab[secId][x.id], np = x.crit.length, dates = pageDates(sem, c, Lo, secId, page);
  const key = `${c.id}|${secId}|${page}`;
  if (ui.exp[key] === undefined || (typeof ui.exp[key] === 'number' && ui.exp[key] > x.exps)) { const last = E.expHeld.lastIndexOf(true); ui.exp[key] = last >= 0 ? last + 1 : 1; }
  const f = ui.exp[key];
  const show = f === 'all' ? Array.from({ length: x.exps }, (_, i) => i + 1) : f === 'sum' ? [] : [f];
  const chips = `<div class="chips">${Array.from({ length: x.exps }, (_, i) => i + 1).map(n => `<button class="chipb ${f === n ? 'on' : ''} ${E.expHeld[n - 1] ? 'held' : ''}" data-act="expf" data-k="${esc(key)}" data-f="${n}">Exp ${n}</button>`).join('')}<button class="chipb ${f === 'sum' ? 'on' : ''}" data-act="expf" data-k="${esc(key)}" data-f="sum">Summary</button><button class="chipb ${f === 'all' ? 'on' : ''}" data-act="expf" data-k="${esc(key)}" data-f="all">All</button></div>`;
  const r_ = row => E.rows[row.r] || {}, cols = [];
  for (const n of show) {
    const gc = n % 2 ? '#2E5C9A' : '#1F3864';
    x.crit.forEach(([ab, lab, mx], j) => cols.push({ g: `Exp. No. ${n}`, gc, h: ab, sub: fmtDate(dates[n - 1]), max: num(mx), entry: (n - 1) * np + j, w: 38, mergeSub: true }));
    cols.push({ g: `Exp. No. ${n}`, gc, h: 'Total', sub: fmtDate(dates[n - 1]), mergeSub: true, max: `/ ${num(E.emax)}`, w: 44, cell: row => ({ t: num(r_(row).tot ? r_(row).tot[n - 1] : ''), cls: 'num b' }), key: 'tot' + n });
  }
  cols.push({ g: 'Summary', gc: '#1F3864', h: 'Exps marked', max: `held: ${E.heldCount}`, w: 54, cell: row => ({ t: r_(row).N ?? '' }), key: 'N' });
  cols.push({ g: 'Summary', gc: '#1F3864', h: 'Total of held', max: `/ ${num(E.SUM7)}`, w: 58, cell: row => ({ t: num(r_(row).SUM), cls: 'num b' }), key: 'SUM' });
  cols.push({ g: 'Summary', gc: '#1F3864', h: 'Percentage', w: 74, cell: row => ({ t: pct(r_(row).PCT), cls: 'num', st: barStyle(r_(row).PCT, x.color) }), key: 'PCT' });
  cols.push({ g: 'Summary', gc: '#1F3864', h: `Marks (/ ${num(x.marks)})`, max: `/ ${num(x.marks)}`, w: 64, cell: row => ({ t: num(r_(row).SC), cls: 'num b sc' }), key: 'SC' });
  const getter = y => (y.entry !== undefined ? rows.map(z => getMark(c, secId, page, z.r, y.entry)) : y.key.startsWith('tot') ? rows.map(z => (r_(z).tot || [])[Number(y.key.slice(3)) - 1]) : rows.map(z => r_(z)[y.key]));
  return sheetHeader(c, secId, page, `<span>${esc(x.crit.map(([ab, lab, mx]) => `${ab} = ${lab} (0–${num(mx)})`).join(' · '))}</span>`) + chips + table(c, secId, page, cols, rows, statFoot(getter, y => y.key === 'PCT'));
}
function tSingle(c, secId, page) {
  const R = Rc(c), Lo = R.Lo, x = Lo.page[page].comp, rows = namedRows(c, secId, page), sem = semOf(state, c);
  if (!rows.length) return sheetHeader(c, secId, page) + noStudents(c, secId, page);
  const X = R.lab[secId][x.id], date = pageDates(sem, c, Lo, secId, page)[0], r_ = row => X.rows[row.r] || {};
  const cols = x.cols.map((col, i) => ({ g: x.title, gc: x.color, h: `${col.label} (0–${num(col.max)})`, sub: `Week ${x.week} · ${fmtDate(date, true)}`, max: num(col.max), entry: i, w: 78, mergeSub: true }));
  cols.push({ g: 'Total', gc: '#1F3864', h: `Total (/ ${num(X.T7)})`, max: `/ ${num(X.T7)}`, w: 64, cell: row => ({ t: num(r_(row).T), cls: 'num b' }), key: 'T' });
  cols.push({ g: 'Total', gc: '#1F3864', h: `Marks (/ ${num(x.marks)})`, max: `/ ${num(x.marks)}`, w: 70, cell: row => ({ t: num(r_(row).SC), cls: 'num b sc', st: barStyle(r_(row).SC, x.color, x.marks) }), key: 'SC' });
  return sheetHeader(c, secId, page, `<span>Date = week ${x.week} lab day of this group (change the week in Course settings).</span>`) + table(c, secId, page, cols, rows, statFoot(y => (y.entry !== undefined ? rows.map(z => getMark(c, secId, page, z.r, y.entry)) : rows.map(z => r_(z)[y.key]))));
}
function tProject(c, secId, page) {
  const R = Rc(c), Lo = R.Lo, x = Lo.page[page].comp, rows = namedRows(c, secId, page), sem = semOf(state, c);
  if (!rows.length) return sheetHeader(c, secId, page) + noStudents(c, secId, page);
  const X = R.lab[secId].PROJ, date = pageDates(sem, c, Lo, secId, page)[0], r_ = row => X.rows[row.r] || {};
  const cols = [], blk = { des: ['Project Design Quantification', '#1F7A5A'], viva: ['Project Viva Quantification', '#7030A0'] };
  for (const b of ['des', 'viva']) {
    x.cols.forEach((col, i) => { if (col.block === b) cols.push({ g: blk[b][0], gc: blk[b][1], h: `${col.label} (0–${num(col.max)})`, sub: fmtDate(date, true), max: num(col.max), entry: i, w: 74, mergeSub: true }); });
    cols.push({ g: blk[b][0], gc: blk[b][1], h: `Total (/ ${num(X.blocks[b].T7)})`, max: `/ ${num(X.blocks[b].T7)}`, w: 56, cell: row => ({ t: num(r_(row)[b] && r_(row)[b].T), cls: 'num b' }), key: b + 'T' });
    cols.push({ g: blk[b][0], gc: blk[b][1], h: `Scaled (/ ${num(x[b].scale)})`, max: `/ ${num(x[b].scale)}`, w: 56, cell: row => ({ t: num(r_(row)[b] && r_(row)[b].SC), cls: 'num' }), key: b + 'SC' });
  }
  cols.push({ g: 'Design project', gc: '#1F3864', h: `Project marks (/ ${num(x.marks)})`, max: `/ ${num(x.marks)}`, w: 84, cell: row => ({ t: num(r_(row).P), cls: 'num b sc', st: barStyle(r_(row).P, '#B45F06', x.marks) }), key: 'P' });
  const getter = y => (y.entry !== undefined ? rows.map(z => getMark(c, secId, page, z.r, y.entry)) : rows.map(z => { const o = r_(z); if (y.key === 'P') return o.P; const b = y.key.replace(/SC$|T$/, ''); return o[b] && o[b][y.key.endsWith('SC') ? 'SC' : 'T']; }));
  return sheetHeader(c, secId, page, `<span>Project = (design scaled + viva scaled) / (${num(x.des.scale)} + ${num(x.viva.scale)}) × ${num(x.marks)}, using only the parts already marked.</span>`) + table(c, secId, page, cols, rows, statFoot(getter));
}
function tLabTotal(c, secId, page) {
  const R = Rc(c), Lo = R.Lo, rows = namedRows(c, secId, page);
  if (!rows.length) return sheetHeader(c, secId, page) + noStudents(c, secId, page);
  const LT = R.lab[secId].total, r_ = row => LT.rows[row.r] || {};
  const cols = Lo.labComps.map((x, i) => ({ g: 'LAB TOTAL — from the lab assessment sheets', gc: '#1F7A5A', h: x.title, max: num(x.marks), w: 62, cell: row => ({ t: num((r_(row).v || [])[i]), cls: 'num' }), i }));
  cols.push({ g: 'Total', gc: '#1F3864', h: `Total (/ ${num(Lo.labTotalMax)})`, max: `/ ${num(Lo.labTotalMax)}`, w: 62, cell: row => ({ t: num(r_(row).T), cls: 'num b sc' }), key: 'T' });
  cols.push({ g: 'Total', gc: '#1F3864', h: 'Max of marked', w: 58, cell: row => ({ t: num(r_(row).HM), cls: 'num' }), key: 'HM' });
  cols.push({ g: 'Total', gc: '#1F3864', h: 'Lab %', w: 74, cell: row => ({ t: pct(r_(row).P), cls: 'num b', st: barStyle(r_(row).P, '#70AD47') }), key: 'P' });
  const links = Lo.labComps.map(x => `<button class="chipb" data-nav="sheet|${c.id}|${secId}|${esc(x.page)}">${esc(x.title)}</button>`).join('');
  return sheetHeader(c, secId, page, `<span>Lab total = ${Lo.labComps.map(x => num(x.marks)).join(' + ')} = ${num(Lo.labTotalMax)}. Lab % uses only the components already marked.</span>`) + `<div class="chips">${links}</div>` +
    table(c, secId, page, cols, rows, statFoot(y => (y.i !== undefined ? rows.map(z => (r_(z).v || [])[y.i]) : rows.map(z => r_(z)[y.key])), y => y.key === 'P'));
}
function summaryCard(title, summary, chartTitle) {
  const rows = summary.map(o => `<tr><td><b>${esc(o.code)}</b></td><td>${pct(o.kpi)}</td><td>${pct(o.avg)}</td><td>${o.n}</td><td>${o.ge}</td><td>${pct(o.share)}</td><td class="pill ${statusCls(o.result)}">${esc(o.result)}</td></tr>`).join('');
  const chart = barChart({ title: chartTitle, cats: summary.map(o => o.code), max: 1, series: [{ name: 'KPI', color: '#BFBFBF', vals: summary.map(o => o.kpi) }, { name: 'Class average', color: '#2E75B6', vals: summary.map(o => o.avg) }, { name: '% of students ≥ KPI', color: '#70AD47', vals: summary.map(o => o.share) }] });
  return `<div class="card"><div class="h3">${esc(title)}</div><div class="scrollx"><table class="mini"><tr><th>Outcome</th><th>KPI</th><th>Class average</th><th>Assessed</th><th>≥ KPI</th><th>% ≥ KPI</th><th>Class result</th></tr>${rows}</table></div><div class="muted small">Class result: attained when the class average reaches the KPI.</div>${chart}</div>`;
}
function tCLO(c, secId, page) {
  const R = Rc(c), Lo = R.Lo, S = R.sec[secId], rows = namedRows(c, secId, page), s = secOf(semOf(state, c), secId);
  const head = sheetHeader(c, secId, page) + summaryCard('Class summary — course learning outcomes', S.cloSummary, `Section ${s.code}: CLO attainment`);
  if (!rows.length) return head + noStudents(c, secId, page);
  const r_ = row => S.clo[row.r] || {};
  const cols = Lo.usedComps.map(x => ({ g: 'Assessment attainment (% of marks)', gc: '#1F7A5A', h: titleShort(x), w: 60, cell: row => ({ t: pct((r_(row).v || {})[x.id]), cls: 'num' }), get: o => o.v[x.id], p: 1 }));
  for (const k of Lo.clos) {
    const g = `${k.code} (KPI = ${pct(k.kpi).replace('.0', '')})`;
    cols.push({ g, gc: colorOf(c, secId), h: `${k.code} total`, sub: Object.entries(k.w).map(([id, w]) => `${COMP_NAMES[id]} ${Math.round(w * 100)}%`).join(', '), w: 76, cell: row => ({ t: pct((r_(row).pct || {})[k.id]), cls: 'num b', st: barStyle((r_(row).pct || {})[k.id], '#2E75B6') }), get: o => o.pct[k.id], p: 1 });
    cols.push({ g, gc: colorOf(c, secId), h: 'Status', w: 74, cell: row => ({ t: (r_(row).st || {})[k.id], cls: 'pill ' + statusCls((r_(row).st || {})[k.id]) }), noStat: true });
  }
  return head + table(c, secId, page, cols, rows, statFoot(y => rows.map(z => (y.get && S.clo[z.r] ? y.get(S.clo[z.r]) : '')), y => !!y.p));
}
function tPLO(c, secId, page) {
  const R = Rc(c), Lo = R.Lo, S = R.sec[secId], rows = namedRows(c, secId, page), s = secOf(semOf(state, c), secId);
  const head = sheetHeader(c, secId, page) + summaryCard('Class summary — programme learning outcomes', S.ploSummary, `Section ${s.code}: PLO attainment`);
  if (!rows.length) return head + noStudents(c, secId, page);
  const cols = [];
  for (const p of Lo.plos) {
    const g = `${p.code} (KPI = ${pct(p.kpi).replace('.0', '')})`;
    for (const [id, w] of Object.entries(p.w)) { const k = Lo.clos.find(x => x.id === id); cols.push({ g, gc: '#7030A0', h: k.code, sub: `weight ${Math.round(w * 100)}%`, w: 64, cell: row => ({ t: pct((S.clo[row.r] || { pct: {} }).pct[id]), cls: 'num' }), get: r => (S.clo[r] || { pct: {} }).pct[id], p: 1 }); }
    cols.push({ g, gc: '#7030A0', h: 'Total 100%', w: 76, cell: row => ({ t: pct((S.plo[row.r] || { pct: {} }).pct[p.id]), cls: 'num b', st: barStyle((S.plo[row.r] || { pct: {} }).pct[p.id], '#7030A0') }), get: r => (S.plo[r] || { pct: {} }).pct[p.id], p: 1 });
    cols.push({ g, gc: '#7030A0', h: 'Status', w: 74, cell: row => ({ t: (S.plo[row.r] || { st: {} }).st[p.id], cls: 'pill ' + statusCls((S.plo[row.r] || { st: {} }).st[p.id]) }), noStat: true });
  }
  return head + table(c, secId, page, cols, rows, statFoot(y => rows.map(z => (y.get ? y.get(z.r) : '')), y => !!y.p));
}
const FINAL_VIEWS = ['Summary', 'Theory', 'Attendance', 'Lab', 'Outcomes', 'Result', 'All'];
function tFinal(c, secId, page) {
  const R = Rc(c), Lo = R.Lo, rows = namedRows(c, secId, page);
  if (!rows.length) return sheetHeader(c, secId, page) + noStudents(c, secId, page);
  const S = R.sec[secId], F = S.final, P = c.plan, r_ = row => F[row.r] || {}, all = [];
  const add = (g, gc, tags, o) => all.push(Object.assign({ g, gc, tags }, o));
  if (Lo.T) {
    for (const x of Lo.theory) add('Theory marks', '#7030A0', 'Theory', { h: titleShort(x), max: `/ ${num(S[x.id].T7)}`, w: 52, cell: row => ({ t: num(r_(row).th[x.id]), cls: 'num' }), get: o => o.th[x.id] });
    add('Theory marks', '#7030A0', 'Theory Summary', { h: 'Theory %', w: 70, cell: row => ({ t: pct(r_(row).thpct), cls: 'num b', st: barStyle(r_(row).thpct, '#9E7BC4') }), get: o => o.thpct, p: 1 });
    add('Theory attendance', '#2E75B6', 'Attendance', { h: 'Classes attended', max: `held: ${S['Theory Att'].heldN}`, w: 60, cell: row => ({ t: r_(row).tatt }), noStat: true });
    add('Theory attendance', '#2E75B6', 'Attendance Summary', { h: 'Theory att. %', w: 70, cell: row => ({ t: pct(r_(row).tattp), cls: 'num' + (isNum(r_(row).tattp) && r_(row).tattp < P.thr ? ' badtxt' : ''), st: barStyle(r_(row).tattp, '#2E75B6') }), get: o => o.tattp, p: 1 });
    add('Theory attendance', '#2E75B6', 'Attendance', { h: 'Status', w: 64, cell: row => ({ t: r_(row).tatts, cls: 'pill ' + statusCls(r_(row).tatts) }), noStat: true });
  }
  if (Lo.L) {
    add('Lab marks', '#1F7A5A', 'Lab', { h: 'Lab group', w: 42, cell: row => ({ t: r_(row).grp }), noStat: true });
    Lo.labComps.forEach((x, i) => add('Lab marks', '#1F7A5A', 'Lab', { h: x.short, max: `/ ${num(x.marks)}`, w: 52, cell: row => ({ t: num(r_(row).lab[i]), cls: 'num' }), get: o => o.lab[i] }));
    if (Lo.labComps.length) {
      add('Lab marks', '#1F7A5A', 'Lab', { h: `Lab total (${num(Lo.labTotalMax)})`, max: `/ ${num(Lo.labTotalMax)}`, w: 56, cell: row => ({ t: num(r_(row).labtot), cls: 'num b' }), get: o => o.labtot });
      add('Lab marks', '#1F7A5A', 'Lab Summary', { h: 'Lab %', w: 70, cell: row => ({ t: pct(r_(row).labpct), cls: 'num b', st: barStyle(r_(row).labpct, '#70AD47') }), get: o => o.labpct, p: 1 });
    }
  }
  for (const k of Lo.clos) add('Outcomes', '#B45F06', 'Outcomes', { h: `${k.code} %`, w: 64, cell: row => ({ t: pct(r_(row).clo[k.id]), cls: 'num', st: barStyle(r_(row).clo[k.id], '#F4B183') }), get: o => o.clo[k.id], p: 1 });
  for (const p of Lo.plos) add('Outcomes', '#B45F06', 'Outcomes Summary', { h: p.code, w: 70, cell: row => ({ t: r_(row).plo[p.id], cls: 'pill ' + statusCls(r_(row).plo[p.id]) }), noStat: true });
  if (Lo.L) {
    add('Lab attendance', '#548235', 'Attendance', { h: 'Labs attended', w: 60, cell: row => ({ t: r_(row).latt }), noStat: true });
    add('Lab attendance', '#548235', 'Attendance Summary', { h: 'Lab att. %', w: 70, cell: row => ({ t: pct(r_(row).lattp), cls: 'num' + (isNum(r_(row).lattp) && r_(row).lattp < P.thr ? ' badtxt' : ''), st: barStyle(r_(row).lattp, '#548235') }), get: o => o.lattp, p: 1 });
    add('Lab attendance', '#548235', 'Attendance', { h: 'Status', w: 64, cell: row => ({ t: r_(row).latts, cls: 'pill ' + statusCls(r_(row).latts) }), noStat: true });
  }
  add('Result', '#C00000', 'Result Summary', { h: 'Course total %', w: 76, cell: row => ({ t: pct(r_(row).ct), cls: 'num b', st: barStyle(r_(row).ct, '#C00000') }), get: o => o.ct, p: 1 });
  add('Result', '#C00000', 'Result Summary', { h: 'Grade', w: 44, cell: row => ({ t: r_(row).grade, cls: 'b ' + (r_(row).grade === 'F' ? 'pill bad' : '') }), noStat: true });
  add('Result', '#C00000', 'Result', { h: 'GP', w: 36, cell: row => ({ t: r_(row).grade ? num(gradePoint(P, r_(row).grade)) : '' }), get: o => (o.grade ? gradePoint(P, o.grade) : '') });
  add('Result', '#C00000', 'Result Summary', { h: 'Remarks', w: 130, cell: row => ({ t: r_(row).rem, cls: 'rem' }), noStat: true });
  const views = FINAL_VIEWS.filter(v => v === 'All' || all.some(x => x.tags.split(' ').includes(v)));
  const view = views.includes(ui.finalView) ? ui.finalView : 'Summary';
  const cols = view === 'All' ? all : all.filter(x => x.tags.split(' ').includes(view));
  const chips = `<div class="chips">${views.map(v => `<button class="chipb ${v === view ? 'on' : ''}" data-act="finalv" data-f="${v}">${v}</button>`).join('')}</div>`;
  return sheetHeader(c, secId, page, `<span>All formulas${Lo.L ? ' · lab results are matched by Reg. No from the student\'s lab group' : ''}</span>`) + chips + table(c, secId, page, cols, rows, statFoot(y => rows.map(z => (y.get ? y.get(r_(z)) : '')), y => !!y.p));
}

// ------------------------------------------------------------------ cell editor
function colInfo(c, secId, page, col) {
  const Lo = Rc(c).Lo, p = Lo.page[page];
  if (p.kind === 'att') return { label: `Week ${col + 1} · ${p.att === 'lec' ? 'lecture' : 'lab'} · ${fmtDate(pageDates(semOf(state, c), c, Lo, secId, page)[col], true, true)}`, att: true };
  const x = p.comp.cols[col];
  let label = x.label;
  if (p.kind === 'exp') label = `Exp. ${x.exp} · ${x.label} — ${x.long}`;
  if (p.kind === 'project') label = `${x.block === 'des' ? 'Design' : 'Viva'} · ${x.label}`;
  return { label: `${p.title} · ${label}`, max: x.max };
}
function openEditor(c, secId, page, r, col) { sel = { c: c.id, secId, page, r, col }; renderEditor(); markSel(true); }
function closeEditor() {
  if (!sel) return;
  commitInput(false);
  sel = null;
  const ed = $('#editor'); ed.hidden = true; ed.innerHTML = '';
  document.querySelectorAll('td.sel').forEach(x => x.classList.remove('sel'));
  sizeTable();
}
function markSel(scroll) {
  document.querySelectorAll('td.sel').forEach(x => x.classList.remove('sel'));
  if (!sel) return;
  const td = document.querySelector(`#main td.e[data-r="${sel.r}"][data-c="${sel.col}"]`);
  if (!td) return;
  td.classList.add('sel');
  if (scroll) {
    const tw = $('#main .tw'); if (!tw) return;
    const a = td.getBoundingClientRect(), b = tw.getBoundingClientRect();
    if (a.left < b.left + 170) tw.scrollLeft -= b.left + 170 - a.left + 8; else if (a.right > b.right) tw.scrollLeft += a.right - b.right + 8;
    if (a.top < b.top + 92) tw.scrollTop -= b.top + 92 - a.top + 4; else if (a.bottom > b.bottom) tw.scrollTop += a.bottom - b.bottom + 4;
  }
}
function renderEditor() {
  const c = courseById(state, sel.c), { secId, page, r, col } = sel, ed = $('#editor');
  const who = rosterOf(c, secId, page)[r], info = colInfo(c, secId, page, col), v = getMark(c, secId, page, r, col);
  let ctl;
  if (info.att) ctl = `<div class="edrow">${['P', 'A', 'L'].map(x => `<button class="attb ${x} ${v === x ? 'on' : ''}" data-act="ed-set" data-v="${x}">${x}</button>`).join('')}<button class="attb clr" data-act="ed-set" data-v="">–</button><button class="nav" data-act="ed-up">▲</button><button class="nav" data-act="ed-down">▼</button><button class="nav done" data-act="ed-close">Done</button></div>`;
  else {
    const ints = info.max <= 10 && Number.isInteger(info.max);
    const quick = ints ? Array.from({ length: info.max + 1 }, (_, i) => i + (ui.half && i < info.max ? 0.5 : 0)) : info.max <= 5 ? [0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5].filter(x => x <= info.max) : [];
    ctl = `<div class="edrow"><button class="nav" data-act="ed-left">◀</button><input id="edin" inputmode="decimal" autocomplete="off" value="${esc(v ?? '')}" placeholder="0–${num(info.max)}"><button class="nav" data-act="ed-right">▶</button><button class="nav" data-act="ed-up">▲</button><button class="nav" data-act="ed-down">▼</button><button class="nav done" data-act="ed-close">Done</button></div>
      ${quick.length ? `<div class="quick">${quick.map(x => `<button data-act="ed-quick" data-v="${x}" class="${v === x ? 'on' : ''}">${x}</button>`).join('')}${ints ? `<button data-act="ed-half" class="half ${ui.half ? 'on' : ''}">+½</button>` : ''}<button data-act="ed-quick" data-v="">clear</button></div>` : ''}`;
  }
  ed.innerHTML = `<div class="edinfo"><b>${esc(who.name)}</b> <span>${esc(who.reg)}</span><div>${esc(info.label)}${info.att ? '' : ` · max ${num(info.max)}`}</div><div id="ederr"></div></div>${ctl}`;
  ed.hidden = false; sizeTable();
  const i = $('#edin');
  if (i) { i.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); if (commitInput(true)) advance(); } }; setTimeout(() => { i.focus(); i.select(); }, 30); }
}
function editedCourse(c) { changed([c.id]); }
function commitInput(showErr) {
  const i = $('#edin');
  if (!sel || !i) return true;
  const c = courseById(state, sel.c), raw = i.value.trim().replace(',', '.'), cur = getMark(c, sel.secId, sel.page, sel.r, sel.col);
  if (raw === '') { if (cur !== null) { setMark(c, sel.secId, sel.page, sel.r, sel.col, null); editedCourse(c); refreshTable(); } return true; }
  const v = Number(raw), max = colInfo(c, sel.secId, sel.page, sel.col).max;
  if (!isFinite(v) || v < 0 || v > max) { if (showErr) { const e = $('#ederr'); if (e) e.textContent = `Enter a number from 0 to ${num(max)}.`; i.classList.add('err'); } return false; }
  if (cur !== v) { setMark(c, sel.secId, sel.page, sel.r, sel.col, v); editedCourse(c); refreshTable(); }
  return true;
}
function setValue(v) {
  const c = courseById(state, sel.c), cur = getMark(c, sel.secId, sel.page, sel.r, sel.col), nv = v === '' ? null : v;
  if (cur !== nv) { setMark(c, sel.secId, sel.page, sel.r, sel.col, nv); editedCourse(c); refreshTable(); }
}
function refreshTable() { if (top().v === 'sheet') render(); }
function move(dr, dc) {
  const c = courseById(state, sel.c), rows = namedRows(c, sel.secId, sel.page).map(x => x.r);
  const cols = [...new Set([...document.querySelectorAll('#main tbody tr:first-child td.e')].map(td => Number(td.dataset.c)))];
  let ri = rows.indexOf(sel.r), ci = cols.indexOf(sel.col);
  if (dr) ri = Math.max(0, Math.min(rows.length - 1, ri + dr));
  if (dc) ci = Math.max(0, Math.min(cols.length - 1, ci + dc));
  if (ri < 0 || ci < 0) return;
  sel = Object.assign({}, sel, { r: rows[ri], col: cols[ci] }); renderEditor(); markSel(true);
}
function advance() {
  const c = courseById(state, sel.c), p = Rc(c).Lo.page[sel.page];
  const rows = namedRows(c, sel.secId, sel.page).map(x => x.r), ri = rows.indexOf(sel.r);
  if (['exp', 'single', 'project'].includes(p.kind)) {
    const cols = p.comp.cols, col = sel.col;
    const same = i => (p.kind === 'exp' ? cols[i].exp === cols[col].exp : p.kind === 'project' ? cols[i].block === cols[col].block : true);
    if (col + 1 < cols.length && same(col + 1)) return move(0, 1);
    let first = col; while (first - 1 >= 0 && same(first - 1)) first--;
    if (ri + 1 < rows.length) { sel = Object.assign({}, sel, { r: rows[ri + 1], col: first }); renderEditor(); markSel(true); } else closeEditor();
    return;
  }
  if (ri + 1 < rows.length) move(1, 0); else closeEditor();
}

// ------------------------------------------------------------------ SCHEDULE, LAB GROUPS, RESULTS
function vSchedule(v) {
  const c = courseById(state, v.course), sem = semOf(state, c), Lo = Rc(c).Lo;
  const cur = ui.sec[c.id] && c.secIds.includes(ui.sec[c.id]) ? ui.sec[c.id] : c.secIds[0];
  let h = `<div class="tabs">${Lo.secs.map(x => `<button class="tab ${x.id === cur ? 'on' : ''}" style="--c:${colorOf(c, x.id)}" data-act="csec" data-course="${c.id}" data-sec="${x.id}">${esc(x.code)}<small>${esc(x.name)}</small></button>`).join('')}</div>
    <div class="muted small pad">Dates come from the semester's week 1 (${fmtDate(sem.start, true)}) and each section's lecture/lab day. Change a date for a holiday; ↺ returns it to automatic.</div>`;
  for (let w = 1; w <= Lo.weeks; w++) {
    const cell = kind => {
      const k = `${cur}|${kind}|${w}`, over = !!c.schedule.dates[k], d = schedDate(sem, c, cur, kind, w);
      return `<label class="dcell ${over ? 'over' : ''}"><span>${kind === 'lec' ? 'Lecture' : 'Lab'}</span>${inp(d, val => { if (val) { c.schedule.dates[k] = val; changed([c.id]); render(); } }, { type: 'date' })}${over ? `<button data-act="sched-reset" data-course="${c.id}" data-k="${k}">↺</button>` : ''}<em>${fmtDate(d, false, true)}</em></label>`;
    };
    h += `<div class="card week"><b>Week ${w}</b><div class="row wrap">${Lo.T ? cell('lec') : ''}${Lo.L ? cell('lab') : ''}</div>
      ${inp(activity(c, Lo, w), val => { const def = w <= (Lo.L ? Number(c.plan.lab.exps) || 0 : 0) ? `Exp. ${String(w).padStart(2, '0')}` : ''; if (val === def) delete c.schedule.activities[w]; else c.schedule.activities[w] = val; changed([c.id]); }, { cls: 'act', ph: 'Lab experiment / activity' })}
      ${inp(c.schedule.notes[w] || '', val => { if (val) c.schedule.notes[w] = val; else delete c.schedule.notes[w]; changed([c.id]); }, { cls: 'act', ph: 'Notes' })}</div>`;
  }
  return h;
}
function vLabGroups(v) {
  const c = courseById(state, v.course), sem = semOf(state, c), Lo = Rc(c).Lo;
  const cur = ui.sec[c.id] && c.secIds.includes(ui.sec[c.id]) ? ui.sec[c.id] : c.secIds[0];
  const s = secOf(sem, cur), lg = c.labGroups[cur], count = Rc(c).lab[cur].roster.filter(x => x.name).length;
  const onSet = (r, k, val) => { const cur_ = Object.assign({}, lg.rows[r], { [k]: val.replace(/\s+/g, ' ').trim() }); if (cur_.reg || cur_.name) lg.rows[r] = cur_; else delete lg.rows[r]; changed([c.id]); };
  return `<div class="tabs">${Lo.secs.map(x => `<button class="tab ${x.id === cur ? 'on' : ''}" style="--c:${colorOf(c, x.id)}" data-act="csec" data-course="${c.id}" data-sec="${x.id}">${esc(x.code)}<small>${esc(x.name)}</small></button>`).join('')}</div>
  <div class="card"><b>Lab group ${esc(s.code)}</b> <span class="muted small">· ${count} students</span>
    <div class="seg"><button class="${!lg.custom ? 'on' : ''}" data-act="lg-mode" data-course="${c.id}" data-sec="${cur}" data-m="same">Same as Section ${esc(s.code)}</button><button class="${lg.custom ? 'on' : ''}" data-act="lg-mode" data-course="${c.id}" data-sec="${cur}" data-m="custom">Custom list</button></div>
    <div class="muted small">${lg.custom ? 'This lab group has its own list for this course. Results reach each student\'s Final Sheet by Reg. No.' : `Follows the Section ${esc(s.code)} class list. Choose “Custom list” if the lab group differs.`}</div>
    ${lg.custom ? `<div class="row"><button class="btn small" data-act="paste" data-kind="lab" data-ctx="${c.id}|${cur}">Paste list</button><button class="btn small" data-act="lg-copy" data-course="${c.id}" data-sec="${cur}">Copy section list</button></div>` : ''}</div>
  ${rosterRows(lg.custom ? lg.rows : s.students, lg.custom, onSet, 'lab', `${c.id}|${cur}`)}`;
}
function vResults(v) {
  const c = courseById(state, v.course), R = Rc(c), X = R.results, secs = R.Lo.secs;
  let h = `<div class="card"><div class="scrollx"><table class="mini res"><tr><th>Measure</th>${secs.map(s => `<th style="background:${colorOf(c, s.id)};color:#fff">${esc(s.code)}<br><small>${esc(s.name)}</small></th>`).join('')}<th>All</th></tr>`;
  for (const row of X.rows) {
    if (row.head) { h += `<tr class="hd"><td colspan="${secs.length + 2}">${esc(row.head)}</td></tr>`; continue; }
    const f = v_ => (row.fmt === 'pct' ? pct(v_) : row.fmt === 'int' ? (isNum(v_) ? v_ : '') : num(isNum(v_) ? Math.round(v_ * 10) / 10 : v_));
    h += `<tr><td class="lbl">${esc(row.label)}</td>${row.vals.map(v_ => `<td class="num" style="${row.bar ? barStyle(v_, '#5B9BD5') : ''}">${esc(f(v_))}</td>`).join('')}<td class="num b">${esc(f(row.all))}</td></tr>`;
  }
  h += '</table></div><div class="muted small">All values come from the Final Sheets.</div></div>';
  if (X.outcomes.length) h += `<div class="card">${barChart({ title: 'CLO / PLO attainment by section', yTitle: 'Students ≥ KPI', cats: X.outcomes.map(o => o.code), max: 1, series: secs.map((s, i) => ({ name: `Section ${s.code}`, color: colorOf(c, s.id), vals: X.outcomes.map(o => o.vals[i]) })) })}
    <div class="scrollx"><table class="mini"><tr><th>Students ≥ KPI</th>${secs.map(s => `<th>${esc(s.code)}</th>`).join('')}<th>All</th></tr>${X.outcomes.map(o => `<tr><td><b>${esc(o.code)}</b></td>${o.vals.map(v_ => `<td>${pct(v_)}</td>`).join('')}<td><b>${pct(o.all)}</b></td></tr>`).join('')}</table></div></div>`;
  h += `<div class="card">${barChart({ title: 'Grade distribution by section', yTitle: 'Students', pct: false, cats: X.grades.map(g => g.g), series: secs.map((s, i) => ({ name: `Section ${s.code}`, color: colorOf(c, s.id), vals: X.grades.map(g => g.vals[i]) })) })}
    <div class="scrollx"><table class="mini"><tr><th>Grade</th>${secs.map(s => `<th>${esc(s.code)}</th>`).join('')}<th>All</th></tr>${X.grades.map(g => `<tr><td><b>${esc(g.g)}</b></td>${g.vals.map(v_ => `<td>${v_}</td>`).join('')}<td><b>${g.all}</b></td></tr>`).join('')}</table></div></div>`;
  return h;
}

// ------------------------------------------------------------------ SYNC and APP SETTINGS
function vSync() {
  const c = sync.cfg, o = sync.overall(state.courses.map(x => x.id));
  const files = state.courses.map(x => {
    const f = sync.fileOf(x.id), sem = semOf(state, x);
    return `<div class="frow"><div><b>${esc(courseLabel(x))}</b><div class="muted small">${esc(folderPathOf(sem).join(' / '))} / ${esc(fileNameOf(x))}</div>${f.lastError && sync.courseStatus(x.id) === 'error' ? `<div class="err small">${esc(f.lastError)}</div>` : ''}</div>
      <div class="fcol"><span data-syncof="${x.id}"></span>${sync.conflictOf(x.id) ? `<button class="btn small primary" data-act="conflict" data-course="${x.id}">Choose…</button>` : ''}${f.webLink ? `<button class="btn small" data-act="open-drive" data-course="${x.id}">Open</button>` : ''}</div></div>`;
  }).join('');
  return `<div class="card"><div class="h3">You</div>${tr('Your name (shown in the files)', inp(state.profile.instructor, val => { state.profile.instructor = val; changed(state.courses.map(x => x.id)); }, { ph: 'Lec. …' }))}${tr('University', inp(state.profile.university, val => { state.profile.university = val; changed(state.courses.map(x => x.id)); }))}</div>
  <div class="card"><div class="h3">Google Drive</div><div class="bigstatus">${chip(o.status, o.pending)}</div>
    ${sync.configured() ? `<div class="row wrap"><button class="btn primary small" data-act="sync-now">Sync now</button></div>` : ''}
    ${files ? `<div class="files">${files}</div>` : '<div class="muted small">No courses yet.</div>'}
    ${sync.configured() && sync.cfg.scriptVersion && sync.cfg.scriptVersion < 2 ? '<div class="warnbox small">Your Drive script is the older version: files are saved directly in your folder. Paste the new script (below) and deploy a new version to get Department / Semester sub-folders.</div>' : ''}</div>
  ${studentAppCard()}
  ${webCard()}
  <div class="card"><div class="h3">Connection</div>
    <label class="fl">Apps Script web app URL<input data-cfg="url" value="${esc(c.url)}" placeholder="https://script.google.com/macros/s/…/exec"></label>
    <label class="fl">Secret key (same as in the script)<input data-cfg="key" value="${esc(c.key)}" placeholder="your secret"></label>
    <div class="row wrap" style="margin:-4px 0 8px"><button class="btn small" data-act="gen-key">Make a strong key</button><span class="muted small">at least 16 letters and numbers</span></div>
    <label class="fl">Drive folder link (empty = My Drive)<input data-cfg="folder" value="${esc(c.folder)}" placeholder="https://drive.google.com/drive/folders/…"></label>
    <label class="cb"><input type="checkbox" data-cfg="auto" ${c.auto ? 'checked' : ''}> Sync automatically (when online)</label>
    <div class="row wrap"><button class="btn primary" data-act="sync-test">Save and test connection</button></div>
    ${c.folderName ? `<div class="muted small">Connected folder: <b>${esc(c.folderName)}</b>${c.scriptVersion ? ` · script v${c.scriptVersion}` : ''}</div>` : ''}
    <div class="muted small">Each course is one Excel file, saved in “Department / Programme Batch semester (Session)” inside your folder. Changes upload about 12 seconds after you stop editing, when you leave the app and every few minutes; edits made in Excel are loaded back.</div></div>
  <div class="card"><div class="h3">One-time set-up (on a computer)</div>
    <ol class="steps"><li>Open <b>script.google.com</b> with the Google account whose Drive should hold the files and create a <b>New project</b> (or open your existing one).</li>
      <li>Replace the code with the script below (<button class="btn small" data-act="copy-script">Copy script</button>) and set <code>SECRET</code> to your own key (at least 16 letters and numbers — <b>Make a strong key</b> above).</li>
      <li><b>Deploy → New deployment → Web app</b> (or <b>Manage deployments → Edit → New version</b> if it already exists). Execute as: <b>Me</b>. Who has access: <b>Anyone</b>.</li>
      <li>Paste the <b>Web app URL</b> (ends with <code>/exec</code>), the secret and your Drive folder link above, then tap <b>Save and test connection</b>.</li></ol>
    <details><summary>Show the script</summary><textarea id="scripttext" readonly rows="12">${esc(SCRIPT)}</textarea></details></div>
  <div class="card"><div class="h3">Backups</div><div class="row wrap">
    <button class="btn" data-act="save-json">Back up all data (.json)</button>
    <label class="btn">Restore backup file<input type="file" accept=".json,application/json" data-filepick="json" hidden></label>
    <button class="btn" data-act="phone-backups">Restore earlier data…</button></div></div>
  ${sync.configured() ? `<div class="card"><button class="btn danger small" data-act="disconnect">Disconnect Drive</button></div>` : ''}`;
}

function studentStatus() {
  const p = portal.portalOf(state), pc = portal.pstate(), shared = state.courses.filter(x => portal.flagsOf(state, x.id).publish);
  let st = '';
  if (p.on) {
    const n = issuesOf(null).count;
    if (n) st += `<div class="warnbox small">${plural(n, 'student')} cannot sign in until the Reg. No is fixed (open the course → PINs and slips).</div>`;
    if (!sync.configured()) st += '<div class="warnbox small">Connect Google Drive below first — the student app reads your published results through your Drive script.</div>';
    else if (pc.lastError) st += `<div class="warnbox small">${esc(pc.lastError)}</div>`;
    else if (sync.cfg.scriptVersion && sync.cfg.scriptVersion < 4) st += '<div class="warnbox small">Update your Drive script to version 5: <b>Copy script</b> (below) → paste it in script.google.com → <b>Deploy → Manage deployments → Edit → New version → Deploy</b> (the web app URL stays the same).</div>';
    else st += `<div class="muted small">${portal.publishedCount()} of ${shared.length} course(s) shared with students${pc.lastPublish ? ` · last update ${esc(new Date(pc.lastPublish).toLocaleString())}` : ''}</div>`;
  }
  return st;
}
function webStatus() {
  const w = portal.webOf(state), pc = portal.pstate(), n = Object.keys(pc.fhashes || {}).length;
  return `${w.on ? `<div class="small" style="margin:8px 0"><span class="okt">✓ On</span> <span class="muted">· ${n} of ${state.courses.length} course(s) on the dashboard${pc.webPublish ? ` · last update ${esc(new Date(pc.webPublish).toLocaleString())}` : ''}</span></div>` : ''}
    ${pc.webError ? `<div class="warnbox small">${esc(pc.webError)}</div>` : ''}`;
}
function webCard() {
  const w = portal.webOf(state);
  return `<div class="card"><div class="h3">Website dashboard</div>
    <div class="muted small">See every course, section and student on the GradesEye website from any computer: sign in there with your class code and this dashboard password. It is read-only, and students cannot use it.</div>
    <div id="webstatus">${webStatus()}</div>
    <label class="fl">${w.on ? 'New dashboard password' : 'Dashboard password'}<input id="webpw1" type="password" autocomplete="new-password"></label>
    <label class="fl">Type it again<input id="webpw2" type="password" autocomplete="new-password"></label>
    <div class="row wrap"><button class="btn primary small" data-act="web-set">${w.on ? 'Change password' : 'Turn on website dashboard'}</button>${w.on ? '<button class="btn small" data-act="copy-code">Copy class code</button><button class="btn danger small" data-act="web-off">Turn off</button>' : ''}</div>
    <div class="muted small" style="margin-top:6px">At least 10 characters with letters and numbers, and not the same as your secret key. Courses appear on the dashboard after they sync with Drive.</div></div>`;
}
function studentAppCard() {
  const p = portal.portalOf(state);
  const on = v => { p.on = !!v; if (p.on) { portal.firstTurnOn(state); portal.ensurePins(state, portal.sharedCourses(state)); } persistNow(); if (sync.configured()) sync.schedule(1200); render(); };
  const share = c => v => { portal.setFlag(state, c.id, 'publish', v); if (v) portal.ensurePins(state, [c]); persistNow(); if (sync.configured()) sync.schedule(1200); render(); };
  return `<div class="card"><div class="h3">Student app (GradesEye Student)</div>
    <div class="muted small">Students install GradesEye Student and sign in with their Reg. No and a PIN from you (they can then set their own password). They see only their own attendance and marks of the courses you share; the course total and grade only after you release them (course page → Student app).</div>
    ${chk(p.on, on, 'Turn on the student app')}
    ${p.on ? `<div id="stustatus">${studentStatus()}</div>
      <div class="glabel">Courses students can see</div>${state.courses.map(x => chk(portal.flagsOf(state, x.id).publish, share(x), `<span class="cl">${esc(courseLabel(x))}<small class="muted">${esc(semesterLabel(semOf(state, x)))}</small></span>`)).join('') || '<div class="muted small">No courses yet.</div>'}
      <div class="row wrap" style="margin-top:8px"><button class="btn primary small" data-act="stu-apk" data-mode="share">Share student app…</button><button class="btn small" data-act="stu-apk" data-mode="save">Save student app (APK)</button><button class="btn small" data-act="copy-code">Copy class code</button></div>
      <div class="muted small" style="margin-top:6px">The student app you share is already linked to your Drive script (it contains its web address, never your secret key), so students only install it and sign in. PINs: open a course → Student app → <b>PINs and slips</b>.</div>` : ''}</div>`;
}

// ------------------------------------------------------------------ dialogs
function replaceAll(st, from) {
  store.save('state-before-' + from, JSON.stringify(state));
  if (state.portal) st.portal = state.portal;          // keep the student-app PINs that students already have
  state = normaliseState(st); cache.clear(); persistNow(); stack = [{ v: 'home' }]; render(true);
}
function applyPull(courseId, res) {
  const i = state.courses.findIndex(c => c.id === courseId);
  if (i < 0) return;
  store.save('state-before-drive', JSON.stringify(state));
  const c = state.courses[i], sem = semOf(state, c);
  const others = new Set();
  const norm = list => JSON.stringify(Object.keys(list).filter(k => list[k] && (list[k].reg || list[k].name || list[k].rem)).sort((a, b) => a - b).map(k => [k, list[k].reg || '', list[k].name || '', list[k].rem || '']));
  for (const [secId, list] of Object.entries(res.students)) {
    const s = secOf(sem, secId); if (!s) continue;
    if (norm(s.students) !== norm(list)) { s.students = list; coursesOfSection(secId).forEach(id => id !== courseId && others.add(id)); }
    if (res.sectionNames[secId] && res.sectionNames[secId] !== s.name) { s.name = res.sectionNames[secId]; coursesOfSection(secId).forEach(id => id !== courseId && others.add(id)); }
  }
  if (res.start && res.start !== sem.start) { sem.start = res.start; state.courses.filter(x => x.semId === sem.id && x.id !== courseId).forEach(x => others.add(x.id)); }
  for (const k of Object.keys(c)) delete c[k];
  Object.assign(c, res.course);                       // same object: open screens keep pointing at the live course
  cache.clear(); persistNow();
  if (others.size) sync.edited([...others]);
  render();
  toast(`Loaded ${courseLabel(c)} from Drive${res.warnings.length ? ` (${res.warnings.length} cells skipped)` : ''}`, 3500);
}
function showConflict(id, cf) {
  const c = courseById(state, id); if (!c || !cf) return;
  const n = Math.max(0, sync.fileOf(id).editVersion - sync.fileOf(id).syncedVersion);
  const when = cf.modified ? new Date(cf.modified).toLocaleString() : '';
  if (cf.layout) {
    modal(`<h3>${esc(courseLabel(c))}</h3><p>${esc(cf.message || 'The Excel file in Drive cannot be loaded.')}</p><p>Keep this phone's data and rewrite the Drive file, or decide later (for example after making the course settings match).</p>
      <div class="btns col"><button class="btn primary" data-x="phone">Keep this phone's data (replace the Drive file)</button><button class="btn" data-x="later">Decide later</button></div>`, { sticky: true });
    $('#modal').querySelectorAll('[data-x]').forEach(b => (b.onclick = async () => { closeModal(); if (b.dataset.x === 'later') return; const r = await sync.resolveConflict(id, 'phone'); toast(r.ok ? 'Done' : 'Could not finish: ' + (r.error || r.reason)); render(); }));
    return;
  }
  const txt = cf.during ? 'The Excel file in Drive changed and you edited on the phone while it was downloading, so nothing was replaced.'
    : cf.neverSynced ? `Your Drive folder already has <b>${esc(fileNameOf(c))}</b> (changed ${esc(when)}). Load it into the app, or replace it with the data on this phone?`
    : `The Excel file in Drive was changed somewhere else (${esc(when)}) and this phone also has ${n} change(s) not uploaded yet.`;
  modal(`<h3>${esc(courseLabel(c))}: choose a version</h3><p>${txt}</p><div class="btns col">
    <button class="btn primary" data-x="drive">Use the Drive file (replace phone data)</button><button class="btn" data-x="phone">Keep this phone's data (replace the Drive file)</button><button class="btn" data-x="later">Decide later</button></div>
    <p class="muted small">A copy of the phone data is kept before anything is replaced.</p>`, { sticky: true });
  $('#modal').querySelectorAll('[data-x]').forEach(b => (b.onclick = async () => { closeModal(); if (b.dataset.x === 'later') return; const r = await sync.resolveConflict(id, b.dataset.x); toast(r.ok ? 'Done' : 'Could not finish: ' + (r.error || r.reason)); render(); }));
}
function clearRow(c, secId, r, scope) {
  const Lo = layout(c, semOf(state, c));
  for (const p of entryPages(Lo)) {
    if (scope === 'sec' && !(p.sec || !c.labGroups[secId].custom)) continue;
    if (scope === 'lab' && p.sec) continue;
    const m = c.marks[markKey(secId, p.id)];
    if (m) for (const k of Object.keys(m)) if (k.startsWith(r + ',')) delete m[k];
  }
}
function studentMenu(kind, ctx, r) {
  let list, editable = true, label, onSave, onDelete, remGet, remSet;
  if (kind === 'sec') {
    const [semId, secId] = ctx.split('|'), sem = state.semesters.find(s => s.id === semId), s = secOf(sem, secId);
    list = s.students; label = `Section ${s.code}`;
    remGet = () => (list[r] && list[r].rem) || ''; remSet = v => { if (list[r] || v) list[r] = Object.assign({}, list[r], { rem: v }); };
    onDelete = () => { delete list[r]; for (const cid of coursesOfSection(secId)) clearRow(courseById(state, cid), secId, r, 'sec'); changed(coursesOfSection(secId)); };
    onSave = () => changed(coursesOfSection(secId));
  } else {
    const [cid, secId] = ctx.split('|'), c = courseById(state, cid), lg = c.labGroups[secId], s = secOf(semOf(state, c), secId);
    editable = lg.custom; list = lg.custom ? lg.rows : s.students; label = `Lab group ${s.code}`;
    remGet = () => lg.rem[r] || ''; remSet = v => { if (v) lg.rem[r] = v; else delete lg.rem[r]; };
    onDelete = () => { delete lg.rows[r]; delete lg.rem[r]; clearRow(c, secId, r, 'lab'); changed([cid]); };
    onSave = () => changed([cid]);
  }
  const x = list[r] || {};
  modal(`<h3>${esc(label)} · row ${r + 1}</h3>
    ${editable ? `<label class="fl">Reg. No<input id="m-reg" value="${esc(x.reg || '')}"></label><label class="fl">Name<input id="m-name" value="${esc(x.name || '')}"></label>` : `<p><b>${esc(x.name || '')}</b> ${esc(x.reg || '')}</p>`}
    <label class="fl">Remarks<input id="m-rem" value="${esc(remGet())}"></label>
    <div class="btns">${editable && (x.name || x.reg) ? '<button class="btn danger" data-x="del">Remove</button>' : ''}<button class="btn" data-x="cancel">Cancel</button><button class="btn primary" data-x="save">Save</button></div>`);
  $('#modal').querySelectorAll('[data-x]').forEach(b => (b.onclick = async () => {
    const a = b.dataset.x;
    if (a === 'cancel') return closeModal();
    if (a === 'save') {
      if (editable) { const nx = Object.assign({}, list[r], { reg: $('#m-reg').value.trim(), name: $('#m-name').value.replace(/\s+/g, ' ').trim() }); if (nx.reg || nx.name || nx.rem) list[r] = nx; else delete list[r]; }
      remSet($('#m-rem').value.trim());
      closeModal(); onSave(); render(); return;
    }
    closeModal();
    if (await confirmBox('Remove student?', `${esc(x.name || x.reg)} will be removed and the attendance and marks in this row will be cleared${kind === 'sec' ? ' in every course of this section' : ''}.`, 'Remove', true)) { onDelete(); render(); }
  }));
}
function pasteDialog(kind, ctx) {
  modal(`<h3>Paste a list</h3><p class="small muted">One student per line: <b>Reg. No, Name</b> (comma or tab between them; copied Excel columns work).</p>
    <textarea id="m-paste" rows="9" placeholder="24-CS-001, Ali Khan&#10;24-CS-002, Sara Ahmed"></textarea>
    <label class="cb"><input type="radio" name="pm" value="append" checked> Add to the empty rows</label><label class="cb"><input type="radio" name="pm" value="replace"> Replace the whole list (marks stay with their row numbers)</label>
    <div class="btns"><button class="btn" data-x="0">Cancel</button><button class="btn primary" data-x="1">Add students</button></div>`);
  $('#modal').querySelectorAll('[data-x]').forEach(b => (b.onclick = () => {
    if (b.dataset.x === '0') return closeModal();
    const mode = document.querySelector('input[name=pm]:checked').value;
    const recs = $('#m-paste').value.split(/\r?\n/).map(l => l.trim()).filter(Boolean).map(l => {
      let p = l.split(/\t|,|;|\s{2,}/).map(x => x.trim()).filter(Boolean);
      if (p.length === 1) { const m = /^(\S*\d\S*)\s+(.+)$/.exec(p[0]); p = m ? [m[1], m[2]] : ['', p[0]]; }
      if (p.length > 2 && /^\d+$/.test(p[0])) p = p.slice(1);
      let [a, bb] = p; if (bb && /\d/.test(bb) && !/\d/.test(a)) [a, bb] = [bb, a];
      return { reg: a || '', name: (bb || '').replace(/\s+/g, ' ') };
    }).filter(x => x.reg || x.name);
    let target, ids;
    if (kind === 'sec') { const [semId, secId] = ctx.split('|'); target = secOf(state.semesters.find(s => s.id === semId), secId).students; ids = coursesOfSection(secId); }
    else { const [cid, secId] = ctx.split('|'); target = courseById(state, cid).labGroups[secId].rows; ids = [cid]; }
    if (mode === 'replace') for (const k of Object.keys(target)) delete target[k];
    let r = 0, added = 0;
    for (const x of recs) { while (r < NROW && target[r] && (target[r].name || target[r].reg)) r++; if (r >= NROW) break; target[r] = Object.assign({}, target[r], x); added++; r++; }
    closeModal(); changed(ids); render();
    toast(`${added} student(s) added${added < recs.length ? ` — ${recs.length - added} did not fit (100 per list)` : ''}`);
  }));
}
function weekMenu(c, secId, page, col) {
  const rows = namedRows(c, secId, page);
  modal(`<h3>Week ${col + 1}</h3><p class="muted">${fmtDate(pageDates(semOf(state, c), c, Rc(c).Lo, secId, page)[col], true, true)} · ${rows.length} students</p>
    <div class="btns col"><button class="btn primary" data-x="allP">Mark everyone Present</button><button class="btn" data-x="blankP">Mark the blank ones Present</button><button class="btn danger" data-x="clear">Clear this week</button><button class="btn" data-x="cancel">Cancel</button></div>`);
  $('#modal').querySelectorAll('[data-x]').forEach(b => (b.onclick = () => {
    const x = b.dataset.x; closeModal(); if (x === 'cancel') return;
    for (const row of rows) { const cur = getMark(c, secId, page, row.r, col); if (x === 'allP' || (x === 'blankP' && !cur)) setMark(c, secId, page, row.r, col, 'P'); if (x === 'clear') setMark(c, secId, page, row.r, col, null); }
    changed([c.id]); render();
  }));
}

// ------------------------------------------------------------------ actions
async function doAction(el) {
  const a = el.dataset.act, d = el.dataset;
  const c = d.course ? courseById(state, d.course) : null;
  switch (a) {
    case 'new-sem': go({ v: 'semester', isNew: true, draft: newSemester({ dept: state.semesters[state.semesters.length - 1]?.dept || '', session: state.semesters[state.semesters.length - 1]?.session || '', start: state.semesters[state.semesters.length - 1]?.start }) }); break;
    case 'create-sem': {
      const s = top().draft;
      if (!s.program && !s.semester) return toast('Enter at least the programme or the semester');
      state.semesters.push(s); changed([]); replaceTop({ v: 'semester', sem: s.id }); toast('Semester created — now add its sections'); break;
    }
    case 'open-sem': go({ v: 'semester', sem: d.sem }); break;
    case 'add-sec': {
      const sem = state.semesters.find(s => s.id === d.sem), code = $('#newsec-code').value.trim(), name = $('#newsec-name').value.trim();
      if (!code) return toast('Enter a section code, e.g. A');
      if (/[\\/?*[\]:]/.test(code) || code.length > 10) return toast('Use up to 10 letters or numbers');
      if (sem.sections.some(x => x.code.toLowerCase() === code.toLowerCase())) return toast('That section already exists');
      sem.sections.push(newSection(code, name || `${sem.program ? sem.program + '-' : ''}${parseInt(sem.semester) || ''}${code}`)); changed([]); render(); break;
    }
    case 'del-sec': {
      const sem = state.semesters.find(s => s.id === d.sem), x = secOf(sem, d.sec), users = state.courses.filter(cc => cc.secIds.includes(x.id));
      if (!(await confirmBox(`Remove section ${x.code}?`, `Its class list will be deleted${users.length ? ` and it will be removed from ${users.map(cc => esc(cc.code)).join(', ')} (with its attendance and marks)` : ''}.`, 'Remove', true))) return;
      sem.sections = sem.sections.filter(y => y !== x);
      users.forEach(cc => { cc.secIds = cc.secIds.filter(id => id !== x.id); for (const k of Object.keys(cc.marks)) if (k.startsWith(x.id + '|')) delete cc.marks[k]; });
      changed(users.map(cc => cc.id)); render(); break;
    }
    case 'del-sem': {
      const sem = state.semesters.find(s => s.id === d.sem), cs = state.courses.filter(cc => cc.semId === sem.id);
      if (!(await confirmBox('Delete semester?', `${esc(semesterLabel(sem))}, its sections, class lists${cs.length ? ` and ${plural(cs.length, 'course')}` : ''} will be deleted from the phone. Excel files already in Drive are not deleted.`, 'Delete', true))) return;
      store.save('state-before-delete', JSON.stringify(state));
      state.semesters = state.semesters.filter(s => s !== sem); cs.forEach(cc => sync.forgetCourse(cc.id)); state.courses = state.courses.filter(cc => cc.semId !== sem.id);
      changed([]); stack = [{ v: 'home' }]; render(true); break;
    }
    case 'new-course': {
      const sem = state.semesters.find(s => s.id === d.sem);
      const draft = newCourse(sem, { type: 'TL', instructor: state.profile.instructor });
      go({ v: 'plan', isNew: true, draft, sem: sem.id }); break;
    }
    case 'edit-plan': go({ v: 'plan', draft: JSON.parse(JSON.stringify(c)), course: c.id }); break;
    case 'plan-cancel': back(); break;
    case 'plan-save': {
      const v = top(), dr = v.draft, sem = semOf(state, dr);
      if (!dr.code && !dr.title) return toast('Enter the course code or title');
      if (!dr.secIds.length) return toast('Choose at least one section');
      const where = x => folderPathOf(semOf(state, x)).join('/') + '/' + fileNameOf(x);
      const clash = state.courses.find(x => x.id !== dr.id && where(x) === where(dr));
      if (clash) return toast('Another course has the same code and title in a semester with the same name — change one of them');
      ensureCourse(dr, sem, state.profile.instructor);
      if (v.isNew) { state.courses.push(dr); changed([dr.id]); replaceTop({ v: 'course', course: dr.id }); toast('Register created — its Excel file is made automatically'); }
      else {
        const old = courseById(state, dr.id);
        if (!old) return toast('This course was deleted');
        const removed = old.secIds.filter(id => !dr.secIds.includes(id));
        if (removed.length && !(await confirmBox('Remove sections from this course?', `The attendance and marks of section(s) ${removed.map(id => esc(secOf(sem, id).code)).join(', ')} in this course will be deleted.`, 'Remove', true))) return;
        const live = courseById(state, dr.id);           // re-read: a sync may have loaded newer marks meanwhile
        if (!live) return toast('This course was deleted');
        for (const k of ['type', 'code', 'title', 'credit', 'secIds', 'sec', 'plan']) live[k] = dr[k];
        for (const id of removed) for (const k of Object.keys(live.marks)) if (k.startsWith(id + '|')) delete live.marks[k];
        ensureCourse(live, sem, state.profile.instructor);
        changed([live.id]); stack.pop(); render(true); toast('Saved');
      }
      break;
    }
    case 'del-course': {
      if (!(await confirmBox('Delete course?', `${esc(courseLabel(c))} and its attendance and marks will be deleted from the phone. Its Excel file in Drive is not deleted. Class lists stay with the sections.`, 'Delete', true))) return;
      store.save('state-before-delete', JSON.stringify(state));
      state.courses = state.courses.filter(x => x !== c); sync.forgetCourse(c.id); changed([]); stack = [{ v: 'home' }]; render(true); break;
    }
    case 'csec': ui.sec[d.course] = d.sec; saveUi(); render(); break;
    case 'expf': ui.exp[d.k] = d.f === 'all' || d.f === 'sum' ? d.f : Number(d.f); saveUi(); closeEditor(); render(); break;
    case 'finalv': ui.finalView = d.f; saveUi(); render(); break;
    case 'week': { const v = top(); weekMenu(courseById(state, v.course), v.sec, v.page, Number(d.c)); break; }
    case 'ed-set': setValue(d.v); if (d.v !== '') advance(); else renderEditor(); break;
    case 'ed-quick': { const v = d.v === '' ? null : Number(d.v); setValue(v === null ? '' : v); if (v !== null) advance(); else renderEditor(); break; }
    case 'ed-half': ui.half = !ui.half; renderEditor(); break;
    case 'ed-up': if (commitInput(true)) move(-1, 0); break;
    case 'ed-down': if (commitInput(true)) move(1, 0); break;
    case 'ed-left': if (commitInput(true)) move(0, -1); break;
    case 'ed-right': if (commitInput(true)) move(0, 1); break;
    case 'ed-close': if (commitInput(true)) closeEditor(); break;
    case 'stu-more': studentMenu(d.kind, d.ctx, Number(d.r)); break;
    case 'paste': pasteDialog(d.kind, d.ctx); break;
    case 'lg-mode': {
      const lg = c.labGroups[d.sec], s = secOf(semOf(state, c), d.sec);
      if (d.m === 'custom' && !lg.custom) { lg.custom = true; lg.rows = {}; for (const [r, x] of Object.entries(s.students)) if (x && (x.reg || x.name)) lg.rows[r] = { reg: x.reg || '', name: x.name || '' }; toast('Copied the section list — edit it as needed'); }
      else if (d.m === 'same' && lg.custom) { if (!(await confirmBox('Follow the section list?', 'This lab group will use the section class list again. Lab marks stay with their row numbers.', 'Use section list'))) return; lg.custom = false; }
      changed([c.id]); render(); break;
    }
    case 'lg-copy': {
      if (!(await confirmBox('Copy the section list?', 'Replace this lab group with the section class list?', 'Copy'))) return;
      const lg = c.labGroups[d.sec], s = secOf(semOf(state, c), d.sec); lg.rows = {};
      for (const [r, x] of Object.entries(s.students)) if (x && (x.reg || x.name)) lg.rows[r] = { reg: x.reg || '', name: x.name || '' };
      changed([c.id]); render(); break;
    }
    case 'sched-reset': delete c.schedule.dates[d.k]; changed([c.id]); render(); break;
    case 'open-drive': { const f = sync.fileOf(d.course); if (f.webLink) openUrl(f.webLink); break; }
    case 'save-xlsx': {
      toast('Preparing the Excel file…');
      const b64 = bytesToBase64(await buildBytes(state, c));
      const ok = await saveFile(fileNameOf(c), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', b64);
      toast(ok ? 'Excel file saved' : 'Not saved'); break;
    }
    case 'sync-now': { const r = await sync.syncAll({ manual: true, check: true }); toast(r.ok ? 'All files are up to date' : r.reason === 'offline' ? 'You are offline — will sync when back online' : (r.results || []).some(x => x.reason === 'conflict') ? 'Choose which version to keep' : 'Some files could not sync'); render(); break; }
    case 'sync-test': {
      const before = [sync.cfg.url, sync.cfg.folder].join('|');
      document.querySelectorAll('[data-cfg]').forEach(i => { sync.cfg[i.dataset.cfg] = i.type === 'checkbox' ? i.checked : i.value.trim(); });
      if (sync.cfg.folder && !sync.folderIdOf(sync.cfg.folder)) return toast('That folder link is not recognised — paste the link of a Drive folder');
      const urlChanged = before.split('|')[0] && before.split('|')[0] !== sync.cfg.url;
      if (before !== [sync.cfg.url, sync.cfg.folder].join('|')) sync.resetFiles();
      sync.saveCfg();
      if (!sync.configured()) return toast('Enter the web app URL and the secret key');
      toast('Testing…');
      try {
        const j = await sync.testConnection();
        toast(`Connected to ${j.user || 'Google Drive'} · folder “${j.folder ? j.folder.name : 'My Drive'}”`, 4000);
        for (const x of state.courses) { const f = sync.fileOf(x.id); if (!f.lastMd5 && hasCourseData(x)) f.editVersion = Math.max(f.editVersion, f.syncedVersion + 1); }
        sync.saveCfg(); render();
        const r = await sync.syncAll({ manual: true, check: true });
        if (r.ok && state.courses.length) toast('Excel files are in your Drive folder', 4000);
        if (urlChanged && portal.portalOf(state).used) modal(`<h3>Web app address changed</h3><p>Student apps you shared earlier still use the old address. Share the student app again (Student app → <b>Share student app…</b>) so students reach the new one.</p><div class="btns"><button class="btn primary" data-x="ok">OK</button></div>`), $('#modal').querySelector('[data-x]').onclick = closeModal;
      } catch (e) { toast(e.message, 6000); }
      render(); break;
    }
    case 'conflict': showConflict(d.course, sync.conflictOf(d.course)); break;
    case 'gen-key': {
      const k = portal.strongKey(), i = document.querySelector('[data-cfg=key]');
      if (i) i.value = k;
      await copyText(k);
      modal(`<h3>New secret key</h3><p class="mono">${esc(k)}</p><p class="small">It is copied. Put it in the script line <code>const SECRET = '…';</code>, save, then <b>Deploy → Manage deployments → Edit → New version → Deploy</b>. Then tap <b>Save and test connection</b> here.</p><div class="btns"><button class="btn" data-x="copy">Copy again</button><button class="btn primary" data-x="ok">OK</button></div>`);
      $('#modal').querySelectorAll('[data-x]').forEach(b => (b.onclick = async () => { if (b.dataset.x === 'copy') { await copyText(k); toast('Copied'); } else closeModal(); }));
      break;
    }
    case 'logins-refresh': loginsErr = ''; await loadLogins(); render(); break;
    case 'logins-filter': ui.loginFilter = d.f; saveUi(); render(); break;
    case 'web-set': {
      const a = ($('#webpw1') || {}).value || '', b = ($('#webpw2') || {}).value || '';
      if (!sync.configured()) return toast('Connect Google Drive first');
      if (a.length < 10 || !/[A-Za-z]/.test(a) || !/[0-9]/.test(a)) return toast('Use at least 10 characters with letters and numbers', 4000);
      if (a !== b) return toast('The two passwords are not the same');
      if (a === sync.cfg.key) return toast('Use a password that is different from your secret key', 4000);
      if (!isOnline()) return toast('You need the internet to set the dashboard password');
      toast('Saving…');
      try {
        await portal.setWebPassword(state, a); persistNow(); sync.schedule(1200); render();
        toast('Website dashboard is on — sign in on the website with your class code and this password', 5000);
      } catch (e) { toast(/Unknown action/i.test(e.message) ? 'Update your Drive script to version 5 first (Copy script below)' : e.message, 6000); }
      break;
    }
    case 'web-off': {
      if (!(await confirmBox('Turn off the website dashboard?', 'Your courses are removed from the dashboard and the password stops working. The apps and Excel files are not affected.', 'Turn off', true))) return;
      try { await portal.setWebPassword(state, ''); persistNow(); sync.schedule(1200); render(); toast('Website dashboard turned off'); }
      catch (e) { toast(e.message, 5000); }
      break;
    }
    case 'pin-new': {
      if (!(await confirmBox('New PIN?', `${esc(d.name)} gets a new PIN. The old PIN stops working after the next sync.`, 'New PIN'))) return;
      portal.newPin(state, d.key); persistNow(); if (sync.configured()) sync.schedule(1500); render(); toast('New PIN made'); break;
    }
    case 'pin-xlsx': {
      const b64 = bytesToBase64(await portal.pinWorkbook(state, c));
      const ok = await saveFile(`${(c.code || c.title || 'Course').replace(/[\\/:*?"<>|]+/g, ' ')} student PINs.xlsx`, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', b64);
      toast(ok ? 'PIN slips saved' : 'Not saved'); break;
    }
    case 'stu-apk': {
      if (!sync.configured()) return toast('Connect Google Drive first');
      if (!portal.validScriptUrl(sync.cfg.url)) return toast('The web app URL must look like https://script.google.com/macros/s/…/exec (copy it from Deploy → Manage deployments)', 6000);
      if ((sync.cfg.scriptVersion || 0) < 4) return toast('Update your Drive script to version 5 first (see below), then tap Save and test connection', 5000);
      toast('Preparing the student app…');
      const r = await studentApk(d.mode, JSON.stringify(portal.connectionOf(state)), 'GradesEye_Student.apk');
      if (r === 'unsupported') return toast('This works in the Android app. Use "Copy class code" here.', 4000);
      toast(r ? (d.mode === 'save' ? 'Student app saved — send it to your students' : 'Choose WhatsApp, Bluetooth or Drive to send it') : 'Not saved', 4000); break;
    }
    case 'copy-code': {
      if (!sync.configured()) return toast('Connect Google Drive first');
      if (!portal.validScriptUrl(sync.cfg.url)) return toast('The web app URL must look like https://script.google.com/macros/s/…/exec (copy it from Deploy → Manage deployments)', 6000);
      if ((sync.cfg.scriptVersion || 0) < 4) return toast('Update your Drive script to version 5 first (see below), then tap Save and test connection', 5000);
      const code = portal.classCode(state);
      await copyText(code);
      modal(`<h3>Class code</h3><p class="small">Copied. Students who installed a copy of GradesEye Student that is not linked can paste this code. The student app you share from here does not need it.</p><textarea readonly rows="4" class="mono">${esc(code)}</textarea><div class="btns"><button class="btn primary" data-x="ok">OK</button></div>`);
      $('#modal').querySelector('[data-x]').onclick = closeModal;
      break;
    }
    case 'disconnect': if (await confirmBox('Disconnect Drive?', 'The app stops syncing. Your data stays on the phone and the Excel files stay in Drive.', 'Disconnect')) { sync.disconnect(); render(); } break;
    case 'copy-script': {
      try { await navigator.clipboard.writeText(SCRIPT); toast('Script copied'); }
      catch (e) { const ta = $('#scripttext'); if (ta) { ta.closest('details').open = true; ta.select(); document.execCommand('copy'); toast('Script copied'); } }
      break;
    }
    case 'save-json': {
      const b64 = bytesToBase64(new TextEncoder().encode(JSON.stringify(state)));
      const ok = await saveFile(`GradesEye_backup_${new Date().toISOString().slice(0, 10)}.json`, 'application/json', b64);
      toast(ok ? 'Backup saved' : 'Not saved'); break;
    }
    case 'phone-backups': {
      const kept = [['state-before-drive', 'Before the last load from Drive'], ['state-before-import', 'Before the last restore'], ['state-before-delete', 'Before the last delete']].filter(([k]) => store.load(k));
      const list = store.backups();
      const fmtB = n => { const m = /state2?-(\d{4})(\d{2})(\d{2})-(\d{2})(\d{2})/.exec(n); return m ? `${m[3]}-${m[2]}-${m[1]} ${m[4]}:${m[5]}` : n; };
      modal(`<h3>Restore earlier data</h3>${kept.length ? `<p class="muted small">Copies kept before data was replaced:</p><div class="btns col">${kept.map(([k, l]) => `<button class="btn" data-k="${k}">${esc(l)}</button>`).join('')}</div>` : ''}
        <p class="muted small">Automatic backups on this phone:</p><div class="btns col">${list.length ? list.map(n => `<button class="btn" data-b="${esc(n)}">${esc(fmtB(n))}</button>`).join('') : '<p class="small">None yet.</p>'}<button class="btn" data-c="1">Close</button></div>`);
      $('#modal').querySelectorAll('[data-k],[data-b],[data-c]').forEach(b => (b.onclick = async () => {
        closeModal(); if (b.dataset.c) return;
        const t = safe(b.dataset.k ? store.load(b.dataset.k) : store.readBackup(b.dataset.b));
        if (!t) return toast('That copy could not be read');
        const st = t.version === 2 ? t : migrateV1(t, WDD_ACTIVITIES);
        if (await confirmBox('Restore this data?', 'The current data will be replaced (a copy is kept).', 'Restore', true)) { replaceAll(st, 'import'); changed(state.courses.map(x => x.id)); }
      }));
      break;
    }
  }
}

// ------------------------------------------------------------------ start
export function start() {
  document.addEventListener('click', e => {
    const t = e.target;
    const g = t.closest('[data-go]'); if (g) { e.preventDefault(); go({ v: g.dataset.go }); return; }
    const oc = t.closest('[data-open-course]'); if (oc) { go({ v: 'course', course: oc.dataset.openCourse }); return; }
    const os = t.closest('[data-open-sem]'); if (os) { go({ v: 'semester', sem: os.dataset.openSem }); return; }
    const cl = t.closest('[data-classlist]'); if (cl) { const [sem, sec] = cl.dataset.classlist.split('|'); go({ v: 'classlist', sem, sec }); return; }
    const nv = t.closest('[data-nav]'); if (nv) { const [v, course, sec, page] = nv.dataset.nav.split('|'); go({ v, course, sec, page }); return; }
    const st = t.closest('[data-step]'); if (st) { const f = FIELDS[Number(st.dataset.step)]; if (f) f.setter(); return; }
    const td = t.closest('#main td.e'); if (td) { const v = top(); if (sel) commitInput(false); openEditor(courseById(state, v.course), v.sec, v.page, Number(td.dataset.r), Number(td.dataset.c)); return; }
    const el = t.closest('[data-act]');
    if (el && el.tagName !== 'INPUT') doAction(el);
  });
  document.addEventListener('change', async e => {
    const el = e.target;
    if (el.dataset.fid !== undefined) {
      const f = FIELDS[Number(el.dataset.fid)]; if (!f) return;
      let v = el.type === 'checkbox' ? el.checked : el.value;
      if (f.type === 'pct') { v = String(v).trim() === '' ? 0 : Number(String(v).replace(',', '.')) / 100; if (!isFinite(v)) return toast('Enter a number'); }
      else if (f.type === 'num' || f.type === 'int') { v = String(v).trim() === '' ? 0 : Number(String(v).replace(',', '.')); if (!isFinite(v)) return toast('Enter a number'); if (f.type === 'int') v = Math.round(v); }
      else if (f.type === 'date') { if (!v) return; }
      else if (f.type !== 'check') v = String(v).replace(/\s+/g, ' ').trim();
      f.setter(v, el);
      const view = top().v;
      if (view === 'plan' && ['check', 'pct', 'num', 'int'].includes(f.type)) render();
      else if ((view === 'classlist' || view === 'labgroups') && el.dataset.rerender) { const focus = document.activeElement && document.activeElement.dataset ? document.activeElement.dataset.fid : null; render(); void focus; }
      else if (view === 'semester' || view === 'home') onSyncStatus();
      return;
    }
    if (el.dataset.cfg && el.type === 'checkbox') { sync.cfg.auto = el.checked; sync.saveCfg(); return; }
    if (el.dataset.filepick === 'json') {
      const f = el.files && el.files[0]; if (!f) return;
      try {
        const t = JSON.parse(new TextDecoder().decode(await f.arrayBuffer()));
        const st = t.version === 2 ? t : migrateV1(t, WDD_ACTIVITIES);
        if (await confirmBox('Restore this backup?', `Load “${esc(f.name)}”? The current data will be replaced (a copy is kept).`, 'Restore', true)) { replaceAll(st, 'import'); changed(state.courses.map(x => x.id)); }
      } catch (err) { toast('Could not read the file: ' + err.message, 5000); }
      el.value = '';
    }
  });
  $('#backbtn').onclick = () => back();
  $('#syncbtn').onclick = () => { if (top().v !== 'sync') go({ v: 'sync' }); };
  const isEditing = () => !$('#modal').hidden || !!sel || top().v === 'plan' || (document.activeElement && document.activeElement.tagName === 'INPUT' && !!document.activeElement.closest('#main'));
  sync.init({ getState: () => state, hasCourseData, applyPull, isEditing, onStatus: onSyncStatus, onConflict: (id, cf) => { if ($('#modal').hidden) showConflict(id, cf); },
    afterSync: () => portal.publish({ getState: () => state, saveState: persistNow, onStatus: () => { onSyncStatus(); refreshPortalNotes(); } }) });
  render(true);
}
