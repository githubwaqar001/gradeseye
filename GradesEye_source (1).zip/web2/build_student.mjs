// Bundle the student app (web-student/src) into one self-contained dist-student/index.html for the WDD Student APK.
import * as esbuild from 'esbuild';
import fs from 'fs';

const r = await esbuild.build({ entryPoints: ['../web-student/src/main.js'], bundle: true, write: false, format: 'iife', target: ['chrome64'], minify: true, legalComments: 'none' });
const js = r.outputFiles[0].text.replace(/<\/script/gi, '<\\/script');
const html = fs.readFileSync('../web-student/src/index.html', 'utf8').replace('<script>/*APP*/</script>', () => `<script>${js}</script>`);
fs.mkdirSync('../dist-student', { recursive: true });
fs.writeFileSync('../dist-student/index.html', html);
console.log('dist-student/index.html', (html.length / 1024).toFixed(0), 'KB');
