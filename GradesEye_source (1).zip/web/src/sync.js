// Google Drive sync through the user's Apps Script web app. Edits are saved on the phone first;
// the Excel file in Drive is rewritten when online (debounced), and edits made to it elsewhere are loaded back.
// Changes are recognised by the file's MD5 checksum as reported by Drive (never by the phone clock).
import { store, http, isOnline } from './platform.js';
import { buildXlsx, readXlsx } from './xlsx.js';
import { md5hex, bytesToBase64 } from './md5.js';

export const DEFAULT_NAME = 'CS309_WDD_Attendance_and_Marks_Fall2026.xlsx';
const DEBOUNCE = 12000, POLL = 5 * 60000;

export const cfg = Object.assign({
  url: '', key: '', folder: '', name: DEFAULT_NAME, auto: true,
  fileId: '', webLink: '', lastMd5: '', pendingUpload: null, driveModified: 0, lastSync: 0, lastError: '', lastCheck: 0,
  editVersion: 0, syncedVersion: 0, folderName: '',
}, safeJSON(store.load('sync')));

let hooks = null, timer = null, busy = false, queued = null, status = 'local', conflict = null;
export const getStatus = () => ({ status, conflict, pendingEdits: Math.max(0, cfg.editVersion - cfg.syncedVersion), busy });

function safeJSON(t) { try { return t ? JSON.parse(t) : {}; } catch (e) { return {}; } }
export function saveCfg() { store.save('sync', JSON.stringify(cfg)); }
export const configured = () => !!(cfg.url && cfg.key);
export const dirty = () => cfg.editVersion > cfg.syncedVersion;

export function folderId(link) {
  const s = String(link || '').trim();
  if (!s) return '';
  const m = /\/folders\/([\w-]+)/.exec(s) || /[?&]id=([\w-]+)/.exec(s);
  if (m) return m[1];
  return /^[\w-]{10,}$/.test(s) ? s : '';
}

function setStatus(s) { status = s; if (s !== 'conflict') conflict = null; hooks && hooks.onStatus(getStatus()); }
export function refresh() { setStatus(!configured() ? 'local' : dirty() ? (isOnline() ? 'pending' : 'offline') : 'synced'); }

export function init(h) {
  hooks = h;
  refresh();
  window.__nativeOnline = on => { if (on) schedule(1500); else if (configured() && status !== 'conflict') setStatus('offline'); };
  window.addEventListener('online', () => schedule(1500));
  window.addEventListener('offline', () => configured() && status !== 'conflict' && setStatus('offline'));
  setInterval(() => { if (configured() && cfg.auto && isOnline() && !busy && status !== 'conflict') syncNow(); }, POLL);
  if (configured() && cfg.auto) schedule(2500);
}

export function edited() {
  cfg.editVersion++;
  saveCfg();
  if (!configured()) return setStatus('local');
  if (status === 'conflict') return hooks.onStatus(getStatus());
  setStatus(isOnline() ? 'pending' : 'offline');
  if (cfg.auto) schedule(DEBOUNCE);
}

// automatic (timer) syncs never run while a conflict is waiting for the user's choice
export function schedule(ms) {
  clearTimeout(timer);
  if (!configured() || status === 'conflict') return;
  timer = setTimeout(() => syncNow(), ms);
}

class SyncError extends Error { constructor(kind, msg) { super(msg); this.kind = kind; } }

export async function api(action, extra = {}) {
  const body = JSON.stringify(Object.assign({ action, key: cfg.key.trim(), folderId: folderId(cfg.folder), name: (cfg.name || DEFAULT_NAME).trim(), fileId: cfg.fileId }, extra));
  const r = await http(cfg.url.trim(), body);
  if (!r.status) throw new SyncError('network', 'No connection to Google (' + (r.text || 'network error') + ')');
  let j;
  try { j = JSON.parse(r.text); } catch (e) {
    throw new SyncError('setup', `The Drive script did not answer correctly (HTTP ${r.status}). Check the web app URL (it ends with /exec) and that it was deployed with access "Anyone".`);
  }
  if (!j.ok && !j.conflict) throw new SyncError('server', j.error || 'The Drive script reported an error.');
  return j;
}

export async function testConnection() {
  const j = await api('ping');
  cfg.folderName = j.folder ? j.folder.name : '';
  saveCfg();
  return j;
}

function raiseConflict(c) {
  conflict = c;
  setStatus('conflict');
  conflict = c;
  hooks.onConflict(c);
  return { ok: false, reason: 'conflict' };
}

// opts.force: 'phone' = overwrite Drive with phone data, 'drive' = replace phone data with the Drive file
// opts.manual: started by the user (runs even while a conflict is waiting)
export async function syncNow(opts = {}) {
  const force = opts.force || null;
  if (!configured()) { setStatus('local'); return { ok: false, reason: 'not-configured' }; }
  if (status === 'conflict' && !force && !opts.manual) return { ok: false, reason: 'conflict' };
  if (!isOnline()) { if (status !== 'conflict') setStatus('offline'); return { ok: false, reason: 'offline' }; }
  if (busy) { if (force || opts.manual || !queued) queued = opts; return { ok: false, reason: 'busy' }; }
  busy = true; clearTimeout(timer);
  setStatus('syncing');
  try {
    const info = await api('info');
    cfg.lastCheck = Date.now();
    const md5 = info.exists ? info.md5 || '' : '';
    if (info.exists) { cfg.fileId = info.fileId; cfg.webLink = info.url || cfg.webLink; cfg.driveModified = info.modified || cfg.driveModified; }
    // an earlier upload whose reply was lost (app closed, network dropped) — recognise it by its checksum
    if (cfg.pendingUpload && md5 && md5 === cfg.pendingUpload.md5) {
      cfg.lastMd5 = md5; cfg.syncedVersion = Math.max(cfg.syncedVersion, cfg.pendingUpload.ver); cfg.pendingUpload = null; saveCfg();
    }
    if (force === 'drive') {
      if (!info.exists) throw new SyncError('server', 'There is no Excel file in the Drive folder yet.');
      if (!(await pull())) return raiseConflict({ neverSynced: false, modified: info.modified, during: true });
      return finish('loaded');
    }
    const changedElsewhere = info.exists && md5 !== cfg.lastMd5;
    if (changedElsewhere && force !== 'phone') {
      const neverSynced = !cfg.lastMd5;
      if (!dirty() && !(neverSynced && hooks.hasData())) {
        if (!(await pull())) return raiseConflict({ neverSynced: false, modified: info.modified, during: true });
        return finish('loaded');
      }
      return raiseConflict({ neverSynced, modified: info.modified });
    }
    if (dirty() || !info.exists || force === 'phone') {
      const ver = cfg.editVersion;
      const bytes = await buildXlsx(hooks.getState(), 'uint8array');
      const sum = md5hex(bytes);
      cfg.pendingUpload = { md5: sum, ver }; saveCfg();
      const res = await api('save', { data: bytesToBase64(bytes), baseMd5: info.exists ? md5 : '', force: force === 'phone' });
      if (res.conflict) { cfg.pendingUpload = null; saveCfg(); return raiseConflict({ neverSynced: !cfg.lastMd5, modified: res.modified }); }
      cfg.fileId = res.fileId; cfg.driveModified = res.modified || 0; cfg.webLink = res.url || cfg.webLink;
      cfg.lastMd5 = res.md5 || sum; cfg.pendingUpload = null;
      cfg.syncedVersion = ver;
      return finish('saved');
    }
    return finish('checked');
  } catch (e) {
    cfg.lastError = e.message; saveCfg();
    setStatus(e.kind === 'network' ? 'offline' : 'error');
    return { ok: false, reason: e.kind || 'error', error: e.message };
  } finally {
    busy = false;
    if (queued) { const q = queued; queued = null; setTimeout(() => syncNow(q), 300); }
    else if (dirty() && cfg.auto && status === 'pending') schedule(DEBOUNCE);
    hooks.onStatus(getStatus());
  }
}

function finish(what) {
  cfg.lastSync = Date.now(); cfg.lastError = '';
  saveCfg();
  setStatus(dirty() ? 'pending' : 'synced');
  return { ok: true, what };
}

// returns false (and changes nothing) if the user edited the phone data while the file was downloading
async function pull() {
  const v = cfg.editVersion;
  const j = await api('load');
  const { state, warnings } = await readXlsx(j.data);
  if (cfg.editVersion !== v) return false;
  hooks.replaceState(state, warnings, 'drive');
  cfg.fileId = j.fileId; cfg.driveModified = j.modified || 0; cfg.webLink = j.url || cfg.webLink;
  cfg.lastMd5 = j.md5 || '';
  cfg.syncedVersion = cfg.editVersion; cfg.pendingUpload = null;
  saveCfg();
  return true;
}

export function resolveConflict(choice) {
  return syncNow({ force: choice, manual: true });
}

export function forget() {
  Object.assign(cfg, { fileId: '', webLink: '', lastMd5: '', pendingUpload: null, driveModified: 0, lastSync: 0, lastError: '', syncedVersion: 0, editVersion: 1 });
  saveCfg();
}
