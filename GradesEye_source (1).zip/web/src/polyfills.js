// small polyfills for older Android WebViews
if (!String.prototype.matchAll) {
  String.prototype.matchAll = function* (re) {
    const r = new RegExp(re.source, re.flags.includes('g') ? re.flags : re.flags + 'g'); let m;
    while ((m = r.exec(this)) !== null) { yield m; if (m[0] === '') r.lastIndex++; }
  };
}
if (!Object.fromEntries) Object.fromEntries = it => { const o = {}; for (const [k, v] of it) o[k] = v; return o; };
if (!Array.prototype.flatMap) Array.prototype.flatMap = function (f) { return [].concat(...this.map(f)); };
