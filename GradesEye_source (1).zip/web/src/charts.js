// Small SVG grouped bar chart (no library), sized by viewBox so it scales to the screen.
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

export function barChart({ title, cats, series, max = null, pct = true, height = 230, yTitle = '' }) {
  const W = 360, H = height, L = 34, Rm = 8, T = title ? 26 : 10, B = 46;
  const vals = series.flatMap(s => s.vals).filter(v => typeof v === 'number' && isFinite(v));
  const top = max != null ? max : Math.max(1, ...vals) * 1.15;
  const ph = H - T - B, pw = W - L - Rm;
  const y = v => T + ph - (Math.max(0, Math.min(v, top)) / top) * ph;
  const fmt = v => (pct ? Math.round(v * 100) + '%' : Math.round(v * 10) / 10);
  let svg = `<svg viewBox="0 0 ${W} ${H}" class="chart" role="img" aria-label="${esc(title || 'chart')}">`;
  if (title) svg += `<text x="${W / 2}" y="17" text-anchor="middle" class="ct">${esc(title)}</text>`;
  const ticks = 4;
  for (let i = 0; i <= ticks; i++) {
    const v = (top / ticks) * i, yy = y(v);
    svg += `<line x1="${L}" x2="${W - Rm}" y1="${yy}" y2="${yy}" class="grid"/><text x="${L - 4}" y="${yy + 3}" text-anchor="end" class="ax">${fmt(v)}</text>`;
  }
  if (yTitle) svg += `<text transform="translate(9 ${T + ph / 2}) rotate(-90)" text-anchor="middle" class="ax">${esc(yTitle)}</text>`;
  const gw = pw / Math.max(1, cats.length), n = series.length, bw = Math.min(26, (gw * 0.78) / n);
  cats.forEach((c, i) => {
    const gx = L + gw * i + (gw - bw * n) / 2;
    series.forEach((s, k) => {
      const v = s.vals[i];
      if (typeof v !== 'number' || !isFinite(v)) return;
      const x = gx + k * bw, yy = y(v), h = T + ph - yy;
      svg += `<rect x="${x + 1}" y="${yy}" width="${bw - 2}" height="${Math.max(0, h)}" rx="2" fill="${s.color}"/>`;
      if (n <= 4) svg += `<text x="${x + bw / 2}" y="${yy - 3}" text-anchor="middle" class="dl">${fmt(v)}</text>`;
    });
    svg += `<text x="${L + gw * i + gw / 2}" y="${T + ph + 14}" text-anchor="middle" class="cat">${esc(c)}</text>`;
  });
  // legend
  let lx = L, ly = H - 12;
  series.forEach(s => {
    svg += `<rect x="${lx}" y="${ly - 8}" width="10" height="10" rx="2" fill="${s.color}"/><text x="${lx + 14}" y="${ly + 1}" class="lg">${esc(s.name)}</text>`;
    lx += 22 + s.name.length * 5.6;
  });
  return svg + '</svg>';
}
