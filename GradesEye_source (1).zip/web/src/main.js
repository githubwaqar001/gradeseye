import './polyfills.js';
import { start } from './ui.js';

function boot() {
  try {
    start();
  } catch (e) {
    document.getElementById('main').innerHTML = `<div class="card"><b>Something went wrong while starting.</b><pre style="white-space:pre-wrap">${String(e && e.stack || e)}</pre></div>`;
  }
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
