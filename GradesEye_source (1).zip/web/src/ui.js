// WDD Register — user interface (all pages of the Excel register on the phone).
import {
  MAP, SECS, NROW, WEEKS, NEXP, TAB, TINT, DAYS, PAGES, PAGE, entryCols, defaultState, normalise, calc, stats,
  getMark, setMark, sheetKey, schedDate, autoDate, midDate, finDate, activity, pageDates, fmtDate, fmtNum, fmtPct, isNum,
  gradePoint, ENTRY_PAGES,
} from './core.js';
import { barChart } from './charts.js';
import { buildXlsx, readXlsx } from './xlsx.js';
import { store, saveFile, openUrl, appVersion, isOnline, native } from './platform.js';
import * as sync from './sync.js';
import SCRIPT from '../../apps-script/Code.gs';

// ------------------------------------------------------------------ state
let state = loadState();
let R = calc(state);
const ui = Object.assign({ sec: 'A', exp: {}, finalView: 'Summary', schedSec: 'A' }, safe(store.load('ui')));
let stack = [{ v: 'home' }];
let sel = null;                       // selected entry cell {s, page, r, c}
let saveTimer = null;

function safe(t) { try { return t ? JSON.parse(t) : {}; } catch (e) { return {}; } }
function loadState() {
  const t = store.load('state');
  if (t) { try { return normalise(JSON.parse(t)); } catch (e) { /* fall through */ } }
  return defaultState();
}
function persistNow() { clearTimeout(saveTimer); saveTimer = null; store.save('state', JSON.stringify(state)); }
function persist() { clearTimeout(saveTimer); saveTimer = setTimeout(persistNow, 400); }
function saveUi() { store.save('ui', JSON.stringify({ sec: ui.sec, exp: ui.exp, finalView: ui.finalView, schedSec: ui.schedSec })); }
function changed() { state.updated = Date.now(); R = calc(state); persist(); sync.edited(); }
const hasData = () => SECS.some(s => Object.values(state.students[s]).some(x => x && (x.name || x.reg))) || Object.values(state.marks).some(m => m && Object.keys(m).length);

// ------------------------------------------------------------------ helpers
const $ = q => document.querySelector(q);
const esc = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const secName = s => state.sections[s].name || `Section ${s}`;
const pct = v => fmtPct(v);
const num = v => fmtNum(v);
function barStyle(v, color, max = 1) {
  if (!isNum(v)) return '';
  const w = Math.max(0, Math.min(100, (v / (max || 1)) * 100));
  return `background:linear-gradient(90deg, ${color}55 0, ${color}55 ${w}%, transparent ${w}%)`;
}
function statusCls(v) {
  return v === 'Eligible' || v === 'Achieved' || v === 'Attained' ? 'ok' : v === 'Short' || v === 'Not achieved' || v === 'Not attained' || v === 'F' ? 'bad' : '';
}
function toast(msg, ms = 2600) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), ms);
}
function modal(html, opts = {}) {
  const m = $('#modal');
  m.innerHTML = `<div class="sheet ${opts.wide ? 'wide' : ''}">${html}</div>`;
  m.hidden = false;
  m.onclick = e => { if (e.target === m && !opts.sticky) closeModal(); };
  return m;
}
function closeModal() { const m = $('#modal'); m.hidden = true; m.innerHTML = ''; }
function confirmBox(title, text, okText, danger = false) {
  return new Promise(res => {
    modal(`<h3>${esc(title)}</h3><p>${text}</p><div class="btns"><button class="btn" data-x="0">Cancel</button><button class="btn ${danger ? 'danger' : 'primary'}" data-x="1">${esc(okText)}</button></div>`);
    $('#modal').querySelectorAll('[data-x]').forEach(b => b.onclick = () => { closeModal(); res(b.dataset.x === '1'); });
  });
}
function rosterOf(s, page) { return PAGE[page].sec ? R.sec[s].roster : R.lab[s].roster; }
function namedRows(s, page) { return rosterOf(s, page).map((x, r) => ({ r, ...x })).filter(x => x.name); }
const groupLabel = (s, sec) => `${sec ? 'Section' : 'Lab group'} ${s} (${secName(s)})`;

// ------------------------------------------------------------------ navigation
function go(view) { closeEditor(); stack.push(view); render(true); }
function back() {
  if (!$('#modal').hidden) { closeModal(); return true; }
  if (sel) { closeEditor(); return true; }
  if (stack.length > 1) {
    stack.pop(); render(true);
    if (stack.length === 1 && sync.dirty()) sync.schedule(1500);
    return true;
  }
  return false;
}
window.__back = () => (back() ? 'ok' : 'exit');
window.__resume = () => { if (sync.configured() && sync.cfg.auto) sync.schedule(1200); };
window.__pause = () => { persistNow(); if (sync.configured() && sync.dirty() && isOnline()) sync.syncNow(); };
const top = () => stack[stack.length - 1];

// ------------------------------------------------------------------ top bar and sync chip
function syncChip(st = sync.getStatus()) {
  const s = st.status, n = st.pendingEdits;
  const m = {
    local: ['☁', 'Set up Drive', 'muted'], synced: ['✓', 'Synced', 'ok'], pending: ['●', n ? `${n} to sync` : 'Waiting', 'warn'],
    offline: ['⚠', n ? `Offline · ${n} saved` : 'Offline', 'warn'], syncing: ['↻', 'Syncing…', 'busy'], error: ['!', 'Sync problem', 'bad'], conflict: ['?', 'Choose version', 'bad'],
  }[s] || ['', s, ''];
  return `<span class="chip ${m[2]}">${m[0]} ${m[1]}</span>`;
}
function onSyncStatus(st) {
  const b = $('#syncbtn'); if (b) b.innerHTML = syncChip(st);
  if (top().v === 'sync') renderSyncStatus();
  if (top().v === 'home') { const h = $('#homesync'); if (h) h.innerHTML = homeSync(); }
}

// ------------------------------------------------------------------ render
const VIEWS = { home: vHome, settings: vSettings, schedule: vSchedule, students: vStudents, labgroups: vLabGroups, sheet: vSheet, results: vResults, sync: vSync };
function render(resetScroll = false) {
  const v = top();
  const main = $('#main');
  const keep = resetScroll ? 0 : main.scrollTop;
  const tw = main.querySelector('.tw'), keepTw = tw && !resetScroll ? [tw.scrollLeft, tw.scrollTop] : null;
  const { title, sub, color } = titleOf(v);
  $('#title').innerHTML = `<b>${esc(title)}</b>${sub ? `<small>${esc(sub)}</small>` : ''}`;
  $('#top').style.background = color || '#1F3864';
  $('#backbtn').style.visibility = stack.length > 1 ? 'visible' : 'hidden';
  main.innerHTML = VIEWS[v.v](v);
  main.scrollTop = keep;
  const tw2 = main.querySelector('.tw');
  if (tw2) { sizeTable(); if (keepTw) { tw2.scrollLeft = keepTw[0]; tw2.scrollTop = keepTw[1]; } }
  if (sel) markSel(false);
}
function titleOf(v) {
  if (v.v === 'home') return { title: 'WDD Register', sub: 'CS-309 · BSCS 5th semester · Fall 2026' };
  if (v.v === 'sheet') return { title: `${v.s} · ${PAGE[v.page].title}`, sub: groupLabel(v.s, PAGE[v.page].sec), color: TAB[v.s] };
  return { title: { settings: 'Settings', schedule: 'Schedule (16 weeks)', students: 'Class Lists', labgroups: 'Lab Groups', results: 'Section-wise Results', sync: 'Google Drive sync' }[v.v] };
}
function sizeTable() {
  const tw = $('#main .tw'); if (!tw) return;
  const ed = $('#editor'), edh = ed.hidden ? 0 : ed.offsetHeight;
  const h = window.innerHeight - tw.getBoundingClientRect().top - edh - 6;
  tw.style.maxHeight = Math.max(220, h) + 'px';
}
window.addEventListener('resize', () => { sizeTable(); if (sel) markSel(true); });

// ------------------------------------------------------------------ HOME
function homeSync() {
  const st = sync.getStatus();
  if (!sync.configured()) return `<div class="note">Your data is saved on this phone. Connect Google Drive to keep the Excel file up to date automatically. <button class="btn small primary" data-go="sync">Connect Drive</button></div>`;
  const when = sync.cfg.lastSync ? new Date(sync.cfg.lastSync).toLocaleString() : 'not yet';
  return `<div class="note">${syncChip(st)} Excel file in Drive · last synced ${esc(when)} <button class="btn small" data-go="sync">Drive sync</button></div>`;
}
function vHome() {
  const s = ui.sec;
  const fin = R.sec[s].Final.filter(Boolean);
  const ct = stats(fin.map(o => o.ct)).avg;
  const short = fin.filter(o => o.tatts === 'Short' || o.latts === 'Short').length;
  const groups = {};
  PAGES.forEach(p => (groups[p.group] = groups[p.group] || []).push(p));
  const empty = !hasData();
  return `
  <div class="card hero">
    <div class="h1">CS-309 Web Design &amp; Development</div>
    <div class="muted">Attendance, Marks, CLO/PLO and Results Register — BSCS 5th Semester, Batch 2024 — Fall 2026</div>
    <div class="muted small">HITEC University, Taxila · Instructor: ${esc(state.sections.A.inst)}</div>
  </div>
  <div id="homesync">${homeSync()}</div>
  ${empty ? `<div class="card tip"><b>Getting started</b><ol><li>Add your students in <a data-go="students">Class Lists</a> (type them or paste a list).</li><li>Check dates and marks in <a data-go="settings">Settings</a>.</li><li><a data-go="sync">Connect Google Drive</a> so the Excel file is created in your folder.</li></ol></div>` : ''}
  <div class="h2">Course set-up and results</div>
  <div class="grid4">
    <button class="tile" style="background:#404040" data-go="settings">Settings<small>Weights, marks, grades, CLO/PLO</small></button>
    <button class="tile" style="background:#595959" data-go="schedule">Schedule<small>16-week dates</small></button>
    <button class="tile" style="background:#1F3864" data-go="students">Class Lists<small>Sections A–D</small></button>
    <button class="tile" style="background:#1F7A5A" data-go="labgroups">Lab Groups<small>Lab lists A–D</small></button>
  </div>
  <button class="tile wide" style="background:#C00000" data-go="results">Section-wise Results<small>Attendance, marks, CLO/PLO attainment and grades of A, B, C, D</small></button>
  <div class="h2">Section sheets</div>
  <div class="tabs">${SECS.map(x => `<button class="tab ${x === s ? 'on' : ''}" style="--c:${TAB[x]}" data-act="sec" data-s="${x}">Section ${x}<small>${esc(secName(x))}</small></button>`).join('')}</div>
  <div class="secsum" style="border-color:${TAB[s]}">
    <span><b>${fin.length}</b> students</span><span>Lab group: <b>${R.lab[s].roster.filter(x => x.name).length}</b></span>
    <span>Avg course total <b>${isNum(ct) ? pct(ct) : '—'}</b></span><span class="${short ? 'badtxt' : ''}"><b>${short}</b> short attendance</span>
  </div>
  ${Object.entries(groups).map(([g, ps]) => `<div class="glabel">${esc(g)}</div><div class="grid2">${ps.map(p =>
    `<button class="pbtn ${p.id === 'Final Sheet' ? 'strong' : ''}" style="--c:${TAB[s]};--t:${TINT[s]}" data-act="open" data-s="${s}" data-page="${esc(p.id)}">${esc(p.title)}</button>`).join('')}</div>`).join('')}
  <div class="foot muted small">Lab group = the section of the same letter unless you change Lab Groups. Lab results reach the Final Sheet by Reg. No. · App ${esc(appVersion())}</div>`;
}

// ------------------------------------------------------------------ SHEETS
function sheetHeader(s, page, extra = '') {
  const p = PAGE[page];
  const inst = p.sec ? `Instructor: ${state.sections[s].inst}` : `Lab instructor: ${state.sections[s].labInst}`;
  return `<div class="sheethead"><span>${esc(groupLabel(s, p.sec))} · ${esc(inst)}</span>${extra}</div>`;
}
function noStudents(s, page) {
  const p = PAGE[page];
  return `<div class="card tip">No students in ${p.sec ? `Section ${s}` : `lab group ${s}`} yet. <button class="btn small primary" data-go="${p.sec ? 'students' : 'labgroups'}">${p.sec ? 'Open Class Lists' : 'Open Lab Groups'}</button></div>`;
}
function vSheet(v) {
  const { s, page } = v, p = PAGE[page];
  const fn = { att: tAtt, items: tTheory, exam: tTheory, exp: tExp, single: tSingle, project: tProject, labtotal: tLabTotal, clo: tCLO, plo: tPLO, final: tFinal }[p.kind];
  return fn(s, page);
}

// generic table: cols [{key, g, gc, h, sub, max, w, entry:c, cell(row)->{t, cls, st}}]
function table(s, page, cols, rows, foot = []) {
  const groups = [];
  cols.forEach(c => { const last = groups[groups.length - 1]; if (last && last.g === c.g) last.n++; else groups.push({ g: c.g, gc: c.gc, n: 1 }); });
  const subs = [];
  cols.forEach(c => { const last = subs[subs.length - 1]; if (last && c.mergeSub && last.sub === c.sub && last.g === c.g && c.sub !== undefined) last.n++; else subs.push({ sub: c.sub, g: c.g, n: 1 }); });
  let h = `<div class="tw"><table class="t" style="--c:${TAB[s]}"><thead>`;
  h += `<tr class="r1"><th class="c0" rowspan="4">#</th><th class="c1" rowspan="4">Student</th>${groups.map(g => `<th colspan="${g.n}" class="grp" style="background:${g.gc || TAB[s]}">${esc(g.g)}</th>`).join('')}</tr>`;
  h += `<tr class="r2">${cols.map(c => `<th class="lab ${c.entry !== undefined ? 'ent' : 'calc'}" style="min-width:${c.w || 44}px" ${c.hact ? `data-act="${c.hact}" data-c="${c.entry}"` : ''}>${esc(c.h)}</th>`).join('')}</tr>`;
  h += `<tr class="r3">${subs.map(x => `<th colspan="${x.n}" class="sub">${esc(x.sub || '')}</th>`).join('')}</tr>`;
  h += `<tr class="r4">${cols.map(c => `<th class="mx">${esc(c.max ?? '')}</th>`).join('')}</tr></thead><tbody>`;
  for (const row of rows) {
    h += `<tr><td class="c0">${row.r + 1}</td><td class="c1"><div class="nm">${esc(row.name)}</div><div class="rg">${esc(row.reg)}</div></td>`;
    for (const c of cols) {
      if (c.entry !== undefined) {
        const v = getMark(state, s, page, row.r, c.entry);
        const cls = PAGE[page].kind === 'att' ? `att ${v || ''}` : '';
        h += `<td class="e ${cls}" data-r="${row.r}" data-c="${c.entry}">${esc(v ?? '')}</td>`;
      } else {
        const x = c.cell(row) || {};
        h += `<td class="f ${x.cls || ''}" ${x.st ? `style="${x.st}"` : ''}>${esc(x.t ?? '')}</td>`;
      }
    }
    h += '</tr>';
  }
  h += '</tbody>';
  if (foot.length && rows.length) {
    h += '<tfoot>';
    for (const f of foot) h += `<tr><td class="c0"></td><td class="c1"><b>${esc(f.label)}</b></td>${cols.map(c => `<td class="ft">${esc(f.cell(c) ?? '')}</td>`).join('')}</tr>`;
    h += '</tfoot>';
  }
  return h + '</table></div>';
}
const statFoot = (getter, isPct = c => false) => ['Class average', 'Highest', 'Lowest'].map((label, i) => ({
  label, cell: c => {
    if (c.noStat) return '';
    const st = stats(getter(c)), v = [st.avg, st.max, st.min][i];
    return isNum(v) ? (isPct(c) ? pct(v) : num(v)) : '';
  },
}));

// ---- attendance
function tAtt(s, page) {
  const p = PAGE[page], rows = namedRows(s, page);
  if (!rows.length) return sheetHeader(s, page) + noStudents(s, page);
  const A = (p.sec ? R.sec[s] : R.lab[s])[page], dates = pageDates(state, s, page);
  const cols = [];
  for (let w = 1; w <= WEEKS; w++) cols.push({
    g: `Wk ${w}`, gc: w % 2 ? '#2E5C9A' : '#1F3864', h: p.att === 'lec' ? 'Lec' : w <= 14 ? `Exp ${w}` : w === 15 ? 'OEL' : 'Final',
    sub: fmtDate(dates[w - 1]), max: A.held[w - 1] ? '✓' : '', entry: w - 1, w: 40, hact: 'week',
  });
  const r_ = row => A.rows[row.r] || {};
  cols.push({ g: 'Summary', gc: '#1F3864', h: 'P', cell: row => ({ t: r_(row).P }), w: 32, stat: true });
  cols.push({ g: 'Summary', gc: '#1F3864', h: 'L', cell: row => ({ t: r_(row).L }), w: 32 });
  cols.push({ g: 'Summary', gc: '#1F3864', h: 'A', cell: row => ({ t: r_(row).A }), w: 32 });
  cols.push({ g: 'Summary', gc: '#1F3864', h: `${p.att === 'lec' ? 'Theory' : 'Lab'} %`, max: `held: ${A.heldN}`, w: 70,
    cell: row => ({ t: pct(r_(row).pct), cls: 'num' + (isNum(r_(row).pct) && r_(row).pct < state.settings.THR ? ' badtxt' : ''), st: barStyle(r_(row).pct, p.att === 'lec' ? '#2E75B6' : '#70AD47') }) });
  cols.push({ g: 'Summary', gc: '#1F3864', h: 'Status', w: 66, cell: row => ({ t: r_(row).status, cls: 'pill ' + statusCls(r_(row).status) }) });
  const foot = [
    { label: 'Present', cell: c => (c.entry !== undefined ? A.perWeek[c.entry].present : '') },
    { label: 'Class %', cell: c => (c.entry !== undefined ? pct(A.perWeek[c.entry].pct).replace('.0%', '%') : c.h.endsWith('%') ? pct(stats(A.rows.map(x => x && x.pct)).avg) : c.h === 'Status' ? `${A.rows.filter(x => x && x.status === 'Short').length} short` : '') },
  ];
  return sheetHeader(s, page, `<span>Min. ${pct(state.settings.THR)} · Leave counts as present: ${esc(state.settings.LEAVE)} · tap a week heading to mark the whole class</span>`) + table(s, page, cols, rows, foot);
}

// ---- quizzes, assignments, exams
function tTheory(s, page) {
  const rows = namedRows(s, page);
  if (!rows.length) return sheetHeader(s, page) + noStudents(s, page);
  const T = R.sec[s][page], cols0 = entryCols(page), dates = pageDates(state, s, page), items = PAGE[page].kind === 'items';
  const cols = cols0.map((c, i) => ({ g: PAGE[page].title, gc: PAGE[page].color, h: c.label, sub: fmtDate(items ? dates[i] : dates[0], true), max: num(state.max[c.maxKey]), entry: i, w: items ? 70 : 42, mergeSub: !items }));
  const r_ = row => T.rows[row.r] || {};
  cols.push({ g: 'Total', gc: '#1F3864', h: items ? `${page === 'Quizzes' ? 'Quiz' : 'Assignment'} total` : 'Exam total', max: `/ ${num(T.T7)}`, w: 64, cell: row => ({ t: num(r_(row).T), cls: 'num b' }), key: 'T' });
  cols.push({ g: 'Total', gc: '#1F3864', h: 'Percentage', w: 80, cell: row => ({ t: pct(r_(row).pct), cls: 'num', st: barStyle(r_(row).pct, PAGE[page].color) }), key: 'pct' });
  const foot = statFoot(c => (c.entry !== undefined ? rows.map(x => getMark(state, s, page, x.r, c.entry)) : rows.map(x => r_(x)[c.key])), c => c.key === 'pct');
  const note = items ? 'Total counts only the items already held (any student has marks).' : 'The exam counts as held once any marks are entered; blank questions count as 0.';
  return sheetHeader(s, page, `<span>${note}</span>`) + table(s, page, cols, rows, foot);
}

// ---- lab performance / reports (14 experiments)
function tExp(s, page) {
  const rows = namedRows(s, page), p = PAGE[page];
  if (!rows.length) return sheetHeader(s, page) + noStudents(s, page);
  const E = R.lab[s][page], parts = MAP.rubric[p.rub].parts, np = parts.length, dates = pageDates(state, s, page);
  const key = `${s}|${page}`;
  if (ui.exp[key] === undefined) { const last = E.expHeld.lastIndexOf(true); ui.exp[key] = last >= 0 ? last + 1 : 1; }
  const f = ui.exp[key];
  const show = f === 'all' ? Array.from({ length: NEXP }, (_, i) => i + 1) : f === 'sum' ? [] : [f];
  const chips = `<div class="chips">${Array.from({ length: NEXP }, (_, i) => i + 1).map(n => `<button class="chipb ${f === n ? 'on' : ''} ${E.expHeld[n - 1] ? 'held' : ''}" data-act="expf" data-k="${key}" data-f="${n}">Exp ${n}</button>`).join('')}<button class="chipb ${f === 'sum' ? 'on' : ''}" data-act="expf" data-k="${key}" data-f="sum">Summary</button><button class="chipb ${f === 'all' ? 'on' : ''}" data-act="expf" data-k="${key}" data-f="all">All</button></div>`;
  const cols = [];
  const r_ = row => E.rows[row.r] || {};
  for (const n of show) {
    const gc = n % 2 ? '#2E5C9A' : '#1F3864';
    parts.forEach(([ab, lab], j) => cols.push({ g: `Exp. No. ${n}`, gc, h: ab, sub: fmtDate(dates[n - 1]), max: num(state.max[`${p.rub}|${ab}`]), entry: (n - 1) * np + j, w: 38, mergeSub: true }));
    cols.push({ g: `Exp. No. ${n}`, gc, h: 'Total', sub: fmtDate(dates[n - 1]), mergeSub: true, max: `/ ${num(E.emax)}`, w: 44, cell: row => ({ t: num(r_(row).tot ? r_(row).tot[n - 1] : ''), cls: 'num b' }), key: 'tot' + n });
  }
  cols.push({ g: 'Summary', gc: '#1F3864', h: 'Exps marked', max: `held: ${E.heldCount}`, w: 54, cell: row => ({ t: r_(row).N ?? '' }), key: 'N' });
  cols.push({ g: 'Summary', gc: '#1F3864', h: 'Total of held', max: `/ ${num(E.SUM7)}`, w: 58, cell: row => ({ t: num(r_(row).SUM), cls: 'num b' }), key: 'SUM' });
  cols.push({ g: 'Summary', gc: '#1F3864', h: 'Percentage', w: 74, cell: row => ({ t: pct(r_(row).PCT), cls: 'num', st: barStyle(r_(row).PCT, p.color) }), key: 'PCT' });
  cols.push({ g: 'Summary', gc: '#1F3864', h: `Marks (/ ${num(E.marks)})`, max: `/ ${num(E.marks)}`, w: 64, cell: row => ({ t: num(r_(row).SC), cls: 'num b sc' }), key: 'SC' });
  const getter = c => {
    if (c.entry !== undefined) return rows.map(x => getMark(state, s, page, x.r, c.entry));
    if (c.key && c.key.startsWith('tot')) { const n = Number(c.key.slice(3)); return rows.map(x => (r_(x).tot || [])[n - 1]); }
    return rows.map(x => r_(x)[c.key]);
  };
  const legend = parts.map(([ab, lab]) => `${ab} = ${lab} (0–${num(state.max[`${p.rub}|${ab}`])})`).join(' · ');
  return sheetHeader(s, page, `<span>${esc(legend)}</span>`) + chips + table(s, page, cols, rows, statFoot(getter, c => c.key === 'PCT'));
}

// ---- lab mid, lab final, OEL
function tSingle(s, page) {
  const rows = namedRows(s, page), p = PAGE[page];
  if (!rows.length) return sheetHeader(s, page) + noStudents(s, page);
  const X = R.lab[s][page], cols0 = entryCols(page), date = pageDates(state, s, page)[0];
  const r_ = row => X.rows[row.r] || {};
  const cols = cols0.map((c, i) => ({ g: p.title, gc: p.color, h: `${c.label} (0–${num(state.max[c.maxKey])})`, sub: `Week ${state.settings[p.wk]} · ${fmtDate(date, true)}`, max: num(state.max[c.maxKey]), entry: i, w: 78, mergeSub: true }));
  cols.push({ g: 'Total', gc: '#1F3864', h: `Total (/ ${num(X.T7)})`, max: `/ ${num(X.T7)}`, w: 64, cell: row => ({ t: num(r_(row).T), cls: 'num b' }), key: 'T' });
  cols.push({ g: 'Total', gc: '#1F3864', h: `Marks (/ ${num(X.marks)})`, max: `/ ${num(X.marks)}`, w: 70, cell: row => ({ t: num(r_(row).SC), cls: 'num b sc', st: barStyle(r_(row).SC, p.color, X.marks) }), key: 'SC' });
  const getter = c => (c.entry !== undefined ? rows.map(x => getMark(state, s, page, x.r, c.entry)) : rows.map(x => r_(x)[c.key]));
  return sheetHeader(s, page, `<span>Date = week ${state.settings[p.wk]} lab day of this group (change the week in Settings).</span>`) + table(s, page, cols, rows, statFoot(getter));
}

// ---- project
function tProject(s, page) {
  const rows = namedRows(s, page);
  if (!rows.length) return sheetHeader(s, page) + noStudents(s, page);
  const X = R.lab[s].Project, cols0 = entryCols(page), date = pageDates(state, s, page)[0];
  const r_ = row => X.rows[row.r] || {};
  const cols = [];
  const blk = { des: ['Project Design Quantification', '#1F7A5A', 'P_DES'], viva: ['Project Viva Quantification', '#7030A0', 'P_VIVA'] };
  for (const b of ['des', 'viva']) {
    cols0.forEach((c, i) => { if (c.block === b) cols.push({ g: blk[b][0], gc: blk[b][1], h: `${c.label} (0–${num(state.max[c.maxKey])})`, sub: fmtDate(date, true), max: num(state.max[c.maxKey]), entry: i, w: 74, mergeSub: true }); });
    cols.push({ g: blk[b][0], gc: blk[b][1], h: `Total (/ ${num(X.blocks[b].T7)})`, max: `/ ${num(X.blocks[b].T7)}`, w: 56, cell: row => ({ t: num(r_(row)[b] && r_(row)[b].T), cls: 'num b' }), key: b + 'T' });
    cols.push({ g: blk[b][0], gc: blk[b][1], h: `Scaled (/ ${num(X.blocks[b].SC7)})`, max: `/ ${num(X.blocks[b].SC7)}`, w: 56, cell: row => ({ t: num(r_(row)[b] && r_(row)[b].SC), cls: 'num' }), key: b + 'SC' });
  }
  cols.push({ g: 'Design project', gc: '#1F3864', h: `Project marks (/ ${num(state.settings.M_PROJ)})`, max: `/ ${num(state.settings.M_PROJ)}`, w: 84, cell: row => ({ t: num(r_(row).P), cls: 'num b sc', st: barStyle(r_(row).P, '#B45F06', state.settings.M_PROJ) }), key: 'P' });
  const getter = c => (c.entry !== undefined ? rows.map(x => getMark(state, s, page, x.r, c.entry)) :
    rows.map(x => { const o = r_(x); return c.key === 'P' ? o.P : o[c.key.replace(/T$|SC$/, '')] && o[c.key.replace(/T$|SC$/, '')][c.key.endsWith('SC') ? 'SC' : 'T']; }));
  return sheetHeader(s, page, `<span>Project = (design scaled + viva scaled) / (${num(state.settings.P_DES)} + ${num(state.settings.P_VIVA)}) × ${num(state.settings.M_PROJ)}, using only the parts already marked.</span>`) + table(s, page, cols, rows, statFoot(getter));
}

// ---- lab total
function tLabTotal(s, page) {
  const rows = namedRows(s, page);
  if (!rows.length) return sheetHeader(s, page) + noStudents(s, page);
  const LT = R.lab[s]['Lab Total'], S = state.settings;
  const labels = ['Lab Performance', 'Lab Reports', 'Final', 'Mid', 'OEL', 'Project Design'];
  const r_ = row => LT.rows[row.r] || {};
  const cols = LT.comps.map(([P, mk], i) => ({ g: 'LAB TOTAL — from the lab assessment sheets', gc: '#1F7A5A', h: labels[i], max: num(S[mk]), w: 62, cell: row => ({ t: num((r_(row).v || [])[i]), cls: 'num link', }), i, act: P }));
  const mt = LT.comps.reduce((a, [, mk]) => a + (Number(S[mk]) || 0), 0);
  cols.push({ g: 'Total', gc: '#1F3864', h: `Total (/ ${num(mt)})`, max: `/ ${num(mt)}`, w: 62, cell: row => ({ t: num(r_(row).T), cls: 'num b sc' }), key: 'T' });
  cols.push({ g: 'Total', gc: '#1F3864', h: 'Max of marked', w: 58, cell: row => ({ t: num(r_(row).HM), cls: 'num' }), key: 'HM' });
  cols.push({ g: 'Total', gc: '#1F3864', h: 'Lab %', w: 74, cell: row => ({ t: pct(r_(row).P), cls: 'num b', st: barStyle(r_(row).P, '#70AD47') }), key: 'P' });
  const getter = c => (c.i !== undefined ? rows.map(x => (r_(x).v || [])[c.i]) : rows.map(x => r_(x)[c.key]));
  const links = LT.comps.map(([P]) => `<button class="chipb" data-act="open" data-s="${s}" data-page="${esc(P)}">${esc(PAGE[P].title)}</button>`).join('');
  return sheetHeader(s, page, `<span>Lab total = ${LT.comps.map(([, mk]) => num(S[mk])).join(' + ')} = ${num(mt)}. Lab % uses only the components already marked.</span>`) +
    `<div class="chips">${links}</div>` + table(s, page, cols, rows, statFoot(getter, c => c.key === 'P'));
}

// ---- CLO / PLO
function summaryCard(title, summary, chartTitle) {
  const rows = summary.map(o => `<tr><td><b>${esc(o.code)}</b></td><td>${pct(o.kpi)}</td><td>${pct(o.avg)}</td><td>${o.n}</td><td>${o.ge}</td><td>${pct(o.share)}</td><td class="pill ${statusCls(o.result)}">${esc(o.result)}</td></tr>`).join('');
  const chart = barChart({
    title: chartTitle, cats: summary.map(o => o.code), max: 1,
    series: [{ name: 'KPI', color: '#BFBFBF', vals: summary.map(o => o.kpi) }, { name: 'Class average', color: '#2E75B6', vals: summary.map(o => o.avg) }, { name: '% of students ≥ KPI', color: '#70AD47', vals: summary.map(o => o.share) }],
  });
  return `<div class="card"><div class="h3">${esc(title)}</div><div class="scrollx"><table class="mini"><tr><th>Outcome</th><th>KPI</th><th>Class average</th><th>Assessed</th><th>≥ KPI</th><th>% ≥ KPI</th><th>Class result</th></tr>${rows}</table></div>
  <div class="muted small">Class result: attained when the class average reaches the KPI.</div>${chart}</div>`;
}
function tCLO(s, page) {
  const rows = namedRows(s, page), C = R.lab[s].CLO, S = state.settings, O = state.outc;
  const head = sheetHeader(s, page) + summaryCard('Class summary — course learning outcomes', C.summary, `Section ${s}: CLO attainment`);
  if (!rows.length) return head + noStudents(s, page);
  const r_ = row => C.rows[row.r] || {};
  const g4 = `${O.CO4.code} (KPI = ${pct(O.CO4.kpi).replace('.0', '')})`, g5 = `${O.CO5.code} (KPI = ${pct(O.CO5.kpi).replace('.0', '')})`;
  const cols = C.co4.map(([P, w, mk], i) => ({ g: g4, gc: TAB[s], h: ['Perf', 'Mid', 'Final', 'Viva'][i], sub: `weight ${pct(S[w]).replace('.0', '')}`, max: `/ ${num(S[mk])}`, w: 48, cell: row => ({ t: num((r_(row).v || [])[i]), cls: 'num' }), i }));
  cols.push({ g: g4, gc: TAB[s], h: `${O.CO4.code} total (100%)`, w: 76, cell: row => ({ t: pct(r_(row).CO4), cls: 'num b', st: barStyle(r_(row).CO4, '#2E75B6') }), key: 'CO4' });
  cols.push({ g: g4, gc: TAB[s], h: `${O.CO4.code} status`, w: 74, cell: row => ({ t: r_(row).S4, cls: 'pill ' + statusCls(r_(row).S4) }), noStat: true });
  cols.push({ g: g5, gc: '#7030A0', h: 'Project', sub: `weight ${pct(S.CO5_PROJ).replace('.0', '')}`, max: `/ ${num(S.M_PROJ)}`, w: 52, cell: row => ({ t: num(r_(row).PR), cls: 'num' }), key: 'PR' });
  cols.push({ g: g5, gc: '#7030A0', h: `${O.CO5.code} total (100%)`, w: 76, cell: row => ({ t: pct(r_(row).CO5), cls: 'num b', st: barStyle(r_(row).CO5, '#7030A0') }), key: 'CO5' });
  cols.push({ g: g5, gc: '#7030A0', h: `${O.CO5.code} status`, w: 74, cell: row => ({ t: r_(row).S5, cls: 'pill ' + statusCls(r_(row).S5) }), noStat: true });
  const getter = c => (c.i !== undefined ? rows.map(x => (r_(x).v || [])[c.i]) : rows.map(x => r_(x)[c.key]));
  return head + table(s, page, cols, rows, statFoot(getter, c => c.key === 'CO4' || c.key === 'CO5'));
}
function tPLO(s, page) {
  const rows = namedRows(s, page), P = R.lab[s].PLO, S = state.settings, O = state.outc;
  const head = sheetHeader(s, page) + summaryCard('Class summary — programme learning outcomes', P.summary, `Section ${s}: PLO attainment`);
  if (!rows.length) return head + noStudents(s, page);
  const r_ = row => P.rows[row.r] || {};
  const cols = [];
  for (const [po, co, wk, col, srcK, pk, sk] of [['PO5', 'CO4', 'PO5_CO4', TAB[s], 'src5', 'PO5', 'S5'], ['PO9', 'CO5', 'PO9_CO5', '#7030A0', 'src9', 'PO9', 'S9']]) {
    const g = `${O[po].code} (KPI = ${pct(O[po].kpi).replace('.0', '')})`;
    cols.push({ g, gc: col, h: `${O[co].code} (100%)`, sub: `weight ${pct(S[wk]).replace('.0', '')}`, w: 70, cell: row => ({ t: pct(r_(row)[srcK]), cls: 'num' }), key: srcK });
    cols.push({ g, gc: col, h: 'Total 100%', w: 76, cell: row => ({ t: pct(r_(row)[pk]), cls: 'num b', st: barStyle(r_(row)[pk], col) }), key: pk });
    cols.push({ g, gc: col, h: 'Status', w: 74, cell: row => ({ t: r_(row)[sk], cls: 'pill ' + statusCls(r_(row)[sk]) }), noStat: true });
  }
  return head + table(s, page, cols, rows, statFoot(c => rows.map(x => r_(x)[c.key]), () => true));
}

// ---- final sheet
const FINAL_VIEWS = ['Summary', 'Theory', 'Attendance', 'Lab', 'Outcomes', 'Result', 'All'];
function tFinal(s, page) {
  const rows = namedRows(s, page);
  if (!rows.length) return sheetHeader(s, page) + noStudents(s, page);
  const F = R.sec[s].Final, S = state.settings, O = state.outc, T = R.sec[s];
  const r_ = row => F[row.r] || {};
  const all = [];
  const add = (grp, gc, tags, c) => all.push(Object.assign({ g: grp, gc, tags }, c));
  [['Quizzes', 'Quizzes'], ['Assignments', 'Assignments'], ['Mid Exam', 'Mid exam'], ['Final Exam', 'Final exam']].forEach(([P, h]) =>
    add('Theory marks', '#7030A0', 'Theory', { h, max: `/ ${num(T[P].T7)}`, w: 52, cell: row => ({ t: num(r_(row).th[P]), cls: 'num' }), get: o => o.th[P] }));
  add('Theory marks', '#7030A0', 'Theory Summary', { h: 'Theory %', w: 70, cell: row => ({ t: pct(r_(row).thpct), cls: 'num b', st: barStyle(r_(row).thpct, '#9E7BC4') }), get: o => o.thpct, p: 1 });
  add('Theory attendance', '#2E75B6', 'Attendance', { h: 'Classes attended', max: `held: ${T['Theory Att'].heldN}`, w: 60, cell: row => ({ t: r_(row).tatt }), noStat: true });
  add('Theory attendance', '#2E75B6', 'Attendance Summary', { h: 'Theory att. %', w: 70, cell: row => ({ t: pct(r_(row).tattp), cls: 'num' + (isNum(r_(row).tattp) && r_(row).tattp < S.THR ? ' badtxt' : ''), st: barStyle(r_(row).tattp, '#2E75B6') }), get: o => o.tattp, p: 1 });
  add('Theory attendance', '#2E75B6', 'Attendance', { h: 'Status', w: 64, cell: row => ({ t: r_(row).tatts, cls: 'pill ' + statusCls(r_(row).tatts) }), noStat: true });
  add('Lab marks', '#1F7A5A', 'Lab', { h: 'Lab group', w: 42, cell: row => ({ t: r_(row).grp }), noStat: true });
  [['Lab Perf.', 'M_PERF'], ['Lab Reports', 'M_REP'], ['Lab Final', 'M_LFIN'], ['Lab Mid', 'M_LMID'], ['OEL', 'M_OEL'], ['Project', 'M_PROJ']].forEach(([h, mk], i) =>
    add('Lab marks', '#1F7A5A', 'Lab', { h, max: `/ ${num(S[mk])}`, w: 50, cell: row => ({ t: num(r_(row).lab[i]), cls: 'num' }), get: o => o.lab[i] }));
  const mt = ['M_PERF', 'M_REP', 'M_LFIN', 'M_LMID', 'M_OEL', 'M_PROJ'].reduce((a, k) => a + (Number(S[k]) || 0), 0);
  add('Lab marks', '#1F7A5A', 'Lab', { h: `Lab total (${num(mt)})`, max: `/ ${num(mt)}`, w: 56, cell: row => ({ t: num(r_(row).labtot), cls: 'num b' }), get: o => o.labtot });
  add('Lab marks', '#1F7A5A', 'Lab Summary', { h: 'Lab %', w: 70, cell: row => ({ t: pct(r_(row).labpct), cls: 'num b', st: barStyle(r_(row).labpct, '#70AD47') }), get: o => o.labpct, p: 1 });
  add('Outcomes', '#B45F06', 'Outcomes', { h: `${O.CO4.code} %`, w: 64, cell: row => ({ t: pct(r_(row).CO4), cls: 'num', st: barStyle(r_(row).CO4, '#F4B183') }), get: o => o.CO4, p: 1 });
  add('Outcomes', '#B45F06', 'Outcomes', { h: `${O.CO5.code} %`, w: 64, cell: row => ({ t: pct(r_(row).CO5), cls: 'num', st: barStyle(r_(row).CO5, '#F4B183') }), get: o => o.CO5, p: 1 });
  add('Outcomes', '#B45F06', 'Outcomes Summary', { h: O.PO5.code, w: 70, cell: row => ({ t: r_(row).PO5, cls: 'pill ' + statusCls(r_(row).PO5) }), noStat: true });
  add('Outcomes', '#B45F06', 'Outcomes Summary', { h: O.PO9.code, w: 70, cell: row => ({ t: r_(row).PO9, cls: 'pill ' + statusCls(r_(row).PO9) }), noStat: true });
  add('Lab attendance', '#548235', 'Attendance', { h: 'Labs attended', max: '', w: 60, cell: row => ({ t: r_(row).latt }), noStat: true });
  add('Lab attendance', '#548235', 'Attendance Summary', { h: 'Lab att. %', w: 70, cell: row => ({ t: pct(r_(row).lattp), cls: 'num' + (isNum(r_(row).lattp) && r_(row).lattp < S.THR ? ' badtxt' : ''), st: barStyle(r_(row).lattp, '#548235') }), get: o => o.lattp, p: 1 });
  add('Lab attendance', '#548235', 'Attendance', { h: 'Status', w: 64, cell: row => ({ t: r_(row).latts, cls: 'pill ' + statusCls(r_(row).latts) }), noStat: true });
  add('Result', '#C00000', 'Result Summary', { h: 'Course total %', w: 76, cell: row => ({ t: pct(r_(row).ct), cls: 'num b', st: barStyle(r_(row).ct, '#C00000') }), get: o => o.ct, p: 1 });
  add('Result', '#C00000', 'Result Summary', { h: 'Grade', w: 44, cell: row => ({ t: r_(row).grade, cls: 'b ' + (r_(row).grade === 'F' ? 'pill bad' : '') }), noStat: true });
  add('Result', '#C00000', 'Result', { h: 'GP', w: 36, cell: row => ({ t: r_(row).grade ? num(gradePoint(state, r_(row).grade)) : '' }), get: o => (o.grade ? gradePoint(state, o.grade) : '') });
  add('Result', '#C00000', 'Result Summary', { h: 'Remarks', w: 130, cell: row => ({ t: r_(row).rem, cls: 'rem' }), noStat: true });
  const view = ui.finalView;
  const cols = view === 'All' ? all : all.filter(c => c.tags.split(' ').includes(view));
  const chips = `<div class="chips">${FINAL_VIEWS.map(v => `<button class="chipb ${v === view ? 'on' : ''}" data-act="finalv" data-f="${v}">${v}</button>`).join('')}</div>`;
  const getter = c => rows.map(x => (c.get ? c.get(r_(x)) : ''));
  return sheetHeader(s, page, `<span>All formulas · lab results are matched by Reg. No from the student's lab group</span>`) + chips + table(s, page, cols, rows, statFoot(getter, c => !!c.p));
}

// ------------------------------------------------------------------ cell editor
function colInfo(s, page, c) {
  const p = PAGE[page], cols = entryCols(page), col = cols[c];
  if (p.kind === 'att') return { label: `Week ${c + 1} · ${p.att === 'lec' ? 'lecture' : 'lab'} · ${fmtDate(pageDates(state, s, page)[c], true, true)}`, att: true };
  const max = Number(state.max[col.maxKey]) || 0;
  let label = col.label;
  if (p.kind === 'exp') label = `Exp. ${col.exp} · ${col.label} — ${col.long}`;
  if (p.kind === 'project') label = `${col.block === 'des' ? 'Design' : 'Viva'} · ${col.label}`;
  return { label: `${p.title} · ${label}`, max };
}
function openEditor(s, page, r, c) {
  sel = { s, page, r, c };
  renderEditor();
  markSel(true);
}
function closeEditor() {
  if (!sel) return;
  commitInput(false);
  sel = null;
  const ed = $('#editor'); ed.hidden = true; ed.innerHTML = '';
  document.querySelectorAll('td.sel').forEach(x => x.classList.remove('sel'));
  sizeTable();
}
function markSel(scroll) {
  document.querySelectorAll('td.sel').forEach(x => x.classList.remove('sel'));
  if (!sel) return;
  const td = document.querySelector(`#main td.e[data-r="${sel.r}"][data-c="${sel.c}"]`);
  if (!td) return;
  td.classList.add('sel');
  if (scroll) {
    const tw = $('#main .tw'); if (!tw) return;
    const a = td.getBoundingClientRect(), b = tw.getBoundingClientRect();
    const stickyW = 170, headH = 92;
    if (a.left < b.left + stickyW) tw.scrollLeft -= b.left + stickyW - a.left + 8;
    else if (a.right > b.right) tw.scrollLeft += a.right - b.right + 8;
    if (a.top < b.top + headH) tw.scrollTop -= b.top + headH - a.top + 4;
    else if (a.bottom > b.bottom) tw.scrollTop += a.bottom - b.bottom + 4;
  }
}
function renderEditor() {
  const { s, page, r, c } = sel, ed = $('#editor');
  const who = rosterOf(s, page)[r], info = colInfo(s, page, c);
  const v = getMark(state, s, page, r, c);
  let ctl;
  if (info.att) {
    ctl = `<div class="edrow">${['P', 'A', 'L'].map(x => `<button class="attb ${x} ${v === x ? 'on' : ''}" data-act="ed-set" data-v="${x}">${x}</button>`).join('')}<button class="attb clr" data-act="ed-set" data-v="">–</button>
      <button class="nav" data-act="ed-up" aria-label="previous student">▲</button><button class="nav" data-act="ed-down" aria-label="next student">▼</button><button class="nav done" data-act="ed-close">Done</button></div>`;
  } else {
    const ints = info.max <= 10 && Number.isInteger(info.max);
    const quick = ints ? Array.from({ length: info.max + 1 }, (_, i) => i + (ui.half && i < info.max ? 0.5 : 0)) : info.max <= 5 ? [0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5].filter(x => x <= info.max) : [];
    ctl = `<div class="edrow"><button class="nav" data-act="ed-left" aria-label="previous column">◀</button><input id="edin" inputmode="decimal" autocomplete="off" value="${esc(v ?? '')}" placeholder="0–${num(info.max)}">
      <button class="nav" data-act="ed-right" aria-label="next column">▶</button><button class="nav" data-act="ed-up">▲</button><button class="nav" data-act="ed-down">▼</button><button class="nav done" data-act="ed-close">Done</button></div>
      ${quick.length ? `<div class="quick">${quick.map(x => `<button data-act="ed-quick" data-v="${x}" class="${v === x ? 'on' : ''}">${x}</button>`).join('')}${ints ? `<button data-act="ed-half" class="half ${ui.half ? 'on' : ''}">+½</button>` : ''}<button data-act="ed-quick" data-v="">clear</button></div>` : ''}`;
  }
  ed.innerHTML = `<div class="edinfo"><b>${esc(who.name)}</b> <span>${esc(who.reg)}</span><div>${esc(info.label)}${info.att ? '' : ` · max ${num(info.max)}`}</div><div id="ederr"></div></div>${ctl}`;
  ed.hidden = false;
  sizeTable();
  const inp = $('#edin');
  if (inp) {
    inp.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); if (commitInput(true)) advance(); } };
    setTimeout(() => { inp.focus(); inp.select(); }, 30);
  }
}
function commitInput(showErr) {
  const inp = $('#edin');
  if (!sel || !inp) return true;
  const raw = inp.value.trim().replace(',', '.');
  const cur = getMark(state, sel.s, sel.page, sel.r, sel.c);
  if (raw === '') { if (cur !== null) { setMark(state, sel.s, sel.page, sel.r, sel.c, null); changed(); refreshTable(); } return true; }
  const v = Number(raw), max = colInfo(sel.s, sel.page, sel.c).max;
  if (!isFinite(v) || v < 0 || v > max) {
    if (showErr) { const e = $('#ederr'); if (e) e.textContent = `Enter a number from 0 to ${num(max)}.`; inp.classList.add('err'); }
    return false;
  }
  if (cur !== v) { setMark(state, sel.s, sel.page, sel.r, sel.c, v); changed(); refreshTable(); }
  return true;
}
function setValue(v) {
  const cur = getMark(state, sel.s, sel.page, sel.r, sel.c);
  if (cur !== (v === '' ? null : v)) { setMark(state, sel.s, sel.page, sel.r, sel.c, v === '' ? null : v); changed(); refreshTable(); }
}
function refreshTable() { if (top().v === 'sheet') render(); }
function move(dr, dc) {
  const { s, page } = sel;
  const rows = namedRows(s, page).map(x => x.r);
  const cols = [...new Set([...document.querySelectorAll('#main tbody tr:first-child td.e')].map(td => Number(td.dataset.c)))];
  let ri = rows.indexOf(sel.r), ci = cols.indexOf(sel.c);
  if (dr) ri = Math.max(0, Math.min(rows.length - 1, ri + dr));
  if (dc) ci = Math.max(0, Math.min(cols.length - 1, ci + dc));
  if (ri < 0 || ci < 0) return;
  sel = { s, page, r: rows[ri], c: cols[ci] };
  renderEditor(); markSel(true);
}
function advance() {
  // rubric pages: across the criteria of the same experiment/part, then the next student; others: down the column
  const { s, page, c } = sel, p = PAGE[page];
  if (['exp', 'single', 'project'].includes(p.kind)) {
    const cols = entryCols(page);
    const sameGroup = i => (p.kind === 'exp' ? cols[i].exp === cols[c].exp : p.kind === 'project' ? cols[i].block === cols[c].block : true);
    if (c + 1 < cols.length && sameGroup(c + 1)) { move(0, 1); return; }
    let first = c; while (first - 1 >= 0 && sameGroup(first - 1)) first--;
    const rows = namedRows(s, page).map(x => x.r), ri = rows.indexOf(sel.r);
    if (ri + 1 < rows.length) { sel = { s, page, r: rows[ri + 1], c: first }; renderEditor(); markSel(true); }
    else closeEditor();
    return;
  }
  const rows = namedRows(s, page).map(x => x.r), ri = rows.indexOf(sel.r);
  if (ri + 1 < rows.length) move(1, 0); else closeEditor();
}

// ------------------------------------------------------------------ STUDENTS and LAB GROUPS
function lastUsed(obj) { let n = -1; for (const k of Object.keys(obj)) { const x = obj[k]; if (x && (x.reg || x.name || x.rem)) n = Math.max(n, Number(k)); } return n; }
function rosterList(kind, s) {
  const isLab = kind === 'lab', lg = state.labGroups[s];
  const src = isLab ? (lg.custom ? lg.rows : state.students[s]) : state.students[s];
  const editable = !isLab || lg.custom;
  const n = Math.min(NROW, lastUsed(src) + (editable ? 2 : 1));
  let h = '<div class="roster">';
  for (let r = 0; r < Math.max(n, editable ? 1 : 0); r++) {
    const x = src[r] || {}, base = isLab ? `labGroups.${s}.rows.${r}` : `students.${s}.${r}`;
    const rem = isLab ? (lg.rem[r] || '') : x.rem || '';
    h += `<div class="srow ${!x.name && !x.reg ? 'blank' : ''}"><span class="sr">${r + 1}</span>`;
    if (editable) h += `<input class="reg" data-bind="${base}.reg" value="${esc(x.reg || '')}" placeholder="Reg. No" autocapitalize="characters"><input class="name" data-bind="${base}.name" value="${esc(x.name || '')}" placeholder="Student name" autocapitalize="words">`;
    else h += `<span class="reg">${esc(x.reg || '')}</span><span class="name">${esc(x.name || '')}</span>`;
    h += `<button class="more" data-act="stu-more" data-kind="${kind}" data-s="${s}" data-r="${r}" aria-label="more">⋮</button>${rem ? `<div class="remline">${esc(rem)}</div>` : ''}</div>`;
  }
  return h + '</div>';
}
function secTabs(act, cur) {
  return `<div class="tabs">${SECS.map(x => `<button class="tab ${x === cur ? 'on' : ''}" style="--c:${TAB[x]}" data-act="${act}" data-s="${x}">${x}<small>${esc(secName(x))}</small></button>`).join('')}</div>`;
}
function vStudents(v) {
  const s = v.s || ui.sec;
  const count = Object.values(state.students[s]).filter(x => x && x.name).length;
  return `${secTabs('stu-sec', s)}
  <div class="card"><div class="row between"><div><b>Section ${s} — ${esc(secName(s))}</b><div class="muted small">${count} students · up to ${NROW} · same row on every sheet of the section</div></div>
  <div class="row"><button class="btn small" data-act="paste" data-kind="sec" data-s="${s}">Paste list</button></div></div></div>
  ${rosterList('sec', s)}
  <div class="muted small pad">Type the Reg. No and name; a new empty row appears below the last student. ⋮ edits remarks or removes a student.</div>`;
}
function vLabGroups(v) {
  const s = v.s || ui.sec, lg = state.labGroups[s];
  const count = R.lab[s].roster.filter(x => x.name).length;
  return `${secTabs('lg-sec', s)}
  <div class="card"><b>Lab group ${s}</b> <span class="muted small">· ${count} students</span>
    <div class="seg"><button class="${!lg.custom ? 'on' : ''}" data-act="lg-mode" data-s="${s}" data-m="same">Same as Section ${s}</button><button class="${lg.custom ? 'on' : ''}" data-act="lg-mode" data-s="${s}" data-m="custom">Custom list</button></div>
    <div class="muted small">${lg.custom ? 'This lab group has its own list. Lab sheets use this list; results reach each student\'s Final Sheet by Reg. No.' : `Follows the Section ${s} class list automatically. Choose “Custom list” if lab groups differ from sections.`}</div>
    ${lg.custom ? `<div class="row"><button class="btn small" data-act="paste" data-kind="lab" data-s="${s}">Paste list</button><button class="btn small" data-act="lg-copy" data-s="${s}">Copy Section ${s} list</button></div>` : ''}
  </div>
  ${rosterList('lab', s)}`;
}

// ------------------------------------------------------------------ SETTINGS
const RUBNICE = { 'Lab Perf': 'Lab performance (each exp.)', 'Lab Reports': 'Lab report (each exp.)', 'Lab Mid': 'Lab mid exam', 'Lab Final': 'Lab final exam', OEL: 'OEL viva voce', 'Project Design': 'Project design', 'Project Viva': 'Project viva' };
function fNum(path, val, type = 'num', extra = '') {
  const shown = type === 'pct' ? (isNum(Number(val)) ? Math.round(Number(val) * 10000) / 100 : '') : val ?? '';
  return `<input class="num" inputmode="decimal" data-bind="${path}" data-type="${type}" value="${esc(shown)}" ${extra}>${type === 'pct' ? '<span class="unit">%</span>' : ''}`;
}
const fText = (path, val, ph = '') => `<input data-bind="${path}" value="${esc(val ?? '')}" placeholder="${esc(ph)}">`;
const totalLine = (label, v, isPct = true) => {
  const ok = !isPct || Math.abs(v - 1) < 1e-6;
  return `<div class="trow total ${ok ? '' : 'badbg'}"><span>${label}</span><b>${isPct ? pct(v).replace('.0%', '%') : num(v)}</b>${ok ? '' : '<span class="small">must be 100%</span>'}</div>`;
};
function vSettings() {
  const S = state.settings, sum = keys => keys.reduce((a, k) => a + (Number(S[k]) || 0), 0);
  const tr = (label, ctl, note = '') => `<div class="trow"><span>${label}${note ? `<small>${note}</small>` : ''}</span><span class="ctl">${ctl}</span></div>`;
  const dayOpts = (path, v) => `<select data-bind="${path}" data-type="int">${DAYS.slice(0, 6).map((d, i) => `<option value="${i}" ${Number(v) === i ? 'selected' : ''}>${d}</option>`).join('')}</select>`;
  const auto = (key, label, def) => tr(label, `<input type="date" data-bind="settings.${key}" data-type="date" value="${esc(S[key] || def)}" ${S[key] ? '' : 'class="auto"'}>
    <label class="cb"><input type="checkbox" data-act="autodate" data-k="${key}" ${S[key] ? '' : 'checked'}> auto</label>`, S[key] ? 'set by you' : 'auto from week 1');
  return `
  <div class="card"><div class="h3">General</div>
    ${tr('Week 1 starts on (Monday)', `<input type="date" data-bind="settings.START" data-type="date" value="${esc(S.START)}">`, 'all dates follow from this')}
    ${tr('Minimum attendance (theory and lab)', fNum('settings.THR', S.THR, 'pct'))}
    ${tr('Count Leave (L) as present?', `<select data-bind="settings.LEAVE"><option ${S.LEAVE === 'No' ? 'selected' : ''}>No</option><option ${S.LEAVE === 'Yes' ? 'selected' : ''}>Yes</option></select>`)}
    ${auto('MIDD', 'Theory mid-term exam date', midDate(state))}
    ${auto('FIND', 'Theory final exam date', finDate(state))}
    ${tr('Lab mid exam — in week', fNum('settings.WK_LMID', S.WK_LMID, 'int'))}
    ${tr('Open-ended lab (OEL) — in week', fNum('settings.WK_OEL', S.WK_OEL, 'int'))}
    ${tr('Project evaluation — in week', fNum('settings.WK_PROJ', S.WK_PROJ, 'int'))}
    ${tr('Lab final exam — in week', fNum('settings.WK_LFIN', S.WK_LFIN, 'int'))}
  </div>
  <div class="card"><div class="h3">Sections</div>
    ${SECS.map(s => `<div class="secbox" style="border-color:${TAB[s]}"><b style="color:${TAB[s]}">Section ${s}</b>
      ${tr('Name', fText(`sections.${s}.name`, state.sections[s].name))}
      ${tr('Theory instructor', fText(`sections.${s}.inst`, state.sections[s].inst))}
      ${tr('Lab instructor', fText(`sections.${s}.labInst`, state.sections[s].labInst))}
      ${tr('Lecture day', dayOpts(`sections.${s}.lec`, state.sections[s].lec))}
      ${tr('Lab day', dayOpts(`sections.${s}.lab`, state.sections[s].lab))}</div>`).join('')}
  </div>
  <div class="card"><div class="h3">Theory weights</div>
    ${tr('Quizzes', fNum('settings.W_Q', S.W_Q, 'pct'))}${tr('Assignments', fNum('settings.W_A', S.W_A, 'pct'))}
    ${tr('Mid-term exam', fNum('settings.W_M', S.W_M, 'pct'))}${tr('Final exam', fNum('settings.W_F', S.W_F, 'pct'))}
    ${totalLine('Theory total', sum(['W_Q', 'W_A', 'W_M', 'W_F']))}
  </div>
  <div class="card"><div class="h3">Course weights</div>
    ${tr('Theory share', fNum('settings.SH_T', S.SH_T, 'pct'), '3(2+1) credit hours')}${tr('Lab share', fNum('settings.SH_L', S.SH_L, 'pct'))}
    ${totalLine('Course total', sum(['SH_T', 'SH_L']))}
  </div>
  <div class="card"><div class="h3">Lab total — marks of each lab component</div>
    ${tr('Lab performance (14 experiments)', fNum('settings.M_PERF', S.M_PERF))}${tr('Lab reports (14 experiments)', fNum('settings.M_REP', S.M_REP))}
    ${tr('Lab final exam', fNum('settings.M_LFIN', S.M_LFIN))}${tr('Lab mid exam', fNum('settings.M_LMID', S.M_LMID))}
    ${tr('Open-ended lab (OEL) viva voce', fNum('settings.M_OEL', S.M_OEL))}${tr('Project (design + viva)', fNum('settings.M_PROJ', S.M_PROJ))}
    ${totalLine('Lab total', sum(['M_PERF', 'M_REP', 'M_LFIN', 'M_LMID', 'M_OEL', 'M_PROJ']), false)}
    ${tr('Project design scaled to', fNum('settings.P_DES', S.P_DES), 'raw out of 20')}${tr('Project viva scaled to', fNum('settings.P_VIVA', S.P_VIVA), 'raw out of 5')}
  </div>
  <div class="card"><div class="h3">Course and programme learning outcomes</div>
    ${['CO4', 'CO5', 'PO5', 'PO9'].map(k => `<div class="secbox">${tr('Code', fText(`outc.${k}.code`, state.outc[k].code))}${tr('KPI', fNum(`outc.${k}.kpi`, state.outc[k].kpi, 'pct'))}${tr('Description', fText(`outc.${k}.desc`, state.outc[k].desc))}</div>`).join('')}
    <div class="h3">${esc(state.outc.CO4.code)} weights</div>
    ${tr('Lab performance', fNum('settings.CO4_PERF', S.CO4_PERF, 'pct'))}${tr('Lab mid exam', fNum('settings.CO4_MID', S.CO4_MID, 'pct'))}
    ${tr('Lab final exam', fNum('settings.CO4_FIN', S.CO4_FIN, 'pct'))}${tr('OEL viva voce', fNum('settings.CO4_VIVA', S.CO4_VIVA, 'pct'))}
    ${totalLine(`${esc(state.outc.CO4.code)} total`, sum(['CO4_PERF', 'CO4_MID', 'CO4_FIN', 'CO4_VIVA']))}
    <div class="h3">Mapping</div>
    ${tr(`${esc(state.outc.CO5.code)} ← Project`, fNum('settings.CO5_PROJ', S.CO5_PROJ, 'pct'))}${tr(`${esc(state.outc.PO5.code)} ← ${esc(state.outc.CO4.code)}`, fNum('settings.PO5_CO4', S.PO5_CO4, 'pct'))}${tr(`${esc(state.outc.PO9.code)} ← ${esc(state.outc.CO5.code)}`, fNum('settings.PO9_CO5', S.PO9_CO5, 'pct'))}
    <div class="muted small">Lab reports count in the lab total but not in ${esc(state.outc.CO4.code)}, as in the class grades sheet template.</div>
  </div>
  <div class="card"><div class="h3">Grade scale</div><div class="muted small">Grade from % (ascending order).</div>
    <div class="gtable"><span class="gh">From %</span><span class="gh">Grade</span><span class="gh">GP</span>
    ${state.grades.map((g, i) => `${fNum(`grades.${i}.0`, g[0])}<input data-bind="grades.${i}.1" value="${esc(g[1])}">${fNum(`grades.${i}.2`, g[2])}`).join('')}</div>
  </div>
  <div class="card"><div class="h3">Maximum marks — theory</div>
    ${Object.entries(MAP.theory).map(([g, items]) => items.map(it => tr(`${g}: ${it}`, fNum(`max.${g}|${it}`, state.max[`${g}|${it}`]))).join('')).join('')}
  </div>
  <div class="card"><div class="h3">Maximum marks — lab rubric</div>
    ${Object.entries(MAP.rubric).map(([g, r]) => r.parts.map(([ab, lab]) => tr(`${RUBNICE[g]}: ${lab}`, fNum(`max.${g}|${ab}`, state.max[`${g}|${ab}`]))).join('')).join('')}
  </div>
  <div class="card"><div class="h3">Data on this phone</div>
    <div class="row wrap"><button class="btn small" data-go="sync">Backups and Excel files</button><button class="btn small danger" data-act="reset">Erase all data</button></div>
  </div>`;
}

// ------------------------------------------------------------------ SCHEDULE
function vSchedule() {
  const s = ui.schedSec;
  let h = `${secTabs('sched-sec', s)}<div class="muted small pad">Dates come from Settings (week 1 Monday and each section's lecture/lab day). Change a date for a holiday; ↺ returns it to automatic.</div>`;
  for (let w = 1; w <= WEEKS; w++) {
    const cell = kind => {
      const k = `${s}|${kind}|${w}`, over = !!state.schedule.dates[k];
      return `<label class="dcell ${over ? 'over' : ''}"><span>${kind === 'lec' ? 'Lecture' : 'Lab'}</span><input type="date" data-act-change="sched-date" data-k="${k}" value="${esc(schedDate(state, s, kind, w))}">${over ? `<button data-act="sched-reset" data-k="${k}" title="automatic">↺</button>` : ''}<em>${fmtDate(schedDate(state, s, kind, w), false, true)}</em></label>`;
    };
    h += `<div class="card week"><div class="row between"><b>Week ${w}</b></div><div class="row wrap">${cell('lec')}${cell('lab')}</div>
      <input class="act" data-act-change="sched-act" data-w="${w}" value="${esc(activity(state, w))}" placeholder="Lab experiment / activity">
      <input class="act" data-act-change="sched-note" data-w="${w}" value="${esc(state.schedule.notes[w] || '')}" placeholder="Notes"></div>`;
  }
  return h;
}

// ------------------------------------------------------------------ SECTION RESULTS
function vResults() {
  const X = R.results;
  let h = `<div class="card"><div class="scrollx"><table class="mini res"><tr><th>Measure</th>${SECS.map(s => `<th style="background:${TAB[s]};color:#fff">Sec ${s}<br><small>${esc(secName(s))}</small></th>`).join('')}<th>All</th></tr>`;
  for (const row of X.rows) {
    if (row.head) { h += `<tr class="hd"><td colspan="6">${esc(row.head)}</td></tr>`; continue; }
    const f = v => (row.fmt === 'pct' ? pct(v) : row.fmt === 'int' ? (isNum(v) ? v : '') : num(isNum(v) ? Math.round(v * 10) / 10 : v));
    h += `<tr><td class="lbl">${esc(row.label)}</td>${row.vals.map(v => `<td class="num" style="${row.bar ? barStyle(v, '#5B9BD5') : ''}">${esc(f(v))}</td>`).join('')}<td class="num b">${esc(f(row.all))}</td></tr>`;
  }
  h += '</table></div><div class="muted small">All values come from the four Final Sheets.</div></div>';
  h += `<div class="card">${barChart({ title: 'CLO / PLO attainment by section', yTitle: 'Students ≥ KPI', cats: X.outcomes.map(o => o.code), max: 1, series: SECS.map((s, i) => ({ name: `Section ${s}`, color: TAB[s], vals: X.outcomes.map(o => o.vals[i]) })) })}
    <div class="scrollx"><table class="mini"><tr><th>Students ≥ KPI</th>${SECS.map(s => `<th>${s}</th>`).join('')}<th>All</th></tr>${X.outcomes.map(o => `<tr><td><b>${esc(o.code)}</b></td>${o.vals.map(v => `<td>${pct(v)}</td>`).join('')}<td><b>${pct(o.all)}</b></td></tr>`).join('')}</table></div></div>`;
  h += `<div class="card">${barChart({ title: 'Grade distribution by section', yTitle: 'Students', pct: false, cats: X.grades.map(g => g.g), series: SECS.map((s, i) => ({ name: `Section ${s}`, color: TAB[s], vals: X.grades.map(g => g.vals[i]) })) })}
    <div class="scrollx"><table class="mini"><tr><th>Grade</th>${SECS.map(s => `<th>${s}</th>`).join('')}<th>All</th></tr>${X.grades.map(g => `<tr><td><b>${esc(g.g)}</b></td>${g.vals.map(v => `<td>${v}</td>`).join('')}<td><b>${g.all}</b></td></tr>`).join('')}</table></div></div>`;
  return h;
}

// ------------------------------------------------------------------ SYNC
function renderSyncStatus() { const el = $('#syncstatus'); if (el) el.innerHTML = syncStatusHtml(); }
function syncStatusHtml() {
  const st = sync.getStatus(), c = sync.cfg;
  const text = { local: 'Not connected — data is saved on this phone only.', synced: 'Up to date. The Excel file in Drive matches this phone.', pending: `${st.pendingEdits} change(s) will be uploaded shortly.`, offline: `Offline. ${st.pendingEdits} change(s) are saved on this phone and will upload automatically when you are online.`, syncing: 'Syncing with Google Drive…', error: 'The last sync failed.', conflict: 'The Drive file and this phone both changed — choose which to keep.' }[st.status];
  return `<div class="bigstatus">${syncChip(st)}</div><div>${esc(text)}</div>
    ${c.lastSync ? `<div class="muted small">Last synced: ${esc(new Date(c.lastSync).toLocaleString())}</div>` : ''}
    ${c.lastError && st.status === 'error' ? `<div class="err small">${esc(c.lastError)}</div>` : ''}
    ${st.status === 'conflict' ? `<button class="btn primary" data-act="conflict">Choose version…</button>` : ''}`;
}
function vSync() {
  const c = sync.cfg;
  return `
  <div class="card" id="syncstatus">${syncStatusHtml()}</div>
  ${sync.configured() ? `<div class="row wrap pad"><button class="btn primary" data-act="sync-now">Sync now</button>${c.webLink ? `<button class="btn" data-act="open-drive">Open the Excel file in Drive</button>` : ''}</div>` : ''}
  <div class="card"><div class="h3">Connection</div>
    <label class="fl">Apps Script web app URL<input data-cfg="url" value="${esc(c.url)}" placeholder="https://script.google.com/macros/s/…/exec"></label>
    <label class="fl">Secret key (same as in the script)<input data-cfg="key" value="${esc(c.key)}" placeholder="your secret"></label>
    <label class="fl">Drive folder link (empty = My Drive)<input data-cfg="folder" value="${esc(c.folder)}" placeholder="https://drive.google.com/drive/folders/…"></label>
    <label class="fl">Excel file name<input data-cfg="name" value="${esc(c.name)}"></label>
    <label class="cb"><input type="checkbox" data-cfg="auto" ${c.auto ? 'checked' : ''}> Sync automatically (when online)</label>
    <div class="row wrap"><button class="btn primary" data-act="sync-test">Save and test connection</button></div>
    ${c.folderName ? `<div class="muted small">Connected folder: <b>${esc(c.folderName)}</b></div>` : ''}
    <div class="muted small">Each upload sends the whole workbook (about 1.6 MB). Changes upload about 12 seconds after you stop editing, when you leave the app, and every few minutes; edits made to the file in Excel are loaded back automatically.</div>
  </div>
  <div class="card"><div class="h3">One-time set-up (on a computer)</div>
    <ol class="steps">
      <li>Open <b>script.google.com</b> with the Google account whose Drive should hold the Excel file, and create a <b>New project</b>.</li>
      <li>Replace the code with the script below (<button class="btn small" data-act="copy-script">Copy script</button>) and change <code>SECRET</code> to your own password.</li>
      <li><b>Deploy → New deployment → Web app</b>. Execute as: <b>Me</b>. Who has access: <b>Anyone</b>. Deploy and allow access.</li>
      <li>Copy the <b>Web app URL</b> (ends with <code>/exec</code>) into the field above, type the same secret, paste your Drive folder link, then tap <b>Save and test connection</b>.</li>
    </ol>
    <details><summary>Show the script</summary><textarea id="scripttext" readonly rows="12">${esc(SCRIPT)}</textarea></details>
  </div>
  <div class="card"><div class="h3">Excel files and backups</div>
    <div class="row wrap">
      <button class="btn" data-act="save-xlsx">Save Excel copy to phone</button>
      <label class="btn">Load Excel file from phone<input type="file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" data-act-change="load-xlsx" hidden></label>
      <button class="btn" data-act="save-json">Back up data (.json)</button>
      <label class="btn">Restore backup file<input type="file" accept=".json,application/json" data-act-change="load-json" hidden></label>
      <button class="btn" data-act="phone-backups">Restore earlier data…</button>
    </div>
  </div>
  ${sync.configured() ? `<div class="card"><div class="h3">Manual control</div><div class="row wrap">
      <button class="btn" data-act="force-drive">Load from Drive (replace phone data)</button>
      <button class="btn" data-act="force-phone">Upload phone data (replace Drive file)</button>
      <button class="btn danger" data-act="disconnect">Disconnect Drive</button></div></div>` : ''}`;
}

// ------------------------------------------------------------------ state replacement (import / Drive)
function replaceState(st, warnings = [], from = '') {
  store.save('state-before-' + (from || 'import'), JSON.stringify(state));
  state = normalise(st);
  R = calc(state);
  persistNow();
  render();
  toast(from === 'drive' ? 'Loaded the latest Excel file from Drive' + (warnings.length ? ` (${warnings.length} cells skipped)` : '') : 'Data loaded' + (warnings.length ? ` (${warnings.length} cells skipped)` : ''), 3500);
}
function showConflict(c) {
  const n = sync.getStatus().pendingEdits;
  const when = c.modified ? new Date(c.modified).toLocaleString() : '';
  const txt = c.during ? `The Excel file in Drive changed and you edited on the phone while it was downloading, so nothing was replaced. Which version do you want to keep?` : c.neverSynced
    ? `Your Drive folder already has <b>${esc(sync.cfg.name)}</b> (last changed ${esc(when)}). Load it into the app, or replace it with the data on this phone?`
    : `The Excel file in Drive was changed somewhere else (${esc(when)}) and this phone also has ${n} change(s) not uploaded yet. Which version do you want to keep?`;
  modal(`<h3>Choose a version</h3><p>${txt}</p><div class="btns col">
    <button class="btn primary" data-x="drive">Use the Drive file (replace phone data)</button>
    <button class="btn" data-x="phone">Keep this phone's data (replace the Drive file)</button>
    <button class="btn" data-x="later">Decide later</button></div><p class="muted small">A copy of the phone data is kept before anything is replaced.</p>`, { sticky: true });
  $('#modal').querySelectorAll('[data-x]').forEach(b => b.onclick = async () => {
    closeModal();
    if (b.dataset.x === 'later') return;
    const r = await sync.resolveConflict(b.dataset.x);
    toast(r.ok ? 'Done' : 'Could not finish: ' + (r.error || r.reason));
  });
}

// ------------------------------------------------------------------ events
function setPath(obj, path, value) {
  const parts = path.split('.');
  let o = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    const k = parts[i];
    if (o[k] === undefined || o[k] === null) o[k] = /^\d+$/.test(parts[i + 1]) && Array.isArray(o) ? [] : {};
    o = o[k];
  }
  o[parts[parts.length - 1]] = value;
}
function onBind(el) {
  const path = el.dataset.bind, type = el.dataset.type;
  // the "max.X|Y" keys contain dots? no — but they contain '|' and spaces; handle max separately
  let v = el.value;
  if (type === 'pct') { v = v.trim() === '' ? 0 : Number(v.replace(',', '.')) / 100; if (!isFinite(v)) return toast('Enter a number'); }
  else if (type === 'num') { v = v.trim() === '' ? 0 : Number(v.replace(',', '.')); if (!isFinite(v)) return toast('Enter a number'); }
  else if (type === 'int') { v = Math.round(Number(v)); if (!isFinite(v)) return toast('Enter a whole number'); if (path.startsWith('settings.WK_') && (v < 1 || v > 16)) return toast('Week must be 1–16'); }
  else if (type === 'date') { if (!v) return; }
  else v = v.replace(/\s+/g, ' ').trim();
  if (path.startsWith('max.')) state.max[path.slice(4)] = v;
  else if (path.startsWith('students.') || path.startsWith('labGroups.')) {
    const p = path.split('.');
    const obj = p[0] === 'students' ? state.students[p[1]] : state.labGroups[p[1]].rows;
    const r = Number(p[p[0] === 'students' ? 2 : 3]), field = p[p.length - 1];
    obj[r] = Object.assign({}, obj[r], { [field]: v });
    if (!obj[r].reg && !obj[r].name && !obj[r].rem) delete obj[r];
  } else setPath(state, path, v);
  changed();
  if (top().v === 'settings' || ((top().v === 'students' || top().v === 'labgroups') && el.classList.contains('name'))) {
    const focusPath = document.activeElement && document.activeElement.dataset ? document.activeElement.dataset.bind : null;
    render();
    if (focusPath) { const f = document.querySelector(`[data-bind="${CSS.escape(focusPath)}"]`); if (f) f.focus(); }
  }
}
function clearRowData(kind, s, r) {
  const pages = ENTRY_PAGES.filter(p => (kind === 'sec' ? p.sec : !p.sec));
  const alsoLab = kind === 'sec' && !state.labGroups[s].custom;
  for (const p of ENTRY_PAGES) {
    if (!(pages.includes(p) || (alsoLab && !p.sec))) continue;
    const m = state.marks[sheetKey(s, p.id)];
    if (m) for (const k of Object.keys(m)) if (k.startsWith(r + ',')) delete m[k];
  }
}
function studentMenu(kind, s, r) {
  const isLab = kind === 'lab', lg = state.labGroups[s];
  const src = isLab ? (lg.custom ? lg.rows : state.students[s]) : state.students[s];
  const x = src[r] || {}, rem = isLab ? lg.rem[r] || '' : x.rem || '';
  const editable = !isLab || lg.custom;
  modal(`<h3>${isLab ? 'Lab group' : 'Section'} ${s} · row ${r + 1}</h3>
    ${editable ? `<label class="fl">Reg. No<input id="m-reg" value="${esc(x.reg || '')}"></label><label class="fl">Name<input id="m-name" value="${esc(x.name || '')}"></label>` : `<p><b>${esc(x.name || '')}</b> ${esc(x.reg || '')}</p>`}
    <label class="fl">Remarks<input id="m-rem" value="${esc(rem)}"></label>
    <div class="btns">${editable && (x.name || x.reg) ? `<button class="btn danger" data-x="del">Remove</button>` : ''}<button class="btn" data-x="cancel">Cancel</button><button class="btn primary" data-x="save">Save</button></div>`);
  $('#modal').querySelectorAll('[data-x]').forEach(b => b.onclick = async () => {
    const act = b.dataset.x;
    if (act === 'cancel') return closeModal();
    if (act === 'save') {
      const rv = $('#m-rem').value.trim();
      if (editable) {
        const nx = { reg: $('#m-reg').value.trim(), name: $('#m-name').value.replace(/\s+/g, ' ').trim() };
        if (!isLab) nx.rem = rv;
        if (nx.reg || nx.name || nx.rem) src[r] = nx; else delete src[r];
      }
      if (isLab) { if (rv) lg.rem[r] = rv; else delete lg.rem[r]; }
      closeModal(); changed(); render(); return;
    }
    if (act === 'del') {
      closeModal();
      const ok = await confirmBox('Remove student?', `${esc(x.name || x.reg)} will be removed from ${isLab ? `lab group ${s}` : `Section ${s}`}, and the attendance and marks in this row of the ${isLab ? 'lab' : 'section'} sheets${!isLab && !lg.custom ? ' (and lab group ' + s + ')' : ''} will be cleared.`, 'Remove', true);
      if (!ok) return;
      delete src[r];
      if (isLab) delete lg.rem[r];
      clearRowData(kind, s, r);
      changed(); render();
    }
  });
}
function pasteDialog(kind, s) {
  modal(`<h3>Paste a list — ${kind === 'lab' ? 'lab group' : 'Section'} ${s}</h3>
    <p class="small muted">One student per line: <b>Reg. No, Name</b> (comma or tab between them; copied Excel columns work). Lines with only a name are fine.</p>
    <textarea id="m-paste" rows="9" placeholder="24-CS-001, Ali Khan&#10;24-CS-002, Sara Ahmed"></textarea>
    <label class="cb"><input type="radio" name="pm" value="append" checked> Add to the empty rows</label>
    <label class="cb"><input type="radio" name="pm" value="replace"> Replace the whole list (marks stay with their row numbers)</label>
    <div class="btns"><button class="btn" data-x="0">Cancel</button><button class="btn primary" data-x="1">Add students</button></div>`);
  $('#modal').querySelectorAll('[data-x]').forEach(b => b.onclick = () => {
    if (b.dataset.x === '0') return closeModal();
    const mode = document.querySelector('input[name=pm]:checked').value;
    const lines = $('#m-paste').value.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
    const recs = lines.map(l => {
      let p = l.split(/\t|,|;|\s{2,}/).map(x => x.trim()).filter(Boolean);
      if (p.length === 1) { const m = /^(\S*\d\S*)\s+(.+)$/.exec(p[0]); p = m ? [m[1], m[2]] : ['', p[0]]; }
      if (p.length > 2 && /^\d+$/.test(p[0])) p = p.slice(1);       // leading serial number
      let [a, bb] = p; if (bb && /\d/.test(bb) && !/\d/.test(a)) [a, bb] = [bb, a];
      return { reg: a || '', name: (bb || '').replace(/\s+/g, ' ') };
    }).filter(x => x.reg || x.name);
    const target = kind === 'lab' ? state.labGroups[s].rows : state.students[s];
    if (mode === 'replace') for (const k of Object.keys(target)) delete target[k];
    let r = 0, added = 0;
    for (const x of recs) {
      while (r < NROW && target[r] && (target[r].name || target[r].reg)) r++;
      if (r >= NROW) break;
      target[r] = Object.assign({}, target[r], x); added++; r++;
    }
    closeModal(); changed(); render();
    toast(`${added} student(s) added${added < recs.length ? ` — ${recs.length - added} did not fit (100 per list)` : ''}`);
  });
}
function weekMenu(s, page, c) {
  const rows = namedRows(s, page);
  modal(`<h3>${esc(PAGE[page].title)} · Week ${c + 1}</h3><p class="muted">${fmtDate(pageDates(state, s, page)[c], true, true)} · ${rows.length} students</p>
    <div class="btns col"><button class="btn primary" data-x="allP">Mark everyone Present</button><button class="btn" data-x="blankP">Mark the blank ones Present</button><button class="btn danger" data-x="clear">Clear this week</button><button class="btn" data-x="cancel">Cancel</button></div>`);
  $('#modal').querySelectorAll('[data-x]').forEach(b => b.onclick = () => {
    const x = b.dataset.x; closeModal();
    if (x === 'cancel') return;
    for (const row of rows) {
      const cur = getMark(state, s, page, row.r, c);
      if (x === 'allP' || (x === 'blankP' && !cur)) setMark(state, s, page, row.r, c, 'P');
      if (x === 'clear') setMark(state, s, page, row.r, c, null);
    }
    changed(); render();
  });
}
async function doAction(el) {
  const a = el.dataset.act, d = el.dataset;
  switch (a) {
    case 'sec': ui.sec = d.s; saveUi(); render(); break;
    case 'open': go({ v: 'sheet', s: d.s, page: d.page }); break;
    case 'expf': ui.exp[d.k] = d.f === 'all' || d.f === 'sum' ? d.f : Number(d.f); saveUi(); closeEditor(); render(); break;
    case 'finalv': ui.finalView = d.f; saveUi(); render(); break;
    case 'week': { const v = top(); weekMenu(v.s, v.page, Number(d.c)); break; }
    case 'ed-set': setValue(d.v); if (d.v !== '') advance(); else renderEditor(); break;
    case 'ed-quick': { const v = d.v === '' ? null : Number(d.v); setValue(v === null ? '' : v); if (v !== null) advance(); else renderEditor(); break; }
    case 'ed-half': ui.half = !ui.half; renderEditor(); break;
    case 'ed-up': if (commitInput(true)) move(-1, 0); break;
    case 'ed-down': if (commitInput(true)) move(1, 0); break;
    case 'ed-left': if (commitInput(true)) move(0, -1); break;
    case 'ed-right': if (commitInput(true)) move(0, 1); break;
    case 'ed-close': if (commitInput(true)) closeEditor(); break;
    case 'stu-sec': top().s = d.s; ui.sec = d.s; saveUi(); render(true); break;
    case 'lg-sec': top().s = d.s; ui.sec = d.s; saveUi(); render(true); break;
    case 'sched-sec': ui.schedSec = d.s; saveUi(); render(true); break;
    case 'stu-more': studentMenu(d.kind, d.s, Number(d.r)); break;
    case 'paste': pasteDialog(d.kind, d.s); break;
    case 'lg-mode': {
      const lg = state.labGroups[d.s];
      if (d.m === 'custom' && !lg.custom) {
        lg.custom = true; lg.rows = {};
        for (const [r, x] of Object.entries(state.students[d.s])) if (x && (x.reg || x.name)) lg.rows[r] = { reg: x.reg || '', name: x.name || '' };
        toast(`Copied the Section ${d.s} list — edit it as needed`);
      } else if (d.m === 'same' && lg.custom) {
        if (!(await confirmBox('Follow the section list?', `Lab group ${d.s} will use the Section ${d.s} class list again. Lab marks stay with their row numbers.`, 'Use section list'))) return;
        lg.custom = false;
      }
      changed(); render(); break;
    }
    case 'lg-copy': {
      if (!(await confirmBox('Copy the section list?', `Replace lab group ${d.s} with the Section ${d.s} class list?`, 'Copy'))) return;
      const lg = state.labGroups[d.s]; lg.rows = {};
      for (const [r, x] of Object.entries(state.students[d.s])) if (x && (x.reg || x.name)) lg.rows[r] = { reg: x.reg || '', name: x.name || '' };
      changed(); render(); break;
    }
    case 'autodate': {
      const k = d.k;
      state.settings[k] = el.checked ? null : (k === 'MIDD' ? midDate(state) : finDate(state));
      changed(); render(); break;
    }
    case 'sched-reset': delete state.schedule.dates[d.k]; changed(); render(); break;
    case 'reset': {
      if (!(await confirmBox('Erase all data?', 'All students, attendance, marks and settings on this phone will be erased. The Drive file is not deleted (it will be overwritten at the next sync unless you disconnect first). A copy is kept in the automatic backups.', 'Erase everything', true))) return;
      store.save('state-before-reset', JSON.stringify(state));
      state = defaultState(); changed(); stack = [{ v: 'home' }]; render(true); break;
    }
    case 'sync-now': { const r = await sync.syncNow({ manual: true }); toast(r.ok ? { saved: 'Uploaded to Drive', loaded: 'Loaded from Drive', checked: 'Already up to date' }[r.what] : r.reason === 'offline' ? 'You are offline — will sync when back online' : r.reason === 'conflict' ? 'Choose which version to keep' : 'Sync failed: ' + (r.error || r.reason)); render(); break; }
    case 'sync-test': {
      const before = [sync.cfg.url, sync.cfg.folder, sync.cfg.name].join('|');
      document.querySelectorAll('[data-cfg]').forEach(inp => { sync.cfg[inp.dataset.cfg] = inp.type === 'checkbox' ? inp.checked : inp.value.trim(); });
      if (!sync.cfg.name) sync.cfg.name = sync.DEFAULT_NAME;
      if (!/\.xlsx$/i.test(sync.cfg.name)) sync.cfg.name += '.xlsx';
      if (sync.cfg.folder && !sync.folderId(sync.cfg.folder)) return toast('That folder link is not recognised — paste the link of a Drive folder');
      if (before !== [sync.cfg.url, sync.cfg.folder, sync.cfg.name].join('|')) { sync.cfg.fileId = ''; sync.cfg.driveModified = 0; sync.cfg.lastMd5 = ''; sync.cfg.pendingUpload = null; }
      sync.saveCfg();
      if (!sync.configured()) return toast('Enter the web app URL and the secret key');
      toast('Testing…');
      try {
        const j = await sync.testConnection();
        toast(`Connected to ${j.user || 'Google Drive'} · folder “${j.folder ? j.folder.name : 'My Drive'}”`, 4000);
        render();
        if (!sync.cfg.lastMd5) { sync.cfg.editVersion = Math.max(sync.cfg.editVersion, sync.cfg.syncedVersion + (hasData() ? 1 : 0)); sync.saveCfg(); }
        const r = await sync.syncNow({ manual: true });
        if (r.ok) toast(r.what === 'loaded' ? 'Loaded the existing Excel file from Drive' : 'Excel file created in your Drive folder', 4000);
      } catch (e) { toast(e.message, 6000); }
      render(); break;
    }
    case 'open-drive': if (sync.cfg.webLink) openUrl(sync.cfg.webLink); break;
    case 'conflict': showConflict(sync.getStatus().conflict || {}); break;
    case 'force-drive': if (await confirmBox('Load from Drive?', 'The data on this phone will be replaced by the Excel file in Drive. A copy of the phone data is kept.', 'Load from Drive', true)) { const r = await sync.syncNow({ force: 'drive', manual: true }); toast(r.ok ? 'Loaded from Drive' : 'Failed: ' + (r.error || r.reason)); } break;
    case 'force-phone': if (await confirmBox('Replace the Drive file?', 'The Excel file in Drive will be rewritten from this phone\'s data.', 'Upload', true)) { const r = await sync.syncNow({ force: 'phone', manual: true }); toast(r.ok ? 'Uploaded to Drive' : 'Failed: ' + (r.error || r.reason)); } break;
    case 'disconnect': if (await confirmBox('Disconnect Drive?', 'The app stops syncing. Your data stays on the phone and the Excel file stays in Drive.', 'Disconnect')) { Object.assign(sync.cfg, { url: '', key: '' }); sync.forget(); sync.refresh(); render(); } break;
    case 'copy-script': {
      const ta = $('#scripttext');
      try { await navigator.clipboard.writeText(SCRIPT); toast('Script copied'); }
      catch (e) { if (ta) { ta.closest('details').open = true; ta.select(); document.execCommand('copy'); toast('Script copied'); } }
      break;
    }
    case 'save-xlsx': {
      toast('Preparing the Excel file…');
      const b64 = await buildXlsx(state);
      const ok = await saveFile(sync.cfg.name || sync.DEFAULT_NAME, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', b64);
      toast(ok ? 'Excel file saved' : 'Not saved'); break;
    }
    case 'save-json': {
      const b64 = btoa(unescape(encodeURIComponent(JSON.stringify(state))));
      const ok = await saveFile(`WDD_Register_backup_${new Date().toISOString().slice(0, 10)}.json`, 'application/json', b64);
      toast(ok ? 'Backup saved' : 'Not saved'); break;
    }
    case 'phone-backups': {
      const kept = [['state-before-drive', 'Before the last load from Drive'], ['state-before-file', 'Before the last file was loaded'], ['state-before-backup', 'Before the last backup was restored'], ['state-before-reset', 'Before “Erase all data”']]
        .filter(([k]) => store.load(k)).map(([k, label]) => `<button class="btn" data-k="${k}">${esc(label)}</button>`).join('');
      const list = store.backups();
      const fmtB = n => { const m = /state-(\d{4})(\d{2})(\d{2})-(\d{2})(\d{2})/.exec(n); return m ? `${m[3]}-${m[2]}-${m[1]} ${m[4]}:${m[5]}` : n; };
      modal(`<h3>Restore earlier data</h3>${kept ? `<p class="muted small">Copies kept before data was replaced:</p><div class="btns col">${kept}</div>` : ''}
        <p class="muted small">Automatic backups on this phone (one every 30 minutes of use, last 20):</p><div class="btns col">${list.length ? list.map(n => `<button class="btn" data-x="${esc(n)}">${esc(fmtB(n))}</button>`).join('') : '<p class="small">None yet.</p>'}<button class="btn" data-c="1">Close</button></div>`);
      $('#modal').querySelectorAll('[data-x],[data-k],[data-c]').forEach(b => b.onclick = async () => {
        closeModal(); if (b.dataset.c) return;
        const t = b.dataset.k ? store.load(b.dataset.k) : store.readBackup(b.dataset.x);
        if (t && await confirmBox('Restore this backup?', 'The current data will be replaced (a copy is kept).', 'Restore', true)) { replaceState(JSON.parse(t), [], 'backup'); sync.edited(); }
      });
      break;
    }
  }
}
async function onChangeAct(el) {
  const a = el.dataset.actChange, d = el.dataset;
  if (a === 'sched-date') { if (el.value) { state.schedule.dates[d.k] = el.value; changed(); render(); } }
  else if (a === 'sched-act') { const w = Number(d.w); const v = el.value.trim(); if (v === (MAP.schedule.activities[w - 1] || '')) delete state.schedule.activities[w]; else state.schedule.activities[w] = v; changed(); }
  else if (a === 'sched-note') { const w = Number(d.w); const v = el.value.trim(); if (v) state.schedule.notes[w] = v; else delete state.schedule.notes[w]; changed(); }
  else if (a === 'load-xlsx' || a === 'load-json') {
    const f = el.files && el.files[0]; if (!f) return;
    try {
      const buf = await f.arrayBuffer();
      let st, warnings = [];
      if (a === 'load-xlsx') ({ state: st, warnings } = await readXlsx(buf));
      else st = JSON.parse(new TextDecoder().decode(buf));
      if (await confirmBox('Replace the data on this phone?', `Load “${esc(f.name)}”? The current data will be replaced (a copy is kept).${warnings.length ? ` ${warnings.length} cells could not be read and were skipped.` : ''}`, 'Load', true)) {
        replaceState(st, warnings, 'file'); sync.edited();
      }
    } catch (e) { toast('Could not read the file: ' + e.message, 5000); }
    el.value = '';
  }
}

// ------------------------------------------------------------------ start
export function start() {
  document.addEventListener('click', e => {
    const g = e.target.closest('[data-go]');
    if (g) { e.preventDefault(); go({ v: g.dataset.go }); return; }
    const td = e.target.closest('#main td.e');
    if (td) { const v = top(); if (sel) commitInput(false); openEditor(v.s, v.page, Number(td.dataset.r), Number(td.dataset.c)); return; }
    const el = e.target.closest('[data-act]');
    if (el && el.tagName !== 'INPUT') doAction(el);
    else if (el && el.type === 'checkbox' && el.dataset.act) doAction(el);
  });
  document.addEventListener('change', e => {
    const el = e.target;
    if (el.dataset.bind) onBind(el);
    else if (el.dataset.actChange) onChangeAct(el);
    else if (el.dataset.cfg && el.type === 'checkbox') { sync.cfg.auto = el.checked; sync.saveCfg(); }
  });
  $('#backbtn').onclick = () => back();
  $('#syncbtn').onclick = () => { if (top().v !== 'sync') go({ v: 'sync' }); };
  sync.init({ getState: () => state, replaceState, hasData, onStatus: onSyncStatus, onConflict: c => { if ($('#modal').hidden) showConflict(c); } });
  $('#syncbtn').innerHTML = syncChip();
  render(true);
}
