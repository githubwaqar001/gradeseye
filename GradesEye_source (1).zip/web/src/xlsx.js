// Excel export / import. Export = built-in template (all formulas, charts, formatting) + the app's input cells.
// Import = read the input cells back from any copy of the workbook (e.g. after editing in Excel on a PC).
import JSZip from 'jszip';
import TEMPLATE from '../../gen/template.b64.js';
import { MAP, SECS, NROW, WEEKS, PAGES, ENTRY_PAGES, entryCols, defaultState, normalise, parseISO, isoOf, isNum, getMark, setMark, sheetKey, activity } from './core.js';

const FIRST = MAP.first;
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const unesc = s => String(s)
  .replace(/_x([0-9A-Fa-f]{4})_/g, (_, h) => String.fromCharCode(parseInt(h, 16)))
  .replace(/&#x([0-9a-fA-F]+);/g, (_, h) => String.fromCodePoint(parseInt(h, 16)))
  .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(Number(d)))
  .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
const colIdx = c => c.split('').reduce((a, ch) => a * 26 + ch.charCodeAt(0) - 64, 0);
const splitRef = ref => { const m = /^([A-Z]+)(\d+)$/.exec(ref); return [m[1], Number(m[2])]; };
export const toSerial = iso => parseISO(iso) / 86400000 + 25569;
export const fromSerial = n => isoOf(Math.round((Number(n) - 25569) * 86400000));

async function sheetPaths(zip) {
  const wb = await zip.file('xl/workbook.xml').async('string');
  const rels = await zip.file('xl/_rels/workbook.xml.rels').async('string');
  const target = {};
  for (const m of rels.matchAll(/<Relationship\b[^>]*>/g)) {
    const id = /\bId="([^"]+)"/.exec(m[0]), t = /\bTarget="([^"]+)"/.exec(m[0]);
    if (id && t) target[id[1]] = t[1].startsWith('/') ? t[1].slice(1) : 'xl/' + t[1].replace(/^\.\//, '');
  }
  const out = {};
  for (const m of wb.matchAll(/<(?:\w+:)?sheet\b[^>]*>/g)) {
    const name = /\bname="([^"]*)"/.exec(m[0]), rid = /\br:id="([^"]+)"/.exec(m[0]) || /\b\w+:id="([^"]+)"/.exec(m[0]);
    if (name && rid) out[unesc(name[1])] = target[rid[1]];
  }
  return out;
}

// ------------------------------------------------------------------ export
function cellXml(ref, style, spec) {
  const s = style ? ` s="${style}"` : '';
  if (spec === null || spec === undefined || spec === '') return `<c r="${ref}"${s}/>`;
  if (typeof spec === 'number') return isFinite(spec) ? `<c r="${ref}"${s}><v>${spec}</v></c>` : `<c r="${ref}"${s}/>`;
  return `<c r="${ref}"${s} t="inlineStr"><is><t xml:space="preserve">${esc(spec)}</t></is></c>`;
}

export function patchSheet(xml, cells) {
  const done = new Set();
  xml = xml.replace(/<c r="([A-Z]+[0-9]+)"([^>]*?)(\/>|>[\s\S]*?<\/c>)/g, (m, ref, attrs) => {
    if (!cells.has(ref)) return m;
    done.add(ref);
    const st = /\bs="(\d+)"/.exec(attrs);
    return cellXml(ref, st && st[1], cells.get(ref));
  });
  const missing = [...cells.keys()].filter(r => !done.has(r));
  if (!missing.length) return xml;
  const byRow = new Map();
  for (const ref of missing) { const [, r] = splitRef(ref); if (!byRow.has(r)) byRow.set(r, []); byRow.get(r).push(ref); }
  for (const [r, refs] of byRow) {
    const re = new RegExp(`<row r="${r}"([^>]*?)(\\/>|>([\\s\\S]*?)<\\/row>)`);
    const m = re.exec(xml);
    const add = refs.map(ref => [colIdx(splitRef(ref)[0]), cellXml(ref, null, cells.get(ref))]);
    if (m) {
      const existing = [...(m[3] || '').matchAll(/<c r="([A-Z]+)\d+"[\s\S]*?(?:\/>|<\/c>)/g)].map(x => [colIdx(x[1]), x[0]]);
      const all = existing.concat(add).sort((a, b) => a[0] - b[0]).map(x => x[1]).join('');
      xml = xml.slice(0, m.index) + `<row r="${r}"${m[1].replace(/\s*$/, '')}>${all}</row>` + xml.slice(m.index + m[0].length);
    } else {
      const rowXml = `<row r="${r}">${add.sort((a, b) => a[0] - b[0]).map(x => x[1]).join('')}</row>`;
      if (/<sheetData\s*\/>/.test(xml)) { xml = xml.replace(/<sheetData\s*\/>/, `<sheetData>${rowXml}</sheetData>`); continue; }
      let pos = -1;
      for (const x of xml.matchAll(/<row r="(\d+)"/g)) if (Number(x[1]) > r) { pos = x.index; break; }
      if (pos < 0) pos = xml.indexOf('</sheetData>');
      xml = xml.slice(0, pos) + rowXml + xml.slice(pos);
    }
  }
  return xml;
}

export function collectCells(st) {
  const edits = new Map();
  const put = (sheet, ref, v) => { if (!edits.has(sheet)) edits.set(sheet, new Map()); edits.get(sheet).set(ref, v); };
  const S = st.settings;
  for (const [k, def] of Object.entries(MAP.settings)) {
    const v = S[k];
    if (k === 'MIDD' || k === 'FIND') { if (v) put('Settings', def.cell, toSerial(v)); continue; }
    if (k === 'START') { put('Settings', def.cell, toSerial(v)); continue; }
    put('Settings', def.cell, typeof def.value === 'number' ? (isNum(Number(v)) && v !== '' ? Number(v) : 0) : String(v ?? ''));
  }
  for (const s of SECS) {
    const row = MAP.sections[s].row, x = st.sections[s];
    ['name', 'inst', 'labInst'].forEach((k, j) => put('Settings', `${'CDE'[j]}${row}`, String(x[k] ?? '')));
    put('Settings', `F${row}`, Number(x.lec) || 0); put('Settings', `G${row}`, Number(x.lab) || 0);
  }
  const gr = st.grades;
  for (let i = 0; i < MAP.grades.rows.length; i++) {
    const r = MAP.grades.first + i, g = gr[i];
    put('Settings', `I${r}`, g ? Number(g[0]) : null); put('Settings', `J${r}`, g ? String(g[1]) : null); put('Settings', `K${r}`, g ? Number(g[2]) : null);
  }
  for (const [k, def] of Object.entries(MAP.max)) put('Settings', def.cell, Number(st.max[k]) || 0);
  for (const [k, def] of Object.entries(MAP.outc)) {
    const o = st.outc[k];
    put('Settings', `C${def.row}`, String(o.code ?? '')); put('Settings', `D${def.row}`, Number(o.kpi) || 0); put('Settings', `E${def.row}`, String(o.desc ?? ''));
  }
  // schedule: overridden dates replace the formulas; activities and notes
  for (let w = 1; w <= WEEKS; w++) {
    const r = MAP.schedule.first + w - 1;
    for (const s of SECS) for (const kind of ['lec', 'lab']) {
      const o = st.schedule.dates[`${s}|${kind}|${w}`];
      if (o) put('Schedule', `${MAP.schedule.cols[s][kind]}${r}`, toSerial(o));
    }
    put('Schedule', `${MAP.schedule.activity}${r}`, String(activity(st, w) ?? ''));
    put('Schedule', `${MAP.schedule.notes}${r}`, st.schedule.notes[w] ? String(st.schedule.notes[w]) : null);
  }
  // class lists and lab groups
  for (const s of SECS) {
    const R = MAP.roster, lg = st.labGroups[s];
    for (let i = 0; i < NROW; i++) {
      const r = FIRST + i, x = st.students[s][i] || {};
      put('Students', `${R.reg[s]}${r}`, x.reg || null); put('Students', `${R.name[s]}${r}`, x.name || null); put('Students', `${R.rem[s]}${r}`, x.rem || null);
      if (lg.custom) { const y = lg.rows[i] || {}; put('Lab Groups', `${R.reg[s]}${r}`, y.reg || null); put('Lab Groups', `${R.name[s]}${r}`, y.name || null); }
      put('Lab Groups', `${R.rem[s]}${r}`, (lg.rem && lg.rem[i]) || null);
    }
  }
  // marks and attendance
  for (const s of SECS) for (const p of ENTRY_PAGES) {
    const name = sheetKey(s, p.id), cols = MAP.entries[name];
    for (let i = 0; i < NROW; i++) for (let c = 0; c < cols.length; c++) {
      const v = getMark(st, s, p.id, i, c);
      put(name, `${cols[c]}${FIRST + i}`, v === null ? null : v);
    }
  }
  return edits;
}

export async function buildXlsx(st, type = 'base64') {
  const zip = await JSZip.loadAsync(TEMPLATE, { base64: true });
  const paths = await sheetPaths(zip);
  const edits = collectCells(st);
  for (const [sheet, cells] of edits) {
    const p = paths[sheet];
    if (!p) throw new Error('Template sheet missing: ' + sheet);
    zip.file(p, patchSheet(await zip.file(p).async('string'), cells));
  }
  const now = new Date().toISOString().replace(/\.\d+Z$/, 'Z');
  const core = zip.file('docProps/core.xml');
  if (core) {
    let x = await core.async('string');
    x = x.replace(/(<dcterms:modified[^>]*>)[^<]*(<\/dcterms:modified>)/, `$1${now}$2`).replace(/(<dc:creator>)[^<]*(<\/dc:creator>)/, '$1WDD Register app$2');
    zip.file('docProps/core.xml', x);
  }
  return zip.generateAsync({ type, compression: 'DEFLATE', compressionOptions: { level: 6 }, mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
}

// ------------------------------------------------------------------ import
function parseShared(xml) {
  if (!xml) return [];
  const out = [];
  for (const m of xml.matchAll(/<si>([\s\S]*?)<\/si>|<si\/>/g)) {
    const body = (m[1] || '').replace(/<rPh\b[\s\S]*?<\/rPh>/g, '');
    out.push(unesc([...body.matchAll(/<t\b[^>]*>([\s\S]*?)<\/t>|<t\b[^>]*\/>/g)].map(x => x[1] || '').join('')));
  }
  return out;
}
function parseCells(xml, ss) {
  const cells = new Map();
  for (const m of xml.matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
    const attrs = m[1], inner = m[2] || '';
    const r = /\br="([A-Z]+\d+)"/.exec(attrs);
    if (!r) continue;
    const t = (/\bt="(\w+)"/.exec(attrs) || [])[1] || 'n';
    const f = /<f\b/.test(inner);
    const v = /<v>([\s\S]*?)<\/v>/.exec(inner);
    let val = '';
    if (t === 's') val = v ? ss[Number(v[1])] ?? '' : '';
    else if (t === 'inlineStr') val = unesc([...inner.matchAll(/<t\b[^>]*>([\s\S]*?)<\/t>/g)].map(x => x[1]).join(''));
    else if (t === 'str' || t === 'e') val = v ? unesc(v[1]) : '';
    else if (t === 'b') val = v ? v[1] === '1' : '';
    else val = v && v[1] !== '' ? Number(v[1]) : '';
    cells.set(r[1], { v: val, f });
  }
  return cells;
}

export async function readXlsx(data) {
  const zip = await JSZip.loadAsync(data, typeof data === 'string' ? { base64: true } : {});
  const paths = await sheetPaths(zip);
  for (const need of ['Settings', 'Students', 'Lab Groups']) if (!paths[need]) throw new Error(`This is not a CS-309 register workbook (sheet "${need}" not found).`);
  const ssFile = zip.file('xl/sharedStrings.xml');
  const ss = parseShared(ssFile ? await ssFile.async('string') : '');
  const cache = {};
  const sheet = async name => {
    if (!cache[name]) cache[name] = paths[name] ? parseCells(await zip.file(paths[name]).async('string'), ss) : new Map();
    return cache[name];
  };
  const st = defaultState(), warn = [];
  const S = await sheet('Settings');
  const get = (sh, ref) => sh.get(ref) || { v: '', f: false };
  const txt = v => (v === '' || v === null || v === undefined ? '' : typeof v === 'number' ? String(v) : String(v).trim());
  for (const [k, def] of Object.entries(MAP.settings)) {
    const c = get(S, def.cell);
    if (k === 'MIDD' || k === 'FIND') { st.settings[k] = !c.f && isNum(c.v) ? fromSerial(c.v) : null; continue; }
    if (k === 'START') { if (isNum(c.v)) st.settings.START = fromSerial(c.v); continue; }
    if (typeof def.value === 'number') { if (isNum(c.v)) st.settings[k] = c.v; }
    else if (c.v !== '') st.settings[k] = String(c.v);
  }
  for (const s of SECS) {
    const row = MAP.sections[s].row, x = st.sections[s];
    ['name', 'inst', 'labInst'].forEach((k, j) => { const v = get(S, `${'CDE'[j]}${row}`).v; if (v !== '') x[k] = txt(v); });
    const lec = get(S, `F${row}`).v, lab = get(S, `G${row}`).v;
    if (isNum(lec)) x.lec = lec; if (isNum(lab)) x.lab = lab;
  }
  const grades = [];
  for (let i = 0; i < MAP.grades.rows.length; i++) {
    const r = MAP.grades.first + i, mn = get(S, `I${r}`).v, g = get(S, `J${r}`).v, gp = get(S, `K${r}`).v;
    if (isNum(mn) && g !== '') grades.push([mn, txt(g), isNum(gp) ? gp : 0]);
  }
  if (grades.length) st.grades = grades;
  for (const [k, def] of Object.entries(MAP.max)) { const v = get(S, def.cell).v; if (isNum(v)) st.max[k] = v; }
  for (const [k, def] of Object.entries(MAP.outc)) {
    const code = get(S, `C${def.row}`).v, kpi = get(S, `D${def.row}`).v, desc = get(S, `E${def.row}`).v;
    if (code !== '') st.outc[k].code = txt(code); if (isNum(kpi)) st.outc[k].kpi = kpi; st.outc[k].desc = txt(desc);
  }
  const SC = await sheet('Schedule');
  for (let w = 1; w <= WEEKS; w++) {
    const r = MAP.schedule.first + w - 1;
    for (const s of SECS) for (const kind of ['lec', 'lab']) {
      const c = get(SC, `${MAP.schedule.cols[s][kind]}${r}`);
      if (!c.f && isNum(c.v)) st.schedule.dates[`${s}|${kind}|${w}`] = fromSerial(c.v);
    }
    const a = txt(get(SC, `${MAP.schedule.activity}${r}`).v);
    if (a !== (MAP.schedule.activities[w - 1] || '')) st.schedule.activities[w] = a;
    const n = txt(get(SC, `${MAP.schedule.notes}${r}`).v);
    if (n) st.schedule.notes[w] = n;
  }
  const ST = await sheet('Students'), LG = await sheet('Lab Groups'), R = MAP.roster;
  for (const s of SECS) {
    for (let i = 0; i < NROW; i++) {
      const r = FIRST + i;
      const reg = txt(get(ST, `${R.reg[s]}${r}`).v), name = txt(get(ST, `${R.name[s]}${r}`).v), rem = txt(get(ST, `${R.rem[s]}${r}`).v);
      if (reg || name || rem) st.students[s][i] = { reg, name, rem };
    }
    const lg = st.labGroups[s];
    let custom = false;
    for (let i = 0; i < NROW && !custom; i++) for (const col of [R.reg[s], R.name[s]]) {
      const c = LG.get(`${col}${FIRST + i}`);
      if (!c || !c.f) { custom = true; break; }
    }
    lg.custom = custom;
    for (let i = 0; i < NROW; i++) {
      const r = FIRST + i;
      const rem = txt(get(LG, `${R.rem[s]}${r}`).v);
      if (rem) lg.rem[i] = rem;
      if (custom) {
        const cr = get(LG, `${R.reg[s]}${r}`), cn = get(LG, `${R.name[s]}${r}`), stu = st.students[s][i] || {};
        const reg = cr.f ? (txt(cr.v) || stu.reg || '') : txt(cr.v), name = cn.f ? (txt(cn.v) || stu.name || '') : txt(cn.v);
        if (reg || name) lg.rows[i] = { reg, name };
      }
    }
  }
  for (const s of SECS) for (const p of ENTRY_PAGES) {
    const name = sheetKey(s, p.id), cols = MAP.entries[name], sh = await sheet(name);
    for (let i = 0; i < NROW; i++) for (let c = 0; c < cols.length; c++) {
      const cell = sh.get(`${cols[c]}${FIRST + i}`);
      if (!cell || cell.v === '' || cell.v === null) continue;
      let v = cell.v;
      if (p.kind === 'att') {
        v = String(v).trim().toUpperCase();
        if (!['P', 'A', 'L'].includes(v)) { warn.push(`${name} ${cols[c]}${FIRST + i}: "${cell.v}" is not P, A or L`); continue; }
      } else {
        if (typeof v !== 'number') v = Number(String(v).trim());
        if (!isNum(v)) { warn.push(`${name} ${cols[c]}${FIRST + i}: "${cell.v}" is not a number`); continue; }
      }
      setMark(st, s, p.id, i, c, v);
    }
  }
  st.updated = Date.now();
  return { state: normalise(st), warnings: warn };
}

export function base64ToBytes(b64) {
  const bin = atob(b64), out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
