// Data model and calculation engine for the CS-309 WDD register.
// Every formula mirrors the Excel workbook built by build6.py, so the app and the Excel file agree.
import MAP from '../../gen/map.json';

export { MAP };
export const SECS = MAP.secs;
export const NROW = MAP.last - MAP.first + 1;          // 100 students per list
export const WEEKS = MAP.weeks;
export const NEXP = MAP.nexp;
export const TAB = { A: '#2E75B6', B: '#548235', C: '#C55A11', D: '#7030A0' };
export const TINT = { A: '#DEEBF7', B: '#E2EFDA', C: '#FBE5D6', D: '#E4DFEC' };
export const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

// ------------------------------------------------------------------ page catalogue
// kind: att | items | exam | exp | single | project | labtotal | clo | plo | final
export const PAGES = [
  { id: 'Theory Att', title: 'Theory Attendance', kind: 'att', att: 'lec', sec: true, group: 'Attendance' },
  { id: 'Lab Att', title: 'Lab Attendance', kind: 'att', att: 'lab', sec: false, group: 'Attendance' },
  { id: 'Quizzes', title: 'Quizzes', kind: 'items', sec: true, group: 'Theory assessments', color: '#C00000' },
  { id: 'Assignments', title: 'Assignments', kind: 'items', sec: true, group: 'Theory assessments', color: '#7030A0' },
  { id: 'Mid Exam', title: 'Mid-Term Exam', kind: 'exam', sec: true, group: 'Theory assessments', color: '#2F5597' },
  { id: 'Final Exam', title: 'Final Exam', kind: 'exam', sec: true, group: 'Theory assessments', color: '#833C0B' },
  { id: 'Lab Perf', title: 'Lab Performance', kind: 'exp', sec: false, group: 'Lab assessments', rub: 'Lab Perf', mk: 'M_PERF', color: '#5B9BD5' },
  { id: 'Lab Reports', title: 'Lab Reports', kind: 'exp', sec: false, group: 'Lab assessments', rub: 'Lab Reports', mk: 'M_REP', color: '#9E7BC4' },
  { id: 'Lab Mid', title: 'Lab Mid Exam', kind: 'single', sec: false, group: 'Lab assessments', rub: 'Lab Mid', mk: 'M_LMID', wk: 'WK_LMID', color: '#2F5597' },
  { id: 'Lab Final', title: 'Lab Final Exam', kind: 'single', sec: false, group: 'Lab assessments', rub: 'Lab Final', mk: 'M_LFIN', wk: 'WK_LFIN', color: '#833C0B' },
  { id: 'OEL', title: 'Open-Ended Lab', kind: 'single', sec: false, group: 'Lab assessments', rub: 'OEL', mk: 'M_OEL', wk: 'WK_OEL', color: '#B45F06' },
  { id: 'Project', title: 'Project', kind: 'project', sec: false, group: 'Lab assessments', color: '#1F7A5A' },
  { id: 'Lab Total', title: 'Lab Total', kind: 'labtotal', sec: false, group: 'Totals, outcomes and result' },
  { id: 'CLO', title: 'CLO Sheet', kind: 'clo', sec: false, group: 'Totals, outcomes and result' },
  { id: 'PLO', title: 'PLO Sheet', kind: 'plo', sec: false, group: 'Totals, outcomes and result' },
  { id: 'Final Sheet', title: 'Final Sheet', kind: 'final', sec: true, group: 'Totals, outcomes and result' },
];
export const PAGE = Object.fromEntries(PAGES.map(p => [p.id, p]));
export const ENTRY_PAGES = PAGES.filter(p => ['att', 'items', 'exam', 'exp', 'single', 'project'].includes(p.kind));

// columns of each entry page: [{label, maxKey, group}]
export function entryCols(pageId) {
  const p = PAGE[pageId];
  if (p.kind === 'att') return Array.from({ length: WEEKS }, (_, w) => ({ label: `Week ${w + 1}`, week: w + 1 }));
  if (p.kind === 'items' || p.kind === 'exam') return MAP.theory[pageId].map(it => ({ label: it, maxKey: `${pageId}|${it}` }));
  if (p.kind === 'exp') {
    const parts = MAP.rubric[p.rub].parts, out = [];
    for (let e = 1; e <= NEXP; e++) parts.forEach(([ab, lab]) => out.push({ label: ab, long: lab, maxKey: `${p.rub}|${ab}`, exp: e }));
    return out;
  }
  if (p.kind === 'single') return MAP.rubric[p.rub].parts.map(([ab, lab]) => ({ label: lab, short: ab, maxKey: `${p.rub}|${ab}` }));
  if (p.kind === 'project') return [
    ...MAP.rubric['Project Design'].parts.map(([ab, lab]) => ({ label: lab, short: ab, maxKey: `Project Design|${ab}`, block: 'des' })),
    ...MAP.rubric['Project Viva'].parts.map(([ab, lab]) => ({ label: lab, short: ab, maxKey: `Project Viva|${ab}`, block: 'viva' })),
  ];
  return [];
}

// ------------------------------------------------------------------ default state
export function defaultState() {
  const settings = {};
  for (const [k, v] of Object.entries(MAP.settings)) settings[k] = typeof v.value === 'string' && v.value.startsWith('=') ? null : v.value;
  const sections = {};
  for (const s of SECS) {
    const [name, inst, labInst, lec, lab] = MAP.sections[s].values;
    sections[s] = { name, inst, labInst, lec, lab };
  }
  const max = {};
  for (const [k, v] of Object.entries(MAP.max)) max[k] = v.value;
  const outc = {};
  for (const [k, v] of Object.entries(MAP.outc)) outc[k] = { code: v.code, kpi: v.kpi, desc: v.desc };
  return {
    version: 1,
    settings, sections, max, outc,
    grades: MAP.grades.rows.map(r => r.slice()),
    schedule: { dates: {}, notes: {}, activities: {} },
    students: Object.fromEntries(SECS.map(s => [s, {}])),
    labGroups: Object.fromEntries(SECS.map(s => [s, { custom: false, rows: {}, rem: {} }])),
    marks: {},
    updated: Date.now(),
  };
}

// fill in anything missing (older saves, imports)
export function normalise(st) {
  const d = defaultState();
  const out = Object.assign({}, d, st || {});
  out.settings = Object.assign({}, d.settings, st && st.settings);
  out.max = Object.assign({}, d.max, st && st.max);
  for (const k of ['sections', 'outc']) {
    out[k] = {};
    for (const key of Object.keys(d[k])) out[k][key] = Object.assign({}, d[k][key], st && st[k] && st[k][key]);
  }
  if (!Array.isArray(out.grades) || !out.grades.length) out.grades = d.grades;
  out.schedule = Object.assign({ dates: {}, notes: {}, activities: {} }, st && st.schedule);
  out.students = Object.assign({}, d.students, st && st.students);
  out.labGroups = Object.assign({}, d.labGroups, st && st.labGroups);
  for (const s of SECS) {
    out.students[s] = out.students[s] || {};
    out.labGroups[s] = Object.assign({ custom: false, rows: {}, rem: {} }, out.labGroups[s]);
  }
  out.marks = out.marks || {};
  return out;
}

// ------------------------------------------------------------------ helpers
export const isNum = v => typeof v === 'number' && isFinite(v);
const N = v => (isNum(v) ? v : 0);
export const sheetKey = (s, page) => `${s} ${page}`;
export function getMark(st, s, page, r, c) {
  const m = st.marks[sheetKey(s, page)];
  if (!m) return null;
  const v = m[`${r},${c}`];
  return v === undefined ? null : v;
}
export function setMark(st, s, page, r, c, v) {
  const k = sheetKey(s, page);
  const m = st.marks[k] || (st.marks[k] = {});
  if (v === null || v === undefined || v === '') delete m[`${r},${c}`];
  else m[`${r},${c}`] = v;
}

const DAY = 86400000;
export function parseISO(d) {
  if (!d) return null;
  const [y, m, dd] = String(d).slice(0, 10).split('-').map(Number);
  return Date.UTC(y, m - 1, dd);
}
export const isoOf = t => new Date(t).toISOString().slice(0, 10);
export function addDays(iso, n) { return isoOf(parseISO(iso) + n * DAY); }
export function fmtDate(iso, withYear = false, withDay = false) {
  if (!iso) return '';
  const d = new Date(parseISO(iso));
  const mon = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.getUTCMonth()];
  const day = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][d.getUTCDay()];
  return `${withDay ? day + ' ' : ''}${String(d.getUTCDate()).padStart(2, '0')}-${mon}${withYear ? '-' + d.getUTCFullYear() : ''}`;
}

// schedule
export function autoDate(st, s, kind, w) {
  const off = Number(st.sections[s][kind === 'lec' ? 'lec' : 'lab']) || 0;
  return addDays(st.settings.START, 7 * (w - 1) + off);
}
export function schedDate(st, s, kind, w) {
  return st.schedule.dates[`${s}|${kind}|${w}`] || autoDate(st, s, kind, w);
}
export const midDate = st => st.settings.MIDD || addDays(st.settings.START, 7 * 8);
export const finDate = st => st.settings.FIND || addDays(st.settings.START, 7 * 16);
export const activity = (st, w) => (st.schedule.activities[w] !== undefined ? st.schedule.activities[w] : MAP.schedule.activities[w - 1]);

export function pageDates(st, s, pageId) {
  const p = PAGE[pageId];
  if (p.kind === 'att') return Array.from({ length: WEEKS }, (_, i) => schedDate(st, s, p.att, i + 1));
  if (pageId === 'Quizzes') return [schedDate(st, s, 'lec', 5), schedDate(st, s, 'lec', 14)];
  if (pageId === 'Assignments') return [schedDate(st, s, 'lec', 8), schedDate(st, s, 'lec', 15)];
  if (pageId === 'Mid Exam') return [midDate(st)];
  if (pageId === 'Final Exam') return [finDate(st)];
  if (p.kind === 'exp') return Array.from({ length: NEXP }, (_, i) => schedDate(st, s, 'lab', i + 1));
  if (p.kind === 'single') return [schedDate(st, s, 'lab', Number(st.settings[p.wk]) || 1)];
  if (p.kind === 'project') return [schedDate(st, s, 'lab', Number(st.settings.WK_PROJ) || 1)];
  return [];
}

// rosters
export function secRoster(st, s) {
  const out = [];
  for (let r = 0; r < NROW; r++) {
    const x = st.students[s][r];
    out.push({ reg: (x && x.reg) || '', name: (x && x.name) || '' });
  }
  return out;
}
export function labRoster(st, g) {
  const lg = st.labGroups[g];
  if (!lg.custom) return secRoster(st, g);
  const out = [];
  for (let r = 0; r < NROW; r++) {
    const x = lg.rows[r];
    out.push({ reg: (x && x.reg) || '', name: (x && x.name) || '' });
  }
  return out;
}

export function gradeOf(st, pct) {
  if (!isNum(pct)) return '';
  const v = Math.round((pct * 100 + 1e-9) * 100) / 100;
  let g = '#N/A';
  for (const [mn, name] of st.grades) if (isNum(Number(mn)) && v >= Number(mn)) g = name;
  return g;
}
export function gradePoint(st, grade) {
  const row = st.grades.find(r => r[1] === grade);
  return row ? row[2] : '';
}

// ------------------------------------------------------------------ calculation engine
function columnHeld(st, s, page, ncol) {
  // attendance: a week counts as held once any cell in its column has an entry (Excel COUNTA over all rows)
  const held = new Array(ncol).fill(false);
  const m = st.marks[sheetKey(s, page)] || {};
  for (const k of Object.keys(m)) {
    const c = Number(k.split(',')[1]);
    const v = m[k];
    if (c < ncol && v !== null && v !== '') held[c] = true;
  }
  return held;
}
function numericHeld(st, s, page, ncol) {
  const held = new Array(ncol).fill(false);
  const m = st.marks[sheetKey(s, page)] || {};
  for (const k of Object.keys(m)) {
    const c = Number(k.split(',')[1]);
    if (c < ncol && isNum(m[k])) held[c] = true;
  }
  return held;
}
const rowVals = (st, s, page, r, ncol) => Array.from({ length: ncol }, (_, c) => getMark(st, s, page, r, c));
const sumNums = arr => arr.reduce((a, v) => a + (isNum(v) ? v : 0), 0);

export function calc(st) {
  const S = st.settings, R = { sec: {}, lab: {} };
  const maxOf = key => Number(st.max[key]) || 0;
  for (const s of SECS) {
    const sec = (R.sec[s] = { roster: secRoster(st, s) });
    const lab = (R.lab[s] = { roster: labRoster(st, s) });
    // attendance (theory uses the section list, lab uses the lab group list)
    for (const [P, kind, ros] of [['Theory Att', 'lec', sec], ['Lab Att', 'lab', lab]]) {
      const held = columnHeld(st, s, P, WEEKS), heldN = held.filter(Boolean).length;
      const rows = ros.roster.map((x, r) => {
        if (!x.name) return null;
        const v = rowVals(st, s, P, r, WEEKS).map(a => (a ? String(a).toUpperCase() : ''));
        const p = v.filter(a => a === 'P').length, l = v.filter(a => a === 'L').length, a = v.filter(a => a === 'A').length;
        const pct = heldN === 0 ? '' : (p + (String(S.LEAVE).toLowerCase() === 'yes' ? l : 0)) / heldN;
        return { P: p, L: l, A: a, pct, status: pct === '' ? '' : pct >= S.THR ? 'Eligible' : 'Short' };
      });
      const perWeek = held.map((h, w) => {
        if (!h) return { present: '', pct: '' };
        let present = 0;
        for (let r = 0; r < NROW; r++) if (String(getMark(st, s, P, r, w) || '').toUpperCase() === 'P') present++;
        const n = ros.roster.filter(x => x.name).length;
        return { present, pct: n ? present / n : '' };
      });
      ros[P] = { held, heldN, rows, perWeek };
    }
    // theory assessments
    for (const P of ['Quizzes', 'Assignments', 'Mid Exam', 'Final Exam']) {
      const cols = entryCols(P), n = cols.length, held = numericHeld(st, s, P, n);
      const items = PAGE[P].kind === 'items';
      const T7 = items ? cols.reduce((a, c, i) => a + (held[i] ? maxOf(c.maxKey) : 0), 0) : cols.reduce((a, c) => a + maxOf(c.maxKey), 0);
      const any = held.some(Boolean);
      const rows = sec.roster.map((x, r) => {
        if (!x.name) return null;
        const vals = rowVals(st, s, P, r, n);
        const T = items ? (T7 === 0 ? '' : sumNums(vals)) : (!any ? '' : sumNums(vals));
        return { T, pct: T === '' || T7 === 0 ? '' : T / T7 };
      });
      sec[P] = { held, T7, any, rows };
    }
    // lab assessments (lab group list)
    const named = lab.roster.map(x => !!x.name), anyNamed = named.some(Boolean);
    for (const P of ['Lab Perf', 'Lab Reports']) {
      const pg = PAGE[P], parts = MAP.rubric[pg.rub].parts, np = parts.length, n = np * NEXP;
      const cols = entryCols(P), held = numericHeld(st, s, P, n);
      const emax = parts.reduce((a, [ab]) => a + maxOf(`${pg.rub}|${ab}`), 0);
      const expHeld = Array.from({ length: NEXP }, (_, e) => held.slice(e * np, e * np + np).some(Boolean));
      const expHeldT = expHeld.map(h => h && anyNamed);
      const SUM7 = expHeldT.reduce((a, h) => a + (h ? emax : 0), 0);
      const marks = Number(S[pg.mk]) || 0;
      const rows = lab.roster.map((x, r) => {
        if (!x.name) return null;
        const vals = rowVals(st, s, P, r, n);
        const tot = expHeld.map((h, e) => (h ? sumNums(vals.slice(e * np, e * np + np)) : ''));
        const SUM = SUM7 === 0 ? '' : sumNums(tot);
        const PCT = SUM === '' ? '' : SUM / SUM7;
        return { tot, N: tot.filter(isNum).length, SUM, PCT, SC: PCT === '' ? '' : PCT * marks };
      });
      lab[P] = { held, expHeld, heldCount: expHeldT.filter(Boolean).length, emax, SUM7, marks, rows, cols };
    }
    for (const P of ['Lab Mid', 'Lab Final', 'OEL']) {
      const pg = PAGE[P], cols = entryCols(P), n = cols.length, held = numericHeld(st, s, P, n), any = held.some(Boolean);
      const T7 = cols.reduce((a, c) => a + maxOf(c.maxKey), 0), marks = Number(S[pg.mk]) || 0;
      const rows = lab.roster.map((x, r) => {
        if (!x.name) return null;
        const T = any ? sumNums(rowVals(st, s, P, r, n)) : '';
        return { T, SC: T === '' || T7 === 0 ? '' : (T / T7) * marks };
      });
      lab[P] = { held, any, T7, marks, rows };
    }
    {
      const cols = entryCols('Project'), held = numericHeld(st, s, 'Project', cols.length);
      const blocks = { des: { idx: [], key: 'P_DES' }, viva: { idx: [], key: 'P_VIVA' } };
      cols.forEach((c, i) => blocks[c.block].idx.push(i));
      for (const b of Object.values(blocks)) {
        b.held = b.idx.some(i => held[i]);
        b.T7 = b.idx.reduce((a, i) => a + maxOf(cols[i].maxKey), 0);
        b.SC7 = Number(S[b.key]) || 0;
      }
      const MP = Number(S.M_PROJ) || 0;
      const rows = lab.roster.map((x, r) => {
        if (!x.name) return null;
        const vals = rowVals(st, s, 'Project', r, cols.length), o = {};
        for (const [nm, b] of Object.entries(blocks)) {
          const T = b.held ? sumNums(b.idx.map(i => vals[i])) : '';
          o[nm] = { T, SC: T === '' || b.T7 === 0 ? '' : (T / b.T7) * b.SC7 };
        }
        const d = o.des.SC, v = o.viva.SC;
        const den = (d === '' ? 0 : blocks.des.SC7) + (v === '' ? 0 : blocks.viva.SC7);
        o.P = d === '' && v === '' ? '' : den === 0 ? '' : ((N(d) + N(v)) / den) * MP;
        return o;
      });
      lab.Project = { held, blocks, rows };
    }
    // lab total
    const comps = [['Lab Perf', 'M_PERF'], ['Lab Reports', 'M_REP'], ['Lab Final', 'M_LFIN'], ['Lab Mid', 'M_LMID'], ['OEL', 'M_OEL'], ['Project', 'M_PROJ']];
    lab['Lab Total'] = {
      comps,
      rows: lab.roster.map((x, r) => {
        if (!x.name) return null;
        const v = comps.map(([P]) => {
          const row = lab[P].rows[r];
          const val = P === 'Project' ? row.P : row.SC;
          return isNum(val) ? val : '';
        });
        const T = v.some(isNum) ? sumNums(v) : '';
        const HM = T === '' ? '' : v.reduce((a, c, i) => a + (isNum(c) ? Number(S[comps[i][1]]) || 0 : 0), 0);
        return { v, T, HM, P: T === '' || !HM ? '' : T / HM };
      }),
    };
  }
  // CLO / PLO per lab group
  for (const s of SECS) {
    const lab = R.lab[s], LT = lab['Lab Total'];
    const idx = Object.fromEntries(LT.comps.map(([P], i) => [P, i]));
    const co4 = [['Lab Perf', 'CO4_PERF', 'M_PERF'], ['Lab Mid', 'CO4_MID', 'M_LMID'], ['Lab Final', 'CO4_FIN', 'M_LFIN'], ['OEL', 'CO4_VIVA', 'M_OEL']];
    const k4 = Number(st.outc.CO4.kpi), k5 = Number(st.outc.CO5.kpi);
    lab.CLO = {
      co4,
      rows: lab.roster.map((x, r) => {
        if (!x.name) return null;
        const t = LT.rows[r];
        const v = co4.map(([P]) => t.v[idx[P]]);
        const den = co4.reduce((a, [, w], i) => a + (isNum(v[i]) ? Number(S[w]) || 0 : 0), 0);
        const num = co4.reduce((a, [, w, mk], i) => a + (isNum(v[i]) ? ((Number(S[w]) || 0) * v[i]) / (Number(S[mk]) || 1) : 0), 0);
        const CO4 = den === 0 ? '' : num / den;
        const PR = t.v[idx.Project];
        const CO5 = isNum(PR) ? PR / (Number(S.M_PROJ) || 1) : '';
        return { v, CO4, S4: CO4 === '' ? '' : CO4 >= k4 ? 'Achieved' : 'Not achieved', PR, CO5, S5: CO5 === '' ? '' : CO5 >= k5 ? 'Achieved' : 'Not achieved' };
      }),
    };
    const kp5 = Number(st.outc.PO5.kpi), kp9 = Number(st.outc.PO9.kpi);
    lab.PLO = {
      rows: lab.CLO.rows.map(c => {
        if (!c) return null;
        const PO5 = isNum(c.CO4) ? c.CO4 * (Number(S.PO5_CO4) || 0) : '';
        const PO9 = isNum(c.CO5) ? c.CO5 * (Number(S.PO9_CO5) || 0) : '';
        return { src5: c.CO4, PO5, S5: PO5 === '' ? '' : PO5 >= kp5 ? 'Achieved' : 'Not achieved', src9: c.CO5, PO9, S9: PO9 === '' ? '' : PO9 >= kp9 ? 'Achieved' : 'Not achieved' };
      }),
    };
    lab.CLO.summary = outcomeSummary([['CO4', lab.CLO.rows.map(r => r && r.CO4)], ['CO5', lab.CLO.rows.map(r => r && r.CO5)]], st);
    lab.PLO.summary = outcomeSummary([['PO5', lab.PLO.rows.map(r => r && r.PO5)], ['PO9', lab.PLO.rows.map(r => r && r.PO9)]], st);
  }
  // final sheets (section list; lab results by Reg. No from the student's lab group)
  const regIndex = SECS.map(g => R.lab[g].roster.map(x => String(x.reg).trim().toLowerCase()));
  const W = { Quizzes: 'W_Q', Assignments: 'W_A', 'Mid Exam': 'W_M', 'Final Exam': 'W_F' };
  for (const s of SECS) {
    const sec = R.sec[s], TA = sec['Theory Att'];
    sec.Final = sec.roster.map((x, r) => {
      if (!x.name) return null;
      const o = { th: {}, };
      for (const P of Object.keys(W)) { const t = sec[P].rows[r]; o.th[P] = t.T; }
      let num = 0, den = 0;
      for (const [P, w] of Object.entries(W)) { const p = sec[P].rows[r].pct; if (isNum(p)) { num += (Number(S[w]) || 0) * p; den += Number(S[w]) || 0; } }
      o.thpct = den === 0 ? '' : num / den;
      const ta = TA.rows[r];
      o.tatt = TA.heldN === 0 ? '' : `${ta.P} / ${TA.heldN}`;
      o.tattp = ta.pct; o.tatts = ta.status;
      let gi = 0, row = -1;
      const reg = String(x.reg).trim().toLowerCase();
      if (reg) for (let g = 0; g < SECS.length && !gi; g++) { const k = regIndex[g].indexOf(reg); if (k >= 0) { gi = g + 1; row = k; } }
      o.grp = gi ? SECS[gi - 1] : '—';
      o.lab = ['', '', '', '', '', '']; o.labtot = ''; o.labpct = ''; o.CO4 = ''; o.CO5 = ''; o.PO5 = ''; o.PO9 = ''; o.latt = ''; o.lattp = ''; o.latts = '';
      if (gi) {
        const L = R.lab[SECS[gi - 1]], lt = L['Lab Total'].rows[row];
        if (lt) {
          o.lab = lt.v.slice(); o.labtot = lt.T; o.labpct = lt.P;
          const c = L.CLO.rows[row], p = L.PLO.rows[row];
          o.CO4 = c.CO4; o.CO5 = c.CO5; o.PO5 = p.S5; o.PO9 = p.S9;
          const la = L['Lab Att'], lr = la.rows[row];
          o.latt = la.heldN === 0 ? '' : `${lr.P} / ${la.heldN}`;
          o.lattp = lr.pct; o.latts = lr.status;
        } else {
          o.latt = L['Lab Att'].heldN === 0 ? '' : ` / ${L['Lab Att'].heldN}`;
        }
      }
      const tp = o.thpct, lp = o.labpct;
      o.ct = tp === '' && lp === '' ? '' :
        ((isNum(tp) ? (Number(S.SH_T) || 0) * tp : 0) + (isNum(lp) ? (Number(S.SH_L) || 0) * lp : 0)) /
        ((isNum(tp) ? Number(S.SH_T) || 0 : 0) + (isNum(lp) ? Number(S.SH_L) || 0 : 0));
      o.grade = gradeOf(st, o.ct);
      o.rem = !x.reg ? 'Reg. No missing' : o.grp === '—' ? 'Not in any lab group' :
        o.tatts === 'Short' && o.latts === 'Short' ? 'Short attendance: theory and lab' :
        o.tatts === 'Short' ? 'Short attendance: theory' : o.latts === 'Short' ? 'Short attendance: lab' : '';
      return o;
    });
  }
  R.results = sectionResults(st, R);
  return R;
}

export function stats(values) {
  const v = values.filter(isNum);
  if (!v.length) return { avg: '', max: '', min: '', n: 0 };
  return { avg: v.reduce((a, b) => a + b, 0) / v.length, max: Math.max(...v), min: Math.min(...v), n: v.length };
}

function outcomeSummary(list, st) {
  return list.map(([key, vals]) => {
    const kpi = Number(st.outc[key].kpi), v = vals.filter(isNum);
    const avg = v.length ? v.reduce((a, b) => a + b, 0) / v.length : '';
    const ge = v.filter(x => x >= kpi).length;
    return { key, code: st.outc[key].code, kpi, avg, n: v.length, ge, share: v.length ? ge / v.length : '', result: v.length ? (avg >= kpi ? 'Attained' : 'Not attained') : '' };
  });
}

function sectionResults(st, R) {
  const fin = s => R.sec[s].Final.filter(Boolean);
  const col = (s, f) => fin(s).map(f);
  const all = f => SECS.flatMap(s => col(s, f));
  const avgOf = a => stats(a).avg;
  const count = (a, val) => a.filter(x => x === val).length;
  const share = (a, kpi) => { const v = a.filter(isNum); return v.length ? v.filter(x => x >= kpi).length / v.length : ''; };
  const ach = a => { const n = a.filter(x => x === 'Achieved' || x === 'Not achieved').length; return n ? count(a, 'Achieved') / n : ''; };
  const graded = a => a.filter(x => x !== '' && x !== null && x !== undefined);
  const rows = [];
  const add = (label, f, allf, fmt, bar) => rows.push({ label, vals: SECS.map(f), all: allf, fmt, bar });
  const head = label => rows.push({ head: label });
  head('Enrolment and classes');
  add('Students in section', s => fin(s).length, SECS.reduce((a, s) => a + fin(s).length, 0), 'int');
  add('Lectures held', s => R.sec[s]['Theory Att'].heldN, '', 'int');
  add('Labs held (lab group of the same letter)', s => R.lab[s]['Lab Att'].heldN, '', 'int');
  head('Attendance');
  add('Average theory attendance %', s => avgOf(col(s, o => o.tattp)), avgOf(all(o => o.tattp)), 'pct', true);
  add('Students short in theory attendance', s => count(col(s, o => o.tatts), 'Short'), count(all(o => o.tatts), 'Short'), 'int');
  add('Average lab attendance %', s => avgOf(col(s, o => o.lattp)), avgOf(all(o => o.lattp)), 'pct', true);
  add('Students short in lab attendance', s => count(col(s, o => o.latts), 'Short'), count(all(o => o.latts), 'Short'), 'int');
  head('Theory marks (class averages)');
  for (const [P, lab] of [['Quizzes', 'Quizzes'], ['Assignments', 'Assignments'], ['Mid Exam', 'Mid exam'], ['Final Exam', 'Final exam']]) {
    const anyHeld = SECS.some(s => R.sec[s][P].rows.some(r => r && isNum(r.T)));
    const hm = Math.max(...SECS.map(s => R.sec[s][P].T7));
    add(anyHeld ? `${lab} (out of ${fmtNum(hm)})` : `${lab} (not held yet)`, s => avgOf(col(s, o => o.th[P])), avgOf(all(o => o.th[P])), 'num');
  }
  add('Theory %', s => avgOf(col(s, o => o.thpct)), avgOf(all(o => o.thpct)), 'pct', true);
  head('Lab marks (class averages)');
  const S = st.settings;
  [['Lab performance', 'M_PERF'], ['Lab Reports', 'M_REP'], ['Lab Final', 'M_LFIN'], ['Lab Mid', 'M_LMID'], ['OEL', 'M_OEL'], ['Project', 'M_PROJ']].forEach(([lab, mk], i) =>
    add(`${lab} (out of ${fmtNum(S[mk])})`, s => avgOf(col(s, o => o.lab[i])), avgOf(all(o => o.lab[i])), 'num'));
  const mt = ['M_PERF', 'M_REP', 'M_LFIN', 'M_LMID', 'M_OEL', 'M_PROJ'].reduce((a, k) => a + (Number(S[k]) || 0), 0);
  add(`Lab total (out of ${fmtNum(mt)})`, s => avgOf(col(s, o => o.labtot)), avgOf(all(o => o.labtot)), 'num');
  add('Lab %', s => avgOf(col(s, o => o.labpct)), avgOf(all(o => o.labpct)), 'pct', true);
  head('Course and programme learning outcomes');
  const outRows = {};
  for (const [k, f] of [['CO4', o => o.CO4], ['CO5', o => o.CO5]]) {
    const kpi = Number(st.outc[k].kpi);
    add(`Average ${st.outc[k].code} attainment`, s => avgOf(col(s, f)), avgOf(all(f)), 'pct', true);
    add(`Students achieving ${st.outc[k].code} (≥ KPI)`, s => share(col(s, f), kpi), share(all(f), kpi), 'pct', true);
    outRows[k] = rows[rows.length - 1];
  }
  for (const [k, f] of [['PO5', o => o.PO5], ['PO9', o => o.PO9]]) {
    add(`Students achieving ${st.outc[k].code}`, s => ach(col(s, f)), ach(all(f)), 'pct', true);
    outRows[k] = rows[rows.length - 1];
  }
  head('Result');
  add('Average course total %', s => avgOf(col(s, o => o.ct)), avgOf(all(o => o.ct)), 'pct', true);
  add('Highest course total %', s => stats(col(s, o => o.ct)).max, stats(all(o => o.ct)).max, 'pct', true);
  add('Lowest course total %', s => stats(col(s, o => o.ct)).min, stats(all(o => o.ct)).min, 'pct', true);
  const passed = a => graded(a).length - count(a, 'F');
  add('Students passed (grade D or better)', s => passed(col(s, o => o.grade)), passed(all(o => o.grade)), 'int');
  add('Students failed (F)', s => count(col(s, o => o.grade), 'F'), count(all(o => o.grade), 'F'), 'int');
  const rate = a => (graded(a).length ? passed(a) / graded(a).length : '');
  add('Pass rate', s => rate(col(s, o => o.grade)), rate(all(o => o.grade)), 'pct', true);
  const outcomes = ['CO4', 'CO5', 'PO5', 'PO9'].map(k => ({ code: st.outc[k].code, vals: outRows[k].vals, all: outRows[k].all }));
  const grades = st.grades.slice().reverse().map(([, g]) => ({ g, vals: SECS.map(s => count(col(s, o => o.grade), g)) }));
  grades.forEach(x => (x.all = x.vals.reduce((a, b) => a + b, 0)));
  return { rows, outcomes, grades };
}

export function fmtNum(v, dp = 2) {
  if (!isNum(v)) return v === null || v === undefined ? '' : String(v);
  const r = Math.round(v * 10 ** dp) / 10 ** dp;
  return String(r);
}
export const fmtPct = (v, dp = 1) => (isNum(v) ? (v * 100).toFixed(dp) + '%' : '');
