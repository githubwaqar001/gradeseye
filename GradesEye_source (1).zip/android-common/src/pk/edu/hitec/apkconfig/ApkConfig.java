package pk.edu.hitec.apkconfig;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Arrays;

/**
 * A small piece of data (the class connection: Drive-script address + teacher name) kept inside the
 * "APK Signing Block" of the student app. The APK signature (v2/v3) does not cover this block's extra
 * ID-value pairs, so the teacher app can write a different connection into the same signed APK without
 * re-signing it, and the student app reads it back from its own installed APK file.
 * Format of the block: uint64 size, ID-value pairs (uint64 length, uint32 id, value), uint64 size, "APK Sig Block 42".
 */
public final class ApkConfig {
    public static final int ID = 0x57444453;               // "WDDS"
    private static final int PADDING_ID = 0x42726577;      // apksigner's alignment padding
    private static final byte[] MAGIC = {'A', 'P', 'K', ' ', 'S', 'i', 'g', ' ', 'B', 'l', 'o', 'c', 'k', ' ', '4', '2'};
    private static final int MAX_VALUE = 16 * 1024;

    private ApkConfig() {
    }

    private static long u32(byte[] a, int o) {
        return (a[o] & 0xFFL) | (a[o + 1] & 0xFFL) << 8 | (a[o + 2] & 0xFFL) << 16 | (a[o + 3] & 0xFFL) << 24;
    }

    private static int u16(byte[] a, int o) {
        return (a[o] & 0xFF) | (a[o + 1] & 0xFF) << 8;
    }

    private static long u64(byte[] a, int o) {
        return u32(a, o) | u32(a, o + 4) << 32;
    }

    private static void put32(byte[] a, int o, long v) {
        for (int i = 0; i < 4; i++) a[o + i] = (byte) (v >>> (8 * i));
    }

    private static void put64(byte[] a, int o, long v) {
        for (int i = 0; i < 8; i++) a[o + i] = (byte) (v >>> (8 * i));
    }

    private static void w32(ByteArrayOutputStream out, long v) {
        byte[] b = new byte[4];
        put32(b, 0, v);
        out.write(b, 0, 4);
    }

    private static void w64(ByteArrayOutputStream out, long v) {
        byte[] b = new byte[8];
        put64(b, 0, v);
        out.write(b, 0, 8);
    }

    /** offset of the End Of Central Directory record inside the tail of a ZIP file, or -1 */
    private static int eocd(byte[] tail) {
        for (int i = tail.length - 22; i >= 0; i--) {
            if (u32(tail, i) == 0x06054b50L && u16(tail, i + 20) == tail.length - i - 22) return i;
        }
        return -1;
    }

    private static boolean magicAt(byte[] a, int o) {
        if (o < 0 || o + 16 > a.length) return false;
        for (int i = 0; i < 16; i++) if (a[o + i] != MAGIC[i]) return false;
        return true;
    }

    /** a copy of the signed APK whose signing block also carries {@code value} under {@link #ID} */
    public static byte[] inject(byte[] apk, byte[] value) throws IOException {
        if (value.length > MAX_VALUE) throw new IOException("Connection data is too large");
        int e = eocd(apk);
        if (e < 0) throw new IOException("Not an APK file");
        long cd = u32(apk, e + 16);
        if (cd < 32 || cd > e || !magicAt(apk, (int) cd - 16)) throw new IOException("The APK has no v2/v3 signature block");
        long size = u64(apk, (int) cd - 24);
        long startL = cd - size - 8;
        if (size < 24 || startL < 0 || u64(apk, (int) startL) != size) throw new IOException("Damaged signature block");
        int start = (int) startL, p = start + 8, end = (int) cd - 24;
        ByteArrayOutputStream pairs = new ByteArrayOutputStream();
        boolean padded = false;
        while (p < end) {
            long len = u64(apk, p);
            if (len < 4 || p + 8 + len > end) throw new IOException("Damaged signature block");
            int id = (int) u32(apk, p + 8);
            if (id == PADDING_ID) padded = true;
            else if (id != ID) pairs.write(apk, p, (int) (8 + len));
            p += (int) (8 + len);
        }
        w64(pairs, 4 + value.length);
        w32(pairs, ID);
        pairs.write(value, 0, value.length);
        byte[] body = pairs.toByteArray();
        int total = 8 + body.length + 8 + 16;
        byte[] pad = null;
        if (padded && total % 4096 != 0) {                  // keep the block a multiple of 4096 bytes, as apksigner made it
            int n = 4096 - total % 4096;
            if (n < 12) n += 4096;
            pad = new byte[n];
            put64(pad, 0, n - 8);
            put32(pad, 8, PADDING_ID);
            total += n;
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream(apk.length + total);
        out.write(apk, 0, start);                          // ZIP entries (unchanged)
        w64(out, total - 8);
        out.write(body, 0, body.length);
        if (pad != null) out.write(pad, 0, pad.length);
        w64(out, total - 8);
        out.write(MAGIC, 0, 16);
        int newCd = out.size();
        out.write(apk, (int) cd, e - (int) cd);            // central directory (unchanged)
        byte[] eo = Arrays.copyOfRange(apk, e, apk.length);
        put32(eo, 16, newCd);                              // EOCD: new offset of the central directory
        out.write(eo, 0, eo.length);
        return out.toByteArray();
    }

    /** the value stored under {@link #ID} in this APK file, or null */
    public static byte[] read(File apk) {
        RandomAccessFile f = null;
        try {
            f = new RandomAccessFile(apk, "r");
            long len = f.length();
            int tailLen = (int) Math.min(len, 65535 + 22);
            byte[] tail = new byte[tailLen];
            f.seek(len - tailLen);
            f.readFully(tail);
            int e = eocd(tail);
            if (e < 0) return null;
            long cd = u32(tail, e + 16);
            if (cd < 32) return null;
            byte[] foot = new byte[24];
            f.seek(cd - 24);
            f.readFully(foot);
            if (!magicAt(foot, 8)) return null;
            long size = u64(foot, 0);
            if (size < 24 || size > 8L * 1024 * 1024 || cd - size - 8 < 0) return null;
            byte[] block = new byte[(int) size - 24];          // the pairs
            f.seek(cd - size);
            f.readFully(block);
            int p = 0;
            while (p + 12 <= block.length) {
                long n = u64(block, p);
                if (n < 4 || p + 8 + n > block.length) return null;
                if ((int) u32(block, p + 8) == ID) return Arrays.copyOfRange(block, p + 12, (int) (p + 8 + n));
                p += (int) (8 + n);
            }
            return null;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                if (f != null) f.close();
            } catch (IOException ignored) {
            }
        }
    }
}
