# GradesEye — Android apps and website (faculty app v1.4, GradesEye Student v1.1, Drive script v5)
© 2026 softonicBank Co. All rights reserved.

Faculty app (package `pk.edu.hitec.wddregister`, kept so updates install over earlier versions): semesters → sections → courses/labs,
Excel registers in Drive, student app with PINs, list of students who have signed in.
Student app (package `pk.edu.hitec.wddstudent`): own attendance and marks; sign in with Reg. No + PIN, then an own password.

What is in this folder
- `android/` — faculty app native shell (Java, no Gradle needed): WebView + bridge for storage, Apps Script calls, file save/open,
  and making / sharing a pre-linked copy of the student app (`ShareProvider.java`).
- `android-student/` — GradesEye Student native shell (package `pk.edu.hitec.wddstudent`); reads its class connection from its own APK.
- `android-common/` — `ApkConfig.java`: writes / reads the class connection (script URL + teacher name, never the key) in the
  APK Signing Block, so the teacher app can link the signed student APK without re-signing it (verified with apksigner v2/v3).
- `web-student/src/` — the student app (sign-in with Reg. No + PIN or own password, change password, attendance, marks, result, offline copy).
- `web2/src/portal.js` — per-course student summaries, PINs (8 characters, sent to Drive only as salted SHA-256), publishing.
- `web2/src/` — the app (v1.1): model (semesters, sections, courses), layout from each course plan, calculation engine,
  Excel workbook generator (`workbook.js` + `xlsxwriter.js`, runs in a Web Worker), Excel reader (`ximport.js`), multi-file Drive sync, screens (`ui.js`).
- `web/src/` — the first single-course version (v1.0), kept for reference.
- `apps-script/Code.gs` — the Google Apps Script (version 4): Excel files in your Drive folder, plus the student endpoint
  (one student's own record after Reg. No + PIN or own password; own passwords stored as salted, repeated SHA-256 and voided by a
  new PIN; sign-in tokens; 6 wrong tries → 15-minute lock; sign-in records for the faculty app). Older versions: `Code_v1.gs` … `Code_v3.gs`.
- `gen/` — the Excel template the app fills (`template.xlsx`) and the map of its input cells (`map.json`).
- `tools_build_workbook.py` — builds the template + map (`TEMPLATE=1 OUT=gen/template.xlsx MAP=gen/map.json python3 tools_build_workbook.py`).
- `keystore/` — the signing key of the app and its password. KEEP THIS SAFE: an update of the app installs over the
  old one (keeping its data) only if it is signed with this same key.

Rebuilding the APKs (Linux)
1. `cd web2 && npm install jszip@3.10.1 esbuild@0.24.0 && node build.mjs && node build_student.mjs` → `dist2/index.html`, `dist-student/index.html`
2. Tools: android.jar (API 33), aapt2 (from Apktool's jar), dx (from dex2jar), uber-apk-signer — paths are at the top of `build_apk.sh`.
3. Student app first (the teacher app bundles it):
   `KSPASS=$(cat keystore/password.txt) APP=student VERSION_CODE=2 VERSION_NAME=1.1 ./build_apk.sh` → `out/GradesEye_Student.apk`
   `KSPASS=$(cat keystore/password.txt) APP=teacher VERSION_CODE=4 VERSION_NAME=1.3 ./build_apk.sh` → `out/GradesEye_Faculty.apk`
   Raise VERSION_CODE for every update. All copies of GradesEye Student share one package name, so a phone holds one linked copy at a time.

Tests: `web2/test/plans_test.js` + `compare_plans.py` (four different course plans: app calculations vs LibreOffice recalculation, read-back round trip),
`web2/test/ui_test.py` (phone-sized browser run with a mock Drive script: semesters, sections, three courses, Drive files in sub-folders, offline queue, PC edits, conflicts, migration from v1.0),
`web2/test/portal_test.js` + `portal_compare.py` (student summaries vs LibreOffice-recalculated Excel), `web2/test/portal_ui_test.py`
(teacher turns on the student app → PINs, slips, release → student sign-in, attendance, marks, result, offline, new PIN, hidden course,
class code, sign-out race, own password, faculty sign-in list, switched off). The Apps Script itself was exercised in Node with stand-ins for Drive, Cache and Properties.

Website (folder `site/` in this archive)
- `site/src/page.html` — product page; `site/src/signin.html` — sign-in page with the student and faculty dashboards (and demos).
- `python3 site/build.py` → `site/dist/site/` (index.html, signin.html, downloads/). Upload that folder to any static host (GitHub Pages,
  Netlify, a university web server). Sign-in talks straight to the teacher's Drive script from the browser; nothing else is needed.
- Optional: paste your class code into `SITE_CLASS_CODE` near the end of signin.html so visitors are linked without typing it,
  or share links like `signin.html?c=GE1-…`.
- Faculty dashboard: the faculty app (Drive and app settings → Website dashboard) sets a dashboard password and publishes a summary of
  every synced course; the website shows it read-only after sign-in with that password. Tests: `web2/test/web_test.py`.
