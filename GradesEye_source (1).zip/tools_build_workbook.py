"""CS-309 WDD register, sections A–D: attendance, a separate sheet for every assessment (theory and lab rubric),
Lab Total (33), CLO and PLO sheets with charts, a combined Final Sheet per section, Section Results and a Home page."""
import datetime as dt
import os, json
APP = os.environ.get('TEMPLATE') == '1'      # clean template for the Android app (no example row) + input-cell map
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter as L, column_index_from_string as CI
from openpyxl.formatting.rule import DataBarRule, CellIsRule, FormulaRule
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.comments import Comment
from openpyxl.worksheet.properties import PageSetupProperties
from openpyxl.worksheet.hyperlink import Hyperlink
from openpyxl.chart import BarChart, Reference
from openpyxl.chart.label import DataLabelList

OUT = os.environ.get('OUT', '/home/claude/attendance/v5/CS309_WDD_Attendance_and_Marks_Fall2026.xlsx')
SECS = ['A', 'B', 'C', 'D']
TAB = {'A': '2E75B6', 'B': '548235', 'C': 'C55A11', 'D': '7030A0'}
TINT = {'A': 'DEEBF7', 'B': 'E2EFDA', 'C': 'FBE5D6', 'D': 'E4DFEC'}
WEEKS, NSTU, NEXP = 16, 100, 14
FIRST, LAST = 8, 8 + NSTU - 1
NAVY, LIGHT, GREY, YELLOW, MAXF = '1F3864', 'D9E2F3', 'F2F2F2', 'FFF2CC', 'E2EFDA'
WEEKFILL = ['FFFFFF', 'EEF3FA']
BLUE = '0000FF'
F = lambda **k: Font(name='Arial', size=k.pop('size', 10), **k)
fill = lambda c: PatternFill('solid', start_color=c, end_color=c)
thin = Side(style='thin', color='A6B4C8')
BOX = Border(left=thin, right=thin, top=thin, bottom=thin)
C = Alignment(horizontal='center', vertical='center', wrap_text=True)
LFT = Alignment(horizontal='left', vertical='center', wrap_text=True)
RGT = Alignment(horizontal='right', vertical='center')
bar = lambda color, mx=1: DataBarRule(start_type='num', start_value=0, end_type='num', end_value=mx, color=color, showValue=True)
q = lambda name: f"'{name}'"
RANGE = lambda col: f'{col}${FIRST}:{col}${LAST}'
HELD = lambda col: f'(COUNT({col}${FIRST}:{col}${LAST})>0)'          # assessment counts once anyone has marks

LABS = ['Introduction to HTML', 'HTML Tables and HTML Form Elements', 'Introduction to CSS',
        'CSS Selectors, Positioning and Pseudo-classes', 'CSS Box Model and Layout', 'JavaScript and the HTML DOM',
        'Introduction to jQuery', 'Bootstrap Components and Buttons', 'Bootstrap Theme', 'Bootstrap Template and Framework',
        'PHP Basics', 'Form Handling in PHP', 'PHP and MySQL Database', 'WordPress',
        'Open-ended lab / semester project', 'Lab final exam']


def cell(ws, r, c, v=None, bg=None, fg='000000', bold=False, size=9, align=C, fmt=None, border=True, italic=False):
    x = ws.cell(row=r, column=c)
    if v is not None: x.value = v
    x.font = F(bold=bold, color=fg, size=size, italic=italic)
    if bg: x.fill = fill(bg)
    if border: x.border = BOX
    x.alignment = align
    if fmt: x.number_format = fmt
    return x


def head(ws, t, sub):
    ws['A1'] = t; ws['A1'].font = F(size=14, bold=True, color=NAVY)
    ws['A2'] = sub; ws['A2'].font = F(size=10, color='595959')


def page(ws, paper=9, rows='4:7', cols='A:C', orient='landscape', tall=0):
    ws.page_setup.orientation = orient; ws.page_setup.paperSize = paper
    ws.page_setup.fitToWidth = 1; ws.page_setup.fitToHeight = tall
    ws.sheet_properties.pageSetUpPr = PageSetupProperties(fitToPage=True)
    if rows: ws.print_title_rows = rows
    if cols: ws.print_title_cols = cols


def note(ws, ref, text, size=9):
    ws[ref] = text; ws[ref].font = F(italic=True, color='595959', size=size)


wb = Workbook()

# ====================================================================== Settings
S = wb.active; S.title = 'Settings'
S.sheet_view.showGridLines = False
for col, w in zip('ABCDEFGHIJK', [3, 46, 14, 18, 18, 12, 12, 3, 46, 12, 12]): S.column_dimensions[col].width = w
S['B1'] = 'CS-309 Web Design & Development — Settings'; S['B1'].font = F(size=15, bold=True, color=NAVY)
S['B2'] = 'BS Computer Science (Batch 2024) · 5th Semester — Fall 2026 · HITEC University, Taxila · yellow cells are inputs'
S['B2'].font = F(size=10, color='595959')
S['B5'] = 'How to use this workbook'; S['B5'].font = F(size=11, bold=True, color=NAVY)
howto = [
    '1. Home lists every sheet as a button; every sheet has a  ⌂ Home  button. Settings (this sheet) holds dates, weights, maximum marks, the grade scale and the CLO/PLO set-up.',
    '2. Students: type the class list of each section A–D (up to 100 each). Lab Groups copies them; type over a lab list only if lab groups differ from the sections.',
    '3. Each section has one sheet per assessment: theory (Quizzes, Assignments, Mid Exam, Final Exam) and lab (Lab Perf and Lab Reports for 14 experiments, Lab Mid, Lab Final, OEL, Project).',
    '4. Lab Total adds the lab marks (out of 33); CLO and PLO compute CO4/CO5 and PO5/PO9 attainment with charts; Final Sheet combines all marks, both attendances and the grade.',
    '5. An assessment counts once any student has marks in it, so totals and percentages show the current standing during the semester; a student without marks then gets 0.',
    ('6. Grey cells are formulas — do not type in them. This file is kept in step with the WDD Register app: the app writes its data here and loads changes typed here on its next sync.'
     if APP else '6. Grey cells are formulas — do not type in them. Section A row 8 holds an example student: overwrite it and clear its marks.'),
]
for i, t in enumerate(howto):
    c = S.cell(row=6 + i, column=2, value=t); c.font = F(); c.alignment = LFT
    S.merge_cells(start_row=6 + i, start_column=2, end_row=6 + i, end_column=11); S.row_dimensions[6 + i].height = 27

CFG = {}


def title(r, col, t):
    S.cell(row=r, column=col, value=t).font = F(size=11, bold=True, color=NAVY)


def table(r, col, headers, rows, key_prefix='', widths=None):
    """rows: (label, value, fmt, key, note). Writes label | value [| note]. Returns next free row."""
    for j, h in enumerate(headers): cell(S, r, col + j, h, NAVY, 'FFFFFF', True, 10)
    r += 1
    for lab, val, fmt, key, nt in rows:
        tot = key is not None and key.endswith('TOTAL')
        cell(S, r, col, lab, LIGHT if tot else None, bold=tot, size=10, align=LFT)
        c = cell(S, r, col + 1, val, GREY if tot else YELLOW, '000000' if tot else BLUE, True, 10, C, fmt)
        if key: CFG[key] = f'Settings!${L(col + 1)}${r}'
        if nt: note(S, f'{L(col + 2)}{r}', nt)
        if tot and fmt == '0%':
            S.conditional_formatting.add(f'{L(col + 1)}{r}', FormulaRule(formula=[f'ROUND({L(col + 1)}{r},4)<>1'], fill=fill('FFC7CE'), font=Font(color='9C0006', bold=True)))
        r += 1
    return r + 1


# ---- left column
title(13, 2, 'General settings')
r = table(14, 2, ['Setting', 'Value'], [
    ('Week 1 starts on (Monday)', dt.date(2026, 9, 7), 'dd-mmm-yyyy', 'START', 'Placeholder — the Monday of your first teaching week.'),
    ('Minimum attendance (theory and lab)', 0.75, '0%', 'THR', 'University rule: 75%.'),
    ('Count Leave (L) as present? (Yes / No)', 'No', '@', 'LEAVE', 'Yes = approved leave does not lower the percentage.'),
    ('Theory mid-term exam date', '=C15+7*8', 'dd-mmm-yyyy', 'MIDD', 'Default: Monday of week 9.'),
    ('Theory final exam date', '=C15+7*16', 'dd-mmm-yyyy', 'FIND', 'Default: Monday after week 16.'),
    ('Lab mid exam — in week', 8, '0', 'WK_LMID', 'Date = that week\'s lab day of each lab group.'),
    ('Open-ended lab (OEL) — in week', 15, '0', 'WK_OEL', ''),
    ('Project evaluation — in week', 15, '0', 'WK_PROJ', ''),
    ('Lab final exam — in week', 16, '0', 'WK_LFIN', ''),
])
dv = DataValidation(type='list', formula1='"Yes,No"'); S.add_data_validation(dv); dv.add(CFG['LEAVE'].split('!')[1].replace('$', ''))
dv = DataValidation(type='whole', operator='between', formula1='1', formula2='16'); S.add_data_validation(dv)
for k in ('WK_LMID', 'WK_OEL', 'WK_PROJ', 'WK_LFIN'): dv.add(CFG[k].split('!')[1].replace('$', ''))

title(r, 2, 'Sections (days after Monday: 0 = Mon, 1 = Tue, 2 = Wed, 3 = Thu, 4 = Fri, 5 = Sat)')
r += 1
for j, h in enumerate(['Section', 'Name', 'Theory instructor', 'Lab instructor', 'Lecture day', 'Lab day']):
    cell(S, r, 2 + j, h, NAVY, 'FFFFFF', True, 10)
SECROW = {}
for i, (s, lec, lab) in enumerate([('A', 0, 1), ('B', 1, 2), ('C', 2, 3), ('D', 3, 4)]):
    rr = r + 1 + i; SECROW[s] = rr
    cell(S, rr, 2, f'Section {s}', LIGHT, bold=True, size=10)
    for j, v in enumerate([f'BSCS-5{s}', 'Lec. Waqar Ismail', 'Lec. Waqar Ismail', lec, lab]):
        cell(S, rr, 3 + j, v, YELLOW, BLUE, size=10, align=C if j >= 3 else LFT)
dv = DataValidation(type='whole', operator='between', formula1='0', formula2='6'); S.add_data_validation(dv)
dv.add(f'F{r + 1}:G{r + 4}')
SECNAME = lambda s: f'Settings!$C${SECROW[s]}'
SECINST = lambda s: f'Settings!$D${SECROW[s]}'
LABINST = lambda s: f'Settings!$E${SECROW[s]}'
r += 6

title(r, 2, 'Theory weights (must add up to 100%)')
r = table(r + 1, 2, ['Component', 'Weight'], [
    ('Quizzes', 0.15, '0.0%', 'W_Q', 'Outline: 10% of 67%'), ('Assignments', 0.15, '0.0%', 'W_A', 'Outline: 10% of 67%'),
    ('Mid-term exam', 0.30, '0.0%', 'W_M', 'Outline: sessionals 20% of 67%'), ('Final exam', 0.40, '0.0%', 'W_F', 'Outline: 27% of 67%'),
    ('Theory total', '=SUM(C{0}:C{1})', '0%', 'W_TTOTAL', '')])
rT = r - 6; S[f'C{r - 2}'] = f'=SUM(C{rT}:C{rT + 3})'
title(r, 2, 'Course weights (must add up to 100%)')
r = table(r + 1, 2, ['Component', 'Weight'], [
    ('Theory share', 2 / 3, '0.0%', 'SH_T', '3(2+1) credit hours'), ('Lab share', 1 / 3, '0.0%', 'SH_L', ''),
    ('Course total', None, '0%', 'SH_TOTAL', '')])
S[f'C{r - 2}'] = f'=SUM(C{r - 4}:C{r - 3})'
title(r, 2, 'Lab total — marks of each lab component (total 33)')
r = table(r + 1, 2, ['Component', 'Marks'], [
    ('Lab performance (14 experiments)', 6, '0', 'M_PERF', ''), ('Lab reports (14 experiments)', 4, '0', 'M_REP', ''),
    ('Lab final exam', 5, '0', 'M_LFIN', ''), ('Lab mid exam', 5, '0', 'M_LMID', ''),
    ('Open-ended lab (OEL) viva voce', 5, '0', 'M_OEL', ''), ('Project (design + viva)', 8, '0', 'M_PROJ', ''),
    ('Lab total', None, '0', 'M_TOTAL', '')])
S[f'C{r - 2}'] = f'=SUM(C{r - 8}:C{r - 3})'
title(r, 2, 'Project — inside its marks')
r = table(r + 1, 2, ['Part', 'Scaled to'], [
    ('Project design (raw 20)', 3, '0.##', 'P_DES', 'Project = (design + viva) / (3 + 3) × project marks'),
    ('Project viva (raw 5)', 3, '0.##', 'P_VIVA', '')])
title(r, 2, 'Course and programme learning outcomes')
for j, h in enumerate(['Outcome', 'Code', 'KPI', 'Description']): cell(S, r + 1, 2 + j, h, NAVY, 'FFFFFF', True, 10)
outs = [('CLO (lab, cognitive/psychomotor)', 'CO4', 0.5, 'Use modern web tools to build and test web applications (lab).'),
        ('CLO (project)', 'CO5', 0.5, 'Demonstrate a complete web project (design, implementation, viva).'),
        ('PLO mapped from CO4', 'PO5', 0.5, 'Modern Tool Usage.'),
        ('PLO mapped from CO5', 'PO9', 0.5, 'Individual and Team Work.')]
OUTC = {}
for i, (lab, code, kpi, desc) in enumerate(outs):
    rr = r + 2 + i
    cell(S, rr, 2, lab, None, size=10, align=LFT)
    cell(S, rr, 3, code, YELLOW, BLUE, True, 10)
    cell(S, rr, 4, kpi, YELLOW, BLUE, True, 10, fmt='0%')
    cell(S, rr, 5, desc, YELLOW, BLUE, size=9, align=LFT); S.merge_cells(start_row=rr, start_column=5, end_row=rr, end_column=7)
    OUTC[['CO4', 'CO5', 'PO5', 'PO9'][i]] = dict(code=f'Settings!$C${rr}', kpi=f'Settings!$D${rr}')
r += 7
title(r, 2, 'CO4 weights (must add up to 100%)')
r = table(r + 1, 2, ['Assessment (lab)', 'Weight'], [
    ('Lab performance', 0.30, '0%', 'CO4_PERF', ''), ('Lab mid exam', 0.25, '0%', 'CO4_MID', ''),
    ('Lab final exam', 0.25, '0%', 'CO4_FIN', ''), ('OEL viva voce', 0.20, '0%', 'CO4_VIVA', ''),
    ('CO4 total', None, '0%', 'CO4_TOTAL', '')])
S[f'C{r - 2}'] = f'=SUM(C{r - 6}:C{r - 3})'
title(r, 2, 'CO5 and PLO mapping')
r = table(r + 1, 2, ['Mapping', 'Weight'], [
    ('CO5 ← Project', 1.0, '0%', 'CO5_PROJ', ''), ('PO5 ← CO4', 1.0, '0%', 'PO5_CO4', ''), ('PO9 ← CO5', 1.0, '0%', 'PO9_CO5', '')])
for i, t in enumerate(['Lab reports (4 marks) count in the lab total but not in CO4, as in the class grades sheet template.',
                       'Weights, KPIs and outcome codes are editable — change them to match the course outline.']):
    note(S, f'B{r + i}', t)
LEFT_END = r + 2

# ---- right column: grade scale, maximum marks, lab rubric
title(13, 9, 'Grade scale (from %)')
for j, h in enumerate(['Grade from %', 'Grade', 'Grade point']): cell(S, 14, 9 + j, h, NAVY, 'FFFFFF', True, 10)
grades = [(0, 'F', 0), (50, 'D', 1.0), (54, 'D+', 1.33), (58, 'C-', 1.67), (61, 'C', 2.0), (64, 'C+', 2.33),
          (68, 'B-', 2.67), (71, 'B', 3.0), (75, 'B+', 3.33), (80, 'A-', 3.67), (85, 'A', 4.0)]
for i, (m, g, gp) in enumerate(grades):
    rr = 15 + i
    cell(S, rr, 9, m, YELLOW, BLUE, size=10); cell(S, rr, 10, g, YELLOW, BLUE, True, 10); cell(S, rr, 11, gp, YELLOW, BLUE, size=10, fmt='0.00')
G0, G1 = 15, 15 + len(grades) - 1
GMIN, GNAME = f'Settings!$I${G0}:$I${G1}', f'Settings!$J${G0}:$J${G1}'
note(S, f'I{G1 + 1}', 'Default scale — check it against university policy; keep the rows in ascending order.')

title(G1 + 3, 9, 'Maximum marks — theory')
MAX = {}
THEORY = {
    'Quizzes': [('Quiz 1', 10), ('Quiz 2', 10)],
    'Assignments': [('Assignment 1', 20), ('Assignment 2', 20)],
    'Mid Exam': [(f'Q{i}', 10) for i in range(1, 6)],
    'Final Exam': [(f'Q{i}', 10) for i in range(1, 11)],
}
rr = G1 + 4
cell(S, rr, 9, 'Assessment: item', NAVY, 'FFFFFF', True, 10); cell(S, rr, 10, 'Max', NAVY, 'FFFFFF', True, 10)
for grp, items in THEORY.items():
    for lab, mx in items:
        rr += 1; MAX[(grp, lab)] = f'Settings!$J${rr}'
        cell(S, rr, 9, f'{grp}: {lab}', None, size=10, align=LFT); cell(S, rr, 10, mx, YELLOW, BLUE, True, 10)
PERF = [('SK', 'Subject Knowledge'), ('DA', 'Data Analysis & Interpretation'), ('AC', 'Ability to Conduct Exp.')]
REP = [('PR', 'Presentation'), ('CC', 'Calculation / Coding'), ('OB', 'Observations / Program Results')]
VIVA = [('RA', 'Responsiveness to Questions / Accuracy'), ('DK', 'Depth of Subject Knowledge')]
DES = [('PC', 'Project Complexity'), ('IC', 'Implementation and Completion'), ('TA', 'Testing and Analysis'), ('AP', 'Appearance')]
RUBRIC = {'Lab Perf': (PERF, [5, 5, 5]), 'Lab Reports': (REP, [5, 5, 5]), 'Lab Mid': (PERF, [5, 5, 5]), 'Lab Final': (PERF, [5, 5, 5]),
          'OEL': (VIVA, [10, 10]), 'Project Design': (DES, [5, 5, 5, 5]), 'Project Viva': (VIVA, [2.5, 2.5])}
title(rr + 2, 9, 'Maximum marks — lab rubric')
rr += 3
cell(S, rr, 9, 'Assessment: criterion', NAVY, 'FFFFFF', True, 10); cell(S, rr, 10, 'Max', NAVY, 'FFFFFF', True, 10)
nice = {'Lab Perf': 'Lab performance (each exp.)', 'Lab Reports': 'Lab report (each exp.)', 'Lab Mid': 'Lab mid exam',
        'Lab Final': 'Lab final exam', 'OEL': 'OEL viva voce', 'Project Design': 'Project design', 'Project Viva': 'Project viva'}
for grp, (parts, mxs) in RUBRIC.items():
    for (ab, lab), mx in zip(parts, mxs):
        rr += 1; MAX[(grp, ab)] = f'Settings!$J${rr}'
        cell(S, rr, 9, f'{nice[grp]}: {lab}', None, size=10, align=LFT); cell(S, rr, 10, mx, YELLOW, BLUE, True, 10, fmt='0.##')
note(S, f'I{rr + 1}', 'Project viva raw total is 5 (two criteria of 2.5) as in the template; change if needed.')
page(S, orient='portrait', rows=None, cols=None)

# ====================================================================== Schedule
SC = wb.create_sheet('Schedule')
SC.sheet_view.showGridLines = False
head(SC, 'CS-309 Web Design & Development — 16-week Schedule',
     'Dates are formulas from Settings (Week-1 Monday and each section\'s lecture/lab day) — overwrite any date that differs, e.g. a holiday.')
for col, w in zip('ABCDEFGHIJKL', [3, 10, 12, 12, 12, 12, 12, 12, 12, 12, 44, 24]): SC.column_dimensions[col].width = w
hdr = ['Week'] + [f'{s} {k}' for s in SECS for k in ('Lecture', 'Lab')] + ['Lab experiment / activity', 'Notes']
for j, h in enumerate(hdr): cell(SC, 5, 2 + j, h, NAVY if j in (0, 9, 10) else TAB[h[0]], 'FFFFFF', True, 10)
SCH0 = 6
DATECOL = {}
for w in range(1, WEEKS + 1):
    rr = SCH0 + w - 1; bg = WEEKFILL[w % 2]
    cell(SC, rr, 2, f'Week {w}', bg, size=10)
    for k, s in enumerate(SECS):
        cl, cb = 3 + 2 * k, 4 + 2 * k
        DATECOL[(s, 'lec')], DATECOL[(s, 'lab')] = L(cl), L(cb)
        cell(SC, rr, cl, f"={CFG['START']}+7*{w - 1}+Settings!$F${SECROW[s]}", bg, size=10, fmt='ddd dd-mmm')
        cell(SC, rr, cb, f"={CFG['START']}+7*{w - 1}+Settings!$G${SECROW[s]}", bg, size=10, fmt='ddd dd-mmm')
    cell(SC, rr, 11, (f'Exp. {w:02d}: ' if w <= 14 else '') + LABS[w - 1], bg, size=10, align=LFT)
    cell(SC, rr, 12, '', bg, size=10, align=LFT)
DATE = lambda s, kind, w: f'Schedule!${DATECOL[(s, kind)]}${SCH0 + w - 1}'
LABWEEK = lambda s, key: f"INDEX(Schedule!${DATECOL[(s, 'lab')]}${SCH0}:${DATECOL[(s, 'lab')]}${SCH0 + WEEKS - 1},{CFG[key]})"
SC.freeze_panes = 'C6'
page(SC, orient='landscape', rows='5:5', cols=None)

# ====================================================================== rosters
BLK = {'A': 1, 'B': 6, 'C': 11, 'D': 16}
REGC = {s: L(BLK[s] + 1) for s in SECS}; NAMEC = {s: L(BLK[s] + 2) for s in SECS}


def roster(name, heading, sub, linked):
    R = wb.create_sheet(name)
    head(R, f'CS-309 Web Design & Development — {heading}', sub)
    for s in SECS:
        b = BLK[s]
        for j, w in enumerate([5, 13, 28, 16]): R.column_dimensions[L(b + j)].width = w
        if b > 1: R.column_dimensions[L(b - 1)].width = 2
        cell(R, 4, b, f'="{"Lab group" if linked else "Section"} {s} — "&{SECNAME(s)}', TAB[s], 'FFFFFF', True, 11)
        R.merge_cells(start_row=4, start_column=b, end_row=4, end_column=b + 3)
        c = R.cell(row=6, column=b, value=f'="Students: "&SUMPRODUCT(--({NAMEC[s]}{FIRST}:{NAMEC[s]}{LAST}<>""))')
        c.alignment = Alignment(horizontal='left'); c.font = F(bold=True, size=9)
        for j, h in enumerate(['Sr.', 'Reg. No', 'Student name', 'Remarks']): cell(R, 7, b + j, h, NAVY, 'FFFFFF', True, 10)
        for r_ in range(FIRST, LAST + 1):
            cell(R, r_, b, r_ - FIRST + 1, GREY)
            if linked:
                cell(R, r_, b + 1, f'=IF(Students!{REGC[s]}{r_}="","",Students!{REGC[s]}{r_})', 'F7F9FC')
                cell(R, r_, b + 2, f'=IF(Students!{NAMEC[s]}{r_}="","",Students!{NAMEC[s]}{r_})', 'F7F9FC', align=LFT)
            else:
                cell(R, r_, b + 1, None); cell(R, r_, b + 2, None, align=LFT)
            cell(R, r_, b + 3, None, align=LFT)
    R.freeze_panes = f'A{FIRST}'
    page(R, rows='4:7', cols=None)
    return R


RS = roster('Students', 'Class Lists (Sections A–D, up to 100 students each)',
            'Type each section\'s students here; every theory sheet and Final Sheet of a section uses this list (same row on every sheet).', False)
if not APP:
    cell(RS, FIRST, 2, '24-CS-001'); cell(RS, FIRST, 3, 'Example Student (replace)', align=LFT)
    RS.cell(row=FIRST, column=3).comment = Comment('Example row showing the format. Overwrite it with your first student and clear its attendance and marks.', 'Template')
roster('Lab Groups', 'Lab Groups (A–D, up to 100 students each)',
       'By default each lab group = its section (pale cells are formulas). If lab groups differ, type the Reg. No and name over them. Lab sheets use these lists.', True)

# ====================================================================== shared sheet scaffold
SHEETS = {}


def scaffold(s, short, heading, sec, sub_extra=''):
    name = f'{s} {short}'
    ws = wb.create_sheet(name); ws.sheet_properties.tabColor = TAB[s]; ws.sheet_view.zoomScale = 90
    roster_sheet = 'Students' if sec else q('Lab Groups')
    who = SECINST(s) if sec else LABINST(s)
    head(ws, f'CS-309 Web Design & Development — Section {s}: {heading}',
         f'="{"Section" if sec else "Lab group"} {s} ("&{SECNAME(s)}&")   ·   Fall 2026   ·   {"Instructor" if sec else "Lab instructor"}: "&{who}&"{sub_extra}"')
    for col_, w in [(1, 5), (2, 12), (3, 26)]: ws.column_dimensions[L(col_)].width = w
    for cc, h in [(1, 'Sr.'), (2, 'Reg. No'), (3, 'Student name')]:
        cell(ws, 4, cc, h, TAB[s], 'FFFFFF', True); ws.merge_cells(start_row=4, start_column=cc, end_row=5, end_column=cc)
    cell(ws, 6, 1, '', LIGHT); cell(ws, 6, 2, '', LIGHT); cell(ws, 6, 3, 'Date →', LIGHT, size=8)
    cell(ws, 7, 1, '', LIGHT); cell(ws, 7, 2, '', LIGHT); cell(ws, 7, 3, 'Maximum marks →', LIGHT, size=8)
    for r_ in range(FIRST, LAST + 1):
        cell(ws, r_, 1, r_ - FIRST + 1)
        cell(ws, r_, 2, f'=IF({roster_sheet}!{REGC[s]}{r_}="","",{roster_sheet}!{REGC[s]}{r_})', GREY)
        cell(ws, r_, 3, f'=IF({roster_sheet}!{NAMEC[s]}{r_}="","",{roster_sheet}!{NAMEC[s]}{r_})', GREY, align=LFT)
    ws.row_dimensions[5].height = 30
    ws.freeze_panes = f'D{FIRST}'
    SHEETS[(s, short)] = q(name)
    return ws


def group_header(ws, c0, c1, text, color, size=9):
    cell(ws, 4, c0, text, color, 'FFFFFF', True, size)
    if c1 > c0: ws.merge_cells(start_row=4, start_column=c0, end_row=4, end_column=c1)


ENTRY = {}


def entry_cols(ws, cols, maxrefs, width=6.5, shade=None):
    ENTRY.setdefault(ws.title, []).extend(cols)
    for cl, mx in zip(cols, maxrefs):
        cell(ws, 7, CI(cl), f'={mx}', MAXF, '375623', True)
        ws.column_dimensions[cl].width = width
        for r_ in range(FIRST, LAST + 1): cell(ws, r_, CI(cl), None, shade, fmt='0.##')
        dv = DataValidation(type='decimal', operator='between', formula1='0', formula2=f'${cl}$7', allow_blank=True,
                            showErrorMessage=True, errorTitle='Marks', error='Enter a number from 0 to the maximum marks in row 7.')
        ws.add_data_validation(dv); dv.add(f'{cl}{FIRST}:{cl}{LAST}')


def formula_col(ws, cl, header, row7, per_row, fmt='0.##', width=9, bold=False, bg=GREY, head_bg='C9DAF0', merge_head=True, row7fmt='"/ "0.##'):
    cidx = CI(cl)
    cell(ws, 5, cidx, header, head_bg, bold=True, size=8)
    if merge_head: ws.merge_cells(start_row=5, start_column=cidx, end_row=6, end_column=cidx)
    cell(ws, 7, cidx, row7, MAXF, '375623', True, fmt=row7fmt)
    ws.column_dimensions[cl].width = width
    for r_ in range(FIRST, LAST + 1):
        cell(ws, r_, cidx, per_row(r_), bg, bold=bold, fmt=fmt, align=RGT if '%' in fmt else C)


def stats(ws, c_from, c_to, pct_cols=()):
    for k_, (lab, fn) in enumerate([('Class average', 'AVERAGE'), ('Highest', 'MAX'), ('Lowest', 'MIN')]):
        r_ = LAST + 2 + k_
        cell(ws, r_, 3, lab, LIGHT, bold=True, align=LFT)
        for cidx in range(c_from, c_to + 1):
            cl = L(cidx)
            cell(ws, r_, cidx, f'=IF(COUNT({cl}{FIRST}:{cl}{LAST})=0,"",{fn}({cl}{FIRST}:{cl}{LAST}))', GREY, bold=True,
                 fmt='0.0%' if cl in pct_cols else '0.0', size=8)


BLANK = lambda r_: f'$C{r_}=""'

# ====================================================================== attendance
ATT = {}


def attendance(s, kind):
    sec = kind == 'lec'
    label = 'Theory' if sec else 'Lab'
    A = scaffold(s, f'{label} Att', f'{label} Attendance (16 weeks)', sec, '   ·   P = Present, A = Absent, L = Leave')
    A.cell(row=7, column=3).value = 'Class held (auto ✓) →'
    W0, WL = 4, 4 + WEEKS - 1; c0, c1 = L(W0), L(WL)
    names = ['Present (P)', 'Leave (L)', 'Absent (A)', f'{label} attendance %', 'Status']
    S0 = WL + 1; SCc = {n: L(S0 + i) for i, n in enumerate(names)}; PCT = SCc[f'{label} attendance %']
    A.cell(row=2, column=S0 + 1, value='Min. %').font = F(size=9, bold=True)
    cell(A, 2, S0 + 2, f"={CFG['THR']}", GREY, bold=True, fmt='0%', border=False)
    A.cell(row=2, column=S0 + 3, value='Leave = present?').font = F(size=9, bold=True)
    cell(A, 2, S0 + 4, f"={CFG['LEAVE']}", GREY, bold=True, border=False)
    THRC, LEAVEC = f'${L(S0 + 2)}$2', f'${L(S0 + 4)}$2'
    for w in range(1, WEEKS + 1):
        cidx = W0 + w - 1; cl = L(cidx)
        cell(A, 4, cidx, f'Week {w}', '2E5C9A' if w % 2 else NAVY, 'FFFFFF', True, 8)
        cell(A, 5, cidx, 'Lecture' if sec else (f'Exp. {w:02d}' if w <= 14 else ('OEL/Proj.' if w == 15 else 'Lab Final')), LIGHT, size=7)
        cell(A, 6, cidx, f'={DATE(s, kind, w)}', WEEKFILL[w % 2], size=8, fmt='dd-mmm')
        cell(A, 7, cidx, f'=IF(COUNTA({cl}{FIRST}:{cl}{LAST})>0,1,0)', MAXF, '375623', size=9, fmt='"✓";;')
        A.column_dimensions[cl].width = 6.6
    group_header(A, S0, S0 + len(names) - 1, 'Summary (formulas)', NAVY)
    for i, n in enumerate(names):
        isp = n == f'{label} attendance %'
        cell(A, 5, S0 + i, n, LIGHT, bold=True, size=8); A.merge_cells(start_row=5, start_column=S0 + i, end_row=6, end_column=S0 + i)
        cell(A, 7, S0 + i, f'=SUM(${c0}$7:${c1}$7)' if isp else '', MAXF, '375623', True, 8, fmt='"held: "0' if isp else None)
        A.column_dimensions[L(S0 + i)].width = [9, 8, 8, 22, 10][i]
    HELDC = f'${PCT}$7'
    for r_ in range(FIRST, LAST + 1):
        rng = f'{c0}{r_}:{c1}{r_}'
        for w in range(1, WEEKS + 1): cell(A, r_, W0 + w - 1, None, WEEKFILL[w % 2], bold=True)
        b = BLANK(r_)
        f = {'Present (P)': f'=IF({b},"",COUNTIF({rng},"P"))', 'Leave (L)': f'=IF({b},"",COUNTIF({rng},"L"))',
             'Absent (A)': f'=IF({b},"",COUNTIF({rng},"A"))',
             f'{label} attendance %': f'=IF(OR({b},{HELDC}=0),"",({SCc["Present (P)"]}{r_}+IF({LEAVEC}="Yes",{SCc["Leave (L)"]}{r_},0))/{HELDC})',
             'Status': f'=IF({PCT}{r_}="","",IF({PCT}{r_}>={THRC},"Eligible","Short"))'}
        for i, n in enumerate(names):
            cell(A, r_, S0 + i, f[n], GREY, fmt='0.0%' if '%' in n else None, align=RGT if '%' in n else C)
    if s == 'A' and not APP:
        for w, v in enumerate(['P', 'P', 'A', 'P'] if sec else ['P', 'P', 'L', 'P']): A.cell(row=FIRST, column=W0 + w, value=v)
    CR1, CR2 = LAST + 2, LAST + 3
    cell(A, CR1, 3, 'Present (count)', LIGHT, bold=True, align=LFT); cell(A, CR2, 3, 'Class attendance %', LIGHT, bold=True, align=LFT)
    nstud = f'SUMPRODUCT(--($C${FIRST}:$C${LAST}<>""))'
    for w in range(1, WEEKS + 1):
        cl = L(W0 + w - 1)
        cell(A, CR1, W0 + w - 1, f'=IF({cl}$7=0,"",COUNTIF({cl}{FIRST}:{cl}{LAST},"P"))', GREY, size=8)
        cell(A, CR2, W0 + w - 1, f'=IF(OR({cl}$7=0,{nstud}=0),"",COUNTIF({cl}{FIRST}:{cl}{LAST},"P")/{nstud})', GREY, size=8, fmt='0%')
    for r_, lab, fx, fm in [(CR1, 'Students', f'={nstud}', '0'),
                            (CR2, 'Class average', f'=IF(COUNT({PCT}{FIRST}:{PCT}{LAST})=0,"",AVERAGE({PCT}{FIRST}:{PCT}{LAST}))', '0.0%')]:
        cell(A, r_, S0 + 2, lab, LIGHT, bold=True); cell(A, r_, S0 + 3, fx, GREY, bold=True, fmt=fm)
    cell(A, CR1, S0 + 4, f'=COUNTIF({SCc["Status"]}{FIRST}:{SCc["Status"]}{LAST},"Short")&" short"', GREY, 'C00000', True)
    grid = f'{c0}{FIRST}:{c1}{LAST}'
    dv = DataValidation(type='list', formula1='"P,A,L"', allow_blank=True, showErrorMessage=True,
                        errorTitle='Attendance', error='Enter P (present), A (absent) or L (leave).')
    A.add_data_validation(dv); dv.add(grid)
    for v, bg, fg in [('P', 'C6EFCE', '006100'), ('A', 'FFC7CE', '9C0006'), ('L', 'FFEB9C', '9C5700')]:
        A.conditional_formatting.add(grid, CellIsRule(operator='equal', formula=[f'"{v}"'], fill=fill(bg), font=Font(color=fg, bold=True)))
    prng = f'{PCT}{FIRST}:{PCT}{LAST}'
    A.conditional_formatting.add(prng, bar('2E75B6' if sec else '70AD47'))
    A.conditional_formatting.add(prng, FormulaRule(formula=[f'AND(ISNUMBER({PCT}{FIRST}),{PCT}{FIRST}<{THRC})'], font=Font(color='C00000', bold=True)))
    A.conditional_formatting.add(f'{c0}{CR2}:{c1}{CR2}', bar('A9D08E'))
    st = f'{SCc["Status"]}{FIRST}:{SCc["Status"]}{LAST}'
    A.conditional_formatting.add(st, CellIsRule(operator='equal', formula=['"Short"'], fill=fill('FFC7CE'), font=Font(color='9C0006', bold=True)))
    A.conditional_formatting.add(st, CellIsRule(operator='equal', formula=['"Eligible"'], fill=fill('C6EFCE'), font=Font(color='006100')))
    page(A)
    ENTRY[A.title] = [L(W0 + w) for w in range(WEEKS)]
    ATT[(s, kind)] = dict(sheet=q(A.title), present=SCc['Present (P)'], pct=PCT, status=SCc['Status'])


# ====================================================================== theory assessments
TH = {}


def theory_items(s, grp, heading, color, dates, mode):
    """mode 'items': each column is its own assessment (quizzes, assignments); 'exam': columns are questions of one exam."""
    ws = scaffold(s, grp, heading, True)
    items = THEORY[grp]
    cols = [L(4 + i) for i in range(len(items))]
    group_header(ws, 4, 3 + len(items), heading.split(' (')[0], color)
    for i, ((lab, mx), cl) in enumerate(zip(items, cols)):
        cell(ws, 5, CI(cl), lab, LIGHT, bold=True, size=8)
        d = dates[i] if mode == 'items' else dates[0]
        cell(ws, 6, CI(cl), f'={d}', YELLOW, BLUE, size=7, fmt='dd-mmm-yy')
    if mode == 'exam' and len(cols) > 1:
        ws.merge_cells(f'{cols[0]}6:{cols[-1]}6')
    entry_cols(ws, cols, [MAX[(grp, lab)] for lab, mx in items], width=10 if mode == 'items' else 6)
    T, P = L(4 + len(items)), L(5 + len(items))
    group_header(ws, CI(T), CI(P), 'Total (formulas)', NAVY)
    rng = lambda r_: f'{cols[0]}{r_}:{cols[-1]}{r_}'
    if mode == 'items':
        heldmax = '+'.join(f'{HELD(c)}*{c}$7' for c in cols)
        anyheld = '+'.join(HELD(c) for c in cols)
        formula_col(ws, T, f'{grp[:-1] if grp.endswith("s") else grp} total', f'={heldmax}',
                    lambda r_: f'=IF(OR({BLANK(r_)},{T}$7=0),"",SUM({rng(r_)}))', bold=True)
    else:
        anyheld = '+'.join(HELD(c) for c in cols)
        formula_col(ws, T, 'Exam total', f'=SUM({cols[0]}7:{cols[-1]}7)',
                    lambda r_: f'=IF(OR({BLANK(r_)},({anyheld})=0),"",SUM({rng(r_)}))', bold=True)
    formula_col(ws, P, 'Percentage', '', lambda r_: f'=IF(OR({T}{r_}="",N({T}$7)=0),"",{T}{r_}/{T}$7)', fmt='0.0%', width=18)
    ws.conditional_formatting.add(f'{P}{FIRST}:{P}{LAST}', bar(color.replace('C00000', 'E06666')))
    note(ws, f'{L(CI(P) + 2)}4', 'Row 7 of the total shows the maximum of the assessments already held.' if mode == 'items' else
         'The exam counts as held once any marks are entered; blank questions count as 0.')
    stats(ws, 4, CI(P), pct_cols=(P,))
    page(ws)
    TH[(s, grp)] = dict(sheet=q(ws.title), total=T, pct=P)
    return ws


# ====================================================================== lab assessments
LB = {}


def experiments(s, short, heading, parts_key, marks_key, legend, color):
    ws = scaffold(s, short, heading, False, '   ·   ' + legend)
    parts, _ = RUBRIC[parts_key]
    col = 4; totals = []; entries = []
    for n in range(1, NEXP + 1):
        c0 = col
        pc = [L(col + j) for j in range(len(parts))]; col += len(parts)
        tc = L(col); col += 1
        group_header(ws, c0, col - 1, f'Exp. No. {n}', '2E5C9A' if n % 2 else NAVY, 8)
        for (ab, lab), cl in zip(parts, pc): cell(ws, 5, CI(cl), ab, LIGHT, bold=True, size=8)
        cell(ws, 6, c0, f'={DATE(s, "lab", n)}', WEEKFILL[n % 2], size=7, fmt='dd-mmm')
        ws.merge_cells(start_row=6, start_column=c0, end_row=6, end_column=col - 1)
        entry_cols(ws, pc, [MAX[(parts_key, ab)] for ab, lab in parts], width=4.4, shade=WEEKFILL[n % 2])
        held = '+'.join(HELD(c) for c in pc)
        formula_col(ws, tc, 'Total', f'=SUM({pc[0]}7:{pc[-1]}7)',
                    lambda r_, pc=pc, held=held: f'=IF(OR({BLANK(r_)},({held})=0),"",SUM({pc[0]}{r_}:{pc[-1]}{r_}))',
                    width=5.2, bold=True, merge_head=False)
        ws.cell(row=5, column=CI(tc)).value = 'Total'
        totals.append(tc); entries += pc
    s0 = col
    cols = {k: L(s0 + i) for i, k in enumerate(['N', 'SUM', 'PCT', 'SC'])}
    group_header(ws, s0, s0 + 3, 'Summary (formulas)', NAVY)
    tlist = ','.join(f'{t}{{r}}' for t in totals)
    formula_col(ws, cols['N'], 'Experiments marked', '=' + '+'.join(HELD(t) for t in totals),
                lambda r_: f'=IF({BLANK(r_)},"",COUNT({tlist.format(r=r_)}))', width=11, row7fmt='"held: "0')
    formula_col(ws, cols['SUM'], 'Total of held experiments', '=' + '+'.join(f'{HELD(t)}*{t}$7' for t in totals),
                lambda r_: f'=IF(OR({BLANK(r_)},{cols["SUM"]}$7=0),"",SUM({tlist.format(r=r_)}))', width=12, bold=True)
    formula_col(ws, cols['PCT'], 'Percentage', '',
                lambda r_: f'=IF({cols["SUM"]}{r_}="","",{cols["SUM"]}{r_}/{cols["SUM"]}$7)', fmt='0.0%', width=16)
    formula_col(ws, cols['SC'], f'Marks (out of {"6" if marks_key == "M_PERF" else "4"})', f"={CFG[marks_key]}",
                lambda r_: f'=IF({cols["PCT"]}{r_}="","",{cols["PCT"]}{r_}*{CFG[marks_key]})', width=11, bold=True, head_bg='FCE4D6')
    ws.conditional_formatting.add(f'{cols["PCT"]}{FIRST}:{cols["PCT"]}{LAST}', bar(color))
    if s == 'A' and not APP:
        for cl, v in zip(entries[:3], [4, 4.5, 5]): ws[f'{cl}{FIRST}'].value = v
    stats(ws, 4, s0 + 3, pct_cols=(cols['PCT'],))
    page(ws, paper=8)
    LB[(s, short)] = dict(sheet=q(ws.title), sc=cols['SC'], pct=cols['PCT'])


def single(s, short, heading, parts_key, raw_label, marks_key, week_key, color, legend=''):
    ws = scaffold(s, short, heading, False, legend)
    parts, _ = RUBRIC[parts_key]
    pc = [L(4 + j) for j in range(len(parts))]
    group_header(ws, 4, 3 + len(parts), heading.split(' (')[0], color)
    for (ab, lab), cl in zip(parts, pc): cell(ws, 5, CI(cl), f'{lab} (0–{"{:g}".format(RUBRIC[parts_key][1][pc.index(cl)])})', LIGHT, bold=True, size=8)
    cell(ws, 6, 4, f'={LABWEEK(s, week_key)}', YELLOW, BLUE, size=8, fmt='dd-mmm-yy')
    ws.merge_cells(start_row=6, start_column=4, end_row=6, end_column=3 + len(parts))
    entry_cols(ws, pc, [MAX[(parts_key, ab)] for ab, lab in parts], width=15)
    T, SCc = L(4 + len(parts)), L(5 + len(parts))
    held = '+'.join(HELD(c) for c in pc)
    group_header(ws, CI(T), CI(SCc), 'Total (formulas)', NAVY)
    formula_col(ws, T, raw_label, f'=SUM({pc[0]}7:{pc[-1]}7)',
                lambda r_: f'=IF(OR({BLANK(r_)},({held})=0),"",SUM({pc[0]}{r_}:{pc[-1]}{r_}))', width=11, bold=True)
    formula_col(ws, SCc, 'Marks (out of 5)', f"={CFG[marks_key]}",
                lambda r_: f'=IF(OR({T}{r_}="",N({T}$7)=0),"",{T}{r_}/{T}$7*{CFG[marks_key]})', width=16, bold=True, head_bg='FCE4D6')
    ws.conditional_formatting.add(f'{SCc}{FIRST}:{SCc}{LAST}', bar(color, mx=f'${SCc}$7'))
    stats(ws, 4, CI(SCc))
    page(ws)
    LB[(s, short)] = dict(sheet=q(ws.title), sc=SCc, raw=T)


def project(s):
    ws = scaffold(s, 'Project', 'Project (design and viva quantification)', False)
    blocks = [('Project Design', 'Project Design Quantification', 'P_DES', '1F7A5A'), ('Project Viva', 'Project Viva Quantification', 'P_VIVA', '7030A0')]
    col = 4; out = {}
    for key, title_, sc_key, color in blocks:
        parts, mxs = RUBRIC[key]
        pc = [L(col + j) for j in range(len(parts))]; col += len(parts)
        T, SCc = L(col), L(col + 1); col += 2
        group_header(ws, CI(pc[0]), CI(SCc), title_, color)
        for (ab, lab), cl, mx in zip(parts, pc, mxs): cell(ws, 5, CI(cl), f'{lab} (0–{mx:g})', LIGHT, bold=True, size=8)
        cell(ws, 6, CI(pc[0]), f'={LABWEEK(s, "WK_PROJ")}', YELLOW, BLUE, size=8, fmt='dd-mmm-yy')
        ws.merge_cells(start_row=6, start_column=CI(pc[0]), end_row=6, end_column=CI(pc[-1]))
        entry_cols(ws, pc, [MAX[(key, ab)] for ab, lab in parts], width=13)
        held = '+'.join(HELD(c) for c in pc)
        formula_col(ws, T, f'Total (out of {sum(mxs):g})', f'=SUM({pc[0]}7:{pc[-1]}7)',
                    lambda r_, pc=pc, held=held: f'=IF(OR({BLANK(r_)},({held})=0),"",SUM({pc[0]}{r_}:{pc[-1]}{r_}))', width=10, bold=True)
        formula_col(ws, SCc, f'Scaled (out of {3})', f"={CFG[sc_key]}",
                    lambda r_, T=T, sc_key=sc_key: f'=IF(OR({T}{r_}="",N({T}$7)=0),"",{T}{r_}/{T}$7*{CFG[sc_key]})', width=10, bold=True)
        out[key] = SCc
    P = L(col)
    group_header(ws, col, col, 'Design project', NAVY)
    d, v = out['Project Design'], out['Project Viva']
    den = f'(IF({d}{{r}}="",0,{d}$7)+IF({v}{{r}}="",0,{v}$7))'
    formula_col(ws, P, 'Project marks (out of 8)', f"={CFG['M_PROJ']}",
                lambda r_: f'=IF(AND({d}{r_}="",{v}{r_}=""),"",(N({d}{r_})+N({v}{r_}))/{den.format(r=r_)}*{CFG["M_PROJ"]})',
                width=18, bold=True, head_bg='FCE4D6')
    ws.conditional_formatting.add(f'{P}{FIRST}:{P}{LAST}', bar('B45F06', mx=f'${P}$7'))
    note(ws, f'{L(col + 2)}4', 'Project = (design scaled + viva scaled) / (3 + 3) × 8, using only the parts already marked.')
    stats(ws, 4, col)
    page(ws)
    LB[(s, 'Project')] = dict(sheet=q(ws.title), sc=P)


def lab_total(s):
    ws = scaffold(s, 'Lab Total', 'Lab Total (out of 33)', False)
    comps = [('Lab Perf', 'Lab Performance', 'M_PERF'), ('Lab Reports', 'Lab Reports', 'M_REP'), ('Lab Final', 'Final', 'M_LFIN'),
             ('Lab Mid', 'Mid', 'M_LMID'), ('OEL', 'OEL', 'M_OEL'), ('Project', 'Project Design', 'M_PROJ')]
    cols = [L(4 + i) for i in range(len(comps))]
    group_header(ws, 4, 3 + len(comps), 'LAB TOTAL — from the lab assessment sheets', '1F7A5A')
    for (key, lab, mk), cl in zip(comps, cols):
        src = LB[(s, key)]
        formula_col(ws, cl, lab, f"={CFG[mk]}",
                    lambda r_, src=src: f'=IF(OR({BLANK(r_)},{src["sheet"]}!{src["sc"]}{r_}=""),"",{src["sheet"]}!{src["sc"]}{r_})',
                    width=11, merge_head=True, head_bg=LIGHT)
    T, HM, P = L(4 + len(comps)), L(5 + len(comps)), L(6 + len(comps))
    group_header(ws, CI(T), CI(P), 'Total (formulas)', NAVY)
    formula_col(ws, T, 'Total (out of 33)', f"={CFG['M_TOTAL']}",
                lambda r_: f'=IF(OR({BLANK(r_)},COUNT({cols[0]}{r_}:{cols[-1]}{r_})=0),"",SUM({cols[0]}{r_}:{cols[-1]}{r_}))', width=11, bold=True, head_bg='FCE4D6')
    formula_col(ws, HM, 'Maximum of components marked', '',
                lambda r_: f'=IF({T}{r_}="","",' + '+'.join(f'IF({c}{r_}="",0,{c}$7)' for c in cols) + ')', width=12)
    formula_col(ws, P, 'Lab percentage', '', lambda r_: f'=IF(OR({T}{r_}="",N({HM}{r_})=0),"",{T}{r_}/{HM}{r_})', fmt='0.0%', width=18)
    ws.conditional_formatting.add(f'{P}{FIRST}:{P}{LAST}', bar('70AD47'))
    stats(ws, 4, CI(P), pct_cols=(P,))
    page(ws)
    LB[(s, 'Lab Total')] = dict(sheet=q(ws.title), cols=dict(zip([c[0] for c in comps], cols)), total=T, pct=P)


# ====================================================================== CLO / PLO
OUTS = {}


def summary_block(ws, c0, rows, title_, chart_title, chart_anchor_row):
    """rows: list of (code-ref formula, kpi ref, pct col letter, status col letter). Writes a class summary table and a bar chart."""
    hdr = ['Outcome', 'KPI', 'Class average', 'Students assessed', 'Students ≥ KPI', '% of students ≥ KPI', 'Class result']
    cell(ws, 4, c0, title_, NAVY, 'FFFFFF', True, 10); ws.merge_cells(start_row=4, start_column=c0, end_row=4, end_column=c0 + len(hdr) - 1)
    for j, h in enumerate(hdr):
        cell(ws, 5, c0 + j, h, LIGHT, bold=True, size=8); ws.column_dimensions[L(c0 + j)].width = 12
    for i, (code, kpi, pc) in enumerate(rows):
        r_ = 6 + i
        rng = f'{pc}{FIRST}:{pc}{LAST}'
        vals = [f'={code}', f'={kpi}', f'=IF(COUNT({rng})=0,"",AVERAGE({rng}))', f'=COUNT({rng})',
                f'=COUNTIF({rng},">="&{kpi})', f'=IF(COUNT({rng})=0,"",COUNTIF({rng},">="&{kpi})/COUNT({rng}))',
                f'=IF(COUNT({rng})=0,"",IF(AVERAGE({rng})>={kpi},"Attained","Not attained"))']
        fm = [None, '0%', '0.0%', '0', '0', '0.0%', None]
        for j, v in enumerate(vals): cell(ws, r_, c0 + j, v, GREY, bold=j in (0, 6), size=9, fmt=fm[j])
    res = f'{L(c0 + 6)}6:{L(c0 + 6)}{5 + len(rows)}'
    ws.conditional_formatting.add(res, CellIsRule(operator='equal', formula=['"Attained"'], fill=fill('C6EFCE'), font=Font(color='006100', bold=True)))
    ws.conditional_formatting.add(res, CellIsRule(operator='equal', formula=['"Not attained"'], fill=fill('FFC7CE'), font=Font(color='9C0006', bold=True)))
    note(ws, f'{L(c0)}{7 + len(rows)}', 'Class result: attained when the class average reaches the KPI.')
    ch = BarChart(); ch.type = 'col'; ch.grouping = 'clustered'; ch.title = chart_title
    ch.y_axis.title = 'Percent'; ch.y_axis.scaling.min = 0; ch.y_axis.scaling.max = 1; ch.y_axis.number_format = '0%'
    ch.y_axis.majorGridlines = None
    for j, color in [(1, 'BFBFBF'), (2, '2E75B6'), (5, '70AD47')]:
        ref = Reference(ws, min_col=c0 + j, min_row=5, max_row=5 + len(rows))
        ch.add_data(ref, titles_from_data=True)
        ser = ch.series[-1]; ser.graphicalProperties.solidFill = color; ser.graphicalProperties.line.solidFill = color
    ch.set_categories(Reference(ws, min_col=c0, min_row=6, max_row=5 + len(rows)))
    ch.dataLabels = DataLabelList(showVal=True, showSerName=False, showCatName=False, showLegendKey=False, showPercent=False,
                                  showLeaderLines=False, numFmt='0%')
    ch.height, ch.width = 8.5, 16
    ch.x_axis.delete = False; ch.y_axis.delete = False
    ch.legend.position = 'b'
    ws.add_chart(ch, f'{L(c0)}{chart_anchor_row}')


def clo(s):
    ws = scaffold(s, 'CLO', 'CLO-based Class Grades Sheet', False)
    LT = LB[(s, 'Lab Total')]
    co4 = [('Perf', 'Lab Perf', 'CO4_PERF', 'M_PERF'), ('Mid', 'Lab Mid', 'CO4_MID', 'M_LMID'), ('Final', 'Lab Final', 'CO4_FIN', 'M_LFIN'),
           ('Viva', 'OEL', 'CO4_VIVA', 'M_OEL')]
    cols = [L(4 + i) for i in range(len(co4))]
    P4, S4, PR, P5, S5 = L(8), L(9), L(10), L(11), L(12)
    cell(ws, 4, 4, f'={OUTC["CO4"]["code"]}&" (KPI = "&TEXT({OUTC["CO4"]["kpi"]},"0%")&")"', TAB[s], 'FFFFFF', True)
    ws.merge_cells('D4:I4')
    cell(ws, 4, 10, f'={OUTC["CO5"]["code"]}&" (KPI = "&TEXT({OUTC["CO5"]["kpi"]},"0%")&")"', '7030A0', 'FFFFFF', True)
    ws.merge_cells('J4:L4')
    for (lab, key, wk, mk), cl in zip(co4, cols):
        cell(ws, 5, CI(cl), lab, LIGHT, bold=True, size=8)
        cell(ws, 6, CI(cl), f"={CFG[wk]}", YELLOW, '000000', size=8, fmt='"weight "0%')
        cell(ws, 7, CI(cl), f"={CFG[mk]}", MAXF, '375623', True, fmt='"/ "0')
        ws.column_dimensions[cl].width = 10
        for r_ in range(FIRST, LAST + 1):
            cell(ws, r_, CI(cl), f'=IF(OR({BLANK(r_)},{LT["sheet"]}!{LT["cols"][key]}{r_}=""),"",{LT["sheet"]}!{LT["cols"][key]}{r_})', GREY, fmt='0.##')
    num = lambda r_: '+'.join(f'IF({c}{r_}="",0,{CFG[wk]}*{c}{r_}/{c}$7)' for c, (lab, key, wk, mk) in zip(cols, co4))
    den = lambda r_: '+'.join(f'IF({c}{r_}="",0,{CFG[wk]})' for c, (lab, key, wk, mk) in zip(cols, co4))
    formula_col(ws, P4, 'CO4 total (100%)', '', lambda r_: f'=IF(OR({BLANK(r_)},({den(r_)})=0),"",({num(r_)})/({den(r_)}))',
                fmt='0.0%', width=16, bold=True, merge_head=False)
    cell(ws, 6, CI(P4), f'={"+".join(CFG[w] for _, _, w, _ in co4)}', MAXF, '375623', size=8, fmt='"weights "0%')
    formula_col(ws, S4, 'CO4 status', '', lambda r_: f'=IF({P4}{r_}="","",IF({P4}{r_}>={OUTC["CO4"]["kpi"]},"Achieved","Not achieved"))', fmt='@', width=12)
    cell(ws, 5, CI(PR), 'Project', LIGHT, bold=True, size=8)
    cell(ws, 6, CI(PR), f"={CFG['CO5_PROJ']}", YELLOW, '000000', size=8, fmt='"weight "0%')
    cell(ws, 7, CI(PR), f"={CFG['M_PROJ']}", MAXF, '375623', True, fmt='"/ "0')
    ws.column_dimensions[PR].width = 10
    for r_ in range(FIRST, LAST + 1):
        cell(ws, r_, CI(PR), f'=IF(OR({BLANK(r_)},{LT["sheet"]}!{LT["cols"]["Project"]}{r_}=""),"",{LT["sheet"]}!{LT["cols"]["Project"]}{r_})', GREY, fmt='0.##')
    formula_col(ws, P5, 'CO5 total (100%)', '', lambda r_: f'=IF({PR}{r_}="","",{PR}{r_}/{PR}$7)', fmt='0.0%', width=16, bold=True)
    formula_col(ws, S5, 'CO5 status', '', lambda r_: f'=IF({P5}{r_}="","",IF({P5}{r_}>={OUTC["CO5"]["kpi"]},"Achieved","Not achieved"))', fmt='@', width=12)
    ws.conditional_formatting.add(f'{P4}{FIRST}:{P4}{LAST}', bar('2E75B6'))
    ws.conditional_formatting.add(f'{P5}{FIRST}:{P5}{LAST}', bar('7030A0'))
    for st in (S4, S5):
        rg = f'{st}{FIRST}:{st}{LAST}'
        ws.conditional_formatting.add(rg, CellIsRule(operator='equal', formula=['"Achieved"'], fill=fill('C6EFCE'), font=Font(color='006100')))
        ws.conditional_formatting.add(rg, CellIsRule(operator='equal', formula=['"Not achieved"'], fill=fill('FFC7CE'), font=Font(color='9C0006', bold=True)))
    stats(ws, 4, 12, pct_cols=(P4, P5))
    ws.column_dimensions['M'].width = 3
    summary_block(ws, 14, [(OUTC['CO4']['code'], OUTC['CO4']['kpi'], P4), (OUTC['CO5']['code'], OUTC['CO5']['kpi'], P5)],
                  'Class summary — course learning outcomes', f'Section {s}: CLO attainment', 11)
    page(ws, cols='A:C')
    OUTS[(s, 'CLO')] = dict(sheet=q(ws.title), CO4=P4, CO5=P5, S4=S4, S5=S5)


def plo(s):
    ws = scaffold(s, 'PLO', 'PLO-based Class Grades Sheet', False)
    CL = OUTS[(s, 'CLO')]
    blocks = [('PO5', 'CO4', 'PO5_CO4', TAB[s]), ('PO9', 'CO5', 'PO9_CO5', '7030A0')]
    col = 4; res = {}
    for po, co, wk, color in blocks:
        src, P, St = L(col), L(col + 1), L(col + 2)
        cell(ws, 4, col, f'={OUTC[po]["code"]}&" (KPI = "&TEXT({OUTC[po]["kpi"]},"0%")&")"', color, 'FFFFFF', True)
        ws.merge_cells(start_row=4, start_column=col, end_row=4, end_column=col + 2)
        cell(ws, 5, col, f'={OUTC[co]["code"]}&" (100%)"', LIGHT, bold=True, size=8)
        cell(ws, 6, col, f"={CFG[wk]}", YELLOW, '000000', size=8, fmt='"weight "0%')
        cell(ws, 7, col, '', MAXF)
        ws.column_dimensions[src].width = 12
        for r_ in range(FIRST, LAST + 1):
            cell(ws, r_, col, f'=IF(OR({BLANK(r_)},{CL["sheet"]}!{CL[co]}{r_}=""),"",{CL["sheet"]}!{CL[co]}{r_})', GREY, fmt='0.0%', align=RGT)
        formula_col(ws, P, 'Total 100%', '', lambda r_, src=src, wk=wk: f'=IF({src}{r_}="","",{src}{r_}*{CFG[wk]})', fmt='0.0%', width=16, bold=True)
        formula_col(ws, St, 'Status', '', lambda r_, P=P, po=po: f'=IF({P}{r_}="","",IF({P}{r_}>={OUTC[po]["kpi"]},"Achieved","Not achieved"))', fmt='@', width=12)
        ws.conditional_formatting.add(f'{P}{FIRST}:{P}{LAST}', bar(color))
        rg = f'{St}{FIRST}:{St}{LAST}'
        ws.conditional_formatting.add(rg, CellIsRule(operator='equal', formula=['"Achieved"'], fill=fill('C6EFCE'), font=Font(color='006100')))
        ws.conditional_formatting.add(rg, CellIsRule(operator='equal', formula=['"Not achieved"'], fill=fill('FFC7CE'), font=Font(color='9C0006', bold=True)))
        res[po] = (P, St); col += 3
    stats(ws, 4, col - 1, pct_cols=(L(4), L(5), L(7), L(8)))
    ws.column_dimensions[L(col)].width = 3
    summary_block(ws, col + 1, [(OUTC['PO5']['code'], OUTC['PO5']['kpi'], res['PO5'][0]), (OUTC['PO9']['code'], OUTC['PO9']['kpi'], res['PO9'][0])],
                  'Class summary — programme learning outcomes', f'Section {s}: PLO attainment', 11)
    page(ws, cols='A:C')
    OUTS[(s, 'PLO')] = dict(sheet=q(ws.title), PO5=res['PO5'][0], PO9=res['PO9'][0], S5=res['PO5'][1], S9=res['PO9'][1])


# ====================================================================== Final Sheet (combined, per section roster)
FINAL = {}


def final_sheet(s):
    ws = scaffold(s, 'Final Sheet', 'Final Sheet (all marks, attendance, CLO/PLO and result)', True,
                  '   ·   all formulas; lab results are matched by Reg. No from the student\'s lab group')
    ws.sheet_view.zoomScale = 85
    ws.cell(row=7, column=3).value = 'Maximum / held →'
    cols = []   # (group, header, kind, source)
    for grp, lab in [('Quizzes', 'Quizzes'), ('Assignments', 'Assignments'), ('Mid Exam', 'Mid exam'), ('Final Exam', 'Final exam')]:
        cols.append(('Theory marks', lab, 'th', grp))
    cols.append(('Theory marks', 'Theory %', 'thpct', None))
    cols += [('Theory attendance', 'Classes attended', 'tatt', None), ('Theory attendance', 'Theory attendance %', 'tattp', None),
             ('Theory attendance', 'Status', 'tatts', None)]
    cols.append(('Lab marks', 'Lab group', 'grp', None))
    for key, lab, mk in [('Lab Perf', 'Lab Perf.', 'M_PERF'), ('Lab Reports', 'Lab Reports', 'M_REP'), ('Lab Final', 'Lab Final', 'M_LFIN'),
                         ('Lab Mid', 'Lab Mid', 'M_LMID'), ('OEL', 'OEL', 'M_OEL'), ('Project', 'Project', 'M_PROJ')]:
        cols.append(('Lab marks', lab, 'lab', (key, mk)))
    cols += [('Lab marks', 'Lab total (33)', 'labtot', None), ('Lab marks', 'Lab %', 'labpct', None)]
    cols += [('Outcomes', 'CO4 %', 'out', ('CLO', 'CO4')), ('Outcomes', 'CO5 %', 'out', ('CLO', 'CO5')),
             ('Outcomes', 'PO5', 'outs', ('PLO', 'S5')), ('Outcomes', 'PO9', 'outs', ('PLO', 'S9'))]
    cols += [('Lab attendance', 'Labs attended', 'latt', None), ('Lab attendance', 'Lab attendance %', 'lattp', None),
             ('Lab attendance', 'Status', 'latts', None)]
    cols += [('Result', 'Course total %', 'ct', None), ('Result', 'Grade', 'grade', None), ('Result', 'Remarks', 'rem', None)]
    F0 = 4; FL = F0 + len(cols) - 1; HG, HR = L(FL + 1), L(FL + 2)
    FC = {(g, h): L(F0 + i) for i, (g, h, k, src) in enumerate(cols)}
    ws.cell(row=2, column=FL - 1, value='Min. %').font = F(size=9, bold=True)
    cell(ws, 2, FL, f"={CFG['THR']}", GREY, bold=True, fmt='0%', border=False)
    THRF = f'${L(FL)}$2'
    GC = {'Theory marks': '7030A0', 'Theory attendance': '2E75B6', 'Lab marks': '1F7A5A', 'Outcomes': 'B45F06',
          'Lab attendance': '548235', 'Result': 'C00000'}
    span = {}
    for i, (g, h, k, src) in enumerate(cols): span.setdefault(g, []).append(F0 + i)
    for g, cl in span.items(): group_header(ws, cl[0], cl[-1], g, GC[g])
    TA, LAs = ATT[(s, 'lec')], {g: ATT[(g, 'lab')] for g in SECS}
    labreg = [f"{q('Lab Groups')}!${REGC[g]}${FIRST}:${REGC[g]}${LAST}" for g in SECS]
    width = {'th': 9, 'thpct': 14, 'tatt': 9, 'tattp': 14, 'tatts': 9, 'grp': 6, 'lab': 8, 'labtot': 9, 'labpct': 14,
             'out': 12, 'outs': 12, 'latt': 9, 'lattp': 14, 'latts': 9, 'ct': 14, 'grade': 7, 'rem': 26}
    for i, (g, h, k, src) in enumerate(cols):
        cidx = F0 + i
        strong = k in ('thpct', 'labtot', 'labpct', 'ct', 'out')
        cell(ws, 5, cidx, h, 'C9DAF0' if strong else LIGHT, bold=strong, size=8)
        ws.merge_cells(start_row=5, start_column=cidx, end_row=6, end_column=cidx)
        r7 = {'th': lambda: f'={TH[(s, src)]["sheet"]}!{TH[(s, src)]["total"]}7', 'lab': lambda: f'={CFG[src[1]]}',
              'labtot': lambda: f"={CFG['M_TOTAL']}", 'tatt': lambda: f'={TA["sheet"]}!${TA["pct"]}$7'}.get(k)
        cell(ws, 7, cidx, r7() if r7 else '', MAXF, '375623', True, fmt='"held: "0' if k == 'tatt' else '"/ "0.##')
        ws.column_dimensions[L(cidx)].width = width[k]
    ws.column_dimensions[HG].hidden = True; ws.column_dimensions[HR].hidden = True
    W = {'Quizzes': 'W_Q', 'Assignments': 'W_A', 'Mid Exam': 'W_M', 'Final Exam': 'W_F'}
    for r_ in range(FIRST, LAST + 1):
        b = BLANK(r_)
        grp, row = f'${HG}{r_}', f'${HR}{r_}'
        ws[f'{HG}{r_}'] = '=IF($B{0}="",0,'.format(r_) + ''.join(
            f'IF(ISNUMBER(MATCH($B{r_},{labreg[i]},0)),{i + 1},' for i in range(4)) + '0' + ')' * 5
        ws[f'{HR}{r_}'] = f'=IF({grp}=0,0,MATCH($B{r_},CHOOSE({grp},{",".join(labreg)}),0))'

        def lab(sheet_of, col):
            refs = ','.join(f'{sheet_of(g)}!{col}${FIRST}:{col}${LAST}' for g in SECS)
            v = f'INDEX(CHOOSE({grp},{refs}),{row})'
            return f'=IF(OR({b},{grp}=0),"",IF({v}="","",{v}))'
        LTs = lambda g: LB[(g, 'Lab Total')]['sheet']
        for i, (g, h, k, src) in enumerate(cols):
            fmt, al, bold, bg = '0.##', C, False, GREY
            if k == 'th':
                t = TH[(s, src)]
                v = f'=IF(OR({b},{t["sheet"]}!{t["total"]}{r_}=""),"",{t["sheet"]}!{t["total"]}{r_})'; bg = 'FFFFFF'
            elif k == 'thpct':
                parts = [(TH[(s, grp_)], W[grp_]) for grp_ in W]
                num = '+'.join(f'IF({t["sheet"]}!{t["pct"]}{r_}="",0,{CFG[w]}*{t["sheet"]}!{t["pct"]}{r_})' for t, w in parts)
                den = '+'.join(f'IF({t["sheet"]}!{t["pct"]}{r_}="",0,{CFG[w]})' for t, w in parts)
                v = f'=IF(OR({b},({den})=0),"",({num})/({den}))'; fmt, al, bold = '0.0%', RGT, True
            elif k == 'tatt':
                v = f'=IF(OR({b},{TA["sheet"]}!${TA["pct"]}$7=0),"",{TA["sheet"]}!{TA["present"]}{r_}&" / "&{TA["sheet"]}!${TA["pct"]}$7)'
            elif k == 'tattp':
                v = f'=IF(OR({b},{TA["sheet"]}!{TA["pct"]}{r_}=""),"",{TA["sheet"]}!{TA["pct"]}{r_})'; fmt, al = '0.0%', RGT
            elif k == 'tatts':
                v = f'=IF(OR({b},{TA["sheet"]}!{TA["status"]}{r_}=""),"",{TA["sheet"]}!{TA["status"]}{r_})'
            elif k == 'grp':
                v = f'=IF({b},"",IF({grp}=0,"—",CHOOSE({grp},"A","B","C","D")))'
            elif k == 'lab':
                v = lab(LTs, LB[('A', 'Lab Total')]['cols'][src[0]]); bg = 'FFFFFF'
            elif k == 'labtot':
                v = lab(LTs, LB[('A', 'Lab Total')]['total']); bold = True
            elif k == 'labpct':
                v = lab(LTs, LB[('A', 'Lab Total')]['pct']); fmt, al, bold = '0.0%', RGT, True
            elif k == 'out':
                v = lab(lambda g: OUTS[(g, 'CLO')]['sheet'], OUTS[('A', 'CLO')][src[1]]); fmt, al = '0.0%', RGT
            elif k == 'outs':
                v = lab(lambda g: OUTS[(g, 'PLO')]['sheet'], OUTS[('A', 'PLO')][src[1]]); fmt = None
            elif k == 'latt':
                pres = ','.join(f'{LAs[g_]["sheet"]}!{LAs["A"]["present"]}${FIRST}:{LAs["A"]["present"]}${LAST}' for g_ in SECS)
                held = ','.join(f'{LAs[g_]["sheet"]}!${LAs["A"]["pct"]}$7' for g_ in SECS)
                v = f'=IF(OR({b},{grp}=0),"",IF(CHOOSE({grp},{held})=0,"",INDEX(CHOOSE({grp},{pres}),{row})&" / "&CHOOSE({grp},{held})))'
            elif k == 'lattp':
                v = lab(lambda g: LAs[g]['sheet'], LAs['A']['pct']); fmt, al = '0.0%', RGT
            elif k == 'latts':
                v = lab(lambda g: LAs[g]['sheet'], LAs['A']['status']); fmt = None
            elif k == 'ct':
                tp, lp = FC[('Theory marks', 'Theory %')], FC[('Lab marks', 'Lab %')]
                v = (f'=IF(OR({b},AND({tp}{r_}="",{lp}{r_}="")),"",(IF({tp}{r_}="",0,{CFG["SH_T"]}*{tp}{r_})+IF({lp}{r_}="",0,{CFG["SH_L"]}*{lp}{r_}))'
                     f'/(IF({tp}{r_}="",0,{CFG["SH_T"]})+IF({lp}{r_}="",0,{CFG["SH_L"]})))')
                fmt, al, bold = '0.0%', RGT, True
            elif k == 'grade':
                ct = FC[('Result', 'Course total %')]
                v = f'=IF({ct}{r_}="","",INDEX({GNAME},MATCH(ROUND({ct}{r_}*100,2),{GMIN},1)))'; fmt, bold = None, True
            elif k == 'rem':
                ts, ls = FC[('Theory attendance', 'Status')], FC[('Lab attendance', 'Status')]
                lg = FC[('Lab marks', 'Lab group')]
                v = (f'=IF({b},"",IF($B{r_}="","Reg. No missing",IF({lg}{r_}="—","Not in any lab group",'
                     f'IF(AND({ts}{r_}="Short",{ls}{r_}="Short"),"Short attendance: theory and lab",IF({ts}{r_}="Short","Short attendance: theory",'
                     f'IF({ls}{r_}="Short","Short attendance: lab",""))))))')
                fmt, al = None, LFT
            cell(ws, r_, F0 + i, v, bg, bold=bold, fmt=fmt, align=al, size=8 if k == 'rem' else 9)
    pcs = [FC[(g, h)] for g, h, k, src in cols if k in ('thpct', 'labpct', 'out', 'tattp', 'lattp', 'ct')]
    for k_, (lab_, fn) in enumerate([('Class average', 'AVERAGE'), ('Highest', 'MAX'), ('Lowest', 'MIN')]):
        r_ = LAST + 2 + k_
        cell(ws, r_, 3, lab_, LIGHT, bold=True, align=LFT)
        for i, (g, h, k, src) in enumerate(cols):
            if k in ('th', 'thpct', 'tattp', 'lab', 'labtot', 'labpct', 'out', 'lattp', 'ct'):
                c_ = L(F0 + i)
                cell(ws, r_, F0 + i, f'=IF(COUNT({c_}{FIRST}:{c_}{LAST})=0,"",{fn}({c_}{FIRST}:{c_}{LAST}))', GREY, bold=True,
                     fmt='0.0%' if c_ in pcs else '0.0', size=8)
    for key in [('Theory attendance', 'Status'), ('Lab attendance', 'Status')]:
        c_ = FC[key]; cell(ws, LAST + 2, CI(c_), f'=COUNTIF({c_}{FIRST}:{c_}{LAST},"Short")&" short"', GREY, 'C00000', True, 8)
    for key, color in [(('Theory marks', 'Theory %'), '9E7BC4'), (('Lab marks', 'Lab %'), '70AD47'), (('Theory attendance', 'Theory attendance %'), '2E75B6'),
                       (('Lab attendance', 'Lab attendance %'), '548235'), (('Result', 'Course total %'), 'C00000'),
                       (('Outcomes', 'CO4 %'), 'F4B183'), (('Outcomes', 'CO5 %'), 'F4B183')]:
        c_ = FC[key]; ws.conditional_formatting.add(f'{c_}{FIRST}:{c_}{LAST}', bar(color))
    for key in [('Theory attendance', 'Theory attendance %'), ('Lab attendance', 'Lab attendance %')]:
        c_ = FC[key]
        ws.conditional_formatting.add(f'{c_}{FIRST}:{c_}{LAST}', FormulaRule(formula=[f'AND(ISNUMBER({c_}{FIRST}),{c_}{FIRST}<{THRF})'], font=Font(color='C00000', bold=True)))
    for key in [('Theory attendance', 'Status'), ('Lab attendance', 'Status'), ('Outcomes', 'PO5'), ('Outcomes', 'PO9')]:
        c_ = FC[key]; st = f'{c_}{FIRST}:{c_}{LAST}'
        for bad in ('"Short"', '"Not achieved"'):
            ws.conditional_formatting.add(st, CellIsRule(operator='equal', formula=[bad], fill=fill('FFC7CE'), font=Font(color='9C0006', bold=True)))
        for good in ('"Eligible"', '"Achieved"'):
            ws.conditional_formatting.add(st, CellIsRule(operator='equal', formula=[good], fill=fill('C6EFCE'), font=Font(color='006100')))
    gcl = FC[('Result', 'Grade')]
    ws.conditional_formatting.add(f'{gcl}{FIRST}:{gcl}{LAST}', CellIsRule(operator='equal', formula=['"F"'], fill=fill('FFC7CE'), font=Font(color='9C0006', bold=True)))
    rm = FC[('Result', 'Remarks')]
    ws.conditional_formatting.add(f'{rm}{FIRST}:{rm}{LAST}', FormulaRule(formula=[f'LEN({rm}{FIRST})>0'], font=Font(color='C00000')))
    page(ws, paper=8)
    FINAL[s] = dict(sheet=q(ws.title), FC=FC)


# ====================================================================== build all sections
PAGES = [('Theory Att', 'Theory Attendance'), ('Lab Att', 'Lab Attendance'), ('Quizzes', 'Quizzes'), ('Assignments', 'Assignments'),
         ('Mid Exam', 'Mid-Term Exam'), ('Final Exam', 'Final Exam'), ('Lab Perf', 'Lab Performance'), ('Lab Reports', 'Lab Reports'),
         ('Lab Mid', 'Lab Mid Exam'), ('Lab Final', 'Lab Final Exam'), ('OEL', 'Open-Ended Lab'), ('Project', 'Project'),
         ('Lab Total', 'Lab Total'), ('CLO', 'CLO Sheet'), ('PLO', 'PLO Sheet'), ('Final Sheet', 'Final Sheet')]
for s in SECS:
    attendance(s, 'lec'); attendance(s, 'lab')
    theory_items(s, 'Quizzes', 'Quizzes', 'C00000', [DATE(s, 'lec', 5), DATE(s, 'lec', 14)], 'items')
    theory_items(s, 'Assignments', 'Assignments', '7030A0', [DATE(s, 'lec', 8), DATE(s, 'lec', 15)], 'items')
    theory_items(s, 'Mid Exam', 'Mid-Term Exam (Q1–Q5)', '2F5597', [CFG['MIDD']], 'exam')
    theory_items(s, 'Final Exam', 'Final Exam (Q1–Q10)', '833C0B', [CFG['FIND']], 'exam')
    experiments(s, 'Lab Perf', 'Lab Performance (14 experiments)', 'Lab Perf', 'M_PERF',
                'SK = Subject Knowledge (0-5), DA = Data Analysis & Interpretation (0-5), AC = Ability to Conduct Exp. (0-5)', '5B9BD5')
    experiments(s, 'Lab Reports', 'Lab Reports (14 experiments)', 'Lab Reports', 'M_REP',
                'PR = Presentation (0-5), CC = Calculation / Coding (0-5), OB = Observations / Program Results (0-5)', '9E7BC4')
    single(s, 'Lab Mid', 'Lab Mid Exam', 'Lab Mid', 'Total (out of 15)', 'M_LMID', 'WK_LMID', '2F5597')
    single(s, 'Lab Final', 'Lab Final Exam', 'Lab Final', 'Total (out of 15)', 'M_LFIN', 'WK_LFIN', '833C0B')
    single(s, 'OEL', 'Open-Ended Lab (viva voce)', 'OEL', 'Total (out of 20)', 'M_OEL', 'WK_OEL', 'B45F06')
    project(s)
    lab_total(s)
    clo(s); plo(s)
for s in SECS:
    final_sheet(s)

# ====================================================================== Section Results
SR = wb.create_sheet('Section Results')
SR.sheet_properties.tabColor = NAVY
SR.sheet_view.showGridLines = False
head(SR, 'CS-309 Web Design & Development — Section-wise Results', 'BSCS 5th Semester, Batch 2024 — Fall 2026   ·   all values are formulas from the four Final Sheets')
for col, w in zip('ABCDEFGH', [3, 46, 15, 15, 15, 15, 15, 3]): SR.column_dimensions[col].width = w
cell(SR, 5, 2, 'Measure', NAVY, 'FFFFFF', True, 10)
for k, s in enumerate(SECS): cell(SR, 5, 3 + k, f'="Section {s}"&CHAR(10)&{SECNAME(s)}', TAB[s], 'FFFFFF', True, 10)
cell(SR, 5, 7, 'All sections', NAVY, 'FFFFFF', True, 10)
SR.row_dimensions[5].height = 30
rng = lambda s, key: f"{FINAL[s]['sheet']}!{FINAL[s]['FC'][key]}{FIRST}:{FINAL[s]['FC'][key]}{LAST}"
allr = lambda key: ','.join(rng(s, key) for s in SECS)
avg = lambda key: (lambda s: f'=IFERROR(AVERAGE({rng(s, key)}),"")', f'=IFERROR(AVERAGE({allr(key)}),"")')
mx_ = lambda key, fn: (lambda s: f'=IF(COUNT({rng(s, key)})=0,"",{fn}({rng(s, key)}))', f'=IF(COUNT({allr(key)})=0,"",{fn}({allr(key)}))')
cnt_eq = lambda key, val: (lambda s: f'=COUNTIF({rng(s, key)},"{val}")', '=' + '+'.join(f'COUNTIF({rng(s, key)},"{val}")' for s in SECS))
nm = lambda s: f"{FINAL[s]['sheet']}!$C${FIRST}:$C${LAST}"
cnt = lambda s: f'SUMPRODUCT(--({nm(s)}<>""))'
graded = lambda s: f'SUMPRODUCT(--({rng(s, ("Result", "Grade"))}<>""))'
passed = lambda s: f'({graded(s)}-COUNTIF({rng(s, ("Result", "Grade"))},"F"))'
share = lambda key, val: (lambda s: f'=IF(COUNT({rng(s, key)})=0,"",COUNTIF({rng(s, key)},">="&{val})/COUNT({rng(s, key)}))',
                          f'=IF(COUNT({allr(key)})=0,"",(' + '+'.join('COUNTIF(' + rng(s, key) + ',">="&' + val + ')' for s in SECS) + f')/COUNT({allr(key)}))')
outof = lambda t, ref: f'="{t} (out of "&TEXT({ref},"0.##")&")"'
rows = [('Enrolment and classes', None, None, None, None),
        ('Students in section', lambda s: f'={cnt(s)}', '=' + '+'.join(cnt(s) for s in SECS), '0', False),
        ('Lectures held', lambda s: f"={ATT[(s, 'lec')]['sheet']}!${ATT[(s, 'lec')]['pct']}$7", '', '0', False),
        ('Labs held (lab group of the same letter)', lambda s: f"={ATT[(s, 'lab')]['sheet']}!${ATT[(s, 'lab')]['pct']}$7", '', '0', False),
        ('Attendance', None, None, None, None),
        ('Average theory attendance %',) + avg(('Theory attendance', 'Theory attendance %')) + ('0.0%', True),
        ('Students short in theory attendance',) + cnt_eq(('Theory attendance', 'Status'), 'Short') + ('0', False),
        ('Average lab attendance %',) + avg(('Lab attendance', 'Lab attendance %')) + ('0.0%', True),
        ('Students short in lab attendance',) + cnt_eq(('Lab attendance', 'Status'), 'Short') + ('0', False),
        ('Theory marks (class averages)', None, None, None, None)]
sumref = lambda grp: '+'.join(MAX[(grp, lab)] for lab, mx in THEORY[grp])
for grp, lab in [('Quizzes', 'Quizzes'), ('Assignments', 'Assignments'), ('Mid Exam', 'Mid exam'), ('Final Exam', 'Final exam')]:
    hm = 'MAX(' + ','.join(f"{TH[(s, grp)]['sheet']}!${TH[(s, grp)]['total']}$7" for s in SECS) + ')'
    held_ = '+'.join(f"COUNT({TH[(s, grp)]['sheet']}!${TH[(s, grp)]['total']}${FIRST}:${TH[(s, grp)]['total']}${LAST})" for s in SECS)
    rows.append((f'=IF(({held_})=0,"{lab} (not held yet)","{lab} (out of "&TEXT({hm},"0.##")&")")',) + avg(('Theory marks', lab)) + ('0.0', False))
rows.append(('Theory %',) + avg(('Theory marks', 'Theory %')) + ('0.0%', True))
rows.append(('Lab marks (class averages)', None, None, None, None))
for lab, mk in [('Lab Perf.', 'M_PERF'), ('Lab Reports', 'M_REP'), ('Lab Final', 'M_LFIN'), ('Lab Mid', 'M_LMID'), ('OEL', 'M_OEL'), ('Project', 'M_PROJ')]:
    rows.append((outof({'Lab Perf.': 'Lab performance'}.get(lab, lab), CFG[mk]),) + avg(('Lab marks', lab)) + ('0.0', False))
rows.append((outof('Lab total', CFG['M_TOTAL']),) + avg(('Lab marks', 'Lab total (33)')) + ('0.0', False))
rows.append(('Lab %',) + avg(('Lab marks', 'Lab %')) + ('0.0%', True))
rows.append(('Course and programme learning outcomes', None, None, None, None))
OUTROWS = {}
for code, key, kpi in [('CO4', ('Outcomes', 'CO4 %'), OUTC['CO4']['kpi']), ('CO5', ('Outcomes', 'CO5 %'), OUTC['CO5']['kpi'])]:
    rows.append((f'="Average "&{OUTC[code]["code"]}&" attainment"',) + avg(key) + ('0.0%', True))
    rows.append((f'="Students achieving "&{OUTC[code]["code"]}&" (≥ KPI)"',) + share(key, kpi) + ('0.0%', True))
    OUTROWS[code] = len(rows)
for code, key in [('PO5', ('Outcomes', 'PO5')), ('PO9', ('Outcomes', 'PO9'))]:
    rows.append((f'="Students achieving "&{OUTC[code]["code"]}',
                 lambda s, key=key: f'=IF(COUNTA({rng(s, key)})-COUNTBLANK({rng(s, key)})=0,"",COUNTIF({rng(s, key)},"Achieved")/(COUNTIF({rng(s, key)},"Achieved")+COUNTIF({rng(s, key)},"Not achieved")))',
                 '=IFERROR((' + '+'.join(f'COUNTIF({rng(s, key)},"Achieved")' for s in SECS) + ')/(' + '+'.join(
                     f'COUNTIF({rng(s, key)},"Achieved")+COUNTIF({rng(s, key)},"Not achieved")' for s in SECS) + '),"")', '0.0%', True))
    OUTROWS[code] = len(rows)
rows.append(('Result', None, None, None, None))
rows += [('Average course total %',) + avg(('Result', 'Course total %')) + ('0.0%', True),
         ('Highest course total %',) + mx_(('Result', 'Course total %'), 'MAX') + ('0.0%', True),
         ('Lowest course total %',) + mx_(('Result', 'Course total %'), 'MIN') + ('0.0%', True),
         ('Students passed (grade D or better)', lambda s: f'={passed(s)}', '=' + '+'.join(passed(s) for s in SECS), '0', False),
         ('Students failed (F)',) + cnt_eq(('Result', 'Grade'), 'F') + ('0', False),
         ('Pass rate', lambda s: f'=IF({graded(s)}=0,"",{passed(s)}/{graded(s)})',
          f'=IF(({"+".join(graded(s) for s in SECS)})=0,"",({"+".join(passed(s) for s in SECS)})/({"+".join(graded(s) for s in SECS)}))', '0.0%', True)]
r = 6
ROWAT = {}
for i, (lab, fn, allf, fmt, isbar) in enumerate(rows):
    if fn is None:
        cell(SR, r, 2, lab, LIGHT, NAVY, True, 10, LFT)
        for c in range(3, 8): cell(SR, r, c, '', LIGHT)
    else:
        cell(SR, r, 2, lab, None, size=10, align=LFT)
        for k, s in enumerate(SECS): cell(SR, r, 3 + k, fn(s), GREY, size=10, fmt=fmt, align=RGT if '%' in fmt else C)
        cell(SR, r, 7, allf, 'E7E6E6', bold=True, size=10, fmt=fmt, align=RGT if '%' in fmt else C)
        if isbar: SR.conditional_formatting.add(f'C{r}:G{r}', bar('5B9BD5'))
    ROWAT[i + 1] = r
    r += 1
# outcome attainment table + chart
r += 1
OA0 = r
cell(SR, r, 2, 'Students achieving the KPI (% of assessed)', NAVY, 'FFFFFF', True, 10, LFT)
for k, s in enumerate(SECS): cell(SR, r, 3 + k, f'Section {s}', TAB[s], 'FFFFFF', True, 10)
cell(SR, r, 7, 'All sections', NAVY, 'FFFFFF', True, 10)
for i, code in enumerate(['CO4', 'CO5', 'PO5', 'PO9']):
    rr = r + 1 + i; src = ROWAT[OUTROWS[code]]
    cell(SR, rr, 2, f'={OUTC[code]["code"]}', None, bold=True, size=10, align=LFT)
    for c in range(3, 8): cell(SR, rr, c, f'={L(c)}{src}', GREY, size=10, fmt='0.0%', align=RGT)
OA1 = r + 4
ch = BarChart(); ch.type = 'col'; ch.grouping = 'clustered'; ch.title = 'CLO / PLO attainment by section'
ch.y_axis.title = 'Students ≥ KPI'; ch.y_axis.scaling.min = 0; ch.y_axis.scaling.max = 1; ch.y_axis.number_format = '0%'
ch.add_data(Reference(SR, min_col=3, max_col=6, min_row=OA0, max_row=OA1), titles_from_data=True)
ch.set_categories(Reference(SR, min_col=2, min_row=OA0 + 1, max_row=OA1))
for k, s in enumerate(SECS):
    ch.series[k].graphicalProperties.solidFill = TAB[s]; ch.series[k].graphicalProperties.line.solidFill = TAB[s]
ch.height, ch.width = 8, 19; ch.legend.position = 'b'; ch.x_axis.delete = False; ch.y_axis.delete = False
# grade distribution
r = OA1 + 2
GD0 = r
cell(SR, r, 2, 'Grade distribution (students per grade)', NAVY, 'FFFFFF', True, 10, LFT)
for k, s in enumerate(SECS): cell(SR, r, 3 + k, f'Section {s}', TAB[s], 'FFFFFF', True, 10)
cell(SR, r, 7, 'All sections', NAVY, 'FFFFFF', True, 10)
for i in range(len(grades)):
    rr = r + 1 + i; gref = f'Settings!$J${G1 - i}'
    cell(SR, rr, 2, f'={gref}', None, size=10, align=LFT)
    for k, s in enumerate(SECS): cell(SR, rr, 3 + k, f'=COUNTIF({rng(s, ("Result", "Grade"))},{gref})', GREY, size=10)
    cell(SR, rr, 7, f'=SUM(C{rr}:F{rr})', 'E7E6E6', bold=True, size=10)
GD1 = r + len(grades)
for k, s in enumerate(SECS):
    SR.conditional_formatting.add(f'{L(3 + k)}{GD0 + 1}:{L(3 + k)}{GD1}', DataBarRule(start_type='num', start_value=0, end_type='max', color=TAB[s], showValue=True))
g = BarChart(); g.type = 'col'; g.grouping = 'clustered'; g.title = 'Grade distribution by section'; g.y_axis.title = 'Students'
g.add_data(Reference(SR, min_col=3, max_col=6, min_row=GD0, max_row=GD1), titles_from_data=True)
g.set_categories(Reference(SR, min_col=2, min_row=GD0 + 1, max_row=GD1))
for k, s in enumerate(SECS):
    g.series[k].graphicalProperties.solidFill = TAB[s]; g.series[k].graphicalProperties.line.solidFill = TAB[s]
g.height, g.width = 8, 19; g.legend.position = 'b'; g.x_axis.delete = False; g.y_axis.delete = False
SR.add_chart(ch, f'B{GD1 + 2}')
SR.add_chart(g, f'B{GD1 + 19}')
page(SR, orient='portrait', rows=None, cols=None)


# ====================================================================== Home page + buttons
def link(ws, ref, target, text, bg, fg='FFFFFF', size=10, merge_to=None, height=None):
    c = ws[ref]
    c.value = text
    c.hyperlink = Hyperlink(ref=ref, location=f"'{target}'!A1", tooltip=f'Go to {target}', display=text)
    c.font = Font(name='Arial', size=size, bold=True, color=fg)
    c.fill = fill(bg)
    c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    side = Side(style='medium', color='FFFFFF')
    c.border = Border(left=side, right=side, top=side, bottom=side)
    if merge_to: ws.merge_cells(f'{ref}:{merge_to}')
    if height: ws.row_dimensions[c.row].height = height
    return c


H = wb.create_sheet('Home')
H.sheet_properties.tabColor = 'C00000'
H.sheet_view.showGridLines = False
for col, w in zip('ABCDEFGHI', [3, 26, 2, 26, 2, 26, 2, 26, 3]): H.column_dimensions[col].width = w
H['B2'] = 'CS-309 Web Design & Development'; H['B2'].font = F(size=20, bold=True, color=NAVY); H.row_dimensions[2].height = 30
H['B3'] = 'Attendance, Marks, CLO/PLO and Results Register — BSCS 5th Semester, Batch 2024 — Fall 2026'; H['B3'].font = F(size=11, color='595959')
H['B4'] = f'="HITEC University, Taxila   ·   Instructor: "&{SECINST("A")}'; H['B4'].font = F(size=10, color='595959')
note(H, 'B6', 'Click a button to open a sheet. Every sheet has a  ⌂ Home  button (top left) that brings you back here.', 10)
H.merge_cells('B6:H6')
H['B8'] = 'Course set-up and results'; H['B8'].font = F(size=12, bold=True, color=NAVY)
for (sheet, text, nt, bg), col in zip([('Settings', 'Settings', 'Weights, max marks, grades, CLO/PLO', '404040'),
                                       ('Schedule', 'Schedule', '16-week dates of all sections', '595959'),
                                       ('Students', 'Class Lists', 'Students of sections A–D', '1F3864'),
                                       ('Lab Groups', 'Lab Groups', 'Lab group lists A–D', '1F7A5A')], 'BDFH'):
    link(H, f'{col}9', sheet, text, bg, size=11, height=32)
    c = H[f'{col}10']; c.value = nt; c.font = F(size=8, italic=True, color='7F7F7F'); c.alignment = C
link(H, 'B11', 'Section Results', 'Section-wise Results  ·  attendance, marks, CLO/PLO attainment and grades of A, B, C, D', 'C00000',
     size=11, merge_to='H11', height=32)
H['B13'] = 'Section sheets'; H['B13'].font = F(size=12, bold=True, color=NAVY)
groups = [('Attendance', PAGES[0:2]), ('Theory assessments', PAGES[2:6]), ('Lab assessments', PAGES[6:12]),
          ('Totals, outcomes and result', PAGES[12:16])]
for s, col in zip(SECS, 'BDFH'):
    c = H[f'{col}14']; c.value = f'="Section {s}  ·  "&{SECNAME(s)}'
    c.font = F(size=12, bold=True, color='FFFFFF'); c.fill = fill(TAB[s]); c.alignment = C
    c = H[f'{col}15']; c.value = f'="Students: "&SUMPRODUCT(--(Students!${NAMEC[s]}${FIRST}:${NAMEC[s]}${LAST}<>""))'
    c.font = F(size=9, color='595959'); c.alignment = C
    r = 16
    for gname, pages in groups:
        c = H[f'{col}{r}']; c.value = gname; c.font = F(size=8, bold=True, color='7F7F7F'); c.alignment = Alignment(horizontal='left', vertical='bottom')
        H.row_dimensions[r].height = 16; r += 1
        for suffix, text in pages:
            link(H, f'{col}{r}', f'{s} {suffix}', text, TINT[s] if suffix != 'Final Sheet' else TAB[s],
                 fg=TAB[s] if suffix != 'Final Sheet' else 'FFFFFF', size=10, height=24)
            r += 1
H.row_dimensions[14].height = 28
note(H, f'B{r + 1}', 'Lab group = the section of the same letter unless you change Lab Groups. Lab results reach the Final Sheet by Reg. No.', 9)
H.merge_cells(f'B{r + 1}:H{r + 1}')
H.page_setup.orientation = 'portrait'; H.page_setup.paperSize = 9; H.page_setup.fitToWidth = 1; H.page_setup.fitToHeight = 1
H.sheet_properties.pageSetUpPr = PageSetupProperties(fitToPage=True)

for ws in wb.worksheets:
    if ws.title == 'Home': continue
    if ws.title in ('Settings', 'Section Results', 'Schedule'):
        link(ws, 'B3', 'Home', '⌂ Home', 'C00000', size=10)
    else:
        link(ws, 'A3', 'Home', '⌂ Home', 'C00000', size=10, merge_to='B3')
    ws.row_dimensions[3].height = 22

order = ['Home', 'Settings', 'Schedule', 'Section Results', 'Students', 'Lab Groups']
for s in SECS: order += [f'{s} {suffix}' for suffix, text in PAGES]
assert set(order) == set(wb.sheetnames), set(wb.sheetnames) ^ set(order)
wb._sheets = [wb[n] for n in order]
wb.active = 0
for ws in wb.worksheets: ws.sheet_view.tabSelected = ws.title == 'Home'
wb.save(OUT)
if APP:
    cref = lambda ref: ref.split('!')[1].replace('$', '')
    val = lambda ref: S[cref(ref)].value
    keys = [k for k in CFG if not k.endswith('TOTAL')]
    M = dict(first=FIRST, last=LAST, weeks=WEEKS, nexp=NEXP, secs=SECS,
             settings={k: dict(cell=cref(CFG[k]), value=(val(CFG[k]).isoformat() if hasattr(val(CFG[k]), 'isoformat') else val(CFG[k]))) for k in keys},
             sections={s: dict(row=SECROW[s], values=[S.cell(row=SECROW[s], column=3 + j).value for j in range(5)]) for s in SECS},
             grades=dict(first=G0, rows=[list(g) for g in grades]),
             max={f'{g}|{i}': dict(cell=cref(r), value=S[cref(r)].value) for (g, i), r in MAX.items()},
             theory={g: [i for i, m in items] for g, items in THEORY.items()},
             rubric={g: dict(parts=[list(p) for p in parts], max=mx) for g, (parts, mx) in RUBRIC.items()},
             outc={k: dict(row=int(cref(v['code'])[1:]), code=S[cref(v['code'])].value, kpi=S[cref(v['kpi'])].value,
                           desc=S.cell(row=int(cref(v['code'])[1:]), column=5).value) for k, v in OUTC.items()},
             schedule=dict(first=SCH0, cols={s: dict(lec=DATECOL[(s, 'lec')], lab=DATECOL[(s, 'lab')]) for s in SECS}, activity='K', notes='L',
                           activities=[SC.cell(row=SCH0 + w, column=11).value for w in range(WEEKS)]),
             roster=dict(reg=REGC, name=NAMEC, rem={s: L(BLK[s] + 3) for s in SECS}),
             entries=ENTRY, pages=PAGES, labs=LABS)
    json.dump(M, open(os.environ['MAP'], 'w'), indent=1, default=str)
    print('map written', os.environ['MAP'])
print('saved', OUT, len(wb.sheetnames), 'sheets')
