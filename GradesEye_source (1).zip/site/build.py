# Builds the GradesEye website: dist/artifact.html (published page) and dist/site/ (folder to host anywhere, with downloads).
import base64, io, os, re, shutil
from PIL import Image
ROOT = '/home/claude/site'; APP = '/home/claude/apk/app'; OUTS = '/home/claude/outputs'
src = open(f'{ROOT}/src/page.html').read()
def data_uri(path, mime): return f'data:{mime};base64,' + base64.b64encode(open(path, 'rb').read()).decode()
def icon(path, size=112):
    im = Image.open(path).convert('RGBA').resize((size, size), Image.LANCZOS); b = io.BytesIO(); im.save(b, 'PNG', optimize=True)
    return 'data:image/png;base64,' + base64.b64encode(b.getvalue()).decode()
imgs = {'icon_faculty': icon(f'{APP}/icon_faculty512.png'), 'icon_student': icon(f'{APP}/icon_student512.png')}
for f in os.listdir(f'{ROOT}/shots'):
    if f.endswith('.webp'): imgs[f[:-5]] = data_uri(f'{ROOT}/shots/{f}', 'image/webp')
files = {'faculty': f'{OUTS}/GradesEye_Faculty_v1.4.apk', 'student': f'{OUTS}/GradesEye_Student_v1.1_unlinked.apk', 'script': f'{OUTS}/GradesEye_Drive_Script_v5.gs'}
kb = lambda p: f'{round(os.path.getsize(p) / 1024)} KB'
page = re.sub(r'\{\{IMG:(\w+)\}\}', lambda m: imgs[m.group(1)], src)
page = re.sub(r'\{\{SIZE:(\w+)\}\}', lambda m: kb(files[m.group(1)]), page)
assert '{{' not in page, re.findall(r'\{\{[^}]+\}\}', page)[:3]
os.makedirs(f'{ROOT}/dist/site/downloads', exist_ok=True)
open(f'{ROOT}/dist/artifact.html', 'w').write(page)
head_extra = ('<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
  '<meta name="description" content="GradesEye keeps attendance and marks on your phone, writes one Excel register per course into your Google Drive, and lets each student see only their own record.">\n'
  '<meta property="og:title" content="GradesEye">\n<meta property="og:description" content="Your register in your Drive. Their results in their pocket.">\n'
  f'<link rel="icon" href="{imgs["icon_faculty"]}">\n')
title_end = page.index('</title>') + len('</title>')
style_end = page.index('</style>') + len('</style>')
hosted = '<!doctype html>\n<html lang="en">\n<head>\n' + head_extra + page[:style_end] + '\n</head>\n<body>\n' + page[style_end:] + '\n</body>\n</html>\n'
open(f'{ROOT}/dist/site/index.html', 'w').write(hosted)
shutil.copy(files['faculty'], f'{ROOT}/dist/site/downloads/GradesEye_Faculty_v1.4.apk')
shutil.copy(files['student'], f'{ROOT}/dist/site/downloads/GradesEye_Student_v1.1.apk')
shutil.copy(files['script'], f'{ROOT}/dist/site/downloads/GradesEye_Drive_Script_v5.gs')
# sign-in page (a full document in both places: the published artifact serves it as a sibling page)
sig = open(f'{ROOT}/src/signin.html').read()
js = lambda p: open(p).read().replace('</', '<\\/')
sig = re.sub(r'\{\{IMG:(\w+)\}\}', lambda m: imgs[m.group(1)], sig)
sig = sig.replace('{{DEMO_STUDENT}}', js(f'{ROOT}/build/demo_student.json')).replace('{{DEMO_FACULTY}}', js(f'{ROOT}/build/demo_faculty.json'))
assert '{{' not in sig, re.findall(r'\{\{[^}]+\}\}', sig)[:3]
open(f'{ROOT}/dist/signin.html', 'w').write(sig)
open(f'{ROOT}/dist/site/signin.html', 'w').write(sig)
print('artifact', len(page) // 1024, 'KB; hosted', len(hosted) // 1024, 'KB; signin', len(sig) // 1024, 'KB')
