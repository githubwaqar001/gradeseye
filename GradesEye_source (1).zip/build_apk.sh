#!/bin/bash
# Build an APK without Gradle: javac -> dx -> aapt2 link -> add dex -> zipalign + sign (v2/v3)
#   APP=student  -> out/GradesEye_Student.apk  (android-student + dist-student)
#   APP=teacher  -> out/GradesEye_Faculty.apk  (android + dist2; bundles out/GradesEye_Student.apk, so build the student app first)
set -euo pipefail
ROOT=/home/claude/apk/app; T=/home/claude/apk/tools; OUTD=$ROOT/out
APP=${APP:-teacher}
VERSION_CODE=${VERSION_CODE:-1}; VERSION_NAME=${VERSION_NAME:-1.0}
ANDROID_JAR=$T/sable/android-33/android.jar
if [ "$APP" = student ]; then
  SRC=$ROOT/android-student; WEB=$ROOT/${DIST:-dist-student}; NAME=GradesEye_Student.apk; B=$ROOT/build-student
else
  SRC=$ROOT/android; WEB=$ROOT/${DIST:-dist2}; NAME=GradesEye_Faculty.apk; B=$ROOT/build
fi
rm -rf $B && mkdir -p $B/classes $B/res $B/assets/www $OUTD
cp -r $WEB/. $B/assets/www/
if [ "$APP" != student ]; then
  test -f $OUTD/GradesEye_Student.apk || { echo "build the student app first (APP=student)"; exit 1; }
  mkdir -p $B/assets/student && cp $OUTD/GradesEye_Student.apk $B/assets/student/GradesEye_Student.apk
fi
javac -nowarn -source 8 -target 8 -bootclasspath $ANDROID_JAR -encoding UTF-8 -d $B/classes $(find $SRC/src $ROOT/android-common/src -name '*.java') 2>&1 | grep -v 'warning: \[options\]' || true
java -cp $T/dex-tools-v2.4/lib/dx-30.0.2.jar com.android.dx.command.Main --dex --min-sdk-version=24 --output=$B/classes.dex $B/classes
$T/bin/aapt2_64 compile --dir $SRC/res -o $B/res/compiled.zip
$T/bin/aapt2_64 link -o $B/base.apk -I $ANDROID_JAR --manifest $SRC/AndroidManifest.xml \
  --min-sdk-version 24 --target-sdk-version 34 --version-code $VERSION_CODE --version-name $VERSION_NAME \
  -A $B/assets $B/res/compiled.zip
(cd $B && zip -q -j base.apk classes.dex)
java -jar $T/uber.jar -a $B/base.apk -o $B/signed --ks $ROOT/keystore/wdd-register.jks --ksAlias wddregister \
  --ksPass "$KSPASS" --ksKeyPass "$KSPASS" --allowResign > $B/sign.log 2>&1 || { cat $B/sign.log; exit 1; }
cp $B/signed/*.apk $OUTD/$NAME
grep -E "VERIFY|signature|ERROR|zipalign" $B/sign.log | head -12
ls -la $OUTD/$NAME
