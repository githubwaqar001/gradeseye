// GradesEye Student (© 2026 softonicBank Co.) — a student's own attendance and marks, read from the teacher's Drive script (read-only).
// The connection (script address + teacher name) is built into the APK the teacher shares; a class code also works.
import '../../web2/src/polyfills.js';
import { store, http, isOnline, appVersion } from '../../web2/src/platform.js';

const $ = q => document.querySelector(q);
const esc = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const safe = t => { try { return t ? JSON.parse(t) : null; } catch (e) { return null; } };
// only a Google Apps Script web app (or a local test server) can be the class server
const okUrl = u => /^https:\/\/script\.google\.com\/(macros|a\/macros\/[\w.-]+)\/s\/[\w-]+\/exec$/.test(String(u || '')) || /^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?\/exec$/.test(String(u || ''));
const int = v => (Number.isFinite(Number(v)) ? Number(v) : 0);
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const WD = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
function fmtDay(iso) {
  if (!iso) return '';
  const [y, m, d] = String(iso).slice(0, 10).split('-').map(Number), t = new Date(Date.UTC(y, m - 1, d));
  return `${WD[t.getUTCDay()]} ${String(d).padStart(2, '0')} ${MONTHS[m - 1]}`;
}
function fmtWhen(ms) {
  if (!ms) return '';
  const d = new Date(ms), now = new Date();
  const hm = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  if (d.toDateString() === now.toDateString()) return `today ${hm}`;
  return `${d.getDate()} ${MONTHS[d.getMonth()]} ${hm}`;
}
const num = v => (typeof v === 'number' && isFinite(v) ? String(Math.round(v * 100) / 100) : '—');
const pct = v => (typeof v === 'number' && isFinite(v) ? `${Math.round(v * 1000) / 10}%` : '—');

// ------------------------------------------------------------------ connection, session, cached data
function builtin() {
  try {
    const t = window.Android && window.Android.config ? window.Android.config() : null;
    const j = t ? JSON.parse(t) : null;
    return j && okUrl(j.u) ? { u: j.u, t: j.t || '', builtin: true } : null;
  } catch (e) { return null; }
}
export function decodeCode(code) {
  const m = /(?:GE1|WDD1)-([A-Za-z0-9_-]+)/.exec(String(code || '').replace(/\s+/g, ''));
  if (!m) return null;
  try {
    let b = m[1].replace(/-/g, '+').replace(/_/g, '/');
    while (b.length % 4) b += '=';
    const j = JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(b), ch => ch.charCodeAt(0))));
    return j && okUrl(j.u) ? { u: j.u, t: j.t || '' } : null;
  } catch (e) { return null; }
}
let conn = builtin() || safe(store.load('conn'));
let session = safe(store.load('session'));
let data = safe(store.load('data'));
let stack = [{ v: 'home' }], tab = 'att', refreshing = false, signingIn = false, changing = false, gen = 0, lastError = '', loginError = '', loginInfo = '';
if (session && !session.token && !session.pin) session = null;

async function call(body) {
  const r = await http(conn.u, JSON.stringify(body));
  if (!r.status) return { net: true, error: 'No internet connection. Check your data or Wi-Fi and try again.' };
  let j;
  try { j = JSON.parse(r.text); } catch (e) { return { error: `The class server did not answer correctly (HTTP ${r.status}). Try again later.` }; }
  if (j && j.ok === false && /secret key|Unknown action/i.test(j.error || '')) j.error = 'Your teacher\'s class server needs an update. Please tell your teacher.';
  return j;
}

function toast(msg, ms = 2600) {
  let t = $('#toast');
  if (!t) { t = document.createElement('div'); t.id = 'toast'; t.style.cssText = 'position:fixed;left:50%;bottom:24px;transform:translateX(-50%);background:#18212f;color:#fff;padding:10px 16px;border-radius:20px;font-size:13px;z-index:50;max-width:88%;text-align:center;transition:opacity .2s;opacity:0;pointer-events:none'; document.body.appendChild(t); }
  t.textContent = msg; t.style.opacity = '1';
  clearTimeout(toast.h); toast.h = setTimeout(() => (t.style.opacity = '0'), ms);
}

async function refresh(manual) {
  if (!conn || !session || refreshing || signingIn) return;
  if (!isOnline()) { lastError = 'offline'; if (manual) toast('You are offline — showing the last saved results'); render(); return; }
  const mine = gen;
  refreshing = true; spin(true);
  const j = await call(session.token ? { action: 'student', token: session.token } : { action: 'student', reg: session.reg, pin: session.pin });
  refreshing = false; spin(false);
  if (mine !== gen || !session) return;                 // signed out (or someone else signed in) meanwhile: drop this answer
  if (j.ok) {
    keep(j);
    if (manual) toast('Up to date');
  } else if (j.net) { lastError = 'offline'; if (manual) toast('You are offline — showing the last saved results'); }
  else if (j.expired || /not correct/i.test(j.error || '')) { signOut('Please sign in again with your PIN or password (your teacher may have given you a new PIN).'); return; }
  else { lastError = j.error || 'Could not refresh.'; if (manual) toast(lastError, 4000); }
  if (mainView()) render();
}
// save a good answer: the sign-in token (never the PIN) and the results
function keep(j) {
  session = { reg: j.reg || (session && session.reg) || '', token: j.token || (session && session.token) || '' };
  store.save('session', JSON.stringify(session));
  const d = Object.assign({}, j, { fetched: Date.now() }); delete d.token;
  data = d; store.save('data', JSON.stringify(data)); lastError = '';
}
function signOut(info = '') {
  gen++;
  session = null; data = null; store.save('session', 'null'); store.save('data', 'null');
  stack = [{ v: 'home' }]; loginInfo = info; loginError = ''; refreshing = false; spin(false); render();
}
// screens that may be redrawn when results arrive (never the password form while it is being typed)
const mainView = () => !!(conn && session) && stack[stack.length - 1].v !== 'password';
function spin(on) { const b = $('#refresh'); if (b) b.classList.toggle('spin', on); }

// ------------------------------------------------------------------ screens
const LOGO = '<div class="logo"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M1.5 12S5.5 5 12 5s10.5 7 10.5 7-4 7-10.5 7S1.5 12 1.5 12z"/><circle cx="12" cy="12" r="3.2" fill="#FFCD40" stroke="#FFCD40"/></svg></div><div class="brand">GradesEye <span>Student</span></div>';
const COPY = '<p class="copy">© 2026 softonicBank Co. All rights reserved.</p>';
function vSetup() {
  return `${LOGO}<div class="card"><div class="h3 center">Link this app to your class</div>
    <p class="muted small center">This copy of GradesEye Student is not linked to a teacher yet. Install the student app your teacher shared (it is already linked), or paste the class code your teacher gave you.</p>
    ${loginError ? `<div class="err">${esc(loginError)}</div>` : ''}
    <label class="fl">Class code<input id="code" placeholder="GE1-…" autocomplete="off" autocapitalize="off" spellcheck="false"></label>
    <button class="btn primary wide" data-act="connect">Link</button></div>${COPY}`;
}
function vLogin() {
  return `${LOGO}<div class="center"><div class="h1">Sign in</div><div class="muted small">${esc(conn.t || 'Your teacher')}</div></div><div style="height:14px"></div>
    <div class="card">${loginInfo ? `<div class="info">${esc(loginInfo)}</div>` : ''}${loginError ? `<div class="err">${esc(loginError)}</div>` : ''}
    <label class="fl">Registration number<input id="reg" placeholder="e.g. 24-CS-001" autocomplete="username" autocapitalize="characters" spellcheck="false" value="${esc((session && session.reg) || store.load('lastReg') || '')}"></label>
    <label class="fl">PIN or password<input id="pin" type="password" placeholder="PIN or password" autocomplete="current-password" autocapitalize="off" spellcheck="false" maxlength="64"></label>
    <label class="cbx"><input type="checkbox" data-show="pin"> Show</label>
    <button class="btn primary wide" data-act="login" ${signingIn ? 'disabled' : ''}>${signingIn ? 'Signing in…' : 'Sign in'}</button>
    <p class="muted small center" style="margin:12px 0 0">First time? Use the PIN on the slip from your teacher; you can then set your own password. Forgot it? Ask your teacher for a new PIN.</p></div>
    ${conn.builtin ? '' : '<div class="foot"><a href="#" data-act="unlink">Use a different class code</a></div>'}${COPY}`;
}
function attPill(a) {
  if (a.none) return `<span class="pill">${esc(a.k)}: no lab group</span>`;
  if (!a.held) return `<span class="pill">${esc(a.k)}: no classes yet</span>`;
  return `<span class="pill ${a.st === 'Short' ? 'bad' : 'ok'}">${esc(a.k)} ${pct(a.pct)}${a.st === 'Short' ? ' · short' : ''}</span>`;
}
const posted = c => c.me.marks.reduce((n, g) => n + g.items.length, 0);
const newest = d => Math.max(0, ...(d.courses || []).map(c => int(c.updated)));
function vHome() {
  const d = data || { courses: [] }, initials = String(d.name || '?').split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0]).join('').toUpperCase();
  const off = lastError === 'offline' || !isOnline();
  let h = `<div class="card"><div class="who"><div class="avatar">${esc(initials)}</div><div><div class="h3" style="margin:0">${esc(d.name || 'Student')}</div><div class="muted small">${esc(d.reg || (session && session.reg) || '')}</div></div></div>
    <div class="state"><span class="dot ${off ? 'off' : ''}"></span>${off ? `Offline · showing results saved ${esc(fmtWhen(d.fetched))}` : `Checked ${esc(fmtWhen(d.fetched))}`}${newest(d) ? ` · teacher's last update ${esc(fmtWhen(newest(d)))}` : ''}</div>
    ${d.own ? '' : '<div class="tipline">🔒 You are signed in with the PIN from your slip. <a href="#" data-act="pwview">Set your own password</a></div>'}</div>`;
  if (lastError && lastError !== 'offline') h += `<div class="warnbox">${esc(lastError)}</div>`;
  if (!d.courses.length) h += `<div class="card"><div class="h3">No courses yet</div><p class="muted small" style="margin:0">Your teacher has not shared any course with you yet. Tap ↻ later to check again.</p></div>`;
  else h += '<div class="h2">My courses</div>';
  d.courses.forEach(c => {
    const n = posted(c), res = c.released && c.me.res;
    h += `<button class="ccard" data-course="${esc(c.id)}"><div class="t">${esc(c.name || [c.code, c.title].filter(Boolean).join(' '))}</div>
      <div class="s">${esc(c.sem)} · Section ${esc(c.me.code)}${c.me.inst ? ' · ' + esc(c.me.inst) : ''}</div>
      <div class="pills">${c.me.att.map(attPill).join('')}<span class="pill">${n} mark${n === 1 ? '' : 's'} posted</span>${res && res.grade ? `<span class="pill grade">Grade ${esc(res.grade)}</span>` : ''}</div></button>`;
  });
  h += `<div class="foot"><div class="row2"><button class="btn" data-act="pwview">${d.own ? 'Change password' : 'Set your own password'}</button><button class="btn" data-act="logout">Sign out</button></div>
    <p class="muted small">GradesEye Student ${esc(appVersion())} · ${esc(conn.t || '')}</p>${COPY}</div>`;
  return h;
}

function attBlock(c, a) {
  if (a.none) return `<div class="card"><div class="h3">${esc(a.k)} attendance</div><p class="muted small" style="margin:0">You are not in a lab group of this course yet. Tell your teacher if this is wrong.</p></div>`;
  const thr = Number(c.thr) || 0, p = typeof a.pct === 'number' ? a.pct : null, held = int(a.held), P = int(a.P), L = int(a.L), A = int(a.A), weeks = int(c.weeks);
  const color = !held ? '#c3ccd3' : a.st === 'Short' ? '#c0262d' : '#1e7b34';
  const unmarked = Math.max(0, held - P - L - A);
  let hint = '';
  if (a.st === 'Short' && thr < 1) {
    const eff = P + (c.leave ? L : 0), k = Math.max(1, Math.ceil((thr * held - eff) / (1 - thr) - 1e-9)), left = Math.max(0, weeks - held);
    hint = k <= left ? `Attend the next ${k} class${k === 1 ? '' : 'es'} in a row to get back to ${pct(thr)}.` : 'Talk to your teacher about your attendance.';
  }
  return `<div class="card"><div class="attsum"><div class="ring" style="--p:${p === null ? 0 : Math.min(100, p * 100)};--c:${color}"><span>${p === null ? '—' : pct(p)}</span></div>
    <div><div class="h3">${esc(a.k)} attendance${a.grp ? ` <span class="muted small">· lab group ${esc(a.grp)}</span>` : ''}</div>
      ${held ? `<div class="status ${a.st === 'Short' ? 'bad' : 'ok'}">${a.st === 'Short' ? 'Short attendance' : 'Eligible'}</div>` : ''}
      <div class="muted small">${held} of ${weeks || '?'} classes held · at least ${pct(thr)} needed${c.leave ? ' (leave counts)' : ''}</div>
      ${a.inst ? `<div class="muted small">${esc(a.inst)}</div>` : ''}</div></div>
    ${held ? `<div class="counts"><div><b>${P}</b>Present</div><div><b>${L}</b>Leave</div><div><b>${A + unmarked}</b>Absent</div></div>` : '<p class="muted small">No classes marked yet.</p>'}
    ${hint ? `<div class="warnbox" style="margin:10px 0 0">${esc(hint)}</div>` : ''}
    ${(a.days || []).length ? `<div class="days">${a.days.slice().reverse().map(([d, m]) => `<div class="day"><span>${esc(fmtDay(d))}</span><span class="mk ${m === 'P' || m === 'A' || m === 'L' ? m : 'N'}">${m === 'P' ? 'Present' : m === 'A' ? 'Absent' : m === 'L' ? 'Leave' : 'Not marked'}</span></div>`).join('')}</div>` : ''}</div>`;
}
function itemHtml(it) {
  const has = typeof it.g === 'number', w = has && it.m ? Math.max(0, Math.min(100, (it.g / it.m) * 100)) : 0;
  const av = typeof it.avg === 'number' && it.m ? Math.max(0, Math.min(100, (it.avg / it.m) * 100)) : null;
  const parts = it.parts && it.parts.length > 1 ? `<details><summary>Details</summary><div class="parts">${it.parts.map(([l, g, m]) => `<span>${esc(l)}</span><span>${g === null ? '—' : num(g)} / ${num(m)}</span>`).join('')}</div></details>` : '';
  return `<div class="item"><div class="irow"><span class="l">${esc(it.l)}${it.d ? `<br><span class="muted small">${esc(fmtDay(it.d))}</span>` : ''}</span>
    <span class="g">${has ? num(it.g) : '—'} <small>/ ${num(it.m)}</small></span></div>
    <div class="bar"><i style="width:${w}%"></i>${av !== null ? `<b style="left:calc(${av}% - 1px)"></b>` : ''}</div>
    <div class="meta"><span>${has ? pct(it.m ? it.g / it.m : null) : 'No marks entered (counts as 0)'}</span><span>${av !== null ? `Class average ${num(it.avg)}` : ''}</span></div>${parts}</div>`;
}
function marksTab(c) {
  const gs = c.me.marks;
  if (!gs.length) return '<div class="card"><p class="muted small" style="margin:0">No assessments in this course.</p></div>';
  return gs.map(g => `<div class="card"><div class="irow"><div class="h3">${esc(g.k)}</div>${int(g.n) > 1 ? `<span class="muted small">${g.items.length} of ${int(g.n)} held</span>` : ''}</div>
    ${g.hidden ? '<div class="none">Shown when your teacher releases the results.</div>' : g.items.length ? g.items.map(itemHtml).join('') : '<div class="none">Not held yet.</div>'}
    ${g.tot ? `<div class="sc"><span>Total so far</span><b>${num(g.tot.g)} / ${num(g.tot.m)}</b></div>` : ''}
    ${g.sc ? `<div class="sc"><span>Counts in your lab total</span><b>${num(g.sc.g)} / ${num(g.sc.m)}</b></div>` : ''}</div>`).join('');
}
function resultTab(c) {
  const r = c.released && c.me.res;
  let h = '';
  if (r) {
    h += `<div class="card"><div class="big"><div><b>${pct(r.ct)}</b><small>Course total</small></div><div><b>${esc(r.grade || '—')}</b><small>Grade</small></div></div>
      ${r.th !== undefined ? `<div class="kv" style="margin-top:10px"><span>Theory</span><b>${pct(r.th)}</b></div>` : ''}
      ${r.lab ? `<div class="kv"><span>Lab total${typeof r.lab.held === 'number' && r.lab.held < r.lab.m ? `<br><span class="muted small">out of ${num(r.lab.held)} marks held so far (${num(r.lab.m)} in all)</span>` : ''}</span><b>${typeof r.lab.held === 'number' ? `${num(r.lab.g)} / ${num(r.lab.held)}` : `${num(r.lab.g)} / ${num(r.lab.m)}`} (${pct(r.lab.pct)})</b></div>` : ''}
      ${r.rem ? `<div class="warnbox" style="margin:10px 0 0">${esc(r.rem)}</div>` : ''}</div>`;
  } else h += `<div class="info">Your teacher has not released the course total and grade yet. Your marks so far are on the Marks tab.</div>`;
  if (c.scheme && c.scheme.length) h += `<div class="card"><div class="h3">How marks are counted</div>${c.scheme.map(s => `<div class="small" style="padding:3px 0">${esc(s)}</div>`).join('')}
    <div class="small muted" style="padding-top:6px">Totals use only the assessments held so far. Minimum attendance: ${pct(c.thr)}.</div></div>`;
  return h;
}
const courseOf = id => (data && data.courses || []).find(c => c.id === id);
function vCourse(v) {
  const c = courseOf(v.id);
  if (!c) { stack = [{ v: 'home' }]; return vHome(); }
  const tabs = [['att', 'Attendance'], ['marks', 'Marks'], ['result', 'Result']];
  return `<div class="card"><div class="h1">${esc(c.name || c.title)}</div><div class="muted small">${esc(c.sem)}${c.dept ? ' · ' + esc(c.dept) : ''}</div>
    <div class="muted small">Section ${esc(c.me.code)} (${esc(c.me.sec)})${c.me.inst ? ' · ' + esc(c.me.inst) : ''}${c.updated ? ` · teacher updated ${esc(fmtWhen(c.updated))}` : ''}</div></div>
    <div class="tabs">${tabs.map(([k, l]) => `<button class="${tab === k ? 'on' : ''}" data-tab="${k}">${l}</button>`).join('')}</div>
    ${tab === 'att' ? c.me.att.map(a => attBlock(c, a)).join('') || '<div class="card muted small">No attendance in this course.</div>' : tab === 'marks' ? marksTab(c) : resultTab(c)}`;
}

const COMMON_PW = ['password', 'passw', 'pass', 'qwerty', 'qwertyuiop', 'asdf', 'zxcvbn', 'abc', 'abcd', 'abcde', 'abcdef', 'iloveyou', 'love', 'pakistan', 'welcome', 'admin', 'letmein', 'hitec', 'student', 'test', 'user', 'computer', 'secret', 'login'];
function pwRule(pw, reg) {
  if (pw.length < 8) return 'Use at least 8 characters.';
  if (pw.length > 64) return 'Use at most 64 characters.';
  if (!/[A-Za-z]/.test(pw) || !/[0-9]/.test(pw)) return 'Use both letters and numbers.';
  const r = String(reg || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (r && pw.toUpperCase().replace(/[^A-Z0-9]/g, '').includes(r)) return 'Do not use your Reg. No in your password.';
  const letters = pw.toLowerCase().replace(/[^a-z]/g, '');
  if (letters.length < 3 || COMMON_PW.includes(letters)) return 'That password is too easy to guess. Mix a few words with numbers.';
  return '';
}
function vPassword() {
  const own = !!(data && data.own);
  return `<div class="card"><div class="h3">${own ? 'Change your password' : 'Set your own password'}</div>
    <p class="muted small">From now on you sign in with your Reg. No and this password${own ? '' : ' instead of the PIN on your slip'}. If you forget it, ask your teacher for a new PIN.</p>
    <div class="err" id="pwerr" hidden></div>
    <label class="fl">${own ? 'Current password' : 'PIN from your slip'}<input id="pw0" type="password" autocomplete="current-password" autocapitalize="off" spellcheck="false" maxlength="64"></label>
    <label class="fl">New password<input id="pw1" type="password" autocomplete="new-password" autocapitalize="off" spellcheck="false" maxlength="64"></label>
    <label class="fl">New password again<input id="pw2" type="password" autocomplete="new-password" autocapitalize="off" spellcheck="false" maxlength="64"></label>
    <label class="cbx"><input type="checkbox" data-show="pw0,pw1,pw2"> Show</label>
    <p class="muted small">At least 8 characters with letters and numbers, and not your Reg. No. Capital and small letters count.</p>
    <button class="btn primary wide" id="pwsave" data-act="setpw">Save password</button></div>${COPY}`;
}
function pwError(msg) { const e = $('#pwerr'); if (e) { e.textContent = msg; e.hidden = !msg; } }

function render() {
  const main = $('#main'), v = stack[stack.length - 1];
  let title = 'GradesEye Student', sub = conn ? conn.t || '' : '';
  let html;
  if (!conn) html = vSetup();
  else if (!session) html = vLogin();
  else if (v.v === 'password') { title = (data && data.own) ? 'Change password' : 'Your own password'; html = vPassword(); }
  else if (v.v === 'course') { const c = courseOf(v.id); title = c ? c.code || c.title : title; sub = c ? c.title : sub; html = vCourse(v); }
  else { title = 'My results'; html = vHome(); }
  $('#title').innerHTML = `<b>${esc(title)}</b><small>${esc(sub)}</small>`;
  $('#backbtn').style.visibility = stack.length > 1 && session ? 'visible' : 'hidden';
  $('#refresh').style.visibility = conn && session && v.v !== 'password' ? 'visible' : 'hidden';
  main.innerHTML = html;
}
function go(v) { stack.push(v); render(); $('#main').scrollTop = 0; }
function back() { if (stack.length > 1) { stack.pop(); render(); return true; } return false; }

async function act(a, el) {
  if (a === 'connect') {
    const cc = decodeCode($('#code').value);
    if (!cc) { loginError = 'That class code is not right. Copy the whole code your teacher sent (it starts with GE1-).'; return render(); }
    conn = cc;
    const j = await call({ action: 'hello' });
    if (!j.ok) { conn = null; loginError = j.net ? j.error : j.error || 'This class code does not work. Ask your teacher.'; return render(); }
    conn.t = conn.t || j.title || ''; store.save('conn', JSON.stringify(conn)); loginError = ''; render(); return;
  }
  if (a === 'unlink') { conn = null; store.save('conn', 'null'); signOut(); return; }
  if (a === 'login') {
    if (signingIn || session) return;
    const reg = $('#reg').value.trim(), pin = $('#pin').value.trim();
    if (!reg || !pin) { loginError = 'Enter your registration number and your PIN or password.'; return render(); }
    store.save('lastReg', reg);
    gen++; signingIn = true; loginError = ''; loginInfo = ''; render();
    const mine = gen, j = await call({ action: 'student', reg, pin });
    signingIn = false;
    if (mine !== gen) return;
    if (!j.ok) { loginError = j.error || 'Could not sign in.'; render(); const p = $('#pin'); if (p) p.focus(); return; }
    keep(j); stack = [{ v: 'home' }]; render(); return;
  }
  if (a === 'logout') { signOut(); return; }
  if (a === 'pwview') { go({ v: 'password' }); const f = $('#pw0'); if (f) f.focus(); return; }
  if (a === 'setpw') {
    if (changing || !session) return;
    const cur = $('#pw0').value.trim(), n1 = $('#pw1').value.trim(), n2 = $('#pw2').value.trim();
    if (!cur || !n1 || !n2) return pwError('Fill in all three boxes.');
    if (n1 !== n2) return pwError('The two new passwords are not the same.');
    const rule = pwRule(n1, session.reg || (data && data.reg)); if (rule) return pwError(rule);
    if (!isOnline()) return pwError('You need the internet to change your password.');
    pwError(''); changing = true;
    const btn = $('#pwsave'); if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }
    const mine = gen, j = await call({ action: 'password', token: session.token, current: cur, next: n1 });
    changing = false;
    if (mine !== gen || !session) return;
    if (btn) { btn.disabled = false; btn.textContent = 'Save password'; }
    if (j.ok) {
      session = Object.assign({}, session, { token: j.token }); store.save('session', JSON.stringify(session));
      if (data) { data.own = true; store.save('data', JSON.stringify(data)); }
      stack = [{ v: 'home' }]; render(); toast('Password saved — use it the next time you sign in.', 3500); return;
    }
    if (j.expired) { signOut('Please sign in again with your PIN or password.'); return; }
    pwError(j.error || 'Could not save the password. Try again.');
    return;
  }
}

function start() {
  document.addEventListener('click', e => {
    const t = e.target;
    const cc = t.closest('[data-course]'); if (cc) { tab = 'att'; go({ v: 'course', id: cc.dataset.course }); return; }
    const tb = t.closest('[data-tab]'); if (tb) { tab = tb.dataset.tab; render(); return; }
    const el = t.closest('[data-act]'); if (el) { e.preventDefault(); act(el.dataset.act, el); }
  });
  document.addEventListener('keydown', e => {
    if (e.key !== 'Enter') return;
    if (e.target.id === 'reg') { const p = $('#pin'); if (p) p.focus(); }
    else if (e.target.id === 'pin') act('login');
    else if (e.target.id === 'code') act('connect');
    else if (e.target.id === 'pw2') act('setpw');
  });
  document.addEventListener('change', e => {
    const sh = e.target.dataset && e.target.dataset.show;
    if (sh) sh.split(',').forEach(id => { const i = $('#' + id); if (i) i.type = e.target.checked ? 'text' : 'password'; });
  });
  $('#backbtn').onclick = () => back();
  $('#refresh').onclick = () => refresh(true);
  window.__back = () => (back() ? 'ok' : 'exit');
  window.__resume = () => { if (session && Date.now() - ((data && data.fetched) || 0) > 60000) refresh(false); };
  window.__pause = () => {};
  window.__nativeOnline = on => { if (!mainView()) return; if (on && lastError === 'offline') refresh(false); else render(); };   // never redraw a form being typed in
  window.addEventListener('online', () => window.__nativeOnline(true));
  render();
  if (session) refresh(false);
}
function boot() {
  try { start(); } catch (e) { $('#main').innerHTML = `<div class="card"><b>Something went wrong while starting.</b><pre style="white-space:pre-wrap">${esc(String((e && e.stack) || e))}</pre></div>`; }
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
