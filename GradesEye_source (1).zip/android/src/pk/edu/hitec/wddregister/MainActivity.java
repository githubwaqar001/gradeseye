package pk.edu.hitec.wddregister;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * GradesEye (faculty app) — © 2026 softonicBank Co. All rights reserved.
 * Thin native shell for the GradesEye web app (assets/www/index.html).
 * The bridge "Android" gives the page: durable storage with backups, HTTPS calls to the
 * user's Google Apps Script (redirects followed natively, no CORS), connectivity events,
 * and saving / opening files through the Android document picker.
 */
public class MainActivity extends Activity {
    private static final int REQ_SAVE = 41;
    private static final int REQ_OPEN = 42;
    private WebView web;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<String, String> responses = new HashMap<String, String>();
    private ValueCallback<Uri[]> fileCallback;
    private String saveId;
    private byte[] saveBytes;
    private ConnectivityManager.NetworkCallback netCallback;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();
        w.setStatusBarColor(0xFF1F3864);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("file:")) return false;
                openExternal(url);
                return true;
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                // the WebView renderer crashed or was killed (low memory): rebuild the screen instead of closing the app
                if (web == view) {
                    web = null;
                    ((android.view.ViewGroup) view.getParent()).removeView(view);
                    view.destroy();
                    recreate();
                }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(i, REQ_OPEN);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/www/index.html");
        watchNetwork();
    }

    private void js(final String code) {
        main.post(new Runnable() {
            @Override
            public void run() {
                if (web != null) web.evaluateJavascript(code, null);
            }
        });
    }

    private void openExternal(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(this, "No app can open this link", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isOnline() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities c = cm.getNetworkCapabilities(n);
            return c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (Exception e) {
            return true;
        }
    }

    private void watchNetwork() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            netCallback = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network network) {
                    js("window.__nativeOnline && window.__nativeOnline(true)");
                }

                @Override
                public void onLost(Network network) {
                    js("window.__nativeOnline && window.__nativeOnline(" + isOnline() + ")");
                }
            };
            cm.registerDefaultNetworkCallback(netCallback);
        } catch (Exception e) {
            netCallback = null;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        js("window.__resume && window.__resume()");
    }

    @Override
    protected void onPause() {
        js("window.__pause && window.__pause()");
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            try {
                web.removeJavascriptInterface("Android");
                web.destroy();
            } catch (Exception ignored) {
            }
            web = null;
        }
        try {
            if (netCallback != null) {
                ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).unregisterNetworkCallback(netCallback);
            }
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (web == null) {
            super.onBackPressed();
            return;
        }
        web.evaluateJavascript("window.__back ? window.__back() : 'exit'", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                if (value == null || value.contains("exit")) moveTaskToBack(true);   // keep one live page; never a second copy
            }
        });
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        if (request == REQ_OPEN) {
            Uri[] picked = null;
            if (result == RESULT_OK && data != null && data.getData() != null) picked = new Uri[]{data.getData()};
            if (fileCallback != null) fileCallback.onReceiveValue(picked);
            fileCallback = null;
            return;
        }
        if (request == REQ_SAVE) {
            boolean ok = false;
            if (result == RESULT_OK && data != null && data.getData() != null && saveBytes != null) {
                OutputStream os = null;
                try {
                    try {
                        os = getContentResolver().openOutputStream(data.getData(), "wt");
                    } catch (Exception notSupported) {
                        os = getContentResolver().openOutputStream(data.getData(), "w");
                    }
                    os.write(saveBytes);
                    os.flush();
                    ok = true;
                } catch (Exception e) {
                    ok = false;
                } finally {
                    try {
                        if (os != null) os.close();
                    } catch (IOException ignored) {
                    }
                }
            }
            js("window.__nativeSaved && window.__nativeSaved(" + JSONObject.quote(saveId == null ? "" : saveId) + "," + ok + ")");
            saveBytes = null;
            saveId = null;
            return;
        }
        super.onActivityResult(request, result, data);
    }

    // ------------------------------------------------------------------ storage helpers
    private File store(String key) {
        File dir = new File(getFilesDir(), "store");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, key.replaceAll("[^A-Za-z0-9_.-]", "_") + ".json");
    }

    private static String readFile(File f) throws IOException {
        InputStream in = new FileInputStream(f);
        try {
            return readAll(in);
        } finally {
            in.close();
        }
    }

    private static String readAll(InputStream in) throws IOException {
        if (in == null) return "";
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        return bo.toString("UTF-8");
    }

    private static void writeFile(File f, String text) throws IOException {
        File tmp = new File(f.getPath() + ".tmp");
        FileOutputStream os = new FileOutputStream(tmp);
        try {
            os.write(text.getBytes("UTF-8"));
            os.getFD().sync();
        } finally {
            os.close();
        }
        if (!tmp.renameTo(f)) {
            f.delete();
            if (!tmp.renameTo(f)) throw new IOException("rename failed");
        }
    }

    private void backup(String text) {
        try {
            File dir = new File(getFilesDir(), "backups");
            if (!dir.exists()) dir.mkdirs();
            File[] old = dir.listFiles();
            long newest = 0;
            if (old != null) for (File f : old) newest = Math.max(newest, f.lastModified());
            if (System.currentTimeMillis() - newest < 30 * 60 * 1000L) return;   // at most one every 30 min
            String stamp = new SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(new Date());
            writeFile(new File(dir, "state-" + stamp + ".json"), text);
            old = dir.listFiles();
            if (old != null && old.length > 20) {
                Arrays.sort(old);
                for (int i = 0; i < old.length - 20; i++) old[i].delete();
            }
        } catch (Exception ignored) {
        }
    }

    // ------------------------------------------------------------------ HTTP (Apps Script web app)
    private String[] request(String url, String body) throws IOException {
        String target = url;
        String method = body == null ? "GET" : "POST";
        byte[] payload = body == null ? null : body.getBytes("UTF-8");
        for (int hop = 0; hop < 8; hop++) {
            HttpURLConnection c = (HttpURLConnection) new URL(target).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(25000);
            c.setReadTimeout(180000);
            c.setRequestMethod(method);
            c.setRequestProperty("Accept", "application/json");
            if ("POST".equals(method)) {
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "text/plain;charset=utf-8");
                c.setFixedLengthStreamingMode(payload.length);
                OutputStream os = c.getOutputStream();
                os.write(payload);
                os.close();
            }
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) throw new IOException("Redirect without a location");
                target = new URL(new URL(target), loc).toString();
                if (code != 307 && code != 308) method = "GET";
                continue;
            }
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String text = readAll(in);
            c.disconnect();
            return new String[]{String.valueOf(code), text};
        }
        throw new IOException("Too many redirects");
    }

    // ------------------------------------------------------------------ bridge
    public class Bridge {
        @JavascriptInterface
        public String load(String key) {
            try {
                File f = store(key);
                return f.exists() ? readFile(f) : null;
            } catch (Exception e) {
                return null;
            }
        }

        @JavascriptInterface
        public boolean save(String key, String text) {
            try {
                writeFile(store(key), text);
                if ("state".equals(key) || "state2".equals(key)) backup(text);
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public String backups() {
            File dir = new File(getFilesDir(), "backups");
            File[] list = dir.listFiles();
            StringBuilder sb = new StringBuilder("[");
            if (list != null) {
                Arrays.sort(list);
                for (int i = list.length - 1; i >= 0; i--) {
                    if (sb.length() > 1) sb.append(',');
                    sb.append(JSONObject.quote(list[i].getName()));
                }
            }
            return sb.append(']').toString();
        }

        @JavascriptInterface
        public String readBackup(String name) {
            try {
                return readFile(new File(new File(getFilesDir(), "backups"), name.replaceAll("[^A-Za-z0-9_.-]", "_")));
            } catch (Exception e) {
                return null;
            }
        }

        @JavascriptInterface
        public boolean online() {
            return isOnline();
        }

        @JavascriptInterface
        public void http(final String id, final String url, final String body) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    String status;
                    String text;
                    try {
                        String[] r = request(url, body);
                        status = r[0];
                        text = r[1];
                    } catch (Exception e) {
                        status = "0";
                        text = String.valueOf(e.getMessage());
                    }
                    synchronized (responses) {
                        responses.put(id, text);
                    }
                    js("window.__nativeHttp && window.__nativeHttp(" + JSONObject.quote(id) + "," + status + ")");
                }
            }).start();
        }

        @JavascriptInterface
        public String take(String id) {
            synchronized (responses) {
                return responses.remove(id);
            }
        }

        @JavascriptInterface
        public void saveFile(final String id, final String name, final String mime, final String base64) {
            main.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        saveBytes = Base64.decode(base64, Base64.DEFAULT);
                        saveId = id;
                        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType(mime);
                        i.putExtra(Intent.EXTRA_TITLE, name);
                        startActivityForResult(i, REQ_SAVE);
                    } catch (Exception e) {
                        js("window.__nativeSaved && window.__nativeSaved(" + JSONObject.quote(id) + ",false)");
                    }
                }
            });
        }

        /** a copy of the bundled GradesEye Student APK with this class connection built in; mode "save" or "share" */
        @JavascriptInterface
        public void studentApk(final String id, final String mode, final String config, final String name) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    final byte[] apk;
                    try {
                        InputStream in = getAssets().open("student/GradesEye_Student.apk");
                        ByteArrayOutputStream bo = new ByteArrayOutputStream();
                        byte[] buf = new byte[65536];
                        int n;
                        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                        in.close();
                        apk = pk.edu.hitec.apkconfig.ApkConfig.inject(bo.toByteArray(), config.getBytes("UTF-8"));
                    } catch (Exception e) {
                        js("window.__nativeSaved && window.__nativeSaved(" + JSONObject.quote(id) + ",false)");
                        return;
                    }
                    final String fname = name.replaceAll("[^A-Za-z0-9_.-]", "_");
                    main.post(new Runnable() {
                        @Override
                        public void run() {
                            if ("share".equals(mode)) {
                                boolean ok = false;
                                try {
                                    File dir = new File(getCacheDir(), "share");
                                    if (!dir.exists()) dir.mkdirs();
                                    File old[] = dir.listFiles();
                                    if (old != null) for (File f : old) f.delete();
                                    File f = new File(dir, fname);
                                    FileOutputStream os = new FileOutputStream(f);
                                    os.write(apk);
                                    os.close();
                                    Uri u = Uri.parse("content://" + ShareProvider.AUTHORITY + "/" + Uri.encode(fname));
                                    Intent send = new Intent(Intent.ACTION_SEND);
                                    send.setType(ShareProvider.APK_MIME);
                                    send.putExtra(Intent.EXTRA_STREAM, u);
                                    send.putExtra(Intent.EXTRA_SUBJECT, "GradesEye Student app");
                                    send.putExtra(Intent.EXTRA_TEXT, "Install GradesEye Student (allow \"install unknown apps\" if asked) and sign in with your Reg. No and the PIN from your teacher. You can then set your own password.");
                                    send.setClipData(android.content.ClipData.newRawUri("GradesEye Student", u));
                                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                    Intent chooser = Intent.createChooser(send, "Send the student app");
                                    chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                    startActivity(chooser);
                                    ok = true;
                                } catch (Exception e) {
                                    ok = false;
                                }
                                js("window.__nativeSaved && window.__nativeSaved(" + JSONObject.quote(id) + "," + ok + ")");
                            } else {
                                try {
                                    saveBytes = apk;
                                    saveId = id;
                                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                                    i.addCategory(Intent.CATEGORY_OPENABLE);
                                    i.setType(ShareProvider.APK_MIME);
                                    i.putExtra(Intent.EXTRA_TITLE, fname);
                                    startActivityForResult(i, REQ_SAVE);
                                } catch (Exception e) {
                                    saveBytes = null;
                                    saveId = null;
                                    js("window.__nativeSaved && window.__nativeSaved(" + JSONObject.quote(id) + ",false)");
                                }
                            }
                        }
                    });
                }
            }).start();
        }

        @JavascriptInterface
        public void openUrl(final String url) {
            main.post(new Runnable() {
                @Override
                public void run() {
                    openExternal(url);
                }
            });
        }

        @JavascriptInterface
        public void toast(final String text) {
            main.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this, text, Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public String version() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            } catch (Exception e) {
                return "?";
            }
        }
    }
}
